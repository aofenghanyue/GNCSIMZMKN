#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/vehicle/common/interfaces/i_aerodynamic_assets_3dof.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <string>
#include <vector>

namespace cavh::components {

class PaperAeroAssets3Dof final
    : public gnc::core::SimulationNode,
      public gnc::vehicle::common::IAerodynamicAssets3Dof,
      public gnc::interfaces::IObservable {
public:
    PaperAeroAssets3Dof() : SimulationNode("CavhPaperAeroAssets3Dof") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        reader.validateNoUnknownKeys();
    }

    gnc::vehicle::output::AeroCoefficients sampleAeroCoefficients3Dof(
        const gnc::vehicle::common::AeroQuery3Dof& query) const override {
        last_query_ = query;
        last_angle_of_attack_deg_ =
            query.angle_of_attack_rad * kRadToDeg;
        last_lift_intercept_ = interpolate(cl0Curve(), query.mach_number);
        last_lift_slope_per_deg_ =
            interpolate(clAlphaCurve(), query.mach_number);
        last_zero_lift_drag_ = interpolate(cd0Curve(), query.mach_number);
        last_induced_drag_factor_ =
            interpolate(inducedDragCurve(), query.mach_number);

        gnc::vehicle::output::AeroCoefficients coefficients;
        coefficients.lift_coefficient =
            last_lift_intercept_ +
            last_lift_slope_per_deg_ * last_angle_of_attack_deg_;
        coefficients.drag_coefficient =
            last_zero_lift_drag_ +
            last_induced_drag_factor_ * coefficients.lift_coefficient *
                coefficients.lift_coefficient;
        last_coefficients_ = coefficients;
        return coefficients;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("angle_of_attack_rad",
                          [this]() { return last_query_.angle_of_attack_rad; });
        builder.addScalar("angle_of_attack_deg",
                          [this]() { return last_angle_of_attack_deg_; });
        builder.addScalar("mach_number",
                          [this]() { return last_query_.mach_number; });
        builder.addScalar("lift_intercept",
                          [this]() { return last_lift_intercept_; });
        builder.addScalar("lift_slope_per_deg",
                          [this]() { return last_lift_slope_per_deg_; });
        builder.addScalar("zero_lift_drag",
                          [this]() { return last_zero_lift_drag_; });
        builder.addScalar("induced_drag_factor",
                          [this]() { return last_induced_drag_factor_; });
        builder.addScalar("lift_coefficient",
                          [this]() {
                              return last_coefficients_.lift_coefficient;
                          });
        builder.addScalar("drag_coefficient",
                          [this]() {
                              return last_coefficients_.drag_coefficient;
                          });
        builder.addScalar("lift_to_drag",
                          [this]() {
                              if (last_coefficients_.drag_coefficient <= 0.0) {
                                  return 0.0;
                              }
                              return last_coefficients_.lift_coefficient /
                                     last_coefficients_.drag_coefficient;
                          });
        return builder.build();
    }

private:
    struct CurveNode {
        double mach = 0.0;
        double value = 0.0;
    };

    static constexpr double kRadToDeg = 57.2957795130823208768;

    static const std::vector<CurveNode>& cl0Curve() {
        static const std::vector<CurveNode> curve = {
            {0.0, -0.0580}, {0.5, -0.0570}, {0.8, -0.0550},
            {1.0, -0.0430}, {1.2, -0.0180}, {1.5, -0.0120},
            {2.0, -0.0110}, {3.0, -0.0104}, {5.0, -0.0100},
            {10.0, -0.0100}, {25.0, -0.0100},
        };
        return curve;
    }

    static const std::vector<CurveNode>& clAlphaCurve() {
        static const std::vector<CurveNode> curve = {
            {0.0, 0.0400},  {1.0, 0.0400},  {1.5, 0.0310},
            {2.0, 0.0250},  {3.0, 0.0200},  {5.0, 0.0160},
            {7.0, 0.0147},  {10.0, 0.0142}, {15.0, 0.0140},
            {20.0, 0.0139}, {25.0, 0.0138},
        };
        return curve;
    }

    static const std::vector<CurveNode>& cd0Curve() {
        static const std::vector<CurveNode> curve = {
            {0.0, 0.0075}, {1.0, 0.0075}, {1.15, 0.0140},
            {1.3, 0.0157}, {1.5, 0.0150}, {2.0, 0.0132},
            {3.0, 0.0127}, {4.0, 0.0105}, {5.0, 0.0088},
            {6.0, 0.0080}, {7.0, 0.0079}, {10.0, 0.0080},
            {25.0, 0.0080},
        };
        return curve;
    }

    static const std::vector<CurveNode>& inducedDragCurve() {
        static const std::vector<CurveNode> curve = {
            {0.0, 0.0},  {1.0, 0.95}, {2.0, 1.55},
            {3.0, 2.05}, {4.0, 2.35}, {5.0, 2.60},
            {7.0, 3.05}, {10.0, 3.35}, {15.0, 3.55},
            {20.0, 3.65}, {25.0, 3.65},
        };
        return curve;
    }

    static double interpolate(const std::vector<CurveNode>& curve,
                              double mach_number) {
        if (curve.empty()) {
            throw std::runtime_error(
                "cavh.common.aero_assets_3dof.paper_parabolic has an empty aerodynamic curve.");
        }
        if (mach_number <= curve.front().mach) {
            return curve.front().value;
        }
        if (mach_number >= curve.back().mach) {
            return curve.back().value;
        }
        for (size_t i = 1; i < curve.size(); ++i) {
            if (mach_number <= curve[i].mach) {
                const auto& lower = curve[i - 1];
                const auto& upper = curve[i];
                const double ratio =
                    (mach_number - lower.mach) / (upper.mach - lower.mach);
                return lower.value + ratio * (upper.value - lower.value);
            }
        }
        return curve.back().value;
    }

    mutable gnc::vehicle::common::AeroQuery3Dof last_query_{};
    mutable gnc::vehicle::output::AeroCoefficients last_coefficients_{};
    mutable double last_angle_of_attack_deg_ = 0.0;
    mutable double last_lift_intercept_ = 0.0;
    mutable double last_lift_slope_per_deg_ = 0.0;
    mutable double last_zero_lift_drag_ = 0.0;
    mutable double last_induced_drag_factor_ = 0.0;
};

} // namespace cavh::components

GNC_REGISTER_NODE_TYPE(
    "cavh.common.aero_assets_3dof.paper_parabolic",
    cavh::components::PaperAeroAssets3Dof,
    ::gnc::core::NodeRole::Asset,
    ::gnc::core::DiscretePhase::None,
    "",
    ::gnc::vehicle::common::IAerodynamicAssets3Dof,
    ::gnc::interfaces::IObservable)
