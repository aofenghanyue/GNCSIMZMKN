#pragma once

#include "gnc/common/math/eigen_types.hpp"
#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/environment/interfaces/i_atmosphere.hpp"
#include "gnc/environment/interfaces/i_earth.hpp"
#include "gnc/environment/interfaces/i_gravity.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/vehicle/output/interfaces/i_aero_model.hpp"
#include "gnc/vehicle/output/interfaces/i_constant_mass.hpp"
#include "gnc/vehicle/output/interfaces/i_continuous_mass.hpp"
#include "gnc/vehicle/process/interfaces/i_guidance_3dof.hpp"
#include "gnc/vehicle/process/interfaces/i_navigation_3dof.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace cavh::components {

class GlideRangeGuidance final
    : public gnc::core::DiscreteNode,
      public gnc::vehicle::process::IGuidance3Dof,
      public gnc::interfaces::IObservable {
public:
    GlideRangeGuidance() : DiscreteNode("CavhGlideRangeGuidance") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        navigation_lookup_name_ =
            reader.optionalString("navigation_lookup_name",
                                  navigation_lookup_name_);
        aero_lookup_name_ =
            reader.optionalString("aero_lookup_name", aero_lookup_name_);
        atmosphere_lookup_name_ =
            reader.optionalString("atmosphere_lookup_name",
                                  atmosphere_lookup_name_);
        gravity_lookup_name_ =
            reader.optionalString("gravity_lookup_name", gravity_lookup_name_);
        earth_lookup_name_ =
            reader.optionalString("earth_lookup_name", earth_lookup_name_);
        mass_lookup_name_ =
            reader.optionalString("mass_lookup_name", mass_lookup_name_);

        tdct_gain_ = reader.requiredDouble("tdct_gain");
        gamma_command_model_ = parseGammaCommandModel(
            reader.optionalString("gamma_command_model",
                                  gammaCommandModelName(gamma_command_model_)),
            config_path);
        bank_angle_rad_ = gnc::math::deg2rad(
            reader.requiredDouble("bank_angle_deg"));
        alpha_min_rad_ = gnc::math::deg2rad(
            reader.requiredDouble("alpha_min_deg"));
        alpha_max_rad_ = gnc::math::deg2rad(
            reader.requiredDouble("alpha_max_deg"));
        alpha_samples_ =
            reader.optionalInt("alpha_samples", alpha_samples_);
        density_gradient_step_m_ =
            reader.optionalDouble("density_gradient_step_m",
                                  density_gradient_step_m_);
        mach_derivative_step_ =
            reader.optionalDouble("mach_derivative_step",
                                  mach_derivative_step_);
        reference_radius_m_ =
            reader.optionalDouble("reference_radius_m", reference_radius_m_);
        reader.validateNoUnknownKeys();

        validateConfig(config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(
            gnc::core::bind(navigation_, navigation_lookup_name_),
            gnc::core::bind(aero_, aero_lookup_name_),
            gnc::core::bind(atmosphere_, atmosphere_lookup_name_),
            gnc::core::bind(gravity_, gravity_lookup_name_),
            gnc::core::bindIfPresent(earth_, earth_lookup_name_),
            gnc::core::bindIfPresent(constant_mass_, mass_lookup_name_),
            gnc::core::bindIfPresent(continuous_mass_, mass_lookup_name_));

        if ((constant_mass_ != nullptr) == (continuous_mass_ != nullptr)) {
            throw std::runtime_error(
                "cavh.process.local_spherical_guidance_3dof.glide_range_maximizing requires exactly one mass provider implementing IConstantMass or IContinuousMass.");
        }
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& navigation = navigation_->navigationState3Dof();
        altitude_m_ = navigation.altitude_m;
        speed_mps_ = std::max(kMinSpeedMps, navigation.speed_mps);
        flight_path_angle_rad_ = navigation.flight_path_angle_rad;

        const auto atmosphere_sample = atmosphere_->sample(altitude_m_);
        speed_of_sound_mps_ =
            std::max(1.0, atmosphere_sample.speed_of_sound_mps);
        density_kg_per_m3_ =
            std::max(kMinDensityKgPerM3,
                     atmosphere_sample.density_kg_per_m3);
        gravity_mps2_ = std::max(kMinGravityMps2,
                                 gravity_->getGravityMagnitude(altitude_m_));
        mass_kg_ = std::max(kMinMassKg, currentMassKg());

        mach_number_ = navigation.mach_number;
        if (mach_number_ <= 0.0) {
            mach_number_ = speed_mps_ / speed_of_sound_mps_;
        }

        density_gradient_per_m_ = densityGradient(altitude_m_);
        const auto optimum = findMaximumLiftToDrag(mach_number_);
        alpha_star_rad_ = optimum.alpha_rad;
        lift_coefficient_star_ = optimum.coefficients.lift_coefficient;
        drag_coefficient_star_ = optimum.coefficients.drag_coefficient;
        lift_to_drag_max_ = optimum.lift_to_drag;
        vertical_lift_scale_ = std::cos(bank_angle_rad_);
        vertical_lift_coefficient_star_ =
            lift_coefficient_star_ * vertical_lift_scale_;

        partial_mach_partial_speed_ = 1.0 / speed_of_sound_mps_;
        partial_mach_partial_altitude_ =
            machAltitudePartial(altitude_m_, speed_mps_);
        lift_coefficient_star_derivative_per_mach_ =
            gamma_command_model_ == GammaCommandModel::Eq17MachDerivative
                ? liftCoefficientStarDerivative(mach_number_)
                : 0.0;
        vertical_lift_coefficient_star_derivative_per_mach_ =
            lift_coefficient_star_derivative_per_mach_ * vertical_lift_scale_;

        // TDCT uses the steady-glide path angle gamma* from Eq. (17)/(18)
        // as the reference, then adds the Eq. (19) negative feedback term
        // alpha = alpha* + k_gamma(gamma* - gamma). This lift modulation
        // supplies damping opposite to the vertical velocity component.
        gamma_command_rad_ =
            gamma_command_model_ == GammaCommandModel::Eq17MachDerivative
                ? computeEq17GammaCommand()
                : computeEq18GammaCommand();
        tdct_error_rad_ = gamma_command_rad_ - flight_path_angle_rad_;
        tdct_angle_of_attack_correction_rad_ =
            tdct_gain_ * tdct_error_rad_;
        feedback_term_rad_ = tdct_angle_of_attack_correction_rad_;

        command_.angle_of_attack_rad =
            std::clamp(alpha_star_rad_ +
                           tdct_angle_of_attack_correction_rad_,
                       alpha_min_rad_,
                       alpha_max_rad_);
        command_.bank_angle_rad = bank_angle_rad_;
        command_.acceleration_command_nue_mps2 = gnc::math::Vector3::Zero();
    }

    const gnc::vehicle::process::GuidanceCommand3Dof& guidanceCommand3Dof()
        const override {
        return command_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("altitude_m", [this]() { return altitude_m_; });
        builder.addScalar("speed_mps", [this]() { return speed_mps_; });
        builder.addScalar("mach_number", [this]() { return mach_number_; });
        builder.addScalar("density_kg_per_m3",
                          [this]() { return density_kg_per_m3_; });
        builder.addScalar("density_gradient_per_m",
                          [this]() { return density_gradient_per_m_; });
        builder.addScalar("speed_of_sound_mps",
                          [this]() { return speed_of_sound_mps_; });
        builder.addScalar("partial_mach_partial_speed",
                          [this]() { return partial_mach_partial_speed_; });
        builder.addScalar("partial_mach_partial_altitude",
                          [this]() { return partial_mach_partial_altitude_; });
        builder.addScalar("lift_coefficient_star_derivative_per_mach",
                          [this]() {
                              return lift_coefficient_star_derivative_per_mach_;
                          });
        builder.addScalar("gravity_mps2", [this]() { return gravity_mps2_; });
        builder.addScalar("mass_kg", [this]() { return mass_kg_; });
        builder.addScalar("alpha_star_rad",
                          [this]() { return alpha_star_rad_; });
        builder.addScalar("alpha_star_deg",
                          [this]() {
                              return gnc::math::rad2deg(alpha_star_rad_);
                          });
        builder.addScalar("angle_of_attack_rad",
                          [this]() {
                              return command_.angle_of_attack_rad;
                          });
        builder.addScalar("angle_of_attack_deg",
                          [this]() {
                              return gnc::math::rad2deg(
                                  command_.angle_of_attack_rad);
                          });
        builder.addScalar("flight_path_angle_rad",
                          [this]() { return flight_path_angle_rad_; });
        builder.addScalar("gamma_command_rad",
                          [this]() { return gamma_command_rad_; });
        builder.addScalar("tdct_gain", [this]() { return tdct_gain_; });
        builder.addScalar("tdct_error_rad",
                          [this]() { return tdct_error_rad_; });
        builder.addScalar("tdct_angle_of_attack_correction_rad",
                          [this]() {
                              return tdct_angle_of_attack_correction_rad_;
                          });
        builder.addScalar("feedback_term_rad",
                          [this]() { return feedback_term_rad_; });
        builder.addScalar("bank_angle_rad",
                          [this]() { return command_.bank_angle_rad; });
        builder.addScalar("bank_angle_deg",
                          [this]() {
                              return gnc::math::rad2deg(
                                  command_.bank_angle_rad);
                          });
        builder.addScalar("vertical_lift_scale",
                          [this]() { return vertical_lift_scale_; });
        builder.addScalar("lift_coefficient_star",
                          [this]() { return lift_coefficient_star_; });
        builder.addScalar("vertical_lift_coefficient_star",
                          [this]() {
                              return vertical_lift_coefficient_star_;
                          });
        builder.addScalar("drag_coefficient_star",
                          [this]() { return drag_coefficient_star_; });
        builder.addScalar("lift_to_drag_max",
                          [this]() { return lift_to_drag_max_; });
        return builder.build();
    }

private:
    enum class GammaCommandModel {
        Eq18Simplified,
        Eq17MachDerivative,
    };

    struct LiftToDragSample {
        double alpha_rad = 0.0;
        gnc::vehicle::output::AeroCoefficients coefficients{};
        double lift_to_drag = -std::numeric_limits<double>::infinity();
    };

    static constexpr double kMinSpeedMps = 1.0;
    static constexpr double kMinDensityKgPerM3 = 1.0e-12;
    static constexpr double kMinGravityMps2 = 1.0e-9;
    static constexpr double kMinMassKg = 1.0e-9;
    static constexpr double kMinDragCoefficient = 1.0e-12;
    static constexpr double kMinLiftCoefficient = 1.0e-12;
    static constexpr double kMinDenominatorAbs = 1.0e-9;
    static constexpr double kMinVerticalLiftScale = 1.0e-6;

    static std::string configFieldPath(const std::string& config_path,
                                       const char* key) {
        if (config_path.empty()) {
            return key;
        }
        return config_path + "." + key;
    }

    static double protectDenominator(double value) {
        if (std::abs(value) >= kMinDenominatorAbs) {
            return value;
        }
        return value >= 0.0 ? kMinDenominatorAbs : -kMinDenominatorAbs;
    }

    static const char* gammaCommandModelName(GammaCommandModel model) {
        switch (model) {
            case GammaCommandModel::Eq18Simplified:
                return "eq18_simplified";
            case GammaCommandModel::Eq17MachDerivative:
                return "eq17_mach_derivative";
        }
        return "eq18_simplified";
    }

    static GammaCommandModel parseGammaCommandModel(
        const std::string& value,
        const std::string& config_path) {
        if (value == "eq18_simplified") {
            return GammaCommandModel::Eq18Simplified;
        }
        if (value == "eq17_mach_derivative") {
            return GammaCommandModel::Eq17MachDerivative;
        }
        throw std::runtime_error(
            configFieldPath(config_path, "gamma_command_model") +
            " must be 'eq18_simplified' or 'eq17_mach_derivative'.");
    }

    void validateConfig(const std::string& config_path) const {
        if (tdct_gain_ < 0.0) {
            throw std::runtime_error(
                configFieldPath(config_path, "tdct_gain") +
                " must be non-negative.");
        }
        if (alpha_max_rad_ <= alpha_min_rad_) {
            throw std::runtime_error(
                configFieldPath(config_path, "alpha_max_deg") +
                " must be greater than " +
                configFieldPath(config_path, "alpha_min_deg") + ".");
        }
        if (alpha_samples_ < 2) {
            throw std::runtime_error(
                configFieldPath(config_path, "alpha_samples") +
                " must be at least 2.");
        }
        if (density_gradient_step_m_ <= 0.0) {
            throw std::runtime_error(
                configFieldPath(config_path, "density_gradient_step_m") +
                " must be positive.");
        }
        if (mach_derivative_step_ <= 0.0) {
            throw std::runtime_error(
                configFieldPath(config_path, "mach_derivative_step") +
                " must be positive.");
        }
        if (std::cos(bank_angle_rad_) <= kMinVerticalLiftScale) {
            throw std::runtime_error(
                configFieldPath(config_path, "bank_angle_deg") +
                " must keep a positive vertical lift projection.");
        }
        if (reference_radius_m_ <= 0.0) {
            throw std::runtime_error(
                configFieldPath(config_path, "reference_radius_m") +
                " must be positive.");
        }
    }

    double currentMassKg() const {
        return continuous_mass_ ? continuous_mass_->getMassKg()
                                : constant_mass_->getMassKg();
    }

    double currentEarthRadiusM() const {
        return earth_ ? earth_->getEquatorialRadius() : reference_radius_m_;
    }

    double densityGradient(double altitude_m) const {
        const double lower_altitude_m =
            std::max(0.0, altitude_m - density_gradient_step_m_);
        const double upper_altitude_m = altitude_m + density_gradient_step_m_;
        if (upper_altitude_m <= lower_altitude_m) {
            return 0.0;
        }

        const double lower_density =
            atmosphere_->sample(lower_altitude_m).density_kg_per_m3;
        const double upper_density =
            atmosphere_->sample(upper_altitude_m).density_kg_per_m3;
        return (upper_density - lower_density) /
               (upper_altitude_m - lower_altitude_m);
    }

    double machAltitudePartial(double altitude_m, double speed_mps) const {
        const double lower_altitude_m =
            std::max(0.0, altitude_m - density_gradient_step_m_);
        const double upper_altitude_m = altitude_m + density_gradient_step_m_;
        if (upper_altitude_m <= lower_altitude_m) {
            return 0.0;
        }

        const double lower_speed_of_sound =
            std::max(1.0,
                     atmosphere_->sample(lower_altitude_m).speed_of_sound_mps);
        const double upper_speed_of_sound =
            std::max(1.0,
                     atmosphere_->sample(upper_altitude_m).speed_of_sound_mps);
        const double lower_mach = speed_mps / lower_speed_of_sound;
        const double upper_mach = speed_mps / upper_speed_of_sound;
        return (upper_mach - lower_mach) /
               (upper_altitude_m - lower_altitude_m);
    }

    LiftToDragSample evaluateLiftToDrag(double alpha_rad,
                                        double mach_number) const {
        LiftToDragSample sample;
        sample.alpha_rad = alpha_rad;
        sample.coefficients =
            aero_->computeCoefficients(alpha_rad, 0.0, mach_number);
        if (sample.coefficients.drag_coefficient > kMinDragCoefficient) {
            sample.lift_to_drag = sample.coefficients.lift_coefficient /
                                  sample.coefficients.drag_coefficient;
        }
        return sample;
    }

    LiftToDragSample betterSample(const LiftToDragSample& lhs,
                                  const LiftToDragSample& rhs) const {
        return rhs.lift_to_drag > lhs.lift_to_drag ? rhs : lhs;
    }

    LiftToDragSample refineMaximum(double lower_alpha_rad,
                                   double upper_alpha_rad,
                                   double mach_number,
                                   LiftToDragSample best) const {
        constexpr double kGoldenRatioConjugate = 0.6180339887498948482;
        double lower = lower_alpha_rad;
        double upper = upper_alpha_rad;
        double left = upper - kGoldenRatioConjugate * (upper - lower);
        double right = lower + kGoldenRatioConjugate * (upper - lower);
        auto left_sample = evaluateLiftToDrag(left, mach_number);
        auto right_sample = evaluateLiftToDrag(right, mach_number);

        for (int i = 0; i < 80; ++i) {
            if (left_sample.lift_to_drag < right_sample.lift_to_drag) {
                lower = left;
                left = right;
                left_sample = right_sample;
                right = lower + kGoldenRatioConjugate * (upper - lower);
                right_sample = evaluateLiftToDrag(right, mach_number);
            } else {
                upper = right;
                right = left;
                right_sample = left_sample;
                left = upper - kGoldenRatioConjugate * (upper - lower);
                left_sample = evaluateLiftToDrag(left, mach_number);
            }
            best = betterSample(best, left_sample);
            best = betterSample(best, right_sample);
        }

        const auto middle =
            evaluateLiftToDrag(0.5 * (lower + upper), mach_number);
        return betterSample(best, middle);
    }

    LiftToDragSample findMaximumLiftToDrag(double mach_number) const {
        LiftToDragSample best;
        int best_index = -1;

        for (int i = 0; i < alpha_samples_; ++i) {
            const double ratio =
                alpha_samples_ == 1
                    ? 0.0
                    : static_cast<double>(i) /
                          static_cast<double>(alpha_samples_ - 1);
            const double alpha =
                alpha_min_rad_ + ratio * (alpha_max_rad_ - alpha_min_rad_);
            const auto sample = evaluateLiftToDrag(alpha, mach_number);
            if (sample.lift_to_drag > best.lift_to_drag) {
                best = sample;
                best_index = i;
            }
        }

        if (best_index < 0 || !std::isfinite(best.lift_to_drag)) {
            throw std::runtime_error(
                "cavh.process.local_spherical_guidance_3dof.glide_range_maximizing could not find a finite L/D optimum.");
        }
        if (best.coefficients.lift_coefficient <= kMinLiftCoefficient) {
            throw std::runtime_error(
                "cavh.process.local_spherical_guidance_3dof.glide_range_maximizing requires a positive lift coefficient at L/Dmax.");
        }

        if (best_index == 0 || best_index == alpha_samples_ - 1) {
            return best;
        }

        const double step =
            (alpha_max_rad_ - alpha_min_rad_) /
            static_cast<double>(alpha_samples_ - 1);
        return refineMaximum(best.alpha_rad - step,
                             best.alpha_rad + step,
                             mach_number,
                             best);
    }

    double liftCoefficientStarDerivative(double mach_number) const {
        const double lower_mach =
            std::max(0.0, mach_number - mach_derivative_step_);
        const double upper_mach = mach_number + mach_derivative_step_;
        if (upper_mach <= lower_mach) {
            return 0.0;
        }

        const auto lower = findMaximumLiftToDrag(lower_mach);
        const auto upper = findMaximumLiftToDrag(upper_mach);
        return (upper.coefficients.lift_coefficient -
                lower.coefficients.lift_coefficient) /
               (upper_mach - lower_mach);
    }

    double computeEq18GammaCommand() const {
        // Eq. (18) is the simplified steady-glide flight-path-angle formula
        // used by TDCT when Mach dependence of the L/D optimum is neglected.
        const double radius_m = currentEarthRadiusM() + altitude_m_;
        const double dynamic_pressure_pa =
            0.5 * density_kg_per_m3_ * speed_mps_ * speed_mps_;
        const double drag_force_n =
            drag_coefficient_star_ * dynamic_pressure_pa *
            aero_->getReferenceArea();

        const double a21 =
            density_gradient_per_m_ * speed_mps_ * speed_mps_ /
            (2.0 * density_kg_per_m3_ * gravity_mps2_);
        const double a24 =
            2.0 * mass_kg_ /
            (vertical_lift_coefficient_star_ * density_kg_per_m3_ *
             aero_->getReferenceArea() * radius_m);
        const double a25 =
            mass_kg_ * speed_mps_ * speed_mps_ /
            (vertical_lift_coefficient_star_ * density_kg_per_m3_ * gravity_mps2_ *
             aero_->getReferenceArea() * radius_m * radius_m);
        const double a31 =
            density_gradient_per_m_ * vertical_lift_coefficient_star_ * speed_mps_ *
            speed_mps_ * aero_->getReferenceArea() * radius_m /
            (4.0 * mass_kg_ * gravity_mps2_);
        const double a34 = 1.0 / a24;
        const double a35 =
            speed_mps_ * speed_mps_ / (2.0 * gravity_mps2_ * radius_m);

        const double denominator_1 =
            protectDenominator(1.0 - a21 + a24 + a25);
        const double denominator_2 =
            protectDenominator(1.0 - a31 + a34 + a35);

        return -drag_force_n / (mass_kg_ * gravity_mps2_) *
               (1.0 / denominator_1 + 1.0 / denominator_2);
    }

    double computeEq17GammaCommand() const {
        // Eq. (17) retains the Mach derivative of CL*; the result is the
        // steady-glide command path angle gamma* used as the TDCT reference.
        const double dcl_dma_dv =
            vertical_lift_coefficient_star_derivative_per_mach_ *
            partial_mach_partial_speed_;
        if (std::abs(dcl_dma_dv) < kMinDenominatorAbs) {
            return computeEq18GammaCommand();
        }

        const double radius_m = currentEarthRadiusM() + altitude_m_;
        const double dynamic_pressure_pa =
            0.5 * density_kg_per_m3_ * speed_mps_ * speed_mps_;
        const double drag_force_n =
            drag_coefficient_star_ * dynamic_pressure_pa *
            aero_->getReferenceArea();

        const double a11 =
            density_gradient_per_m_ * vertical_lift_coefficient_star_ * speed_mps_ /
            (dcl_dma_dv * density_kg_per_m3_ * gravity_mps2_);
        const double a12 =
            partial_mach_partial_altitude_ * speed_mps_ /
            (partial_mach_partial_speed_ * gravity_mps2_);
        const double a13 =
            2.0 * vertical_lift_coefficient_star_ / (dcl_dma_dv * speed_mps_);
        const double a14 =
            4.0 * mass_kg_ /
            (dcl_dma_dv * density_kg_per_m3_ * speed_mps_ *
             aero_->getReferenceArea() * radius_m);
        const double a15 =
            2.0 * speed_mps_ * mass_kg_ /
            (dcl_dma_dv * density_kg_per_m3_ * aero_->getReferenceArea() *
             gravity_mps2_ * radius_m * radius_m);

        const double a21 =
            density_gradient_per_m_ * speed_mps_ * speed_mps_ /
            (2.0 * density_kg_per_m3_ * gravity_mps2_);
        const double a22 =
            vertical_lift_coefficient_star_derivative_per_mach_ *
            partial_mach_partial_altitude_ * speed_mps_ * speed_mps_ /
            (2.0 * vertical_lift_coefficient_star_ * gravity_mps2_);
        const double a23 = 1.0 / a13;
        const double a24 =
            2.0 * mass_kg_ /
            (vertical_lift_coefficient_star_ * density_kg_per_m3_ *
             aero_->getReferenceArea() * radius_m);
        const double a25 =
            mass_kg_ * speed_mps_ * speed_mps_ /
            (vertical_lift_coefficient_star_ * density_kg_per_m3_ * gravity_mps2_ *
             aero_->getReferenceArea() * radius_m * radius_m);

        const double a31 =
            density_gradient_per_m_ * vertical_lift_coefficient_star_ * speed_mps_ *
            speed_mps_ * aero_->getReferenceArea() * radius_m /
            (4.0 * mass_kg_ * gravity_mps2_);
        const double a32 =
            vertical_lift_coefficient_star_derivative_per_mach_ *
            partial_mach_partial_altitude_ * density_kg_per_m3_ * speed_mps_ *
            speed_mps_ * aero_->getReferenceArea() * radius_m /
            (4.0 * mass_kg_ * gravity_mps2_);
        const double a33 = 1.0 / a14;
        const double a34 = 1.0 / a24;
        const double a35 =
            speed_mps_ * speed_mps_ / (2.0 * gravity_mps2_ * radius_m);

        const double denominator_1 =
            protectDenominator(1.0 - a11 - a12 + a13 + a14 + a15);
        const double denominator_2 =
            protectDenominator(1.0 - a21 - a22 + a23 + a24 + a25);
        const double denominator_3 =
            protectDenominator(1.0 - a31 - a32 + a33 + a34 + a35);

        return -drag_force_n / (mass_kg_ * gravity_mps2_) *
               (1.0 / denominator_1 + 1.0 / denominator_2 +
                1.0 / denominator_3);
    }

    gnc::vehicle::process::INavigation3Dof* navigation_ = nullptr;
    gnc::vehicle::output::IAeroModel* aero_ = nullptr;
    gnc::environment::IAtmosphere* atmosphere_ = nullptr;
    gnc::environment::IGravity* gravity_ = nullptr;
    gnc::environment::IEarth* earth_ = nullptr;
    gnc::vehicle::output::IConstantMass* constant_mass_ = nullptr;
    gnc::vehicle::output::IContinuousMass* continuous_mass_ = nullptr;

    std::string navigation_lookup_name_ = "navigation";
    std::string aero_lookup_name_ = "aero";
    std::string atmosphere_lookup_name_ = "env.atmosphere";
    std::string gravity_lookup_name_ = "env.gravity";
    std::string earth_lookup_name_ = "env.earth";
    std::string mass_lookup_name_ = "mass";

    gnc::vehicle::process::GuidanceCommand3Dof command_{};
    double tdct_gain_ = 0.0;
    GammaCommandModel gamma_command_model_ = GammaCommandModel::Eq18Simplified;
    double bank_angle_rad_ = 0.0;
    double alpha_min_rad_ = 0.0;
    double alpha_max_rad_ = 0.0;
    int alpha_samples_ = 181;
    double density_gradient_step_m_ = 100.0;
    double mach_derivative_step_ = 0.05;
    double reference_radius_m_ = 6371000.0;

    double altitude_m_ = 0.0;
    double speed_mps_ = 0.0;
    double mach_number_ = 0.0;
    double flight_path_angle_rad_ = 0.0;
    double density_kg_per_m3_ = 0.0;
    double density_gradient_per_m_ = 0.0;
    double speed_of_sound_mps_ = 0.0;
    double partial_mach_partial_speed_ = 0.0;
    double partial_mach_partial_altitude_ = 0.0;
    double lift_coefficient_star_derivative_per_mach_ = 0.0;
    double gravity_mps2_ = 0.0;
    double mass_kg_ = 0.0;
    double alpha_star_rad_ = 0.0;
    double gamma_command_rad_ = 0.0;
    double tdct_error_rad_ = 0.0;
    double tdct_angle_of_attack_correction_rad_ = 0.0;
    double feedback_term_rad_ = 0.0;
    double lift_coefficient_star_ = 0.0;
    double vertical_lift_scale_ = 1.0;
    double vertical_lift_coefficient_star_ = 0.0;
    double vertical_lift_coefficient_star_derivative_per_mach_ = 0.0;
    double drag_coefficient_star_ = 0.0;
    double lift_to_drag_max_ = 0.0;
};

} // namespace cavh::components

GNC_REGISTER_NODE_TYPE(
    "cavh.process.local_spherical_guidance_3dof.glide_range_maximizing",
    cavh::components::GlideRangeGuidance,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "local_spherical_3dof",
    ::gnc::vehicle::process::IGuidance3Dof,
    ::gnc::interfaces::IObservable)
