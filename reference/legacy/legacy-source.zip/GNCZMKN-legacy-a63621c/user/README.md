# User 工作区

`user/` 是研究项目的工作区，用来保存 mission、项目节点、私有头文件、数据资产和仿真输出。仍在随论文或试验变化的模型优先放在这里；framework 代码不能依赖某个具体的 `user/<project>`。

## 目录结构

| 路径 | 用途 |
| --- | --- |
| `user/active_project` | 未设置 `-DGNC_ACTIVE_PROJECT=...` 时的默认 active project 名 |
| `user/<project>/config/mission.json` | active project 的默认 mission |
| `user/<project>/components/` | 会被 CMake 扫描并自动注册的项目组件头文件 |
| `user/<project>/interfaces/` | 项目私有接口；进入 include path，不扫描注册 |
| `user/<project>/common/` | 项目共享工具；进入 include path，不扫描注册 |
| `user/<project>/include/` | 项目私有 include root；进入 include path，不扫描注册 |
| `user/<project>/simflows/` | 可注册的项目 SimFlow materializer 头文件 |
| `user/<project>/simflow/` | 普通 SimFlow JSON、CSV 等项目输入；目录名可按项目约定 |
| `user/data/` | 跨项目数据资产，可用 `user-data://...` 引用 |
| `user/outputs/` | 运行时输出目录 |

`components/` 只放包含 `GNC_REGISTER_NODE_TYPE` 的可注册节点头。共享接口、数据结构、工具函数应放在 `interfaces/`、`common/` 或 `include/`。

## Active project 怎样选择

CMake 按以下顺序选择 active project：

1. `-DGNC_ACTIVE_PROJECT=<project>` cache value。
2. `user/active_project`。

两处都设置了项目名且内容不同时，CMake 会给出 warning，并使用 cache value。active project 必须提供 `config/mission.json`，缺少该文件时 CMake 配置会失败。没有选择 active project 时，`gnc_sim` 不带默认 mission，运行时必须传入 `--config <path>`。

当前仓库默认：

```text
example_05_ideal_3dof_geographic_baseline
```

只有 active project 的 `components/*.hpp` 会自动注册到 `gnc_sim`。修改 `user/active_project`、`-DGNC_ACTIVE_PROJECT`，或者增删组件头文件以后，需要重新运行 CMake 配置并构建。

`simflows/*.hpp` 采用同样的 active-project 扫描规则，用于注册自定义 SimFlow materializer。保存 SimFlow JSON 的目录无需被 CMake 扫描，YYZ 示例使用单数目录 `simflow/`。

## 从一个新项目开始

实验室项目通常从最接近研究对象的 baseline 开始。复制后先原样运行一次，确认 Environment、Form、GNC、Interaction 和输出链仍然正常，再逐项替换算法与模型。这样，每轮实验只引入少量变化，问题也更容易定位。

可以按下面的顺序创建项目：

1. 在 `user/` 下复制最接近的 3DoF/6DoF、geographic/Cartesian baseline。
2. 修改项目名、mission 输出目录和实验说明。
3. 先用普通 `--config` 运行复制后的 mission，保存这次 nominal 结果。
4. 把第一个自定义节点放入 `components/`，共享接口放入 `interfaces/`。
5. 在 mission 中只替换一个 type，保留稳定的局部 name 和下游接口。
6. 用新的构建目录指定 `-DGNC_ACTIVE_PROJECT=<project>`。
7. 先查 `--list-components-verbose`，再运行短任务并检查 CSV 和 `summary.txt`。
8. 为关键算法增加项目测试，稳定后再扩展更多节点。

一个建议结构：

```text
user/my_project/
├── README.md                 # 研究目标、入口和结果说明
├── config/
│   ├── mission.json          # 默认可复现任务
│   ├── assembly/             # 可选：通过 $include 拆分装配
│   └── parameters/           # 可选：模型和算法参数
├── components/               # 可注册节点
├── interfaces/               # 项目 typed contracts
├── common/                   # 表格、数学、状态机等局部工具
├── data/                     # 项目资产
├── simflow/                  # SimFlow JSON 与 case CSV
└── simflows/                 # 可选：自定义 materializer 头文件
```

项目 README 至少要写清 active-project 构建命令、普通 mission 命令、SimFlow 命令（如果使用）、输出位置和主要算法替换点。第一个自定义制导节点的完整教程见 [扩展指南](../doc/04-extension-guide.md#0-第一次扩展替换一个制导算法)。

除了运行入口，研究项目还应维护一份“模型可信范围”，至少包含：

- 当前研究问题和主要指标；
- Form 状态、坐标、单位和四元数约定；
- truth、传感器、导航、制导控制、执行机构、气动与推进分别采用的理想化；
- Interaction 怎样形成 Form input，重力和惯性项由哪一侧承担；
- `dt`、各节点 `rate_hz` 和同 phase priority 的依据；
- 名义 case、步长验证、资产来源、随机 seed 和可回放异常 case；
- 当前结果可以支持的结论，以及仍待数据验证的部分。

仓库 baseline 主要保证架构接线和时间契约。复制成新项目以后，应逐层替换占位或 reference 模型，并为每一步保留名义 case 和回归证据。研究方法与交付检查见 [研究级 GNC 仿真方法](../doc/08-research-simulation-methodology.md)。

### 为什么推荐独立构建目录

`GNC_ACTIVE_PROJECT` 是 CMake cache 值。为不同项目使用 `build-mingw-<project>` 可以避免 cache 与 `user/active_project` 混淆，也能让多个项目构建并存：

```powershell
cmake -S . -B build-mingw-my-project -G "MinGW Makefiles" `
    -DGNC_ACTIVE_PROJECT=my_project `
    -DBUILD_TESTS=OFF
cmake --build build-mingw-my-project -j 4
build-mingw-my-project\bin\gnc_sim.exe --list-components-verbose
build-mingw-my-project\bin\gnc_sim.exe --config user/my_project/config/mission.json
```

项目刚创建时，可以先关闭全量测试以缩短构建时间。节点逐渐稳定以后，再使用 `BUILD_TESTS=ON` 配置测试构建，并运行相关 test target。

## 示例项目

| 项目 | 用途 |
| --- | --- |
| `example_04_ideal_6dof_baseline` | ideal geographic 6DoF baseline |
| `example_05_ideal_3dof_geographic_baseline` | ideal geographic 3DoF baseline |
| `example_06_ideal_cartesian_3dof_baseline` | ideal Cartesian launch-frame 3DoF baseline |
| `example_07_ideal_cartesian_6dof_baseline` | ideal Cartesian launch-frame 6DoF baseline |
| `example_08_cavh_geographic_3dof_custom` | CAVH geographic 3DoF custom user project |

## 常用命令

运行 active project mission：

```powershell
build-mingw\bin\gnc_sim.exe
```

运行指定 mission：

```powershell
build-mingw\bin\gnc_sim.exe --config user/example_05_ideal_3dof_geographic_baseline/config/mission.json
```

查看已注册组件：

```powershell
build-mingw\bin\gnc_sim.exe --list-components-verbose
```

切换 active project 的推荐方式：

```powershell
cmake -S . -B build-mingw -G "MinGW Makefiles" -DGNC_ACTIVE_PROJECT=example_08_cavh_geographic_3dof_custom
cmake --build build-mingw -j 4
```
