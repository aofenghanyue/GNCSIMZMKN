#pragma once

#include "interfaces/yyz_c6_types.hpp"

#include <algorithm>
#include <cstddef>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace yyz_c6 {

struct StandardTrajectorySegment {
    size_t index = 0;
    int phase_id = 0;
    size_t begin_row = 0;
    size_t end_row = 0; // inclusive
    double begin_time_s = 0.0;
    double end_time_s = 0.0;
};

/**
 * @brief Immutable, many-column result produced from one standard trajectory.
 *
 * The product keeps every source column and may contain additional derived
 * columns. Project algorithms can extend the preprocessor while consumers keep
 * this stable table-and-metadata contract.
 */
class ProcessedStandardTrajectory {
public:
    ProcessedStandardTrajectory(std::vector<std::string> columns,
                                std::vector<std::vector<double>> rows,
                                std::vector<StandardTrajectorySegment> segments,
                                std::string source_path,
                                std::string source_fingerprint,
                                std::string processing_profile,
                                std::string time_column_name,
                                std::string phase_column_name,
                                RigidBodyState initial_state)
        : columns_(std::move(columns)),
          rows_(std::move(rows)),
          segments_(std::move(segments)),
          source_path_(std::move(source_path)),
          source_fingerprint_(std::move(source_fingerprint)),
          processing_profile_(std::move(processing_profile)),
          time_column_name_(std::move(time_column_name)),
          phase_column_name_(std::move(phase_column_name)),
          initial_state_(std::move(initial_state)) {
        for (size_t i = 0; i < columns_.size(); ++i) {
            const auto inserted = column_indices_.emplace(columns_[i], i);
            if (!inserted.second) {
                throw std::runtime_error(
                    "Processed standard trajectory has duplicate column '" +
                    columns_[i] + "'.");
            }
        }
        if (rows_.empty()) {
            throw std::runtime_error(
                "Processed standard trajectory must contain at least one row.");
        }
        for (const auto& row : rows_) {
            if (row.size() != columns_.size()) {
                throw std::runtime_error(
                    "Processed standard trajectory row width is inconsistent.");
            }
        }
        time_column_ = columnIndex(time_column_name_);
        (void)columnIndex(phase_column_name_);
    }

    size_t rowCount() const { return rows_.size(); }
    size_t columnCount() const { return columns_.size(); }
    const std::vector<std::string>& columns() const { return columns_; }
    const std::vector<std::vector<double>>& rows() const { return rows_; }
    const std::vector<StandardTrajectorySegment>& segments() const {
        return segments_;
    }

    bool hasColumn(const std::string& name) const {
        return column_indices_.count(name) > 0;
    }

    size_t columnIndex(const std::string& name) const {
        const auto it = column_indices_.find(name);
        if (it == column_indices_.end()) {
            throw std::runtime_error(
                "Processed standard trajectory is missing column '" + name + "'.");
        }
        return it->second;
    }

    double value(size_t row, size_t column) const {
        if (row >= rows_.size() || column >= columns_.size()) {
            throw std::runtime_error(
                "Processed standard trajectory cell index is out of range.");
        }
        return rows_[row][column];
    }

    double value(size_t row, const std::string& column) const {
        return value(row, columnIndex(column));
    }

    size_t rowAtOrBeforeTime(double time_s) const {
        const auto it = std::upper_bound(
            rows_.begin(), rows_.end(), time_s,
            [this](double value, const std::vector<double>& row) {
                return value < row[time_column_];
            });
        if (it == rows_.begin()) {
            return 0;
        }
        return static_cast<size_t>(std::distance(rows_.begin(), it) - 1);
    }

    size_t segmentIndexForRow(size_t row) const {
        for (const auto& segment : segments_) {
            if (row >= segment.begin_row && row <= segment.end_row) {
                return segment.index;
            }
        }
        throw std::runtime_error(
            "Processed standard trajectory row has no segment metadata.");
    }

    double beginTime() const { return rows_.front()[time_column_]; }
    double endTime() const { return rows_.back()[time_column_]; }
    const RigidBodyState& initialState() const { return initial_state_; }
    const std::string& sourcePath() const { return source_path_; }
    const std::string& sourceFingerprint() const { return source_fingerprint_; }
    const std::string& processingProfile() const { return processing_profile_; }
    const std::string& timeColumnName() const { return time_column_name_; }
    const std::string& phaseColumnName() const { return phase_column_name_; }

private:
    std::vector<std::string> columns_;
    std::vector<std::vector<double>> rows_;
    std::vector<StandardTrajectorySegment> segments_;
    std::unordered_map<std::string, size_t> column_indices_;
    std::string source_path_;
    std::string source_fingerprint_;
    std::string processing_profile_;
    std::string time_column_name_;
    std::string phase_column_name_;
    RigidBodyState initial_state_{};
    size_t time_column_ = 0;
};

class IStandardTrajectoryProvider {
public:
    virtual ~IStandardTrajectoryProvider() = default;
    virtual std::shared_ptr<const ProcessedStandardTrajectory>
    standardTrajectory() const = 0;
};

struct TrajectoryReference {
    size_t row_index = 0;
    size_t segment_index = 0;
    int phase_id = 0;
    double time_s = 0.0;
    RigidBodyState state{};
    double speed_mps = 0.0;
    double flight_path_angle_rad = 0.0;
};

class ITrajectoryReferenceProvider {
public:
    virtual ~ITrajectoryReferenceProvider() = default;
    virtual const TrajectoryReference& trajectoryReference() const = 0;
};

} // namespace yyz_c6
