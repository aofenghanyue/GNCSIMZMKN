#pragma once

#include "gnc/common/math/eigen_types.hpp"

#include <Eigen/Geometry>

#include <string>

// Stable template contract for the YYZ Cartesian 6DoF project family.
// Change this file first when a project needs a new cross-component interface.
namespace yyz_c6 {

inline constexpr const char* kFormFamily = "yyz_c6";
inline constexpr int kGuidanceModeAttitude = 0;
inline constexpr int kGuidanceModeForce = 1;

struct RigidBodyState {
    gnc::math::Vector3 position_launch_m = gnc::math::Vector3::Zero();
    gnc::math::Vector3 velocity_launch_mps = gnc::math::Vector3::Zero();
    Eigen::Quaterniond attitude_body_to_inertial =
        Eigen::Quaterniond::Identity();
    gnc::math::Vector3 angular_rate_body_radps = gnc::math::Vector3::Zero();
};

struct MassProperties {
    double mass_kg = 1.0;
    gnc::math::Vector3 center_of_gravity_body_m = gnc::math::Vector3::Zero();
    gnc::math::Matrix3 inertia_body_kgm2 = gnc::math::Matrix3::Identity();
};

struct FormInput {
    gnc::math::Vector3 total_force_body_n = gnc::math::Vector3::Zero();
    gnc::math::Vector3 total_moment_body_nm = gnc::math::Vector3::Zero();
    gnc::math::Vector3 gravity_launch_mps2 =
        gnc::math::Vector3(0.0, 0.0, -9.80665);
    MassProperties mass{};
};

struct Truth {
    RigidBodyState state{};
    gnc::math::Vector3 acceleration_launch_mps2 = gnc::math::Vector3::Zero();
    gnc::math::Vector3 specific_force_body_mps2 = gnc::math::Vector3::Zero();
    gnc::math::Vector3 angular_acceleration_body_radps2 =
        gnc::math::Vector3::Zero();
    gnc::math::Vector3 gravity_launch_mps2 =
        gnc::math::Vector3(0.0, 0.0, -9.80665);
    double sample_time_s = 0.0;
};

class ITruthView {
public:
    virtual ~ITruthView() = default;
    virtual const Truth& yyzC6Truth() const = 0;
};

class IInputProvider {
public:
    virtual ~IInputProvider() = default;
    virtual FormInput computeYyzC6Input(const Truth& truth,
                                        double time_s) const = 0;
};

struct EllipsoidModel {
    double semi_major_axis_m = 6378137.0;
    double flattening = 1.0 / 298.257222101;
    double gravitational_parameter_m3ps2 = 3.986004418e14;
    double rotation_rate_radps = 7.292115e-5;
};

struct AtmosphereSample {
    double density_kgpm3 = 1.225;
    double pressure_pa = 101325.0;
    double temperature_k = 288.15;
    double speed_of_sound_mps = 340.294;
};

struct GravitySample {
    gnc::math::Vector3 gravity_launch_mps2 =
        gnc::math::Vector3(0.0, 0.0, -9.80665);
    double magnitude_mps2 = 9.80665;
};

struct WindSample {
    gnc::math::Vector3 wind_launch_mps = gnc::math::Vector3::Zero();
};

class IEllipsoidProvider {
public:
    virtual ~IEllipsoidProvider() = default;
    virtual const EllipsoidModel& ellipsoidModel() const = 0;
};

class IAtmosphereProvider {
public:
    virtual ~IAtmosphereProvider() = default;
    virtual AtmosphereSample sampleAtmosphere(double altitude_m) const = 0;
};

class IGravityProvider {
public:
    virtual ~IGravityProvider() = default;
    virtual GravitySample sampleGravity(const gnc::math::Vector3& position_launch_m)
        const = 0;
};

class IWindProvider {
public:
    virtual ~IWindProvider() = default;
    virtual WindSample sampleWind(const gnc::math::Vector3& position_launch_m,
                                  double time_s) const = 0;
};

struct ImuMeasurement {
    gnc::math::Vector3 specific_force_body_mps2 = gnc::math::Vector3::Zero();
    gnc::math::Vector3 angular_rate_body_radps = gnc::math::Vector3::Zero();
    gnc::math::Vector3 angular_acceleration_body_radps2 =
        gnc::math::Vector3::Zero();
};

struct SatelliteNavMeasurement {
    gnc::math::Vector3 position_launch_m = gnc::math::Vector3::Zero();
    gnc::math::Vector3 velocity_launch_mps = gnc::math::Vector3::Zero();
    Eigen::Quaterniond attitude_body_to_inertial =
        Eigen::Quaterniond::Identity();
    double sample_time_s = 0.0;
};

struct AirDataMeasurement {
    gnc::math::Vector3 relative_velocity_body_mps = gnc::math::Vector3::Zero();
    gnc::math::Vector3 wind_launch_mps = gnc::math::Vector3::Zero();
    double altitude_m = 0.0;
    double speed_mps = 0.0;
    double mach_number = 0.0;
    double dynamic_pressure_pa = 0.0;
    double alpha_rad = 0.0;
    double beta_rad = 0.0;
    AtmosphereSample atmosphere{};
};

class IImuProvider {
public:
    virtual ~IImuProvider() = default;
    virtual const ImuMeasurement& imuMeasurement() const = 0;
};

class ISatelliteNavProvider {
public:
    virtual ~ISatelliteNavProvider() = default;
    virtual const SatelliteNavMeasurement& satelliteNavMeasurement() const = 0;
};

class IAirDataProvider {
public:
    virtual ~IAirDataProvider() = default;
    virtual const AirDataMeasurement& airDataMeasurement() const = 0;
};

struct PhaseState {
    std::string phase_name = "init";
    int phase_index = 0;
    double phase_elapsed_time_s = 0.0;
    double mission_time_s = 0.0;
};

struct NavigationSolution {
    gnc::math::Vector3 position_launch_m = gnc::math::Vector3::Zero();
    gnc::math::Vector3 velocity_launch_mps = gnc::math::Vector3::Zero();
    Eigen::Quaterniond attitude_body_to_inertial =
        Eigen::Quaterniond::Identity();
    gnc::math::Vector3 angular_rate_body_radps = gnc::math::Vector3::Zero();
    double altitude_m = 0.0;
    double speed_mps = 0.0;
    double sample_time_s = 0.0;
};

struct TargetState {
    gnc::math::Vector3 position_launch_m = gnc::math::Vector3::Zero();
    gnc::math::Vector3 velocity_launch_mps = gnc::math::Vector3::Zero();
};

struct OnboardState {
    NavigationSolution navigation{};
    AirDataMeasurement air_data{};
    PhaseState phase{};
};

struct GuidanceCommand {
    // kGuidanceModeAttitude uses desired_euler_rad/attitude_error_rad.
    // kGuidanceModeForce uses desired_force_body_n/actual_force_body_n.
    int command_mode = kGuidanceModeAttitude;
    gnc::math::Vector3 desired_euler_rad = gnc::math::Vector3::Zero();
    gnc::math::Vector3 attitude_error_rad = gnc::math::Vector3::Zero();
    gnc::math::Vector3 desired_force_body_n = gnc::math::Vector3::Zero();
    gnc::math::Vector3 actual_force_body_n = gnc::math::Vector3::Zero();
    double fuel_command = 0.0;
};

struct FlightControlCommand {
    gnc::math::Vector3 moment_command_body_nm = gnc::math::Vector3::Zero();
    gnc::math::Vector3 raw_actuator_command_rad = gnc::math::Vector3::Zero();
    double throttle_command = 0.0;
};

struct ControlAllocationCommand {
    gnc::math::Vector3 fin_deflection_command_rad = gnc::math::Vector3::Zero();
    double throttle_command = 0.0;
};

class IPhaseProvider {
public:
    virtual ~IPhaseProvider() = default;
    virtual const PhaseState& phaseState() const = 0;
};

class INavigationProvider {
public:
    virtual ~INavigationProvider() = default;
    virtual const NavigationSolution& navigationSolution() const = 0;
};

class ITargetProvider {
public:
    virtual ~ITargetProvider() = default;
    virtual const TargetState& targetState() const = 0;
};

class IOnboardStateProvider {
public:
    virtual ~IOnboardStateProvider() = default;
    virtual const OnboardState& onboardState() const = 0;
};

class IGuidanceProvider {
public:
    virtual ~IGuidanceProvider() = default;
    virtual const GuidanceCommand& guidanceCommand() const = 0;
};

class IFlightControlProvider {
public:
    virtual ~IFlightControlProvider() = default;
    virtual const FlightControlCommand& flightControlCommand() const = 0;
};

class IControlAllocationProvider {
public:
    virtual ~IControlAllocationProvider() = default;
    virtual const ControlAllocationCommand& controlAllocationCommand() const = 0;
};

struct ActuatorState {
    // x/y/z map to the template roll/pitch/yaw control channels.
    gnc::math::Vector3 fin_deflection_rad = gnc::math::Vector3::Zero();
    double throttle = 0.0;
};

struct AeroCoefficients {
    // Force coefficients use F_* and moment coefficients use M_* to avoid
    // case-only column distinctions in CSV tooling.
    double F_CA = 0.0;
    double F_CY = 0.0;
    double F_CN = 0.0;
    double M_Cl = 0.0;
    double M_Cm = 0.0;
    double M_Cn = 0.0;
};

struct AeroState {
    AeroCoefficients coefficients{};
    double reference_area_m2 = 1.0;
    double reference_length_m = 1.0;
    gnc::math::Vector3 force_body_n = gnc::math::Vector3::Zero();
    gnc::math::Vector3 moment_body_nm = gnc::math::Vector3::Zero();
    AirDataMeasurement air_data{};
};

struct PropulsionState {
    gnc::math::Vector3 force_body_n = gnc::math::Vector3::Zero();
    gnc::math::Vector3 moment_body_nm = gnc::math::Vector3::Zero();
    double fuel_mass_flow_kgps = 0.0;
    double ablation_rate_kgps = 0.0;
    bool enabled = false;
    double isp_s = 0.0;
    double air_flow_kgps = 0.0;
    double equivalence_ratio = 0.0;
    double remaining_fuel_kg = 0.0;
};

class IMassPropertiesProvider {
public:
    virtual ~IMassPropertiesProvider() = default;
    virtual const MassProperties& massProperties() const = 0;
};

class IPropulsionProvider {
public:
    virtual ~IPropulsionProvider() = default;
    virtual const PropulsionState& propulsionState() const = 0;
};

class IActuatorProvider {
public:
    virtual ~IActuatorProvider() = default;
    virtual const ActuatorState& actuatorState() const = 0;
};

class IAerodynamicsProvider {
public:
    virtual ~IAerodynamicsProvider() = default;
    virtual const AeroState& aeroState() const = 0;
};

} // namespace yyz_c6
