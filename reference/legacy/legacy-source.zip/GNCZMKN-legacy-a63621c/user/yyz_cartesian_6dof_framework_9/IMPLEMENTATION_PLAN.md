# YYZ Cartesian 6DoF Framework 9 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a reusable user-project framework for a family of Cartesian 6DoF GNC simulations with fixed interfaces and replaceable mission parameters/assets.

**Architecture:** Keep all scenario-specific contracts in `user/yyz_cartesian_6dof_framework_9`. Define a project-owned form family (`yyz_c6`) because the builtin Cartesian 6DoF form does not match the required launch-frame translation and inertial attitude contract. Provide complete input/process/output/interaction components as reference implementation slots so a detailed mission can run immediately and later projects can replace internals without changing the mission shape.

**Tech Stack:** C++17 header-only project components, GNCZMKN component registration, mission JSON with `$include`, CSV outputs, lightweight text/CSV assets.

---

### Task 1: Project Contracts And Helpers

**Files:**
- Create: `user/yyz_cartesian_6dof_framework_9/interfaces/yyz_c6_types.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/common/yyz_config_helpers.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/common/yyz_table.hpp`

- [x] Define fixed scenario data structures for truth, form input, sensors, GNC commands, actuator state, aero, mass, propulsion, environment, and target state.
- [x] Define small provider interfaces for each data role.
- [x] Add config helpers for required vectors and warning-only unknown key handling.
- [x] Add a lightweight flat-table loader with header, required-column, and nearest-row query support for project assets.

### Task 2: Form, Environment, And Input Components

**Files:**
- Create: `user/yyz_cartesian_6dof_framework_9/components/form_rigid_body_6dof.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/environment_cgcs2000.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/environment_wind_field.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/input_imu.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/input_satnav.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/input_air_data.hpp`

- [x] Implement launch-frame translation and inertial attitude integration in the project form.
- [x] Provide CGCS2000 ellipsoid constants and reference launch-frame gravity.
- [x] Provide perturbation-aware constant wind.
- [x] Provide reference IMU, satellite navigation, and air-data measurements from truth.

### Task 3: Process Components

**Files:**
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_sequencer.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_navigation.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_target_manager.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_onboard_state.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_guidance.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_flight_control.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/process_control_allocation.hpp`

- [x] Implement a component-local time sequencer.
- [x] Implement pass-through navigation and target management.
- [x] Implement derived onboard state publication.
- [x] Implement guidance, flight-control, and allocation reference slots with stable interfaces.

### Task 4: Output And Interaction Components

**Files:**
- Create: `user/yyz_cartesian_6dof_framework_9/components/output_mass_properties.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/output_propulsion.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/output_actuator.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/output_aerodynamics.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/interaction_force_moment_6dof.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/termination_state_metric.hpp`
- Create: `user/yyz_cartesian_6dof_framework_9/components/summary_basic_metrics.hpp`

- [x] Implement mass, propulsion, actuator, and aerodynamic providers with perturbation hooks and table-backed aerodynamic reference lookup.
- [x] Implement interaction that sums body forces/moments and passes gravity/mass/inertia to the form.
- [x] Implement project-owned termination and summary components for custom metrics.

### Task 5: Mission, Assets, And Documentation

**Files:**
- Create: `user/yyz_cartesian_6dof_framework_9/config/mission.json`
- Create: `user/yyz_cartesian_6dof_framework_9/config/fragments/environment.json`
- Create: `user/yyz_cartesian_6dof_framework_9/config/fragments/interceptor.json`
- Create: `user/yyz_cartesian_6dof_framework_9/config/fragments/target.json`
- Create: `user/yyz_cartesian_6dof_framework_9/data/aero_pitch_table.csv`
- Create: `user/yyz_cartesian_6dof_framework_9/data/aero_yaw_table.csv`
- Create: `user/yyz_cartesian_6dof_framework_9/data/aero_roll_table.csv`
- Create: `user/yyz_cartesian_6dof_framework_9/README.md`

- [x] Provide a detailed example mission with one interceptor and one minimal target.
- [x] Provide example flat-table aero assets.
- [x] Document the scenario-class boundary, file layout, component chain, plan coverage, asset contracts, and extension points.

### Task 6: Lightweight Verification

**Commands:**
- Configure: `cmake -S . -B build-mingw-yyz9 -G "MinGW Makefiles" -DBUILD_TESTS=OFF -DGNC_ACTIVE_PROJECT=yyz_cartesian_6dof_framework_9`
- Build: `cmake --build build-mingw-yyz9 -j 4`
- Register: `build-mingw-yyz9\bin\gnc_sim.exe --list-components-verbose`
- Run: `build-mingw-yyz9\bin\gnc_sim.exe --config user/yyz_cartesian_6dof_framework_9/config/mission.json`

- [x] Configure the active project.
- [x] Build the executable.
- [x] Confirm project components are registered.
- [x] Run the detailed example mission and confirm CSV/summary output is produced.

**Verification Evidence:**
- `cmake -S . -B build-mingw-yyz9 -G "MinGW Makefiles" -DBUILD_TESTS=OFF -DGNC_ACTIVE_PROJECT=yyz_cartesian_6dof_framework_9` completed with project component discovery enabled and 20 auto-registered component headers.
- `cmake --build build-mingw-yyz9 -j 4` completed with `Built target gnc_sim`.
- `build-mingw-yyz9\bin\gnc_sim.exe --list-components-verbose` listed all 20 `custom.*` project components; `custom.form.c6.rigid_body` and `custom.interaction.c6.force_moment` report form-family `yyz_c6`.
- `build-mingw-yyz9\bin\gnc_sim.exe --config user/yyz_cartesian_6dof_framework_9/config/mission.json` completed at `t=2 s` with termination reason `max_time_s`.
- Generated CSV: `user/outputs/yyz_cartesian_6dof_framework_9/2026-07-07_222921/trajectory_000001_case_000001.csv` with 101 data rows.
- Generated summary: `user/outputs/yyz_cartesian_6dof_framework_9/2026-07-07_222921/summary.txt`.
- Follow-up review updated the project namespace to `yyz_c6`, normalized aerodynamic coefficient names to `F_CA/F_CY/F_CN/M_Cl/M_Cm/M_Cn`, and added `TEMPLATE_GUIDE.md` plus code-level template extension markers.
- Follow-up design review added `SCENARIO_CONTRACT.md`, promoted the flat-table loader into a minimal asset contract, and changed `custom.output.c6.aerodynamics` from coefficient constants to three-channel table-backed nearest-node reference lookup.

## Template usability revision

The initial implementation is archived in Git commit `29fcc54`. The next
revision restructures the project for copy-first laboratory use:

- `config/assembly/` owns stable wiring and explicit intra-stage priorities.
- `config/parameters/` owns values that users normally tune.
- `project://` runtime asset roots remove copied-project path rewrites.
- `data/aero/<set>/` and perturbation enum maps demonstrate asset-set switching.
- `simflow/single.json`, `matrix.json`, and `random.json` provide ordinary
  single, matrix, and Monte Carlo entrypoints.
- `tools/New-YyzProject.ps1` creates a renamed project copy.
- `tools/Verify-Template.ps1` checks registration, nominal execution,
  materialization, and effective-mission replay.
- `ALGORITHM_SLOTS.md` identifies the reference algorithms users replace.
