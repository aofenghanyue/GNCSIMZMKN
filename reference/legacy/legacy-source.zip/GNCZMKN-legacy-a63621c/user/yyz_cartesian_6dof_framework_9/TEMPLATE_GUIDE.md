# YYZ Cartesian 6DoF 模板维护指南

本文说明复制项目后如何保持模板接线稳定，以及何时修改参数、资产、算法、接口和 assembly。

## 修改决策

| 变化 | 修改位置 |
| --- | --- |
| 步长、时长、输出、终止阈值 | `config/mission.json` |
| 初始状态和普通模型参数 | `config/parameters/` |
| 同格式资产内容 | `data/` |
| 算法内部实现 | 对应 `components/*.hpp` 的模板槽位 |
| 组件采样率、顺序、增删或 lookup | `config/assembly/` |
| provider 数据结构 | `interfaces/yyz_c6_types.hpp`、`interfaces/yyz_standard_trajectory.hpp` 及相关 producer/consumer |
| 新的批量变量 | `config/parameters/perturbation.json` 与 `simflow/*.json` |

## 三层配置

### `config/mission.json`

这是具体任务的短入口。它 include 完整 assembly，并覆盖任务级参数。常规仿真无需展开或复制整条组件链。

### `config/parameters/`

这里保存组件算法配置。文件按 environment、input、process、output 分类。参数文件只描述组件自身，lookup name 和 stage 顺序留在 assembly。

### `config/assembly/`

这里保存模板结构：组件 type id、name、placement、priority、rate 和依赖接线。普通调参保持这一层不动。组件结构发生变化时再进入这一层。

## 固定骨架

建议长期保留：

- form family `yyz_c6`。
- form 通过 `IInputProvider` 消费 interaction 输出。
- input、process、output 的 stage 边界。
- `target.truth -> target_manager` 的单一目标源。
- `actuator -> propulsion -> mass/aerodynamics -> interaction` 的 output 顺序。
- `vehicles[].perturbation` 作为运行时拉偏源。
- `standard_trajectory` 在 build-time preparation 中生成只读数据产品。
- form 与 `trajectory_planner` 通过 typed provider 读取标准轨迹处理结果。
- effective mission 作为单 case 复现入口。

接口可以包含参考算法暂时不用的字段。实验项目中保留少量冗余可以减少组件间的重复改造。

## Type id 规则

算法、参数或资产内容变化且 provider 兼容时，保留 type id。已有 mission、record 规则和分析工具可以直接复用。

以下变化建议新增 type id：

- 配置 schema 完全不同且旧 mission 无法继续使用。
- provider 数据结构或语义发生明显变化。
- mission placement 改变。
- form input 或 truth 契约整体变化。

## 组件顺序

同一个 process stage 内，模板用 priority 固定数据链：

```text
sequencer 0
navigation 10
trajectory_planner 15
target_manager 20
onboard_state 30
guidance 40
flight_control 50
control_allocation 60
```

output stage：

```text
actuator 0
propulsion 10
mass 20
aerodynamics 30
```

新增组件时给它分配明确 priority，避免依赖 JSON 数组的偶然顺序。跨 stage 顺序仍由框架固定。

## 资产集合

气动组件配置由两部分组成：

- `default_asset_root`：普通 mission 的名义集合。
- `asset_root_key`：从 perturbation 读取的资产集合键。

perturbation 的 `enum_maps` 把数值 case 输入映射成 `project://data/...`。这种形式允许 SimFlow 保持纯数值输入，同时让运行时组件加载字符串路径。

新资产格式仍可以沿用同一范式：

```text
numeric case value
-> enum_maps resolved string
-> component prepare()
-> asset loader
```

## 标准轨迹准备

模板把标准轨迹分成四层：

```text
SimFlow / perturbation: 选择当前 case 的源文件
-> common_standard_trajectory: 进入 prepare() 并管理缓存
-> StandardTrajectoryPreprocessor: 校验、切分、提取、追加派生列
-> IStandardTrajectoryProvider: 向 form 和 process 暴露只读内存产品
```

源 CSV 的全部列会保留。参考处理器要求位置、速度、姿态、角速度、时间和阶段列，并追加一组示例派生列。项目需要更多列时直接扩展 preprocessor；需要改变跨组件语义时再修改 `ProcessedStandardTrajectory`。

`config/parameters/initial_state.json` 默认只声明 `initial_state_source = standard_trajectory`，无需再维护一份重复状态。需要绕过标准轨迹时切换为 `config`，并在同一文件补充完整 `initial_state` 对象。

缓存键组合源文件指纹、processing profile、列配置和切分阈值。缓存项保持到当前进程结束，串行 case 可以直接复用；多进程 case 各自处理。有效 mission 保存源资产的固化路径和 case 输入，不保存处理后的大表。一次批量试验中的唯一轨迹/profile 组合数量应保持可控。

## SimFlow 扩展

模板提供：

- `simflow/single.json`：最小物化和回放验证。
- `simflow/matrix.json` + `cases.csv`：人工设计矩阵。
- `simflow/random.json`：固定 seed 的随机试验。

新增拉偏变量时同步更新三个位置：

1. `config/parameters/perturbation.json` 的名义值。
2. 使用该变量的组件配置或算法。
3. 对应 SimFlow 文件的 `inputs` 与 `vehicles.interceptor.inputs`。

## 复制检查清单

复制脚本完成后：

1. 修改 `project.json` 的说明文字。
2. 修改 `config/mission.json`。
3. 检查 `config/parameters/initial_state.json` 和 `target.json`。
4. 替换 `data/aero/` 与 `data/trajectory/` 资产。
5. 按 [ALGORITHM_SLOTS.md](ALGORITHM_SLOTS.md) 替换研究算法。
6. 检查 assembly 中的 `rate_hz` 与 `simulation.dt`。
7. 运行 `tools/Verify-Template.ps1`。

新增或删除 `components/*.hpp` 后，需要重新运行 CMake 配置，再重新构建。
