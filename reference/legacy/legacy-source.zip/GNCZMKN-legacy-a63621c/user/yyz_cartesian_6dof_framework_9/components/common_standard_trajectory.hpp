#pragma once

#include "interfaces/yyz_standard_trajectory.hpp"
#include "yyz_config_helpers.hpp"
#include "yyz_standard_trajectory_preprocessor.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/prepared_asset_cache.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/perturbation/interfaces/i_perturbation_provider.hpp"

#include <memory>
#include <stdexcept>
#include <string>

namespace yyz_c6::components {

class StandardTrajectoryCommon final
    : public gnc::core::SimulationNode,
      public yyz_c6::IStandardTrajectoryProvider,
      public gnc::interfaces::IObservable {
public:
    StandardTrajectoryCommon() : SimulationNode("YyzC6StandardTrajectoryCommon") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        source_file_key_ =
            reader.optionalString("source_file_key", source_file_key_);
        default_source_file_ = reader.requiredString("default_source_file");
        perturbation_lookup_name_ = reader.optionalString(
            "perturbation_lookup_name", perturbation_lookup_name_);
        options_.processing_profile = reader.optionalString(
            "processing_profile", options_.processing_profile);
        options_.time_column =
            reader.optionalString("time_column", options_.time_column);
        options_.phase_column =
            reader.optionalString("phase_column", options_.phase_column);
        options_.max_time_gap_s =
            reader.optionalDouble("max_time_gap_s", options_.max_time_gap_s);
        if (source_file_key_.empty() || options_.processing_profile.empty() ||
            options_.time_column.empty() || options_.phase_column.empty()) {
            throw std::runtime_error(
                config_path +
                " source_file_key, processing_profile, time_column and phase_column must be non-empty.");
        }
        if (options_.max_time_gap_s < 0.0) {
            throw std::runtime_error(config_path + ".max_time_gap_s must be >= 0.");
        }
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bindIfPresent(perturbation_,
                                                  perturbation_lookup_name_));
    }

    void prepare(const gnc::core::PreparationContext& context) override {
        const std::string selected_source =
            perturbation_ ? perturbation_->getString(source_file_key_,
                                                       default_source_file_)
                          : default_source_file_;
        const auto source_file = context.paths().requireRegularFile(
            selected_source, "Standard trajectory");
        const std::string fingerprint = context.paths().fingerprint(source_file);
        const std::string cache_key = fingerprint + "|" +
                                      options_.processing_profile + "|" +
                                      options_.time_column + "|" +
                                      options_.phase_column + "|" +
                                      std::to_string(options_.max_time_gap_s);
        trajectory_ = gnc::core::PreparedAssetCache::getOrCreate<
            ProcessedStandardTrajectory>(cache_key, [&] {
            return StandardTrajectoryPreprocessor::process(
                source_file, fingerprint, options_);
        });
    }

    void initialize() override {
        if (!trajectory_) {
            throw std::runtime_error(
                "Standard trajectory data was not prepared before initialize().");
        }
    }

    std::shared_ptr<const ProcessedStandardTrajectory>
    standardTrajectory() const override {
        return trajectory_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("row_count", [this]() {
            return trajectory_ ? static_cast<double>(trajectory_->rowCount()) : 0.0;
        });
        builder.addScalar("column_count", [this]() {
            return trajectory_ ? static_cast<double>(trajectory_->columnCount()) : 0.0;
        });
        builder.addScalar("segment_count", [this]() {
            return trajectory_ ? static_cast<double>(trajectory_->segments().size()) : 0.0;
        });
        builder.addScalar("begin_time_s", [this]() {
            return trajectory_ ? trajectory_->beginTime() : 0.0;
        });
        builder.addScalar("end_time_s", [this]() {
            return trajectory_ ? trajectory_->endTime() : 0.0;
        });
        builder.addVector3("initial_position_launch", [this]() -> const gnc::math::Vector3& {
            return trajectory_->initialState().position_launch_m;
        });
        return builder.build();
    }

private:
    gnc::perturbation::IPerturbationProvider* perturbation_ = nullptr;
    std::string perturbation_lookup_name_ = "perturbation";
    std::string source_file_key_ = "trajectory.asset_set.resolved";
    std::string default_source_file_;
    StandardTrajectoryProcessingOptions options_{};
    std::shared_ptr<const ProcessedStandardTrajectory> trajectory_;
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.common.c6.standard_trajectory",
    yyz_c6::components::StandardTrajectoryCommon,
    ::gnc::core::NodeRole::Asset,
    ::gnc::core::DiscretePhase::None,
    yyz_c6::kFormFamily,
    ::yyz_c6::IStandardTrajectoryProvider,
    ::gnc::interfaces::IObservable)
