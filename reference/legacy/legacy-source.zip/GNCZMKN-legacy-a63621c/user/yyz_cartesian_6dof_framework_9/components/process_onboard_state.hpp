#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <string>

// TEMPLATE REFERENCE SLOT: custom.process.c6.onboard_state.
// Replace update() when onboard derived states need project-specific logic.
namespace yyz_c6::components {

class OnboardStateProcess final : public gnc::core::DiscreteNode,
                                  public yyz_c6::IOnboardStateProvider,
                                  public gnc::interfaces::IObservable {
public:
    OnboardStateProcess() : DiscreteNode("YyzC6OnboardStateProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        navigation_lookup_name_ =
            reader.optionalString("navigation_lookup_name",
                                  navigation_lookup_name_);
        air_data_lookup_name_ =
            reader.optionalString("air_data_lookup_name", air_data_lookup_name_);
        phase_lookup_name_ =
            reader.optionalString("phase_lookup_name", phase_lookup_name_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(navigation_, navigation_lookup_name_),
                         gnc::core::bindIfPresent(air_data_,
                                                  air_data_lookup_name_),
                         gnc::core::bindIfPresent(phase_, phase_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        state_.navigation = navigation_->navigationSolution();
        if (air_data_) {
            state_.air_data = air_data_->airDataMeasurement();
        }
        if (phase_) {
            state_.phase = phase_->phaseState();
        }
    }

    const OnboardState& onboardState() const override { return state_; }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("altitude_m",
                          [this]() { return state_.navigation.altitude_m; });
        builder.addScalar("speed_mps",
                          [this]() { return state_.navigation.speed_mps; });
        builder.addScalar("mach_number",
                          [this]() { return state_.air_data.mach_number; });
        builder.addScalar("dynamic_pressure_pa",
                          [this]() { return state_.air_data.dynamic_pressure_pa; });
        builder.addScalar("alpha_rad",
                          [this]() { return state_.air_data.alpha_rad; });
        builder.addScalar("beta_rad",
                          [this]() { return state_.air_data.beta_rad; });
        builder.addScalar("phase_index", [this]() {
            return static_cast<double>(state_.phase.phase_index);
        });
        return builder.build();
    }

private:
    yyz_c6::INavigationProvider* navigation_ = nullptr;
    yyz_c6::IAirDataProvider* air_data_ = nullptr;
    yyz_c6::IPhaseProvider* phase_ = nullptr;
    std::string navigation_lookup_name_ = "navigation";
    std::string air_data_lookup_name_ = "air_data";
    std::string phase_lookup_name_ = "sequencer";
    OnboardState state_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.onboard_state",
    yyz_c6::components::OnboardStateProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::IOnboardStateProvider,
    ::gnc::interfaces::IObservable)
