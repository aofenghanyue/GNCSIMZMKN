#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "interfaces/yyz_standard_trajectory.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/core/state_layout.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_continuous_system.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <cmath>
#include <string>

// TEMPLATE CONTRACT SLOT: custom.form.c6.rigid_body.
// Keep the type id and yyz_c6::ITruthView contract when only the equations
// change. Create a new form component when the state layout or form input
// contract changes.
namespace yyz_c6::components {

class RigidBodyForm6Dof final : public gnc::core::SimulationNode,
                                public gnc::core::IPublishTask,
                                public gnc::interfaces::IContinuousSystem,
                                public yyz_c6::ITruthView,
                                public gnc::interfaces::IObservable {
public:
    RigidBodyForm6Dof() : SimulationNode("YyzC6RigidBodyForm") {
        position_x_index_ = layout_.addVariable("position_launch_x_m");
        position_y_index_ = layout_.addVariable("position_launch_y_m");
        position_z_index_ = layout_.addVariable("position_launch_z_m");
        velocity_x_index_ = layout_.addVariable("velocity_launch_x_mps");
        velocity_y_index_ = layout_.addVariable("velocity_launch_y_mps");
        velocity_z_index_ = layout_.addVariable("velocity_launch_z_mps");
        q_w_index_ = layout_.addVariable("q_body_to_inertial_w");
        q_x_index_ = layout_.addVariable("q_body_to_inertial_x");
        q_y_index_ = layout_.addVariable("q_body_to_inertial_y");
        q_z_index_ = layout_.addVariable("q_body_to_inertial_z");
        omega_x_index_ = layout_.addVariable("angular_rate_body_x_radps");
        omega_y_index_ = layout_.addVariable("angular_rate_body_y_radps");
        omega_z_index_ = layout_.addVariable("angular_rate_body_z_radps");
        state_vector_ = Eigen::VectorXd::Zero(layout_.dimension());
        initial_state_vector_ = state_vector_;
    }

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        input_lookup_name_ =
            reader.optionalString("input_lookup_name", input_lookup_name_);
        initial_state_source_ = reader.optionalString(
            "initial_state_source", initial_state_source_);
        standard_trajectory_lookup_name_ = reader.optionalString(
            "standard_trajectory_lookup_name",
            standard_trajectory_lookup_name_);
        if (initial_state_source_ != "config" &&
            initial_state_source_ != "standard_trajectory") {
            throw std::runtime_error(
                config_path +
                ".initial_state_source must be 'config' or 'standard_trajectory'.");
        }

        if (reader.has("initial_state")) {
            const auto initial_reader = reader.requiredObject("initial_state");
            RigidBodyState initial;
            initial.position_launch_m = config::toVector3(
                initial_reader.requiredDoubleArray("position_launch_m", 3));
            initial.velocity_launch_mps = config::toVector3(
                initial_reader.requiredDoubleArray("velocity_launch_mps", 3));
            initial.attitude_body_to_inertial = config::toQuaternion(
                initial_reader.requiredDoubleArray("attitude_body_to_inertial", 4),
                config_path + ".initial_state.attitude_body_to_inertial");
            initial.angular_rate_body_radps = config::toVector3(
                initial_reader.requiredDoubleArray("angular_rate_body_radps", 3));
            config::warnUnknownKeys(config["initial_state"],
                                    config_path + ".initial_state");
            packState(initial, initial_state_vector_);
            state_vector_ = initial_state_vector_;
        } else if (initial_state_source_ == "config") {
            throw std::runtime_error(
                config_path +
                ".initial_state is required when initial_state_source is 'config'.");
        }
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(input_provider_, input_lookup_name_));
        if (initial_state_source_ == "standard_trajectory") {
            standard_trajectory_ =
                registry.requireByName<IStandardTrajectoryProvider>(
                    standard_trajectory_lookup_name_);
        }
    }

    void initialize() override {
        if (initial_state_source_ == "standard_trajectory") {
            const auto trajectory = standard_trajectory_->standardTrajectory();
            if (!trajectory) {
                throw std::runtime_error(
                    "Rigid-body form received an empty prepared standard trajectory.");
            }
            // TEMPLATE ALGORITHM SLOT: a concrete project may derive the launch
            // state from several rows or processed metadata. The reference
            // template uses the product's extracted initial state.
            packState(trajectory->initialState(), initial_state_vector_);
            state_vector_ = initial_state_vector_;
        }
        publish({0.0, 0});
    }

    gnc::core::PublishPhase publishPhase() const override {
        return gnc::core::PublishPhase::StateOwner;
    }

    void publish(const gnc::core::PublishContext& context) override {
        const double time = context.time_s;
        const auto state = unpackState(state_vector_);
        const auto base_truth = truthFromState(state, {}, time);
        const auto input = input_provider_->computeYyzC6Input(base_truth, time);
        truth_ = truthFromState(state, input, time);
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }

    void computeDerivatives(double time,
                            const Eigen::VectorXd& state_vector,
                            Eigen::VectorXd& derivative_vector) const override {
        derivative_vector = Eigen::VectorXd::Zero(layout_.dimension());
        const auto state = unpackState(state_vector);
        const auto base_truth = truthFromState(state, {}, time);
        const auto input = input_provider_->computeYyzC6Input(base_truth, time);

        const double mass_kg = std::max(1.0e-9, input.mass.mass_kg);
        const gnc::math::Vector3 force_launch_n =
            state.attitude_body_to_inertial * input.total_force_body_n;
        const gnc::math::Vector3 acceleration_launch_mps2 =
            force_launch_n / mass_kg + input.gravity_launch_mps2;

        const gnc::math::Matrix3 inertia = regularizedInertia(
            input.mass.inertia_body_kgm2);
        const gnc::math::Vector3 angular_momentum =
            inertia * state.angular_rate_body_radps;
        const gnc::math::Vector3 angular_acceleration =
            inertia.inverse() *
            (input.total_moment_body_nm -
             state.angular_rate_body_radps.cross(angular_momentum));

        derivative_vector[position_x_index_] = state.velocity_launch_mps.x();
        derivative_vector[position_y_index_] = state.velocity_launch_mps.y();
        derivative_vector[position_z_index_] = state.velocity_launch_mps.z();
        derivative_vector[velocity_x_index_] = acceleration_launch_mps2.x();
        derivative_vector[velocity_y_index_] = acceleration_launch_mps2.y();
        derivative_vector[velocity_z_index_] = acceleration_launch_mps2.z();

        const Eigen::Quaterniond omega_q(0.0,
                                         state.angular_rate_body_radps.x(),
                                         state.angular_rate_body_radps.y(),
                                         state.angular_rate_body_radps.z());
        const Eigen::Quaterniond q_dot =
            state.attitude_body_to_inertial * omega_q;
        derivative_vector[q_w_index_] = 0.5 * q_dot.w();
        derivative_vector[q_x_index_] = 0.5 * q_dot.x();
        derivative_vector[q_y_index_] = 0.5 * q_dot.y();
        derivative_vector[q_z_index_] = 0.5 * q_dot.z();
        derivative_vector[omega_x_index_] = angular_acceleration.x();
        derivative_vector[omega_y_index_] = angular_acceleration.y();
        derivative_vector[omega_z_index_] = angular_acceleration.z();
    }

    const Eigen::VectorXd& getState() const override { return state_vector_; }

    void setState(const Eigen::VectorXd& state) override {
        state_vector_ = state;
        normalizeStateQuaternion(state_vector_);
    }

    Eigen::VectorXd getInitialState() const override {
        return initial_state_vector_;
    }

    const Truth& yyzC6Truth() const override { return truth_; }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("position_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.state.position_launch_m;
                           });
        builder.addVector3("velocity_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.state.velocity_launch_mps;
                           });
        builder.addQuaternion("attitude_body_to_inertial",
                              [this]() -> const Eigen::Quaterniond& {
                                  return truth_.state.attitude_body_to_inertial;
                              });
        builder.addVector3("angular_rate_body",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.state.angular_rate_body_radps;
                           });
        builder.addVector3("acceleration_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.acceleration_launch_mps2;
                           });
        builder.addVector3("specific_force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.specific_force_body_mps2;
                           });
        builder.addVector3("angular_acceleration_body",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.angular_acceleration_body_radps2;
                           });
        builder.addVector3("gravity_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return truth_.gravity_launch_mps2;
                           });
        builder.addScalar("altitude_m", [this]() {
            return truth_.state.position_launch_m.z();
        });
        builder.addScalar("speed_mps", [this]() {
            return truth_.state.velocity_launch_mps.norm();
        });
        return builder.build();
    }

private:
    RigidBodyState unpackState(const Eigen::VectorXd& state_vector) const {
        RigidBodyState state;
        state.position_launch_m = gnc::math::Vector3(
            state_vector[position_x_index_],
            state_vector[position_y_index_],
            state_vector[position_z_index_]);
        state.velocity_launch_mps = gnc::math::Vector3(
            state_vector[velocity_x_index_],
            state_vector[velocity_y_index_],
            state_vector[velocity_z_index_]);
        state.attitude_body_to_inertial =
            Eigen::Quaterniond(state_vector[q_w_index_],
                               state_vector[q_x_index_],
                               state_vector[q_y_index_],
                               state_vector[q_z_index_]);
        normalize(state.attitude_body_to_inertial);
        state.angular_rate_body_radps =
            gnc::math::Vector3(state_vector[omega_x_index_],
                               state_vector[omega_y_index_],
                               state_vector[omega_z_index_]);
        return state;
    }

    void packState(const RigidBodyState& state,
                   Eigen::VectorXd& state_vector) const {
        Eigen::Quaterniond q = state.attitude_body_to_inertial;
        normalize(q);
        state_vector = Eigen::VectorXd::Zero(layout_.dimension());
        state_vector[position_x_index_] = state.position_launch_m.x();
        state_vector[position_y_index_] = state.position_launch_m.y();
        state_vector[position_z_index_] = state.position_launch_m.z();
        state_vector[velocity_x_index_] = state.velocity_launch_mps.x();
        state_vector[velocity_y_index_] = state.velocity_launch_mps.y();
        state_vector[velocity_z_index_] = state.velocity_launch_mps.z();
        state_vector[q_w_index_] = q.w();
        state_vector[q_x_index_] = q.x();
        state_vector[q_y_index_] = q.y();
        state_vector[q_z_index_] = q.z();
        state_vector[omega_x_index_] = state.angular_rate_body_radps.x();
        state_vector[omega_y_index_] = state.angular_rate_body_radps.y();
        state_vector[omega_z_index_] = state.angular_rate_body_radps.z();
    }

    Truth truthFromState(const RigidBodyState& state,
                         const FormInput& input,
                         double time_s) const {
        Truth truth;
        truth.state = state;
        truth.sample_time_s = time_s;
        truth.gravity_launch_mps2 = input.gravity_launch_mps2;
        const double mass_kg = std::max(1.0e-9, input.mass.mass_kg);
        truth.specific_force_body_mps2 = input.total_force_body_n / mass_kg;
        truth.acceleration_launch_mps2 =
            state.attitude_body_to_inertial * truth.specific_force_body_mps2 +
            input.gravity_launch_mps2;
        const auto inertia = regularizedInertia(input.mass.inertia_body_kgm2);
        truth.angular_acceleration_body_radps2 =
            inertia.inverse() * input.total_moment_body_nm;
        return truth;
    }

    static gnc::math::Matrix3 regularizedInertia(gnc::math::Matrix3 inertia) {
        for (int i = 0; i < 3; ++i) {
            if (std::abs(inertia(i, i)) < 1.0e-9) {
                inertia(i, i) = 1.0;
            }
        }
        return inertia;
    }

    static void normalize(Eigen::Quaterniond& q) {
        if (!std::isfinite(q.norm()) || q.norm() == 0.0) {
            q = Eigen::Quaterniond::Identity();
        } else {
            q.normalize();
        }
    }

    void normalizeStateQuaternion(Eigen::VectorXd& state_vector) const {
        Eigen::Quaterniond q(state_vector[q_w_index_],
                             state_vector[q_x_index_],
                             state_vector[q_y_index_],
                             state_vector[q_z_index_]);
        normalize(q);
        state_vector[q_w_index_] = q.w();
        state_vector[q_x_index_] = q.x();
        state_vector[q_y_index_] = q.y();
        state_vector[q_z_index_] = q.z();
    }

    gnc::core::StateLayout layout_;
    Eigen::VectorXd state_vector_;
    Eigen::VectorXd initial_state_vector_;
    yyz_c6::IInputProvider* input_provider_ = nullptr;
    yyz_c6::IStandardTrajectoryProvider* standard_trajectory_ = nullptr;
    std::string input_lookup_name_ = "interaction";
    std::string initial_state_source_ = "config";
    std::string standard_trajectory_lookup_name_ = "standard_trajectory";
    Truth truth_{};
    int position_x_index_ = -1;
    int position_y_index_ = -1;
    int position_z_index_ = -1;
    int velocity_x_index_ = -1;
    int velocity_y_index_ = -1;
    int velocity_z_index_ = -1;
    int q_w_index_ = -1;
    int q_x_index_ = -1;
    int q_y_index_ = -1;
    int q_z_index_ = -1;
    int omega_x_index_ = -1;
    int omega_y_index_ = -1;
    int omega_z_index_ = -1;
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.form.c6.rigid_body",
    yyz_c6::components::RigidBodyForm6Dof,
    ::gnc::core::NodeRole::Form,
    ::gnc::core::DiscretePhase::None,
    yyz_c6::kFormFamily,
    ::gnc::interfaces::IContinuousSystem,
    ::yyz_c6::ITruthView,
    ::gnc::interfaces::IObservable)
