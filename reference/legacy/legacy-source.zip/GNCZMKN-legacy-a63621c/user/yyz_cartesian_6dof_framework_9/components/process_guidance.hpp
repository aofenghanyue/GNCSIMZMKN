#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.process.c6.guidance.
// Replace update() with the concrete guidance law while keeping
// yyz_c6::GuidanceCommand stable for downstream control.
namespace yyz_c6::components {

class GuidanceProcess final : public gnc::core::DiscreteNode,
                              public yyz_c6::IGuidanceProvider,
                              public gnc::interfaces::IObservable {
public:
    GuidanceProcess() : DiscreteNode("YyzC6GuidanceProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        navigation_lookup_name_ =
            reader.optionalString("navigation_lookup_name",
                                  navigation_lookup_name_);
        target_lookup_name_ =
            reader.optionalString("target_lookup_name", target_lookup_name_);
        onboard_state_lookup_name_ =
            reader.optionalString("onboard_state_lookup_name",
                                  onboard_state_lookup_name_);
        command_.command_mode = reader.optionalInt("command_mode",
                                                   command_.command_mode);
        command_.desired_euler_rad = config::toVector3(
            reader.optionalDoubleArray("desired_euler_rad",
                                       {0.0, 0.0, 0.0},
                                       3));
        base_desired_force_body_n_ = config::toVector3(
            reader.optionalDoubleArray("desired_force_body_n",
                                       {0.0, 0.0, 0.0},
                                       3));
        line_of_sight_force_gain_n_ =
            reader.optionalDouble("line_of_sight_force_gain_n",
                                  line_of_sight_force_gain_n_);
        command_.fuel_command =
            reader.optionalDouble("fuel_command", command_.fuel_command);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(navigation_, navigation_lookup_name_),
                         gnc::core::bind(target_, target_lookup_name_),
                         gnc::core::bindIfPresent(onboard_state_,
                                                  onboard_state_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& nav = navigation_->navigationSolution();
        const auto& target = target_->targetState();
        const gnc::math::Vector3 los =
            target.position_launch_m - nav.position_launch_m;
        const double range_m = std::max(1.0e-9, los.norm());
        const gnc::math::Vector3 los_unit_launch = los / range_m;
        const gnc::math::Vector3 los_unit_body =
            nav.attitude_body_to_inertial.inverse() * los_unit_launch;

        command_.desired_force_body_n =
            base_desired_force_body_n_ +
            line_of_sight_force_gain_n_ * los_unit_body;

        const auto euler = nav.attitude_body_to_inertial.toRotationMatrix()
                               .eulerAngles(0, 1, 2);
        const gnc::math::Vector3 current_euler_rad(euler.x(), euler.y(), euler.z());
        command_.attitude_error_rad =
            command_.desired_euler_rad - current_euler_rad;
        if (onboard_state_) {
            command_.actual_force_body_n =
                gnc::math::Vector3(0.0,
                                   0.0,
                                   onboard_state_->onboardState()
                                       .air_data.dynamic_pressure_pa);
        }
    }

    const GuidanceCommand& guidanceCommand() const override {
        return command_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("command_mode",
                          [this]() { return static_cast<double>(command_.command_mode); });
        builder.addVector3("desired_euler",
                           [this]() -> const gnc::math::Vector3& {
                               return command_.desired_euler_rad;
                           });
        builder.addVector3("attitude_error",
                           [this]() -> const gnc::math::Vector3& {
                               return command_.attitude_error_rad;
                           });
        builder.addVector3("desired_force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return command_.desired_force_body_n;
                           });
        builder.addVector3("actual_force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return command_.actual_force_body_n;
                           });
        builder.addScalar("fuel_command",
                          [this]() { return command_.fuel_command; });
        return builder.build();
    }

private:
    yyz_c6::INavigationProvider* navigation_ = nullptr;
    yyz_c6::ITargetProvider* target_ = nullptr;
    yyz_c6::IOnboardStateProvider* onboard_state_ = nullptr;
    std::string navigation_lookup_name_ = "navigation";
    std::string target_lookup_name_ = "target_manager";
    std::string onboard_state_lookup_name_ = "onboard_state";
    GuidanceCommand command_{};
    gnc::math::Vector3 base_desired_force_body_n_ =
        gnc::math::Vector3::Zero();
    double line_of_sight_force_gain_n_ = 0.0;
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.guidance",
    yyz_c6::components::GuidanceProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::IGuidanceProvider,
    ::gnc::interfaces::IObservable)
