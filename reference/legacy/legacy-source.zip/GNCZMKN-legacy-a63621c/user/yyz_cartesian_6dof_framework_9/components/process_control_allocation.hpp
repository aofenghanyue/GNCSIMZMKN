#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.process.c6.control_allocation.
// Replace update() when the actuator set or allocation method changes.
namespace yyz_c6::components {

class ControlAllocationProcess final
    : public gnc::core::DiscreteNode,
      public yyz_c6::IControlAllocationProvider,
      public gnc::interfaces::IObservable {
public:
    ControlAllocationProcess()
        : DiscreteNode("YyzC6ControlAllocationProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        flight_control_lookup_name_ =
            reader.optionalString("flight_control_lookup_name",
                                  flight_control_lookup_name_);
        deflection_limit_rad_ = config::toVector3(
            reader.optionalDoubleArray("deflection_limit_rad",
                                       {0.5, 0.5, 0.5},
                                       3));
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(flight_control_,
                                         flight_control_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& command = flight_control_->flightControlCommand();
        for (int i = 0; i < 3; ++i) {
            const double limit = std::max(0.0, deflection_limit_rad_[i]);
            allocation_.fin_deflection_command_rad[i] =
                std::clamp(command.raw_actuator_command_rad[i], -limit, limit);
        }
        allocation_.throttle_command =
            std::clamp(command.throttle_command, 0.0, 1.0);
    }

    const ControlAllocationCommand& controlAllocationCommand() const override {
        return allocation_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("fin_deflection_command",
                           [this]() -> const gnc::math::Vector3& {
                               return allocation_.fin_deflection_command_rad;
                           });
        builder.addScalar("throttle_command",
                          [this]() { return allocation_.throttle_command; });
        return builder.build();
    }

private:
    yyz_c6::IFlightControlProvider* flight_control_ = nullptr;
    std::string flight_control_lookup_name_ = "flight_control";
    gnc::math::Vector3 deflection_limit_rad_ =
        gnc::math::Vector3(0.5, 0.5, 0.5);
    ControlAllocationCommand allocation_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.control_allocation",
    yyz_c6::components::ControlAllocationProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::IControlAllocationProvider,
    ::gnc::interfaces::IObservable)
