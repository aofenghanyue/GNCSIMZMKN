#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_manager.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <stdexcept>
#include <string>
#include <vector>

// TEMPLATE REFERENCE SLOT: custom.process.c6.sequencer.
// Replace update() with the project-specific component-local state machine.
namespace yyz_c6::components {

class SequencerProcess final : public gnc::core::DiscreteNode,
                               public yyz_c6::IPhaseProvider,
                               public gnc::interfaces::IObservable {
public:
    SequencerProcess() : DiscreteNode("YyzC6SequencerProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        phases_.clear();
        const auto& phases = config["phases"];
        if (phases.isNull()) {
            phases_.push_back({"init", -1.0});
        } else {
            if (!phases.isArray() || phases.size() == 0) {
                throw std::runtime_error(config_path +
                                         ".phases must be a non-empty array.");
            }
            for (size_t i = 0; i < phases.size(); ++i) {
                const auto& item = phases[i];
                if (!item.isObject()) {
                    throw std::runtime_error(config_path + ".phases[" +
                                             std::to_string(i) +
                                             "] must be an object.");
                }
                const auto& name = item["name"];
                if (!name.isString() || name.asString().empty()) {
                    throw std::runtime_error(config_path + ".phases[" +
                                             std::to_string(i) +
                                             "].name must be a non-empty string.");
                }
                const auto& duration = item["duration_s"];
                double duration_s = -1.0;
                if (!duration.isNull()) {
                    if (!duration.isNumber()) {
                        throw std::runtime_error(config_path + ".phases[" +
                                                 std::to_string(i) +
                                                 "].duration_s must be a number.");
                    }
                    duration_s = duration.asDouble();
                }
                phases_.push_back({name.asString(), duration_s});
            }
        }
        config::warnUnknownKeys(config, config_path);
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const double time_s = context.time_s;
        double phase_start_s = 0.0;
        int active_index = static_cast<int>(phases_.size()) - 1;

        for (size_t i = 0; i < phases_.size(); ++i) {
            const double duration_s = phases_[i].duration_s;
            if (duration_s < 0.0 || time_s < phase_start_s + duration_s ||
                i + 1 == phases_.size()) {
                active_index = static_cast<int>(i);
                break;
            }
            phase_start_s += duration_s;
        }

        state_.phase_index = active_index;
        state_.phase_name = phases_[static_cast<size_t>(active_index)].name;
        state_.mission_time_s = time_s;
        state_.phase_elapsed_time_s = time_s - phase_start_s;
    }

    const PhaseState& phaseState() const override { return state_; }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("phase_index",
                          [this]() { return static_cast<double>(state_.phase_index); });
        builder.addScalar("mission_time_s",
                          [this]() { return state_.mission_time_s; });
        builder.addScalar("phase_elapsed_time_s",
                          [this]() { return state_.phase_elapsed_time_s; });
        return builder.build();
    }

private:
    struct PhaseConfig {
        std::string name;
        double duration_s = -1.0;
    };

    std::vector<PhaseConfig> phases_{{"init", -1.0}};
    PhaseState state_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.sequencer",
    yyz_c6::components::SequencerProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::IPhaseProvider,
    ::gnc::interfaces::IObservable)
