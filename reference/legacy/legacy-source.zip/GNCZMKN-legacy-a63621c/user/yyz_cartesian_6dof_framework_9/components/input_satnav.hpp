#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <string>

// TEMPLATE REFERENCE SLOT: custom.input.c6.satnav.
// Replace update() with the concrete satellite navigation measurement model.
namespace yyz_c6::components {

class SatelliteNavInput final : public gnc::core::DiscreteNode,
                                public yyz_c6::ISatelliteNavProvider,
                                public gnc::interfaces::IObservable {
public:
    SatelliteNavInput() : DiscreteNode("YyzC6SatelliteNavInput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        truth_lookup_name_ =
            reader.optionalString("truth_lookup_name", truth_lookup_name_);
        position_bias_launch_m_ = config::toVector3(
            reader.optionalDoubleArray("position_bias_launch_m",
                                       {0.0, 0.0, 0.0},
                                       3));
        velocity_bias_launch_mps_ = config::toVector3(
            reader.optionalDoubleArray("velocity_bias_launch_mps",
                                       {0.0, 0.0, 0.0},
                                       3));
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(truth_, truth_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& truth = truth_->yyzC6Truth();
        measurement_.position_launch_m =
            truth.state.position_launch_m + position_bias_launch_m_;
        measurement_.velocity_launch_mps =
            truth.state.velocity_launch_mps + velocity_bias_launch_mps_;
        measurement_.attitude_body_to_inertial =
            truth.state.attitude_body_to_inertial;
        measurement_.sample_time_s = truth.sample_time_s;
    }

    const SatelliteNavMeasurement& satelliteNavMeasurement() const override {
        return measurement_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("position_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.position_launch_m;
                           });
        builder.addVector3("velocity_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.velocity_launch_mps;
                           });
        builder.addQuaternion("attitude_body_to_inertial",
                              [this]() -> const Eigen::Quaterniond& {
                                  return measurement_.attitude_body_to_inertial;
                              });
        builder.addScalar("sample_time_s",
                          [this]() { return measurement_.sample_time_s; });
        return builder.build();
    }

private:
    yyz_c6::ITruthView* truth_ = nullptr;
    std::string truth_lookup_name_ = "dynamics";
    gnc::math::Vector3 position_bias_launch_m_ = gnc::math::Vector3::Zero();
    gnc::math::Vector3 velocity_bias_launch_mps_ = gnc::math::Vector3::Zero();
    SatelliteNavMeasurement measurement_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.input.c6.satnav",
    yyz_c6::components::SatelliteNavInput,
    ::gnc::core::NodeRole::Input,
    ::gnc::core::DiscretePhase::Input,
    "",
    ::yyz_c6::ISatelliteNavProvider,
    ::gnc::interfaces::IObservable)
