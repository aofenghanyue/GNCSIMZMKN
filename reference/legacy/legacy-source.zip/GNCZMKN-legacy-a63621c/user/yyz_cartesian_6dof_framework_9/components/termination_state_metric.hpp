#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/interfaces/i_termination_evaluator.hpp"

#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.termination.c6.state_metric.
// Replace shouldTerminate() with project-specific terminal event logic.
namespace yyz_c6::components {

class StateMetricTermination final
    : public gnc::core::SimulationNode,
      public gnc::interfaces::ITerminationEvaluator {
public:
    StateMetricTermination() : SimulationNode("YyzC6StateMetricTermination") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        truth_lookup_name_ =
            reader.optionalString("truth_lookup_name", truth_lookup_name_);
        target_lookup_name_ =
            reader.optionalString("target_lookup_name", target_lookup_name_);
        max_time_s_ = reader.optionalDouble("max_time_s", max_time_s_);
        min_altitude_m_ =
            reader.optionalDouble("min_altitude_m", min_altitude_m_);
        min_speed_mps_ = reader.optionalDouble("min_speed_mps", min_speed_mps_);
        hit_range_m_ = reader.optionalDouble("hit_range_m", hit_range_m_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& context) override {
        truth_ = context.requireByName<yyz_c6::ITruthView>(truth_lookup_name_);
        if (!target_lookup_name_.empty()) {
            target_ = context.tryGetByName<yyz_c6::ITargetProvider>(
                target_lookup_name_);
        }
    }

    bool shouldTerminate() const override {
        const auto& truth = truth_->yyzC6Truth();
        if (truth.sample_time_s >= max_time_s_) {
            reason_ = "max_time_s";
            return true;
        }
        if (truth.state.position_launch_m.z() <= min_altitude_m_) {
            reason_ = "min_altitude_m";
            return true;
        }
        if (truth.state.velocity_launch_mps.norm() <= min_speed_mps_) {
            reason_ = "min_speed_mps";
            return true;
        }
        if (target_) {
            const double range_m =
                (target_->targetState().position_launch_m -
                 truth.state.position_launch_m)
                    .norm();
            if (range_m <= hit_range_m_) {
                reason_ = "hit_range_m";
                return true;
            }
        }
        reason_ = "running";
        return false;
    }

    std::string reason() const override { return reason_; }

private:
    yyz_c6::ITruthView* truth_ = nullptr;
    yyz_c6::ITargetProvider* target_ = nullptr;
    std::string truth_lookup_name_ = "interceptor.dynamics";
    std::string target_lookup_name_ = "interceptor.target_manager";
    double max_time_s_ = std::numeric_limits<double>::infinity();
    double min_altitude_m_ = -std::numeric_limits<double>::infinity();
    double min_speed_mps_ = -std::numeric_limits<double>::infinity();
    double hit_range_m_ = -std::numeric_limits<double>::infinity();
    mutable std::string reason_ = "running";
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.termination.c6.state_metric",
    yyz_c6::components::StateMetricTermination,
    ::gnc::core::NodeRole::Termination,
    ::gnc::core::DiscretePhase::None,
    "",
    ::gnc::interfaces::ITerminationEvaluator)
