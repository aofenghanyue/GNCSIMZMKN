#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <string>

// TEMPLATE REFERENCE SLOT: custom.input.c6.imu.
// Replace update() with the concrete sensor error, delay, and sampling model.
namespace yyz_c6::components {

class ImuInput final : public gnc::core::DiscreteNode,
                       public yyz_c6::IImuProvider,
                       public gnc::interfaces::IObservable {
public:
    ImuInput() : DiscreteNode("YyzC6ImuInput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        truth_lookup_name_ =
            reader.optionalString("truth_lookup_name", truth_lookup_name_);
        specific_force_bias_body_mps2_ = config::toVector3(
            reader.optionalDoubleArray("specific_force_bias_body_mps2",
                                       {0.0, 0.0, 0.0},
                                       3));
        gyro_bias_body_radps_ = config::toVector3(
            reader.optionalDoubleArray("gyro_bias_body_radps",
                                       {0.0, 0.0, 0.0},
                                       3));
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(truth_, truth_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& truth = truth_->yyzC6Truth();
        measurement_.specific_force_body_mps2 =
            truth.specific_force_body_mps2 + specific_force_bias_body_mps2_;
        measurement_.angular_rate_body_radps =
            truth.state.angular_rate_body_radps + gyro_bias_body_radps_;
        measurement_.angular_acceleration_body_radps2 =
            truth.angular_acceleration_body_radps2;
    }

    const ImuMeasurement& imuMeasurement() const override {
        return measurement_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("specific_force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.specific_force_body_mps2;
                           });
        builder.addVector3("angular_rate_body",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.angular_rate_body_radps;
                           });
        builder.addVector3("angular_acceleration_body",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.angular_acceleration_body_radps2;
                           });
        return builder.build();
    }

private:
    yyz_c6::ITruthView* truth_ = nullptr;
    std::string truth_lookup_name_ = "dynamics";
    gnc::math::Vector3 specific_force_bias_body_mps2_ =
        gnc::math::Vector3::Zero();
    gnc::math::Vector3 gyro_bias_body_radps_ = gnc::math::Vector3::Zero();
    ImuMeasurement measurement_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.input.c6.imu",
    yyz_c6::components::ImuInput,
    ::gnc::core::NodeRole::Input,
    ::gnc::core::DiscretePhase::Input,
    "",
    ::yyz_c6::IImuProvider,
    ::gnc::interfaces::IObservable)
