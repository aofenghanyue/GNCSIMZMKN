#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <string>

// TEMPLATE CONTRACT SLOT: custom.interaction.c6.force_moment.
// Replace coordinate/closure details here when the force, moment, or gravity
// convention changes, while keeping yyz_c6::IInputProvider for the form.
namespace yyz_c6::components {

class ForceMomentInteraction6Dof final
    : public gnc::core::SimulationNode,
      public yyz_c6::IInputProvider,
      public gnc::interfaces::IObservable {
public:
    ForceMomentInteraction6Dof()
        : SimulationNode("YyzC6ForceMomentInteraction") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        aero_lookup_name_ =
            reader.optionalString("aero_lookup_name", aero_lookup_name_);
        propulsion_lookup_name_ =
            reader.optionalString("propulsion_lookup_name",
                                  propulsion_lookup_name_);
        mass_lookup_name_ =
            reader.optionalString("mass_lookup_name", mass_lookup_name_);
        gravity_lookup_name_ =
            reader.optionalString("gravity_lookup_name", gravity_lookup_name_);
        include_gravity_ =
            reader.optionalBool("include_gravity", include_gravity_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(aero_, aero_lookup_name_),
                         gnc::core::bind(propulsion_, propulsion_lookup_name_),
                         gnc::core::bind(mass_, mass_lookup_name_),
                         gnc::core::bindIfPresent(gravity_, gravity_lookup_name_));
    }

    FormInput computeYyzC6Input(const Truth& truth,
                                double) const override {
        FormInput input;
        const auto& aero = aero_->aeroState();
        const auto& propulsion = propulsion_->propulsionState();
        input.mass = mass_->massProperties();
        input.total_force_body_n =
            aero.force_body_n + propulsion.force_body_n;
        input.total_moment_body_nm =
            aero.moment_body_nm + propulsion.moment_body_nm;
        if (include_gravity_ && gravity_) {
            input.gravity_launch_mps2 =
                gravity_->sampleGravity(truth.state.position_launch_m)
                    .gravity_launch_mps2;
        } else {
            input.gravity_launch_mps2 = gnc::math::Vector3::Zero();
        }

        last_input_ = input;
        return input;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("total_force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return last_input_.total_force_body_n;
                           });
        builder.addVector3("total_moment_body",
                           [this]() -> const gnc::math::Vector3& {
                               return last_input_.total_moment_body_nm;
                           });
        builder.addVector3("gravity_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return last_input_.gravity_launch_mps2;
                           });
        builder.addScalar("mass_kg",
                          [this]() { return last_input_.mass.mass_kg; });
        return builder.build();
    }

private:
    yyz_c6::IAerodynamicsProvider* aero_ = nullptr;
    yyz_c6::IPropulsionProvider* propulsion_ = nullptr;
    yyz_c6::IMassPropertiesProvider* mass_ = nullptr;
    yyz_c6::IGravityProvider* gravity_ = nullptr;
    std::string aero_lookup_name_ = "aero";
    std::string propulsion_lookup_name_ = "propulsion";
    std::string mass_lookup_name_ = "mass";
    std::string gravity_lookup_name_ = "env.cgcs2000";
    bool include_gravity_ = true;
    mutable FormInput last_input_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.interaction.c6.force_moment",
    yyz_c6::components::ForceMomentInteraction6Dof,
    ::gnc::core::NodeRole::Interaction,
    ::gnc::core::DiscretePhase::None,
    yyz_c6::kFormFamily,
    ::yyz_c6::IInputProvider,
    ::gnc::interfaces::IObservable)
