#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/perturbation/interfaces/i_perturbation_provider.hpp"

#include <algorithm>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.output.c6.mass_properties.
// Replace update() for burn, separation, ablation, and configuration logic.
namespace yyz_c6::components {

class MassPropertiesOutput final : public gnc::core::DiscreteNode,
                                   public yyz_c6::IMassPropertiesProvider,
                                   public gnc::interfaces::IObservable {
public:
    MassPropertiesOutput() : DiscreteNode("YyzC6MassPropertiesOutput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        initial_mass_kg_ = reader.requiredDouble("initial_mass_kg");
        dry_mass_kg_ = reader.requiredDouble("dry_mass_kg");
        fallback_mass_flow_kgps_ =
            reader.optionalDouble("fallback_mass_flow_kgps",
                                  fallback_mass_flow_kgps_);
        properties_.center_of_gravity_body_m = config::toVector3(
            reader.requiredDoubleArray("center_of_gravity_body_m", 3));
        properties_.inertia_body_kgm2 = config::diagonalMatrix(
            reader.requiredDoubleArray("inertia_body_kgm2", 3));
        perturbation_lookup_name_ =
            reader.optionalString("perturbation_lookup_name",
                                  perturbation_lookup_name_);
        mass_scale_key_ =
            reader.optionalString("mass_scale_key", mass_scale_key_);
        propulsion_lookup_name_ = reader.optionalString(
            "propulsion_lookup_name", propulsion_lookup_name_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bindIfPresent(perturbation_,
                                                  perturbation_lookup_name_),
                         gnc::core::bindIfPresent(propulsion_,
                                                  propulsion_lookup_name_));
    }

    void initialize() override {
        burned_mass_kg_ = 0.0;
        update({0.0, 0.0, 0});
    }

    void update(const gnc::core::StepContext& context) override {
        const double dt = context.dt_s;
        const double scale = perturbation_
                                 ? perturbation_->getNumber(mass_scale_key_, 1.0)
                                 : 1.0;
        const double mass_flow_kgps = propulsion_
                                          ? propulsion_->propulsionState()
                                                .fuel_mass_flow_kgps
                                          : fallback_mass_flow_kgps_;
        if (dt > 0.0) {
            burned_mass_kg_ += std::max(0.0, mass_flow_kgps) * dt;
        }
        properties_.mass_kg =
            std::max(dry_mass_kg_, initial_mass_kg_ * scale - burned_mass_kg_);
    }

    const MassProperties& massProperties() const override {
        return properties_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("mass_kg",
                          [this]() { return properties_.mass_kg; });
        builder.addVector3("center_of_gravity_body",
                           [this]() -> const gnc::math::Vector3& {
                               return properties_.center_of_gravity_body_m;
                           });
        builder.addScalar("inertia_body.ixx", [this]() {
            return properties_.inertia_body_kgm2(0, 0);
        });
        builder.addScalar("inertia_body.iyy", [this]() {
            return properties_.inertia_body_kgm2(1, 1);
        });
        builder.addScalar("inertia_body.izz", [this]() {
            return properties_.inertia_body_kgm2(2, 2);
        });
        return builder.build();
    }

private:
    gnc::perturbation::IPerturbationProvider* perturbation_ = nullptr;
    yyz_c6::IPropulsionProvider* propulsion_ = nullptr;
    std::string perturbation_lookup_name_ = "perturbation";
    std::string mass_scale_key_ = "mass.scale";
    std::string propulsion_lookup_name_ = "propulsion";
    double initial_mass_kg_ = 1.0;
    double dry_mass_kg_ = 1.0;
    double fallback_mass_flow_kgps_ = 0.0;
    double burned_mass_kg_ = 0.0;
    MassProperties properties_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.output.c6.mass_properties",
    yyz_c6::components::MassPropertiesOutput,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "",
    ::yyz_c6::IMassPropertiesProvider,
    ::gnc::interfaces::IObservable)
