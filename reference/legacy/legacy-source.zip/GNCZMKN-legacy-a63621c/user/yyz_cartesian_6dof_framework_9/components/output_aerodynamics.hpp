#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"
#include "yyz_table.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/perturbation/interfaces/i_perturbation_provider.hpp"

#include <filesystem>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.output.c6.aerodynamics.
// Keep F_CA/F_CY/F_CN/M_Cl/M_Cm/M_Cn as the outward coefficient contract. The
// reference implementation uses nearest rows from the three channel tables;
// concrete projects should replace the lookup kernel with multidimensional
// interpolation while preserving the table schema and provider interface.
namespace yyz_c6::components {

class AerodynamicsOutput final : public gnc::core::DiscreteNode,
                                 public yyz_c6::IAerodynamicsProvider,
                                 public gnc::interfaces::IObservable {
public:
    AerodynamicsOutput() : DiscreteNode("YyzC6AerodynamicsOutput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        air_data_lookup_name_ =
            reader.optionalString("air_data_lookup_name", air_data_lookup_name_);
        actuator_lookup_name_ =
            reader.optionalString("actuator_lookup_name", actuator_lookup_name_);
        perturbation_lookup_name_ =
            reader.optionalString("perturbation_lookup_name",
                                  perturbation_lookup_name_);
        pitch_table_file_ = reader.requiredString("pitch_table_file");
        yaw_table_file_ = reader.requiredString("yaw_table_file");
        roll_table_file_ = reader.requiredString("roll_table_file");
        asset_root_key_ =
            reader.optionalString("asset_root_key", asset_root_key_);
        default_asset_root_ =
            reader.requiredString("default_asset_root");
        state_.reference_area_m2 =
            reader.requiredDouble("reference_area_m2");
        state_.reference_length_m =
            reader.requiredDouble("reference_length_m");
        F_CA_bias_key_ = reader.optionalString("F_CA_bias_key", F_CA_bias_key_);
        F_CN_bias_key_ = reader.optionalString("F_CN_bias_key", F_CN_bias_key_);
        F_CY_bias_key_ = reader.optionalString("F_CY_bias_key", F_CY_bias_key_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(air_data_, air_data_lookup_name_),
                         gnc::core::bind(actuator_, actuator_lookup_name_),
                         gnc::core::bindIfPresent(perturbation_,
                                                  perturbation_lookup_name_));
    }

    void prepare(const gnc::core::PreparationContext& context) override {
        const std::string asset_root =
            perturbation_ ? perturbation_->getString(asset_root_key_,
                                                       default_asset_root_)
                          : default_asset_root_;
        pitch_table_ = loadPitchTable(context.paths().requireRegularPath(
            context.paths().resolveUnder(asset_root, pitch_table_file_),
            "Pitch aerodynamic table"));
        yaw_table_ = loadYawTable(context.paths().requireRegularPath(
            context.paths().resolveUnder(asset_root, yaw_table_file_),
            "Yaw aerodynamic table"));
        roll_table_ = loadRollTable(context.paths().requireRegularPath(
            context.paths().resolveUnder(asset_root, roll_table_file_),
            "Roll aerodynamic table"));
    }

    void initialize() override {
        update({0.0, 0.0, 0});
    }

    void update(const gnc::core::StepContext& context) override {
        state_.air_data = air_data_->airDataMeasurement();
        const auto& actuator = actuator_->actuatorState();
        const double F_CA_bias =
            perturbation_ ? perturbation_->getNumber(F_CA_bias_key_, 0.0) : 0.0;
        const double F_CN_bias =
            perturbation_ ? perturbation_->getNumber(F_CN_bias_key_, 0.0) : 0.0;
        const double F_CY_bias =
            perturbation_ ? perturbation_->getNumber(F_CY_bias_key_, 0.0) : 0.0;

        const auto coefficients =
            computeReferenceTableCoefficients(state_.air_data, actuator);
        state_.coefficients.F_CA = coefficients.F_CA + F_CA_bias;
        state_.coefficients.F_CN = coefficients.F_CN + F_CN_bias;
        state_.coefficients.F_CY = coefficients.F_CY + F_CY_bias;
        state_.coefficients.M_Cl = coefficients.M_Cl;
        state_.coefficients.M_Cm = coefficients.M_Cm;
        state_.coefficients.M_Cn = coefficients.M_Cn;

        const double q_s =
            state_.air_data.dynamic_pressure_pa * state_.reference_area_m2;
        state_.force_body_n =
            gnc::math::Vector3(-state_.coefficients.F_CA * q_s,
                               state_.coefficients.F_CY * q_s,
                               -state_.coefficients.F_CN * q_s);
        state_.moment_body_nm =
            gnc::math::Vector3(state_.coefficients.M_Cl,
                               state_.coefficients.M_Cm,
                               state_.coefficients.M_Cn) *
            q_s * state_.reference_length_m;
    }

    const AeroState& aeroState() const override { return state_; }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("F_CA", [this]() { return state_.coefficients.F_CA; });
        builder.addScalar("F_CY", [this]() { return state_.coefficients.F_CY; });
        builder.addScalar("F_CN", [this]() { return state_.coefficients.F_CN; });
        builder.addScalar("M_Cl", [this]() { return state_.coefficients.M_Cl; });
        builder.addScalar("M_Cm", [this]() { return state_.coefficients.M_Cm; });
        builder.addScalar("M_Cn", [this]() { return state_.coefficients.M_Cn; });
        builder.addVector3("force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return state_.force_body_n;
                           });
        builder.addVector3("moment_body",
                           [this]() -> const gnc::math::Vector3& {
                               return state_.moment_body_nm;
                           });
        builder.addScalar("dynamic_pressure_pa", [this]() {
            return state_.air_data.dynamic_pressure_pa;
        });
        builder.addScalar("mach_number",
                          [this]() { return state_.air_data.mach_number; });
        builder.addScalar("pitch_table_rows",
                          [this]() {
                              return static_cast<double>(
                                  pitch_table_.table.rowCount());
                          });
        builder.addScalar("yaw_table_rows",
                          [this]() {
                              return static_cast<double>(
                                  yaw_table_.table.rowCount());
                          });
        builder.addScalar("roll_table_rows",
                          [this]() {
                              return static_cast<double>(
                                  roll_table_.table.rowCount());
                          });
        return builder.build();
    }

private:
    struct PitchTable {
        FlatTable table;
        size_t alpha_rad = 0;
        size_t mach = 0;
        size_t delta_pitch_rad = 0;
        size_t F_CA = 0;
        size_t F_CN = 0;
        size_t M_Cm = 0;
    };

    struct YawTable {
        FlatTable table;
        size_t beta_rad = 0;
        size_t mach = 0;
        size_t delta_yaw_rad = 0;
        size_t F_CA = 0;
        size_t F_CY = 0;
        size_t M_Cn = 0;
    };

    struct RollTable {
        FlatTable table;
        size_t roll_rate_radps = 0;
        size_t mach = 0;
        size_t delta_roll_rad = 0;
        size_t F_CA = 0;
        size_t M_Cl = 0;
    };

    static PitchTable loadPitchTable(const std::filesystem::path& path) {
        PitchTable result;
        result.table = FlatTable::load(path, 6);
        result.table.requireColumns({"alpha_rad",
                                     "mach",
                                     "delta_pitch_rad",
                                     "F_CA",
                                     "F_CN",
                                     "M_Cm"});
        result.alpha_rad = result.table.columnIndex("alpha_rad");
        result.mach = result.table.columnIndex("mach");
        result.delta_pitch_rad = result.table.columnIndex("delta_pitch_rad");
        result.F_CA = result.table.columnIndex("F_CA");
        result.F_CN = result.table.columnIndex("F_CN");
        result.M_Cm = result.table.columnIndex("M_Cm");
        return result;
    }

    static YawTable loadYawTable(const std::filesystem::path& path) {
        YawTable result;
        result.table = FlatTable::load(path, 6);
        result.table.requireColumns({"beta_rad",
                                     "mach",
                                     "delta_yaw_rad",
                                     "F_CA",
                                     "F_CY",
                                     "M_Cn"});
        result.beta_rad = result.table.columnIndex("beta_rad");
        result.mach = result.table.columnIndex("mach");
        result.delta_yaw_rad = result.table.columnIndex("delta_yaw_rad");
        result.F_CA = result.table.columnIndex("F_CA");
        result.F_CY = result.table.columnIndex("F_CY");
        result.M_Cn = result.table.columnIndex("M_Cn");
        return result;
    }

    static RollTable loadRollTable(const std::filesystem::path& path) {
        RollTable result;
        result.table = FlatTable::load(path, 5);
        result.table.requireColumns({"roll_rate_radps",
                                     "mach",
                                     "delta_roll_rad",
                                     "F_CA",
                                     "M_Cl"});
        result.roll_rate_radps = result.table.columnIndex("roll_rate_radps");
        result.mach = result.table.columnIndex("mach");
        result.delta_roll_rad = result.table.columnIndex("delta_roll_rad");
        result.F_CA = result.table.columnIndex("F_CA");
        result.M_Cl = result.table.columnIndex("M_Cl");
        return result;
    }

    AeroCoefficients computeReferenceTableCoefficients(
        const AirDataMeasurement& air_data,
        const ActuatorState& actuator) const {
        const size_t pitch_row = pitch_table_.table.nearestRowByColumns(
            {pitch_table_.alpha_rad,
             pitch_table_.mach,
             pitch_table_.delta_pitch_rad},
            {air_data.alpha_rad,
             air_data.mach_number,
             actuator.fin_deflection_rad.y()});
        const size_t yaw_row = yaw_table_.table.nearestRowByColumns(
            {yaw_table_.beta_rad, yaw_table_.mach, yaw_table_.delta_yaw_rad},
            {air_data.beta_rad,
             air_data.mach_number,
             actuator.fin_deflection_rad.z()});

        // TEMPLATE EXTENSION POINT:
        // Connect a concrete roll-rate source here when the project roll
        // aerodynamic table depends on measured or estimated roll rate.
        const double roll_rate_radps = 0.0;
        const size_t roll_row = roll_table_.table.nearestRowByColumns(
            {roll_table_.roll_rate_radps,
             roll_table_.mach,
             roll_table_.delta_roll_rad},
            {roll_rate_radps,
             air_data.mach_number,
             actuator.fin_deflection_rad.x()});

        AeroCoefficients coefficients;
        coefficients.F_CA =
            (pitch_table_.table.value(pitch_row, pitch_table_.F_CA) +
             yaw_table_.table.value(yaw_row, yaw_table_.F_CA) +
             roll_table_.table.value(roll_row, roll_table_.F_CA)) /
            3.0;
        coefficients.F_CN =
            pitch_table_.table.value(pitch_row, pitch_table_.F_CN);
        coefficients.F_CY = yaw_table_.table.value(yaw_row, yaw_table_.F_CY);
        coefficients.M_Cl = roll_table_.table.value(roll_row, roll_table_.M_Cl);
        coefficients.M_Cm = pitch_table_.table.value(pitch_row, pitch_table_.M_Cm);
        coefficients.M_Cn = yaw_table_.table.value(yaw_row, yaw_table_.M_Cn);
        return coefficients;
    }

    yyz_c6::IAirDataProvider* air_data_ = nullptr;
    yyz_c6::IActuatorProvider* actuator_ = nullptr;
    gnc::perturbation::IPerturbationProvider* perturbation_ = nullptr;
    std::string air_data_lookup_name_ = "air_data";
    std::string actuator_lookup_name_ = "actuator";
    std::string perturbation_lookup_name_ = "perturbation";
    std::string pitch_table_file_;
    std::string yaw_table_file_;
    std::string roll_table_file_;
    std::string asset_root_key_ = "aero.asset_set.resolved";
    std::string default_asset_root_;
    std::string F_CA_bias_key_ = "aero.F_CA_bias";
    std::string F_CN_bias_key_ = "aero.F_CN_bias";
    std::string F_CY_bias_key_ = "aero.F_CY_bias";
    PitchTable pitch_table_{};
    YawTable yaw_table_{};
    RollTable roll_table_{};
    AeroState state_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.output.c6.aerodynamics",
    yyz_c6::components::AerodynamicsOutput,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "",
    ::yyz_c6::IAerodynamicsProvider,
    ::gnc::interfaces::IObservable)
