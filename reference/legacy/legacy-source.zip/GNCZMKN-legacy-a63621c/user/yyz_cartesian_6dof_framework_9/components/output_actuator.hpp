#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.output.c6.actuator.
// Replace update() with the concrete transfer-function and nonlinearity chain.
namespace yyz_c6::components {

class ActuatorOutput final : public gnc::core::DiscreteNode,
                             public yyz_c6::IActuatorProvider,
                             public gnc::interfaces::IObservable {
public:
    ActuatorOutput() : DiscreteNode("YyzC6ActuatorOutput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        allocation_lookup_name_ =
            reader.optionalString("allocation_lookup_name",
                                  allocation_lookup_name_);
        deflection_limit_rad_ = config::toVector3(
            reader.optionalDoubleArray("deflection_limit_rad",
                                       {0.5, 0.5, 0.5},
                                       3));
        rate_limit_radps_ = config::toVector3(
            reader.optionalDoubleArray("rate_limit_radps",
                                       {10.0, 10.0, 10.0},
                                       3));
        time_constant_s_ =
            reader.optionalDouble("time_constant_s", time_constant_s_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(allocation_,
                                         allocation_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const double dt = context.dt_s;
        const auto& command = allocation_->controlAllocationCommand();
        gnc::math::Vector3 target = command.fin_deflection_command_rad;
        for (int i = 0; i < 3; ++i) {
            const double limit = std::max(0.0, deflection_limit_rad_[i]);
            target[i] = std::clamp(target[i], -limit, limit);
        }

        if (dt <= 0.0 || time_constant_s_ <= 0.0) {
            state_.fin_deflection_rad = target;
        } else {
            const double alpha = std::clamp(dt / time_constant_s_, 0.0, 1.0);
            gnc::math::Vector3 desired =
                state_.fin_deflection_rad +
                alpha * (target - state_.fin_deflection_rad);
            for (int i = 0; i < 3; ++i) {
                const double step_limit = std::max(0.0, rate_limit_radps_[i]) * dt;
                desired[i] = std::clamp(desired[i],
                                        state_.fin_deflection_rad[i] - step_limit,
                                        state_.fin_deflection_rad[i] + step_limit);
            }
            state_.fin_deflection_rad = desired;
        }
        state_.throttle = std::clamp(command.throttle_command, 0.0, 1.0);
    }

    const ActuatorState& actuatorState() const override { return state_; }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("fin_deflection",
                           [this]() -> const gnc::math::Vector3& {
                               return state_.fin_deflection_rad;
                           });
        builder.addScalar("throttle", [this]() { return state_.throttle; });
        return builder.build();
    }

private:
    yyz_c6::IControlAllocationProvider* allocation_ = nullptr;
    std::string allocation_lookup_name_ = "control_allocation";
    gnc::math::Vector3 deflection_limit_rad_ =
        gnc::math::Vector3(0.5, 0.5, 0.5);
    gnc::math::Vector3 rate_limit_radps_ =
        gnc::math::Vector3(10.0, 10.0, 10.0);
    double time_constant_s_ = 0.0;
    ActuatorState state_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.output.c6.actuator",
    yyz_c6::components::ActuatorOutput,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "",
    ::yyz_c6::IActuatorProvider,
    ::gnc::interfaces::IObservable)
