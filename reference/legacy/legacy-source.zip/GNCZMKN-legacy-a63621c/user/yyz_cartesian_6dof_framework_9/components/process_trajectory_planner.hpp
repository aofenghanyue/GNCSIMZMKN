#pragma once

#include "interfaces/yyz_standard_trajectory.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <memory>
#include <stdexcept>
#include <string>

// TEMPLATE REFERENCE SLOT: project trajectory-planning logic may consume any
// source or derived column from the prepared data product. This implementation
// samples one reference row by mission time.
namespace yyz_c6::components {

class TrajectoryPlannerProcess final
    : public gnc::core::DiscreteNode,
      public yyz_c6::ITrajectoryReferenceProvider,
      public gnc::interfaces::IObservable {
public:
    TrajectoryPlannerProcess() : DiscreteNode("YyzC6TrajectoryPlannerProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        standard_trajectory_lookup_name_ = reader.optionalString(
            "standard_trajectory_lookup_name", standard_trajectory_lookup_name_);
        time_offset_s_ = reader.optionalDouble("time_offset_s", time_offset_s_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(standard_trajectory_,
                                         standard_trajectory_lookup_name_));
    }

    void initialize() override {
        trajectory_ = standard_trajectory_->standardTrajectory();
        if (!trajectory_) {
            throw std::runtime_error(
                "Trajectory planner received an empty prepared trajectory.");
        }
        update({0.0, 0.0, 0});
    }

    void update(const gnc::core::StepContext& context) override {
        const double query_time = context.time_s + time_offset_s_;
        const size_t row = trajectory_->rowAtOrBeforeTime(query_time);
        reference_.row_index = row;
        reference_.segment_index = trajectory_->segmentIndexForRow(row);
        reference_.phase_id = static_cast<int>(
            trajectory_->value(row, trajectory_->phaseColumnName()));
        reference_.time_s =
            trajectory_->value(row, trajectory_->timeColumnName());
        reference_.state.position_launch_m = gnc::math::Vector3(
            trajectory_->value(row, "position_launch_x_m"),
            trajectory_->value(row, "position_launch_y_m"),
            trajectory_->value(row, "position_launch_z_m"));
        reference_.state.velocity_launch_mps = gnc::math::Vector3(
            trajectory_->value(row, "velocity_launch_x_mps"),
            trajectory_->value(row, "velocity_launch_y_mps"),
            trajectory_->value(row, "velocity_launch_z_mps"));
        reference_.state.attitude_body_to_inertial = Eigen::Quaterniond(
            trajectory_->value(row, "q_body_to_inertial_w"),
            trajectory_->value(row, "q_body_to_inertial_x"),
            trajectory_->value(row, "q_body_to_inertial_y"),
            trajectory_->value(row, "q_body_to_inertial_z"));
        reference_.state.attitude_body_to_inertial.normalize();
        reference_.state.angular_rate_body_radps = gnc::math::Vector3(
            trajectory_->value(row, "angular_rate_body_x_radps"),
            trajectory_->value(row, "angular_rate_body_y_radps"),
            trajectory_->value(row, "angular_rate_body_z_radps"));
        reference_.speed_mps = trajectory_->value(row, "speed_mps");
        reference_.flight_path_angle_rad =
            trajectory_->value(row, "flight_path_angle_rad");
    }

    const TrajectoryReference& trajectoryReference() const override {
        return reference_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("reference_row", [this]() {
            return static_cast<double>(reference_.row_index);
        });
        builder.addScalar("reference_segment", [this]() {
            return static_cast<double>(reference_.segment_index);
        });
        builder.addScalar("reference_phase", [this]() {
            return static_cast<double>(reference_.phase_id);
        });
        builder.addScalar("reference_time_s", [this]() { return reference_.time_s; });
        builder.addVector3("reference_position_launch", [this]() -> const gnc::math::Vector3& {
            return reference_.state.position_launch_m;
        });
        builder.addVector3("reference_velocity_launch", [this]() -> const gnc::math::Vector3& {
            return reference_.state.velocity_launch_mps;
        });
        builder.addScalar("reference_speed_mps", [this]() { return reference_.speed_mps; });
        builder.addScalar("reference_flight_path_angle_rad", [this]() {
            return reference_.flight_path_angle_rad;
        });
        return builder.build();
    }

private:
    IStandardTrajectoryProvider* standard_trajectory_ = nullptr;
    std::shared_ptr<const ProcessedStandardTrajectory> trajectory_;
    std::string standard_trajectory_lookup_name_ = "standard_trajectory";
    double time_offset_s_ = 0.0;
    TrajectoryReference reference_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.trajectory_planner",
    yyz_c6::components::TrajectoryPlannerProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::ITrajectoryReferenceProvider,
    ::gnc::interfaces::IObservable)
