#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <string>

// TEMPLATE REFERENCE SLOT: custom.process.c6.navigation.
// Replace update() with the concrete integrated navigation algorithm.
namespace yyz_c6::components {

class NavigationProcess final : public gnc::core::DiscreteNode,
                                public yyz_c6::INavigationProvider,
                                public gnc::interfaces::IObservable {
public:
    NavigationProcess() : DiscreteNode("YyzC6NavigationProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        satnav_lookup_name_ =
            reader.optionalString("satnav_lookup_name", satnav_lookup_name_);
        imu_lookup_name_ =
            reader.optionalString("imu_lookup_name", imu_lookup_name_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(satnav_, satnav_lookup_name_),
                         gnc::core::bindIfPresent(imu_, imu_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& satnav = satnav_->satelliteNavMeasurement();
        solution_.position_launch_m = satnav.position_launch_m;
        solution_.velocity_launch_mps = satnav.velocity_launch_mps;
        solution_.attitude_body_to_inertial =
            satnav.attitude_body_to_inertial;
        solution_.altitude_m = satnav.position_launch_m.z();
        solution_.speed_mps = satnav.velocity_launch_mps.norm();
        solution_.sample_time_s = satnav.sample_time_s;
        if (imu_) {
            solution_.angular_rate_body_radps =
                imu_->imuMeasurement().angular_rate_body_radps;
        }
    }

    const NavigationSolution& navigationSolution() const override {
        return solution_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("position_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return solution_.position_launch_m;
                           });
        builder.addVector3("velocity_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return solution_.velocity_launch_mps;
                           });
        builder.addQuaternion("attitude_body_to_inertial",
                              [this]() -> const Eigen::Quaterniond& {
                                  return solution_.attitude_body_to_inertial;
                              });
        builder.addVector3("angular_rate_body",
                           [this]() -> const gnc::math::Vector3& {
                               return solution_.angular_rate_body_radps;
                           });
        builder.addScalar("altitude_m",
                          [this]() { return solution_.altitude_m; });
        builder.addScalar("speed_mps",
                          [this]() { return solution_.speed_mps; });
        return builder.build();
    }

private:
    yyz_c6::ISatelliteNavProvider* satnav_ = nullptr;
    yyz_c6::IImuProvider* imu_ = nullptr;
    std::string satnav_lookup_name_ = "satnav";
    std::string imu_lookup_name_ = "imu";
    NavigationSolution solution_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.navigation",
    yyz_c6::components::NavigationProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::INavigationProvider,
    ::gnc::interfaces::IObservable)
