#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <string>

// TEMPLATE REFERENCE SLOT: custom.process.c6.flight_control.
// Replace update() with the concrete attitude/control law.
namespace yyz_c6::components {

class FlightControlProcess final : public gnc::core::DiscreteNode,
                                   public yyz_c6::IFlightControlProvider,
                                   public gnc::interfaces::IObservable {
public:
    FlightControlProcess() : DiscreteNode("YyzC6FlightControlProcess") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        guidance_lookup_name_ =
            reader.optionalString("guidance_lookup_name",
                                  guidance_lookup_name_);
        attitude_error_gain_nm_per_rad_ = config::toVector3(
            reader.optionalDoubleArray("attitude_error_gain_nm_per_rad",
                                       {0.0, 0.0, 0.0},
                                       3));
        feedforward_moment_body_nm_ = config::toVector3(
            reader.optionalDoubleArray("feedforward_moment_body_nm",
                                       {0.0, 0.0, 0.0},
                                       3));
        actuator_gain_rad_per_nm_ = config::toVector3(
            reader.optionalDoubleArray("actuator_gain_rad_per_nm",
                                       {0.0, 0.0, 0.0},
                                       3));
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(guidance_, guidance_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& guidance = guidance_->guidanceCommand();
        command_.moment_command_body_nm =
            feedforward_moment_body_nm_ +
            attitude_error_gain_nm_per_rad_.cwiseProduct(
                guidance.attitude_error_rad);
        command_.raw_actuator_command_rad =
            actuator_gain_rad_per_nm_.cwiseProduct(
                command_.moment_command_body_nm);
        command_.throttle_command = guidance.fuel_command;
    }

    const FlightControlCommand& flightControlCommand() const override {
        return command_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("moment_command_body",
                           [this]() -> const gnc::math::Vector3& {
                               return command_.moment_command_body_nm;
                           });
        builder.addVector3("raw_actuator_command",
                           [this]() -> const gnc::math::Vector3& {
                               return command_.raw_actuator_command_rad;
                           });
        builder.addScalar("throttle_command",
                          [this]() { return command_.throttle_command; });
        return builder.build();
    }

private:
    yyz_c6::IGuidanceProvider* guidance_ = nullptr;
    std::string guidance_lookup_name_ = "guidance";
    gnc::math::Vector3 attitude_error_gain_nm_per_rad_ =
        gnc::math::Vector3::Zero();
    gnc::math::Vector3 feedforward_moment_body_nm_ =
        gnc::math::Vector3::Zero();
    gnc::math::Vector3 actuator_gain_rad_per_nm_ =
        gnc::math::Vector3::Zero();
    FlightControlCommand command_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.process.c6.flight_control",
    yyz_c6::components::FlightControlProcess,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::yyz_c6::IFlightControlProvider,
    ::gnc::interfaces::IObservable)
