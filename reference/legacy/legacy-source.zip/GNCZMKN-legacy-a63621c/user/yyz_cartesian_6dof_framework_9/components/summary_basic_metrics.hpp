#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/interfaces/i_summary_observer.hpp"

#include <algorithm>
#include <limits>
#include <ostream>
#include <stdexcept>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.summary.c6.basic_metrics.
// Replace update()/writeSummary() with project evaluation metrics.
namespace yyz_c6::components {

class BasicMetricsSummary final : public gnc::core::DiscreteNode,
                                  public gnc::interfaces::ISummaryObserver {
public:
    BasicMetricsSummary() : DiscreteNode("YyzC6BasicMetricsSummary") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        truth_lookup_name_ =
            reader.optionalString("truth_lookup_name", truth_lookup_name_);
        air_data_lookup_name_ =
            reader.optionalString("air_data_lookup_name", air_data_lookup_name_);
        mass_lookup_name_ =
            reader.optionalString("mass_lookup_name", mass_lookup_name_);
        target_lookup_name_ =
            reader.optionalString("target_lookup_name", target_lookup_name_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        truth_ =
            registry.registry().get<yyz_c6::ITruthView>(truth_lookup_name_);
        if (!truth_) {
            throw std::runtime_error("custom.summary.c6.basic_metrics cannot find truth provider '" +
                                     truth_lookup_name_ + "'.");
        }
        air_data_ = registry.registry().get<yyz_c6::IAirDataProvider>(
            air_data_lookup_name_);
        mass_ = registry.registry().get<yyz_c6::IMassPropertiesProvider>(
            mass_lookup_name_);
        target_ = registry.registry().get<yyz_c6::ITargetProvider>(
            target_lookup_name_);
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& truth = truth_->yyzC6Truth();
        maximum_acceleration_mps2_ =
            std::max(maximum_acceleration_mps2_,
                     truth.acceleration_launch_mps2.norm());
        final_altitude_m_ = truth.state.position_launch_m.z();
        final_speed_mps_ = truth.state.velocity_launch_mps.norm();
        final_time_s_ = truth.sample_time_s;

        if (air_data_) {
            maximum_dynamic_pressure_pa_ =
                std::max(maximum_dynamic_pressure_pa_,
                         air_data_->airDataMeasurement().dynamic_pressure_pa);
        }
        if (mass_) {
            final_mass_kg_ = mass_->massProperties().mass_kg;
        }
        if (target_) {
            minimum_target_range_m_ =
                std::min(minimum_target_range_m_,
                         (target_->targetState().position_launch_m -
                          truth.state.position_launch_m)
                             .norm());
        }
    }

    void writeSummary(std::ostream& out) const override {
        out << "YYZ Cartesian 6DoF Basic Metrics\n";
        out << "final_time_s: " << final_time_s_ << "\n";
        out << "final_altitude_m: " << final_altitude_m_ << "\n";
        out << "final_speed_mps: " << final_speed_mps_ << "\n";
        out << "final_mass_kg: " << final_mass_kg_ << "\n";
        out << "maximum_dynamic_pressure_pa: "
            << maximum_dynamic_pressure_pa_ << "\n";
        out << "maximum_acceleration_mps2: "
            << maximum_acceleration_mps2_ << "\n";
        out << "minimum_target_range_m: " << minimum_target_range_m_ << "\n";
    }

private:
    yyz_c6::ITruthView* truth_ = nullptr;
    yyz_c6::IAirDataProvider* air_data_ = nullptr;
    yyz_c6::IMassPropertiesProvider* mass_ = nullptr;
    yyz_c6::ITargetProvider* target_ = nullptr;
    std::string truth_lookup_name_ = "interceptor.dynamics";
    std::string air_data_lookup_name_ = "interceptor.air_data";
    std::string mass_lookup_name_ = "interceptor.mass";
    std::string target_lookup_name_ = "interceptor.target_manager";
    double maximum_dynamic_pressure_pa_ = 0.0;
    double maximum_acceleration_mps2_ = 0.0;
    double minimum_target_range_m_ = std::numeric_limits<double>::infinity();
    double final_time_s_ = 0.0;
    double final_altitude_m_ = 0.0;
    double final_speed_mps_ = 0.0;
    double final_mass_kg_ = 0.0;
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.summary.c6.basic_metrics",
    yyz_c6::components::BasicMetricsSummary,
    ::gnc::core::NodeRole::Summary,
    ::gnc::core::DiscretePhase::Evaluation,
    "",
    ::gnc::interfaces::ISummaryObserver)
