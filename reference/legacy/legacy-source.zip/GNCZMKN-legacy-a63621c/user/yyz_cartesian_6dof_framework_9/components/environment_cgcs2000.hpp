#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <cmath>

// TEMPLATE REFERENCE SLOT: custom.environment.c6.cgcs2000.
// Replace the gravity/atmosphere internals for a concrete project while
// keeping the provider interfaces stable.
namespace yyz_c6::components {

class Cgcs2000Environment final : public gnc::core::SimulationNode,
                                  public yyz_c6::IEllipsoidProvider,
                                  public yyz_c6::IGravityProvider,
                                  public yyz_c6::IAtmosphereProvider,
                                  public gnc::interfaces::IObservable {
public:
    Cgcs2000Environment() : SimulationNode("YyzC6Cgcs2000Environment") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        ellipsoid_.semi_major_axis_m =
            reader.optionalDouble("semi_major_axis_m",
                                  ellipsoid_.semi_major_axis_m);
        ellipsoid_.flattening =
            reader.optionalDouble("flattening", ellipsoid_.flattening);
        ellipsoid_.gravitational_parameter_m3ps2 =
            reader.optionalDouble("gravitational_parameter_m3ps2",
                                  ellipsoid_.gravitational_parameter_m3ps2);
        ellipsoid_.rotation_rate_radps =
            reader.optionalDouble("rotation_rate_radps",
                                  ellipsoid_.rotation_rate_radps);
        sea_level_gravity_mps2 =
            reader.optionalDouble("sea_level_gravity_mps2",
                                  sea_level_gravity_mps2);
        sea_level_density_kgpm3 =
            reader.optionalDouble("sea_level_density_kgpm3",
                                  sea_level_density_kgpm3);
        density_scale_height_m =
            reader.optionalDouble("density_scale_height_m",
                                  density_scale_height_m);
        sea_level_pressure_pa =
            reader.optionalDouble("sea_level_pressure_pa",
                                  sea_level_pressure_pa);
        sea_level_temperature_k =
            reader.optionalDouble("sea_level_temperature_k",
                                  sea_level_temperature_k);
        speed_of_sound_mps =
            reader.optionalDouble("speed_of_sound_mps", speed_of_sound_mps);
        config::warnUnknownKeys(config, config_path);
    }

    const EllipsoidModel& ellipsoidModel() const override {
        return ellipsoid_;
    }

    GravitySample sampleGravity(
        const gnc::math::Vector3& position_launch_m) const override {
        const double altitude_m = std::max(0.0, position_launch_m.z());
        const double radius =
            ellipsoid_.semi_major_axis_m /
            (ellipsoid_.semi_major_axis_m + altitude_m);
        GravitySample sample;
        sample.magnitude_mps2 = sea_level_gravity_mps2 * radius * radius;
        sample.gravity_launch_mps2 =
            gnc::math::Vector3(0.0, 0.0, -sample.magnitude_mps2);
        last_gravity_ = sample;
        last_altitude_m_ = altitude_m;
        return sample;
    }

    AtmosphereSample sampleAtmosphere(double altitude_m) const override {
        const double clamped_altitude_m = std::max(0.0, altitude_m);
        AtmosphereSample sample;
        sample.density_kgpm3 =
            sea_level_density_kgpm3 *
            std::exp(-clamped_altitude_m / density_scale_height_m);
        sample.pressure_pa =
            sea_level_pressure_pa *
            std::exp(-clamped_altitude_m / density_scale_height_m);
        sample.temperature_k = sea_level_temperature_k;
        sample.speed_of_sound_mps = speed_of_sound_mps;
        last_atmosphere_ = sample;
        last_altitude_m_ = clamped_altitude_m;
        return sample;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("semi_major_axis_m",
                          [this]() { return ellipsoid_.semi_major_axis_m; });
        builder.addScalar("flattening",
                          [this]() { return ellipsoid_.flattening; });
        builder.addScalar("last_altitude_m",
                          [this]() { return last_altitude_m_; });
        builder.addScalar("gravity_mps2",
                          [this]() { return last_gravity_.magnitude_mps2; });
        builder.addScalar("density_kgpm3",
                          [this]() { return last_atmosphere_.density_kgpm3; });
        builder.addScalar("speed_of_sound_mps",
                          [this]() { return last_atmosphere_.speed_of_sound_mps; });
        return builder.build();
    }

private:
    EllipsoidModel ellipsoid_{};
    double sea_level_gravity_mps2 = 9.80665;
    double sea_level_density_kgpm3 = 1.225;
    double density_scale_height_m = 7200.0;
    double sea_level_pressure_pa = 101325.0;
    double sea_level_temperature_k = 288.15;
    double speed_of_sound_mps = 340.294;
    mutable GravitySample last_gravity_{};
    mutable AtmosphereSample last_atmosphere_{};
    mutable double last_altitude_m_ = 0.0;
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.environment.c6.cgcs2000",
    yyz_c6::components::Cgcs2000Environment,
    ::gnc::core::NodeRole::EnvironmentModel,
    ::gnc::core::DiscretePhase::None,
    "",
    ::yyz_c6::IEllipsoidProvider,
    ::yyz_c6::IGravityProvider,
    ::yyz_c6::IAtmosphereProvider,
    ::gnc::interfaces::IObservable)
