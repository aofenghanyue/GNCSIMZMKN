#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/perturbation/interfaces/i_perturbation_provider.hpp"

#include <string>

// TEMPLATE REFERENCE SLOT: custom.environment.c6.wind.constant.
// Replace update()/sampleWind() when perturbation inputs map to a table,
// function model, or flight-state-dependent wind field.
namespace yyz_c6::components {

class ConstantWindField final : public gnc::core::DiscreteNode,
                                public yyz_c6::IWindProvider,
                                public gnc::interfaces::IObservable {
public:
    ConstantWindField() : DiscreteNode("YyzC6ConstantWindField") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        const auto wind =
            reader.optionalDoubleArray("wind_launch_mps", {0.0, 0.0, 0.0}, 3);
        base_wind_launch_mps_ = config::toVector3(wind);
        perturbation_lookup_name_ =
            reader.optionalString("perturbation_lookup_name",
                                  perturbation_lookup_name_);
        wind_scale_key_ = reader.optionalString("wind_scale_key", wind_scale_key_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bindIfPresent(perturbation_,
                                                  perturbation_lookup_name_));
    }

    void initialize() override { refreshFromPerturbation(); }

    void update(const gnc::core::StepContext& context) override { refreshFromPerturbation(); }

    WindSample sampleWind(const gnc::math::Vector3&, double) const override {
        // The environment stage executes before the vehicle perturbation stage.
        // Refreshing at query time lets the later air-data stage consume the
        // perturbation value materialized for the current vehicle cycle.
        refreshFromPerturbation();
        return current_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("wind_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return current_.wind_launch_mps;
                           });
        return builder.build();
    }

private:
    void refreshFromPerturbation() const {
        const double scale = perturbation_
                                 ? perturbation_->getNumber(wind_scale_key_, 1.0)
                                 : 1.0;
        current_.wind_launch_mps = scale * base_wind_launch_mps_;
    }
    gnc::perturbation::IPerturbationProvider* perturbation_ = nullptr;
    std::string perturbation_lookup_name_ = "perturbation";
    std::string wind_scale_key_ = "environment.wind_scale";
    gnc::math::Vector3 base_wind_launch_mps_ = gnc::math::Vector3::Zero();
    mutable WindSample current_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.environment.c6.wind.constant",
    yyz_c6::components::ConstantWindField,
    ::gnc::core::NodeRole::EnvironmentModel,
    ::gnc::core::DiscretePhase::Environment,
    "",
    ::yyz_c6::IWindProvider,
    ::gnc::interfaces::IObservable)
