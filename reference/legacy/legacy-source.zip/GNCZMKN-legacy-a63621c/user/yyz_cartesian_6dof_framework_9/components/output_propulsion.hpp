#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/perturbation/interfaces/i_perturbation_provider.hpp"

#include <algorithm>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.output.c6.propulsion.
// Replace update() with table, function, or integral engine models.
namespace yyz_c6::components {

class PropulsionOutput final : public gnc::core::DiscreteNode,
                               public yyz_c6::IPropulsionProvider,
                               public gnc::interfaces::IObservable {
public:
    PropulsionOutput() : DiscreteNode("YyzC6PropulsionOutput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        nominal_force_body_n_ = config::toVector3(
            reader.optionalDoubleArray("force_body_n", {0.0, 0.0, 0.0}, 3));
        application_point_body_m_ = config::toVector3(
            reader.optionalDoubleArray("application_point_body_m",
                                       {0.0, 0.0, 0.0},
                                       3));
        feedforward_moment_body_nm_ = config::toVector3(
            reader.optionalDoubleArray("feedforward_moment_body_nm",
                                       {0.0, 0.0, 0.0},
                                       3));
        fuel_mass_flow_kgps_ =
            reader.optionalDouble("fuel_mass_flow_kgps", fuel_mass_flow_kgps_);
        ablation_rate_kgps_ =
            reader.optionalDouble("ablation_rate_kgps", ablation_rate_kgps_);
        initial_fuel_kg_ =
            reader.optionalDouble("initial_fuel_kg", initial_fuel_kg_);
        isp_s_ = reader.optionalDouble("isp_s", isp_s_);
        air_flow_kgps_ = reader.optionalDouble("air_flow_kgps", air_flow_kgps_);
        equivalence_ratio_ =
            reader.optionalDouble("equivalence_ratio", equivalence_ratio_);
        enabled_phase_name_ =
            reader.optionalString("enabled_phase_name", enabled_phase_name_);
        phase_lookup_name_ =
            reader.optionalString("phase_lookup_name", phase_lookup_name_);
        actuator_lookup_name_ =
            reader.optionalString("actuator_lookup_name", actuator_lookup_name_);
        use_actuator_throttle_ = reader.optionalBool(
            "use_actuator_throttle", use_actuator_throttle_);
        perturbation_lookup_name_ =
            reader.optionalString("perturbation_lookup_name",
                                  perturbation_lookup_name_);
        thrust_scale_key_ =
            reader.optionalString("thrust_scale_key", thrust_scale_key_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bindIfPresent(phase_, phase_lookup_name_),
                         gnc::core::bindIfPresent(actuator_,
                                                  actuator_lookup_name_),
                         gnc::core::bindIfPresent(perturbation_,
                                                  perturbation_lookup_name_));
    }

    void initialize() override {
        consumed_fuel_kg_ = 0.0;
        update({0.0, 0.0, 0});
    }

    void update(const gnc::core::StepContext& context) override {
        const double dt = context.dt_s;
        state_ = {};
        state_.enabled = enabledForCurrentPhase();
        state_.remaining_fuel_kg =
            std::max(0.0, initial_fuel_kg_ - consumed_fuel_kg_);
        state_.isp_s = isp_s_;
        state_.air_flow_kgps = air_flow_kgps_;
        state_.equivalence_ratio = equivalence_ratio_;
        if (!state_.enabled || state_.remaining_fuel_kg <= 0.0) {
            return;
        }

        const double perturbation_scale =
            perturbation_ ? perturbation_->getNumber(thrust_scale_key_, 1.0) : 1.0;
        const double throttle = use_actuator_throttle_ && actuator_
                                    ? std::clamp(actuator_->actuatorState().throttle,
                                                 0.0,
                                                 1.0)
                                    : 1.0;
        state_.force_body_n =
            throttle * perturbation_scale * nominal_force_body_n_;
        state_.moment_body_nm =
            application_point_body_m_.cross(state_.force_body_n) +
            feedforward_moment_body_nm_;
        state_.fuel_mass_flow_kgps = throttle * fuel_mass_flow_kgps_;
        state_.ablation_rate_kgps = ablation_rate_kgps_;
        if (dt > 0.0) {
            consumed_fuel_kg_ += state_.fuel_mass_flow_kgps * dt;
        }
    }

    const PropulsionState& propulsionState() const override {
        return state_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("force_body",
                           [this]() -> const gnc::math::Vector3& {
                               return state_.force_body_n;
                           });
        builder.addVector3("moment_body",
                           [this]() -> const gnc::math::Vector3& {
                               return state_.moment_body_nm;
                           });
        builder.addScalar("enabled",
                          [this]() { return state_.enabled ? 1.0 : 0.0; });
        builder.addScalar("fuel_mass_flow_kgps",
                          [this]() { return state_.fuel_mass_flow_kgps; });
        builder.addScalar("remaining_fuel_kg",
                          [this]() { return state_.remaining_fuel_kg; });
        builder.addScalar("isp_s", [this]() { return state_.isp_s; });
        builder.addScalar("air_flow_kgps",
                          [this]() { return state_.air_flow_kgps; });
        builder.addScalar("equivalence_ratio",
                          [this]() { return state_.equivalence_ratio; });
        return builder.build();
    }

private:
    bool enabledForCurrentPhase() const {
        if (enabled_phase_name_.empty() || !phase_) {
            return true;
        }
        return phase_->phaseState().phase_name == enabled_phase_name_;
    }

    yyz_c6::IPhaseProvider* phase_ = nullptr;
    yyz_c6::IActuatorProvider* actuator_ = nullptr;
    gnc::perturbation::IPerturbationProvider* perturbation_ = nullptr;
    std::string phase_lookup_name_ = "sequencer";
    std::string actuator_lookup_name_ = "actuator";
    std::string perturbation_lookup_name_ = "perturbation";
    std::string thrust_scale_key_ = "propulsion.thrust_scale";
    std::string enabled_phase_name_;
    bool use_actuator_throttle_ = true;
    gnc::math::Vector3 nominal_force_body_n_ = gnc::math::Vector3::Zero();
    gnc::math::Vector3 application_point_body_m_ = gnc::math::Vector3::Zero();
    gnc::math::Vector3 feedforward_moment_body_nm_ =
        gnc::math::Vector3::Zero();
    double fuel_mass_flow_kgps_ = 0.0;
    double ablation_rate_kgps_ = 0.0;
    double initial_fuel_kg_ = 0.0;
    double isp_s_ = 0.0;
    double air_flow_kgps_ = 0.0;
    double equivalence_ratio_ = 0.0;
    double consumed_fuel_kg_ = 0.0;
    PropulsionState state_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.output.c6.propulsion",
    yyz_c6::components::PropulsionOutput,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "",
    ::yyz_c6::IPropulsionProvider,
    ::gnc::interfaces::IObservable)
