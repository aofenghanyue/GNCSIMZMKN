#pragma once

#include "interfaces/yyz_c6_types.hpp"
#include "yyz_config_helpers.hpp"

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"

#include <algorithm>
#include <cmath>
#include <string>

// TEMPLATE REFERENCE SLOT: custom.input.c6.air_data.
// Replace update() when the project uses a concrete air-data hardware chain.
namespace yyz_c6::components {

class AirDataInput final : public gnc::core::DiscreteNode,
                           public yyz_c6::IAirDataProvider,
                           public gnc::interfaces::IObservable {
public:
    AirDataInput() : DiscreteNode("YyzC6AirDataInput") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        truth_lookup_name_ =
            reader.optionalString("truth_lookup_name", truth_lookup_name_);
        atmosphere_lookup_name_ =
            reader.optionalString("atmosphere_lookup_name",
                                  atmosphere_lookup_name_);
        wind_lookup_name_ =
            reader.optionalString("wind_lookup_name", wind_lookup_name_);
        config::warnUnknownKeys(config, config_path);
    }

    void bind(gnc::core::AssemblyContext& registry) override {
        registry.bindAll(gnc::core::bind(truth_, truth_lookup_name_),
                         gnc::core::bind(atmosphere_, atmosphere_lookup_name_),
                         gnc::core::bindIfPresent(wind_, wind_lookup_name_));
    }

    void initialize() override { update({0.0, 0.0, 0}); }

    void update(const gnc::core::StepContext& context) override {
        const auto& truth = truth_->yyzC6Truth();
        measurement_.altitude_m = truth.state.position_launch_m.z();
        measurement_.atmosphere =
            atmosphere_->sampleAtmosphere(measurement_.altitude_m);
        const WindSample wind =
            wind_ ? wind_->sampleWind(truth.state.position_launch_m,
                                      truth.sample_time_s)
                  : WindSample{};
        measurement_.wind_launch_mps = wind.wind_launch_mps;

        const gnc::math::Vector3 relative_velocity_launch_mps =
            truth.state.velocity_launch_mps - wind.wind_launch_mps;
        measurement_.relative_velocity_body_mps =
            truth.state.attitude_body_to_inertial.inverse() *
            relative_velocity_launch_mps;
        measurement_.speed_mps =
            measurement_.relative_velocity_body_mps.norm();
        const double speed_of_sound =
            std::max(1.0, measurement_.atmosphere.speed_of_sound_mps);
        measurement_.mach_number = measurement_.speed_mps / speed_of_sound;
        measurement_.dynamic_pressure_pa =
            0.5 * measurement_.atmosphere.density_kgpm3 *
            measurement_.speed_mps * measurement_.speed_mps;

        const double vx = measurement_.relative_velocity_body_mps.x();
        const double vy = measurement_.relative_velocity_body_mps.y();
        const double vz = measurement_.relative_velocity_body_mps.z();
        measurement_.alpha_rad = std::atan2(vz, std::max(1.0e-9, vx));
        measurement_.beta_rad = std::atan2(vy, std::max(1.0e-9, std::abs(vx)));
    }

    const AirDataMeasurement& airDataMeasurement() const override {
        return measurement_;
    }

    std::vector<gnc::interfaces::ObservableField> getObservableFields()
        const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addVector3("relative_velocity_body",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.relative_velocity_body_mps;
                           });
        builder.addVector3("wind_launch",
                           [this]() -> const gnc::math::Vector3& {
                               return measurement_.wind_launch_mps;
                           });
        builder.addScalar("altitude_m",
                          [this]() { return measurement_.altitude_m; });
        builder.addScalar("speed_mps",
                          [this]() { return measurement_.speed_mps; });
        builder.addScalar("mach_number",
                          [this]() { return measurement_.mach_number; });
        builder.addScalar("dynamic_pressure_pa",
                          [this]() { return measurement_.dynamic_pressure_pa; });
        builder.addScalar("alpha_rad",
                          [this]() { return measurement_.alpha_rad; });
        builder.addScalar("beta_rad",
                          [this]() { return measurement_.beta_rad; });
        builder.addScalar("density_kgpm3", [this]() {
            return measurement_.atmosphere.density_kgpm3;
        });
        return builder.build();
    }

private:
    yyz_c6::ITruthView* truth_ = nullptr;
    yyz_c6::IAtmosphereProvider* atmosphere_ = nullptr;
    yyz_c6::IWindProvider* wind_ = nullptr;
    std::string truth_lookup_name_ = "dynamics";
    std::string atmosphere_lookup_name_ = "env.cgcs2000";
    std::string wind_lookup_name_ = "env.wind";
    AirDataMeasurement measurement_{};
};

} // namespace yyz_c6::components

GNC_REGISTER_NODE_TYPE(
    "custom.input.c6.air_data",
    yyz_c6::components::AirDataInput,
    ::gnc::core::NodeRole::Input,
    ::gnc::core::DiscretePhase::Input,
    "",
    ::yyz_c6::IAirDataProvider,
    ::gnc::interfaces::IObservable)
