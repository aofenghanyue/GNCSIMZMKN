# YYZ Cartesian 6DoF 项目模板

这是一个面向实验室 6DoF 笛卡尔 GNC 研究的可复制 `user/<project>` 模板。模板提供完整组件链路、稳定接线、可运行参考算法、参数目录、资产集合、SimFlow 示例和验证脚本。

复制后的主要工作集中在三处：

1. 修改 `config/mission.json` 和 `config/parameters/` 中的关键参数。
2. 替换 `data/` 下的项目资产。
3. 在 `components/` 中替换标有 `TEMPLATE REFERENCE SLOT` 或 `TEMPLATE ALGORITHM SLOT` 的参考算法。

## 五分钟开始新项目

在仓库根目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File user/yyz_cartesian_6dof_framework_9/tools/New-YyzProject.ps1 `
  -ProjectName my_cartesian_6dof_project `
  -Activate

cmake -S . -B build-mingw-my_cartesian_6dof_project -G "MinGW Makefiles" `
  -DBUILD_TESTS=OFF `
  -DGNC_ACTIVE_PROJECT=my_cartesian_6dof_project
cmake --build build-mingw-my_cartesian_6dof_project -j 4
build-mingw-my_cartesian_6dof_project\bin\gnc_sim.exe
```

复制脚本会复制完整项目、替换项目目录名和配置中的项目标识。`yyz_c6` 接口命名会保留，用作这一类项目的共同契约。

## 目录分工

| 路径 | 使用者操作 |
| --- | --- |
| `project.json` | 项目标识和模板版本；复制脚本自动更新项目名 |
| `config/mission.json` | 常改：步长、时长、输出、终止阈值 |
| `config/parameters/` | 常改：初始状态、环境、传感器、GNC、飞行器参数、拉偏 |
| `config/assembly/` | 稳定接线；新增、删除、重排组件时修改 |
| `data/` | 直接替换资产集合；目录结构保持兼容即可 |
| `simflow/` | 单 case、矩阵和随机试验入口 |
| `interfaces/` | 跨组件 provider 契约；算法内部变化通常无需修改 |
| `components/` | 参考算法和组件实现槽位 |
| `common/` | 项目公共配置、表格和标准轨迹处理算法 |
| `tools/` | 创建新项目和验证模板 |

这种分层让普通 case 调参避开较长的组件接线文件。组件依赖、lookup name、priority 和 placement 集中保存在 `config/assembly/`。

## 组件链路

```text
target.truth -> target_manager

raw standard trajectory
-> common: standard_trajectory (prepare, immutable product)
-> form initial state / process: trajectory_planner

form truth
-> input: imu / satnav / air_data
-> process: sequencer / navigation / trajectory_planner / target_manager / onboard_state
-> process: guidance / flight_control / control_allocation
-> output: actuator -> propulsion -> mass / aerodynamics
-> interaction: force_moment
-> form input
```

process 组件使用显式 `priority` 固定同 stage 内的数据流顺序。output 中执行机构先更新，推进读取当前油门，质量读取当前推进流量，气动读取当前舵偏。具体项目可以替换算法，同时保留这条接线骨架。

目标位置只在 `config/parameters/target.json` 配置一次。`target_manager` 的参考实现读取 `target.truth`，并留有目标坐标适配算法槽位。

## 参数修改入口

最常用文件：

- `config/mission.json`：`dt`、`duration`、输出和终止阈值。
- `config/parameters/initial_state.json`：初始状态来源；模板默认从标准轨迹处理结果初始化。切换为 `config` 时需在此文件提供完整初始状态。
- `config/parameters/common/standard_trajectory.json`：源轨迹、处理 profile、时间列和阶段列。
- `config/parameters/target.json`：目标初始状态。
- `config/parameters/process/`：时序、制导、飞控和控制分配参数。
- `config/parameters/output/`：质量、推进、执行机构和气动参数。
- `config/parameters/perturbation.json`：单次运行的名义拉偏输入与资产枚举。

修改 `simulation.dt` 时还要检查 `config/assembly/interceptor.json` 中的 `rate_hz`。框架要求所有采样率形成整数 step interval，这项约束会在 build mission 阶段给出错误。

## 资产替换

默认气动资产集合位于：

```text
data/aero/nominal/
  pitch.csv
  yaw.csv
  roll.csv
```

保持文件名和表头契约时，可以直接覆盖文件。`aero.asset_set` 经 perturbation 的 `enum_maps` 解析为资产目录；模板附带 `demo_alternate` 集合，用来演示单个 case 和 SimFlow 对整套资产的切换。

标准轨迹资产位于：

```text
data/trajectory/
  nominal.csv
  demo_alternate.csv
```

`standard_trajectory` 组件在 framework 的 `prepare()` 阶段读取当前 case 选择的文件，保留全部源列，并追加速度、发射点距离、航迹倾角、三轴加速度、行号和切分段号。处理产物使用 `shared_ptr<const ProcessedStandardTrajectory>` 在内存中共享；form 从产物提取初始状态，`trajectory_planner` 按仿真时间读取参考行。整个流程不会写出处理后的轨迹文本。

`trajectory.asset_set` 控制 case 的标准轨迹选择。具体项目可以在 `common/yyz_standard_trajectory_preprocessor.hpp` 扩展切分、提取、判断和派生列算法，同时保持 provider 接口与组件接线稳定。

运行时项目组件支持 `project://`、`repo://` 和 `user-data://` 资产路径。复制项目后无需在 C++ 或 mission 中重写模板目录绝对路径。

## 替换算法

完整清单见 [ALGORITHM_SLOTS.md](ALGORITHM_SLOTS.md)。代码内可以搜索：

```powershell
rg -n "TEMPLATE (CONTRACT|REFERENCE|ALGORITHM) SLOT" `
  user/my_cartesian_6dof_project/components
```

参考实现以“完整可运行”为目标，允许暂时只使用 provider 中的一部分字段。用户替换算法时优先保留 type id、provider 接口、observable 前缀和 mission placement，已有接线与分析脚本可以继续使用。

## 单次运行和批量运行

```powershell
# 普通 mission
build-mingw-yyz9\bin\gnc_sim.exe `
  --config user/yyz_cartesian_6dof_framework_9/config/mission.json

# 单 case 物化
build-mingw-yyz9\bin\gnc_sim.exe `
  --simflow user/yyz_cartesian_6dof_framework_9/simflow/single.json --jobs 1

# CSV 矩阵
build-mingw-yyz9\bin\gnc_sim.exe `
  --simflow user/yyz_cartesian_6dof_framework_9/simflow/matrix.json --jobs 1

# 固定 seed 随机试验
build-mingw-yyz9\bin\gnc_sim.exe `
  --simflow user/yyz_cartesian_6dof_framework_9/simflow/random.json --jobs 4
```

每个 case 都会生成 `effective_mission.json`。复制这个文件后可以通过普通 `--config` 命令复现该 case。

## 验证

```powershell
powershell -ExecutionPolicy Bypass -File `
  user/yyz_cartesian_6dof_framework_9/tools/Verify-Template.ps1 `
  -BuildDirectory build-mingw-yyz9 `
  -Reconfigure
```

脚本检查组件注册、名义 mission、标准轨迹准备、不同 case 资产选择、单 case SimFlow 和 effective mission 回放。算法替换期间建议频繁运行。

更多替换和接线规则见 [TEMPLATE_GUIDE.md](TEMPLATE_GUIDE.md)，场景边界见 [SCENARIO_CONTRACT.md](SCENARIO_CONTRACT.md)，本轮运行证据见 [VERIFICATION.md](VERIFICATION.md)。
