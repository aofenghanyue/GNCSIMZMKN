# 资产目录

模板把“资产集合选择”和“资产文件内容”分开：

```text
perturbation input: aero.asset_set
-> perturbation enum_maps
-> project://data/aero/<set>
-> aerodynamics component loads pitch/yaw/roll files
```

`aero/nominal/` 是默认集合，`aero/demo_alternate/` 用来验证 SimFlow 可以切换整套资产。复制项目后可以直接替换目录内文件；保持文件名和表头契约时无需修改 C++。

标准轨迹使用另一条资产选择链：

```text
perturbation input: trajectory.asset_set
-> perturbation enum_maps
-> project://data/trajectory/<file>.csv
-> standard_trajectory prepare()
-> ProcessedStandardTrajectory in memory
-> form initialization / trajectory_planner
```

`trajectory/nominal.csv` 与 `trajectory/demo_alternate.csv` 包含 20 个示例源列。参考预处理器保留这些列并追加 8 个处理列，生成 5 行、28 列、3 个阶段段的只读数据产品。数据产品不写入磁盘；CSV 输出只记录组件挑选出的稳定 observable。

具体项目可以增加任意源列与派生列。跨组件消费者通过列名读取，修改时应同步维护必需列校验和文档。

需要采用另一种资产结构时，在对应组件中替换标有 `TEMPLATE REFERENCE SLOT` 的加载和算法实现，并同步修改 `config/parameters/output/aerodynamics.json`。
