# 模板验收记录

验收日期：2026-07-10。

初始版本存档：Git commit `29fcc54`。

## 用户流程验收

| 用户目标 | 验收方式 | 结果 |
| --- | --- | --- |
| 找到常改参数 | `config/mission.json` 与 `config/parameters/` 独立于 assembly | 通过 |
| 保持完整组件接线 | 检查 process/output priority、lookup 和 placement | 通过 |
| 直接替换资产 | 名义与 alternate 气动目录使用相同文件契约 | 通过 |
| 通过拉偏切换资产 | matrix case 0/1 分别得到 `F_CA=0.08/0.09` | 通过 |
| 标准轨迹多列预处理 | 20 个源列保留并追加 8 个处理列，得到 5 行、28 列、3 个阶段段 | 通过 |
| 处理结果保持内存共享 | `IStandardTrajectoryProvider` 返回只读 shared product，未生成处理后轨迹文本 | 通过 |
| form 读取提取结果初始化 | nominal 初始位置 `(0, 0, 1000)`，alternate 初始位置 `(50, -20, 1200)` | 通过 |
| 规划组件读取整表 | `trajectory_planner` 按 mission time 选择参考行并发布参考状态 | 通过 |
| 风场读取飞行器 case 拉偏 | matrix case 风速缩放后得到 `5/6 mps` | 通过 |
| 普通 mission 可运行 | `tools/Verify-Template.ps1` | 通过 |
| 单 case 可物化和回放 | `simflow/single.json` 与生成的 `effective_mission.json` | 通过 |
| effective mission 资产路径自足 | 物化时将显式 URI 固化，输出目录内普通 `--config` 回放成功 | 通过 |
| 矩阵试验可运行 | `simflow/matrix.json --jobs 2`，3 个 case succeeded | 通过 |
| 随机试验可运行 | `simflow/random.json --jobs 4`，8 个固定 seed case succeeded | 通过 |
| 复制后无需改资产路径 | 创建 `yyz_preparation_copy_smoke`，独立 CMake、build、mission 均成功 | 通过 |
| 临时复制不污染仓库 | 验收后删除临时项目、构建目录和输出目录 | 通过 |

## 执行过的主要命令

```powershell
cmake --build build-mingw-yyz9 -j 4

powershell -ExecutionPolicy Bypass -File `
  user/yyz_cartesian_6dof_framework_9/tools/Verify-Template.ps1 `
  -BuildDirectory build-mingw-yyz9

build-mingw-yyz9\bin\gnc_sim.exe `
  --simflow user/yyz_cartesian_6dof_framework_9/simflow/matrix.json --jobs 2

build-mingw-yyz9\bin\gnc_sim.exe `
  --config user/outputs/yyz_cartesian_6dof_framework_9/simflow_matrix/case_000002_alternate_assets/effective_mission.json

build-mingw-yyz9\bin\gnc_sim.exe `
  --simflow user/yyz_cartesian_6dof_framework_9/simflow/random.json --jobs 4
```

复制验收使用 `tools/New-YyzProject.ps1` 创建临时项目，随后为该项目配置独立 build directory、完成编译并运行默认 mission。

## 验收边界

这些检查证明模板结构、复制路径、资产选择和运行入口完整。form 方程、坐标处理、环境精度、传感器误差、导航、制导、控制、气动插值、推进和质量模型仍是参考算法槽位，具体研究项目需要按 [ALGORITHM_SLOTS.md](ALGORITHM_SLOTS.md) 替换。
