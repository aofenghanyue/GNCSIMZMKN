# 算法替换槽位

模板中的 C++ 实现分成两类标记：

- `TEMPLATE CONTRACT SLOT`：跨组件边界。只替换内部算法时保留 type id、provider 接口和 mission placement。
- `TEMPLATE REFERENCE SLOT` / `TEMPLATE ALGORITHM SLOT`：可运行示例。复制项目后按研究任务替换。

建议直接搜索：

```powershell
rg -n "TEMPLATE (CONTRACT|REFERENCE|ALGORITHM) SLOT" user/<project>/components
```

## 优先替换

| 文件 | 主要入口 | 模板保留项 |
| --- | --- | --- |
| `form_rigid_body_6dof.hpp` | `computeDerivatives()`, `publish()` | form family、状态所有权、input/truth provider 关系 |
| `common/yyz_standard_trajectory_preprocessor.hpp` | `StandardTrajectoryPreprocessor::process()` | 全列保留、typed immutable product、build-time preparation 边界 |
| `common_standard_trajectory.hpp` | `prepare()` | case 选轨迹、统一路径上下文、进程内缓存和 provider |
| `environment_cgcs2000.hpp` | 环境查询函数 | environment placement 和 provider 接口 |
| `input_imu.hpp` | `update()` | `IImuProvider` |
| `input_satnav.hpp` | `update()` | `ISatelliteNavProvider` |
| `input_air_data.hpp` | `update()` | `IAirDataProvider` |
| `process_navigation.hpp` | `update()` | `INavigationProvider` |
| `process_trajectory_planner.hpp` | `update()` | `ITrajectoryReferenceProvider` 与标准轨迹只读输入 |
| `process_guidance.hpp` | `update()` | `IGuidanceProvider` 与冗余命令结构 |
| `process_flight_control.hpp` | `update()` | `IFlightControlProvider` |
| `process_control_allocation.hpp` | `update()` | `IControlAllocationProvider` |
| `output_mass_properties.hpp` | `update()` | `IMassPropertiesProvider` |
| `output_propulsion.hpp` | `update()` | `IPropulsionProvider` |
| `output_actuator.hpp` | `update()` | `IActuatorProvider` |
| `output_aerodynamics.hpp` | `computeReferenceTableCoefficients()` | 三通道资产入口和 `IAerodynamicsProvider` |
| `interaction_force_moment_6dof.hpp` | `computeYyzC6Input()` | form input provider 与 interaction placement |

## 按项目选择替换

| 文件 | 何时修改 |
| --- | --- |
| `process_sequencer.hpp` | 项目有自己的组件时序或状态机 |
| `process_target_manager.hpp` | 目标需要坐标适配、导引头、标准轨迹或程序生成 |
| `process_onboard_state.hpp` | 机上派生状态与模板不同 |
| `form_rigid_body_6dof.hpp` 的标准轨迹初始化槽位 | 初始状态需要由多行、分段结果或其它提取量计算 |
| `termination_state_metric.hpp` | 项目终止条件变化 |
| `summary_basic_metrics.hpp` | 项目评估指标变化 |

允许参考算法只消费接口中的一部分字段。接口冗余用于减少后续项目间的连锁改动。
