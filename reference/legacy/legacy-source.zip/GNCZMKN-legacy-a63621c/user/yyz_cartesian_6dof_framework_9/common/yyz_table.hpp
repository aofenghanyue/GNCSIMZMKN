#pragma once

#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace yyz_c6 {

// Minimal asset-table contract for this scenario family.
// It intentionally stops at loading, column validation, and nearest-row lookup;
// concrete projects can replace the lookup kernel with interpolation while
// preserving the same file shape.
class FlatTable {
public:
    static FlatTable load(const std::filesystem::path& path,
                          size_t minimum_columns) {
        std::ifstream input(path);
        if (!input) {
            throw std::runtime_error("Cannot open YYZ table asset: " +
                                     path.string());
        }

        FlatTable table;
        table.source_path_ = path.string();
        std::string line;
        size_t line_number = 0;
        bool header_checked = false;

        while (std::getline(input, line)) {
            ++line_number;
            line = trim(line);
            if (line.empty() || line.front() == '#') {
                continue;
            }

            const auto fields = split(line);
            if (fields.size() < minimum_columns) {
                throw std::runtime_error("YYZ table " + path.string() +
                                         " line " + std::to_string(line_number) +
                                         " has fewer columns than expected.");
            }

            if (!header_checked) {
                header_checked = true;
                if (!looksNumeric(fields.front())) {
                    table.header_ = fields;
                    continue;
                }
            }

            std::vector<double> row;
            row.reserve(fields.size());
            for (size_t i = 0; i < fields.size(); ++i) {
                row.push_back(parseDouble(fields[i], path, line_number, i));
            }
            table.rows_.push_back(std::move(row));
        }

        if (table.rows_.empty()) {
            throw std::runtime_error("YYZ table asset has no data rows: " +
                                     path.string());
        }
        return table;
    }

    const std::vector<std::string>& header() const { return header_; }
    const std::vector<std::vector<double>>& rows() const { return rows_; }
    bool hasHeader() const { return !header_.empty(); }
    size_t rowCount() const { return rows_.size(); }

    size_t columnIndex(const std::string& name) const {
        if (header_.empty()) {
            throw std::runtime_error("YYZ table asset " + source_path_ +
                                     " must have a header to resolve column '" +
                                     name + "'.");
        }
        for (size_t i = 0; i < header_.size(); ++i) {
            if (header_[i] == name) {
                return i;
            }
        }
        throw std::runtime_error("YYZ table asset " + source_path_ +
                                 " is missing required column '" + name + "'.");
    }

    void requireColumns(const std::vector<std::string>& names) const {
        for (const auto& name : names) {
            (void)columnIndex(name);
        }
    }

    double value(size_t row_index, size_t column_index) const {
        if (row_index >= rows_.size()) {
            throw std::runtime_error("YYZ table asset " + source_path_ +
                                     " row index is out of range.");
        }
        if (column_index >= rows_[row_index].size()) {
            throw std::runtime_error("YYZ table asset " + source_path_ +
                                     " column index is out of range.");
        }
        return rows_[row_index][column_index];
    }

    size_t nearestRowByColumns(const std::vector<size_t>& column_indices,
                               const std::vector<double>& targets) const {
        if (column_indices.size() != targets.size()) {
            throw std::runtime_error("YYZ table nearest-row query for " +
                                     source_path_ +
                                     " has mismatched column and target counts.");
        }
        size_t best_row = 0;
        double best_score = std::numeric_limits<double>::infinity();
        for (size_t row = 0; row < rows_.size(); ++row) {
            double score = 0.0;
            for (size_t i = 0; i < column_indices.size(); ++i) {
                const double delta = value(row, column_indices[i]) - targets[i];
                score += delta * delta;
            }
            if (score < best_score) {
                best_score = score;
                best_row = row;
            }
        }
        return best_row;
    }

private:
    static std::string trim(const std::string& text) {
        const auto begin =
            std::find_if_not(text.begin(), text.end(), [](unsigned char c) {
                return std::isspace(c) != 0;
            });
        const auto end =
            std::find_if_not(text.rbegin(), text.rend(), [](unsigned char c) {
                return std::isspace(c) != 0;
            }).base();
        if (begin >= end) {
            return {};
        }
        return std::string(begin, end);
    }

    static std::vector<std::string> split(const std::string& line) {
        std::string normalized = line;
        std::replace(normalized.begin(), normalized.end(), ',', ' ');

        std::stringstream stream(normalized);
        std::vector<std::string> fields;
        std::string field;
        while (stream >> field) {
            fields.push_back(field);
        }
        return fields;
    }

    static bool looksNumeric(const std::string& value) {
        try {
            size_t parsed = 0;
            (void)std::stod(value, &parsed);
            return parsed == value.size();
        } catch (const std::exception&) {
            return false;
        }
    }

    static double parseDouble(const std::string& value,
                              const std::filesystem::path& path,
                              size_t line_number,
                              size_t column_index) {
        try {
            size_t parsed = 0;
            const double result = std::stod(value, &parsed);
            if (parsed != value.size()) {
                throw std::invalid_argument("trailing characters");
            }
            return result;
        } catch (const std::exception&) {
            throw std::runtime_error("YYZ table " + path.string() + " line " +
                                     std::to_string(line_number) + " column " +
                                     std::to_string(column_index) +
                                     " must be numeric.");
        }
    }

    std::vector<std::string> header_;
    std::vector<std::vector<double>> rows_;
    std::string source_path_;
};

} // namespace yyz_c6
