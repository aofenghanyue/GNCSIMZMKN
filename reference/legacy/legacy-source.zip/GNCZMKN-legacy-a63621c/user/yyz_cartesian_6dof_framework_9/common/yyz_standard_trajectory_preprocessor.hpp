#pragma once

#include "interfaces/yyz_standard_trajectory.hpp"
#include "yyz_table.hpp"

#include <Eigen/Geometry>

#include <cmath>
#include <filesystem>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace yyz_c6 {

struct StandardTrajectoryProcessingOptions {
    std::string processing_profile = "reference_v1";
    std::string time_column = "time_s";
    std::string phase_column = "phase_id";
    double max_time_gap_s = 0.0;
};

// TEMPLATE ALGORITHM SLOT: replace or extend this pipeline for a concrete
// project. The reference implementation preserves all input columns, validates
// time, splits phases, extracts the initial state and appends common derived
// columns. It never writes the processed table to disk.
class StandardTrajectoryPreprocessor {
public:
    static std::shared_ptr<const ProcessedStandardTrajectory> process(
        const std::filesystem::path& source_file,
        const std::string& source_fingerprint,
        const StandardTrajectoryProcessingOptions& options) {
        const FlatTable source = FlatTable::load(source_file, 2);
        if (!source.hasHeader()) {
            throw std::runtime_error(
                "Standard trajectory must have a header: " +
                source_file.generic_string());
        }
        source.requireColumns(requiredStateColumns(options));

        std::vector<std::string> columns = source.header();
        std::vector<std::vector<double>> rows = source.rows();
        const size_t time_column = source.columnIndex(options.time_column);
        const size_t phase_column = source.columnIndex(options.phase_column);
        validateRows(rows, columns.size(), time_column, source_file);

        const size_t position_x = source.columnIndex("position_launch_x_m");
        const size_t position_y = source.columnIndex("position_launch_y_m");
        const size_t position_z = source.columnIndex("position_launch_z_m");
        const size_t velocity_x = source.columnIndex("velocity_launch_x_mps");
        const size_t velocity_y = source.columnIndex("velocity_launch_y_mps");
        const size_t velocity_z = source.columnIndex("velocity_launch_z_mps");
        const size_t quaternion_w = source.columnIndex("q_body_to_inertial_w");
        const size_t quaternion_x = source.columnIndex("q_body_to_inertial_x");
        const size_t quaternion_y = source.columnIndex("q_body_to_inertial_y");
        const size_t quaternion_z = source.columnIndex("q_body_to_inertial_z");
        validatePhaseAndQuaternion(rows,
                                   phase_column,
                                   quaternion_w,
                                   quaternion_x,
                                   quaternion_y,
                                   quaternion_z,
                                   source_file);

        appendColumn(columns, rows, "trajectory_row_index",
                     [&](size_t row) { return static_cast<double>(row); });
        appendColumn(columns, rows, "speed_mps", [&](size_t row) {
            return vectorNorm(rows[row], velocity_x, velocity_y, velocity_z);
        });
        appendColumn(columns, rows, "range_from_launch_m", [&](size_t row) {
            const double dx = rows[row][position_x] - rows.front()[position_x];
            const double dy = rows[row][position_y] - rows.front()[position_y];
            const double dz = rows[row][position_z] - rows.front()[position_z];
            return std::sqrt(dx * dx + dy * dy + dz * dz);
        });
        appendColumn(columns, rows, "flight_path_angle_rad", [&](size_t row) {
            const double horizontal = std::hypot(rows[row][velocity_x],
                                                 rows[row][velocity_y]);
            return std::atan2(rows[row][velocity_z], horizontal);
        });

        appendDerivativeColumn(columns, rows, "acceleration_launch_x_mps2",
                               time_column, velocity_x);
        appendDerivativeColumn(columns, rows, "acceleration_launch_y_mps2",
                               time_column, velocity_y);
        appendDerivativeColumn(columns, rows, "acceleration_launch_z_mps2",
                               time_column, velocity_z);

        auto segments = splitSegments(rows,
                                      time_column,
                                      phase_column,
                                      options.max_time_gap_s);
        appendSegmentIndex(columns, rows, segments);

        RigidBodyState initial_state;
        initial_state.position_launch_m = gnc::math::Vector3(
            rows.front()[position_x], rows.front()[position_y], rows.front()[position_z]);
        initial_state.velocity_launch_mps = gnc::math::Vector3(
            rows.front()[velocity_x], rows.front()[velocity_y], rows.front()[velocity_z]);
        initial_state.attitude_body_to_inertial = Eigen::Quaterniond(
            rows.front()[quaternion_w],
            rows.front()[quaternion_x],
            rows.front()[quaternion_y],
            rows.front()[quaternion_z]);
        initial_state.attitude_body_to_inertial.normalize();
        initial_state.angular_rate_body_radps = gnc::math::Vector3(
            rows.front()[source.columnIndex("angular_rate_body_x_radps")],
            rows.front()[source.columnIndex("angular_rate_body_y_radps")],
            rows.front()[source.columnIndex("angular_rate_body_z_radps")]);

        return std::make_shared<const ProcessedStandardTrajectory>(
            std::move(columns),
            std::move(rows),
            std::move(segments),
            source_file.generic_string(),
            source_fingerprint,
            options.processing_profile,
            options.time_column,
            options.phase_column,
            std::move(initial_state));
    }

private:
    template <typename ValueFunction>
    static void appendColumn(std::vector<std::string>& columns,
                             std::vector<std::vector<double>>& rows,
                             const std::string& name,
                             ValueFunction&& value) {
        for (const auto& column : columns) {
            if (column == name) {
                throw std::runtime_error(
                    "Standard trajectory derived column conflicts with source column '" +
                    name + "'.");
            }
        }
        columns.push_back(name);
        for (size_t row = 0; row < rows.size(); ++row) {
            rows[row].push_back(value(row));
        }
    }

    static void appendDerivativeColumn(std::vector<std::string>& columns,
                                       std::vector<std::vector<double>>& rows,
                                       const std::string& name,
                                       size_t time_column,
                                       size_t value_column) {
        appendColumn(columns, rows, name, [&](size_t row) {
            if (rows.size() == 1) {
                return 0.0;
            }
            const size_t left = row == 0 ? 0 : row - 1;
            const size_t right = row + 1 < rows.size() ? row + 1 : row;
            const double dt = rows[right][time_column] - rows[left][time_column];
            return dt > 0.0
                       ? (rows[right][value_column] - rows[left][value_column]) / dt
                       : 0.0;
        });
    }

    static void appendSegmentIndex(
        std::vector<std::string>& columns,
        std::vector<std::vector<double>>& rows,
        const std::vector<StandardTrajectorySegment>& segments) {
        appendColumn(columns, rows, "processed_segment_index", [&](size_t row) {
            for (const auto& segment : segments) {
                if (row >= segment.begin_row && row <= segment.end_row) {
                    return static_cast<double>(segment.index);
                }
            }
            throw std::runtime_error(
                "Standard trajectory segment split left an uncovered row.");
        });
    }

    static std::vector<std::string> requiredStateColumns(
        const StandardTrajectoryProcessingOptions& options) {
        return {options.time_column,
                options.phase_column,
                "position_launch_x_m",
                "position_launch_y_m",
                "position_launch_z_m",
                "velocity_launch_x_mps",
                "velocity_launch_y_mps",
                "velocity_launch_z_mps",
                "q_body_to_inertial_w",
                "q_body_to_inertial_x",
                "q_body_to_inertial_y",
                "q_body_to_inertial_z",
                "angular_rate_body_x_radps",
                "angular_rate_body_y_radps",
                "angular_rate_body_z_radps"};
    }

    static void validateRows(const std::vector<std::vector<double>>& rows,
                             size_t column_count,
                             size_t time_column,
                             const std::filesystem::path& source_file) {
        double previous_time = -std::numeric_limits<double>::infinity();
        for (size_t row = 0; row < rows.size(); ++row) {
            if (rows[row].size() != column_count) {
                throw std::runtime_error(
                    "Standard trajectory has inconsistent row width at row " +
                    std::to_string(row) + ": " + source_file.generic_string());
            }
            for (size_t column = 0; column < rows[row].size(); ++column) {
                if (!std::isfinite(rows[row][column])) {
                    throw std::runtime_error(
                        "Standard trajectory values must be finite at row " +
                        std::to_string(row) + ", column " +
                        std::to_string(column) + ": " +
                        source_file.generic_string());
                }
            }
            const double time = rows[row][time_column];
            if (!std::isfinite(time) || time <= previous_time) {
                throw std::runtime_error(
                    "Standard trajectory time must be finite and strictly increasing at row " +
                    std::to_string(row) + ": " + source_file.generic_string());
            }
            previous_time = time;
        }
    }

    static void validatePhaseAndQuaternion(
        const std::vector<std::vector<double>>& rows,
        size_t phase_column,
        size_t quaternion_w,
        size_t quaternion_x,
        size_t quaternion_y,
        size_t quaternion_z,
        const std::filesystem::path& source_file) {
        for (size_t row = 0; row < rows.size(); ++row) {
            const double phase = rows[row][phase_column];
            if (std::floor(phase) != phase) {
                throw std::runtime_error(
                    "Standard trajectory phase id must be an integer at row " +
                    std::to_string(row) + ": " + source_file.generic_string());
            }
            const double norm_squared =
                rows[row][quaternion_w] * rows[row][quaternion_w] +
                rows[row][quaternion_x] * rows[row][quaternion_x] +
                rows[row][quaternion_y] * rows[row][quaternion_y] +
                rows[row][quaternion_z] * rows[row][quaternion_z];
            if (norm_squared <= 0.0) {
                throw std::runtime_error(
                    "Standard trajectory quaternion must be non-zero at row " +
                    std::to_string(row) + ": " + source_file.generic_string());
            }
        }
    }

    static std::vector<StandardTrajectorySegment> splitSegments(
        const std::vector<std::vector<double>>& rows,
        size_t time_column,
        size_t phase_column,
        double max_time_gap_s) {
        std::vector<StandardTrajectorySegment> segments;
        size_t begin = 0;
        for (size_t row = 1; row <= rows.size(); ++row) {
            const bool at_end = row == rows.size();
            const bool phase_changed =
                !at_end && rows[row][phase_column] != rows[row - 1][phase_column];
            const bool time_gap =
                !at_end && max_time_gap_s > 0.0 &&
                rows[row][time_column] - rows[row - 1][time_column] > max_time_gap_s;
            if (!at_end && !phase_changed && !time_gap) {
                continue;
            }
            StandardTrajectorySegment segment;
            segment.index = segments.size();
            segment.phase_id = static_cast<int>(rows[begin][phase_column]);
            segment.begin_row = begin;
            segment.end_row = row - 1;
            segment.begin_time_s = rows[begin][time_column];
            segment.end_time_s = rows[row - 1][time_column];
            segments.push_back(segment);
            begin = row;
        }
        return segments;
    }

    static double vectorNorm(const std::vector<double>& row,
                             size_t x,
                             size_t y,
                             size_t z) {
        return std::sqrt(row[x] * row[x] + row[y] * row[y] + row[z] * row[z]);
    }
};

} // namespace yyz_c6
