#pragma once

#include "gnc/common/logger.hpp"
#include "gnc/common/math/eigen_types.hpp"
#include "gnc/core/config_manager.hpp"
#include "gnc/core/config_reader.hpp"

#include <Eigen/Geometry>

#include <cmath>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace yyz_c6::config {

inline gnc::math::Vector3 toVector3(const std::vector<double>& values) {
    return gnc::math::Vector3(values[0], values[1], values[2]);
}

inline Eigen::Quaterniond toQuaternion(const std::vector<double>& values,
                                       const std::string& path) {
    Eigen::Quaterniond q(values[0], values[1], values[2], values[3]);
    if (!std::isfinite(q.norm()) || q.norm() == 0.0) {
        throw std::runtime_error(path + " must be a non-zero quaternion.");
    }
    q.normalize();
    return q;
}

inline gnc::math::Matrix3 diagonalMatrix(const std::vector<double>& values) {
    gnc::math::Matrix3 matrix = gnc::math::Matrix3::Zero();
    matrix(0, 0) = values[0];
    matrix(1, 1) = values[1];
    matrix(2, 2) = values[2];
    return matrix;
}

inline void warnUnknownKeys(const gnc::core::ConfigNode& node,
                            const std::string& path) {
    const auto unused = node.getUnusedKeys();
    if (unused.empty()) {
        return;
    }

    std::ostringstream joined;
    for (size_t i = 0; i < unused.size(); ++i) {
        if (i > 0) {
            joined << ", ";
        }
        joined << unused[i];
    }
    LOG_WARNING("{} ignores unrecognized config keys: {}.", path, joined.str());
}

inline std::string optionalString(const gnc::core::ConfigNode& node,
                                  const std::string& key,
                                  const std::string& fallback,
                                  const std::string& path) {
    const auto& child = node[key];
    if (child.isNull()) {
        return fallback;
    }
    if (!child.isString()) {
        throw std::runtime_error(path + "." + key + " must be a string.");
    }
    return child.asString();
}

inline double optionalDouble(const gnc::core::ConfigNode& node,
                             const std::string& key,
                             double fallback,
                             const std::string& path) {
    const auto& child = node[key];
    if (child.isNull()) {
        return fallback;
    }
    if (!child.isNumber()) {
        throw std::runtime_error(path + "." + key + " must be a number.");
    }
    return child.asDouble();
}

inline bool optionalBool(const gnc::core::ConfigNode& node,
                         const std::string& key,
                         bool fallback,
                         const std::string& path) {
    const auto& child = node[key];
    if (child.isNull()) {
        return fallback;
    }
    if (!child.isBool()) {
        throw std::runtime_error(path + "." + key + " must be a boolean.");
    }
    return child.asBool();
}

inline std::vector<double> optionalDoubleArray(const gnc::core::ConfigNode& node,
                                               const std::string& key,
                                               std::vector<double> fallback,
                                               size_t exact_size,
                                               const std::string& path) {
    const auto& child = node[key];
    if (child.isNull()) {
        return fallback;
    }
    if (!child.isArray()) {
        throw std::runtime_error(path + "." + key + " must be an array.");
    }
    if (exact_size > 0 && child.size() != exact_size) {
        throw std::runtime_error(path + "." + key + " must contain exactly " +
                                 std::to_string(exact_size) + " numbers.");
    }
    std::vector<double> values;
    values.reserve(child.size());
    for (size_t i = 0; i < child.size(); ++i) {
        const auto& item = child[i];
        if (!item.isNumber()) {
            throw std::runtime_error(path + "." + key + "[" +
                                     std::to_string(i) + "] must be a number.");
        }
        values.push_back(item.asDouble());
    }
    return values;
}

} // namespace yyz_c6::config
