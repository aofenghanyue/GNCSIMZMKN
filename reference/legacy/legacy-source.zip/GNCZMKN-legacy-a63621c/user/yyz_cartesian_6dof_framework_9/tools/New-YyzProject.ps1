param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectName,

    [switch]$Activate
)

$ErrorActionPreference = 'Stop'

if ($ProjectName -notmatch '^[A-Za-z_][A-Za-z0-9_-]*$') {
    throw "ProjectName must match [A-Za-z_][A-Za-z0-9_-]*."
}

$templateRoot = Split-Path -Parent $PSScriptRoot
$templateName = Split-Path -Leaf $templateRoot
$userRoot = Split-Path -Parent $templateRoot
$repoRoot = Split-Path -Parent $userRoot
$destination = Join-Path $userRoot $ProjectName

if (Test-Path -LiteralPath $destination) {
    throw "Destination already exists: $destination"
}

Copy-Item -LiteralPath $templateRoot -Destination $destination -Recurse

$textExtensions = @(
    '.md', '.json', '.hpp', '.cpp', '.csv', '.txt', '.ps1', '.cmake'
)
$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

Get-ChildItem -LiteralPath $destination -Recurse -File | ForEach-Object {
    if ($textExtensions -contains $_.Extension.ToLowerInvariant()) {
        $text = [System.IO.File]::ReadAllText($_.FullName, [System.Text.Encoding]::UTF8)
        $updated = $text.Replace($templateName, $ProjectName)
        if ($updated -ne $text) {
            [System.IO.File]::WriteAllText($_.FullName, $updated, $utf8NoBom)
        }
    }
}

if ($Activate) {
    [System.IO.File]::WriteAllText(
        (Join-Path $userRoot 'active_project'),
        "$ProjectName`n",
        $utf8NoBom)
}

Write-Host "Created project: $destination"
if ($Activate) {
    Write-Host "Updated user/active_project to $ProjectName"
}
Write-Host "Next commands:"
Write-Host "  cmake -S `"$repoRoot`" -B build-mingw-$ProjectName -G `"MinGW Makefiles`" -DBUILD_TESTS=OFF -DGNC_ACTIVE_PROJECT=$ProjectName"
Write-Host "  cmake --build build-mingw-$ProjectName -j 4"
Write-Host "  build-mingw-$ProjectName\bin\gnc_sim.exe --config user/$ProjectName/config/mission.json"
