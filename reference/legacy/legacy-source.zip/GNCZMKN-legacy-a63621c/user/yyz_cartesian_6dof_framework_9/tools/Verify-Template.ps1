param(
    [string]$BuildDirectory = '',
    [switch]$Reconfigure
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$userRoot = Split-Path -Parent $projectRoot
$repoRoot = Split-Path -Parent $userRoot
$projectName = Split-Path -Leaf $projectRoot
if ([string]::IsNullOrWhiteSpace($BuildDirectory)) {
    $BuildDirectory = "build-mingw-$projectName"
}
$buildPath = Join-Path $repoRoot $BuildDirectory
$exe = Join-Path $buildPath 'bin/gnc_sim.exe'

Push-Location $repoRoot
try {
    if ($Reconfigure -or !(Test-Path -LiteralPath $exe)) {
        & cmake -S . -B $BuildDirectory -G 'MinGW Makefiles' -DBUILD_TESTS=OFF "-DGNC_ACTIVE_PROJECT=$projectName"
        if ($LASTEXITCODE -ne 0) { throw 'CMake configure failed.' }
        & cmake --build $BuildDirectory -j 4
        if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
    }

    $listing = & $exe --list-components-verbose 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) { throw 'Component listing failed.' }
    foreach ($requiredType in @(
        'custom.common.c6.standard_trajectory',
        'custom.form.c6.rigid_body',
        'custom.process.c6.trajectory_planner',
        'custom.process.c6.guidance',
        'custom.output.c6.aerodynamics',
        'custom.interaction.c6.force_moment'
    )) {
        if (!$listing.Contains($requiredType)) {
            throw "Required component type is missing: $requiredType"
        }
    }

    & $exe --config "user/$projectName/config/mission.json"
    if ($LASTEXITCODE -ne 0) { throw 'Nominal mission failed.' }

    & $exe --simflow "user/$projectName/simflow/single.json" --jobs 1
    if ($LASTEXITCODE -ne 0) { throw 'Single-case SimFlow failed.' }

    $effectiveMission = Join-Path $repoRoot "user/outputs/$projectName/simflow_single/case_000001_nominal/effective_mission.json"
    if (!(Test-Path -LiteralPath $effectiveMission)) {
        throw "Effective mission was not produced: $effectiveMission"
    }
    $effectiveMissionText = [System.IO.File]::ReadAllText(
        $effectiveMission,
        [System.Text.Encoding]::UTF8
    )
    if ($effectiveMissionText.Contains('project://')) {
        throw 'Effective mission still contains project:// and cannot be replayed from its case directory.'
    }

    & $exe --config $effectiveMission
    if ($LASTEXITCODE -ne 0) { throw 'Effective mission replay failed.' }

    & $exe --simflow "user/$projectName/simflow/matrix.json" --jobs 1
    if ($LASTEXITCODE -ne 0) { throw 'Matrix SimFlow failed.' }

    $matrixRoot = Join-Path $repoRoot "user/outputs/$projectName/simflow_matrix"
    $nominalCsv = Join-Path $matrixRoot 'case_000001_nominal/trajectory_nominal.csv'
    $alternateCsv = Join-Path $matrixRoot 'case_000002_alternate_assets/trajectory_nominal.csv'
    if (!(Test-Path -LiteralPath $nominalCsv) -or !(Test-Path -LiteralPath $alternateCsv)) {
        throw 'Matrix standard-trajectory verification CSV files are missing.'
    }
    $nominal = Import-Csv -LiteralPath $nominalCsv | Select-Object -First 1
    $alternate = Import-Csv -LiteralPath $alternateCsv | Select-Object -First 1
    if ([double]$nominal.'interceptor.standard_trajectory.row_count' -ne 5.0 -or
        [double]$nominal.'interceptor.standard_trajectory.column_count' -ne 28.0 -or
        [double]$nominal.'interceptor.standard_trajectory.segment_count' -ne 3.0) {
        throw 'Nominal standard trajectory was not prepared into the expected in-memory product.'
    }
    if ([double]$nominal.'interceptor.dynamics.position_launch.x' -ne 0.0 -or
        [double]$nominal.'interceptor.dynamics.position_launch.z' -ne 1000.0 -or
        [double]$alternate.'interceptor.dynamics.position_launch.x' -ne 50.0 -or
        [double]$alternate.'interceptor.dynamics.position_launch.z' -ne 1200.0) {
        throw 'Case-selected standard trajectories did not initialize the form with different extracted states.'
    }
    if (Test-Path -LiteralPath (Join-Path $matrixRoot 'processed_standard_trajectory.csv')) {
        throw 'Prepared standard trajectory must remain in memory.'
    }

    Write-Host 'YYZ template verification passed:'
    Write-Host '  component registration'
    Write-Host '  nominal mission'
    Write-Host '  in-memory standard trajectory preparation'
    Write-Host '  case-specific trajectory selection and form initialization'
    Write-Host '  single-case SimFlow'
    Write-Host '  effective mission replay'
}
finally {
    Pop-Location
}
