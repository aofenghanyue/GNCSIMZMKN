# YYZ Cartesian 6DoF Scenario Contract

本文把 `plan.md` 的问答沉淀为这一类 user 项目的模板契约。目标是固定接口、输入文件形状、组件链路和替换边界；具体项目主要替换参数、资产文件和组件内部算法。

## 核心固定点

| 主题 | 固定契约 | 项目可变项 |
| --- | --- | --- |
| 场景类别 | 单主飞行器加可选简易目标，主飞行器采用 6DoF 笛卡尔 form family `yyz_c6` | 项目名、研究算法、飞行阶段含义、目标程序 |
| 坐标与状态 | 发射系位置速度，惯性系体姿态，体轴角速度 | 坐标转换细节、引力/非惯性项完整模型 |
| Mission 形状 | 短入口 mission include 完整 assembly；主飞行器加简易目标 | `dt`、运行时长、输出目录、终止条件、record 字段 |
| 输入链路 | IMU、卫导、空速数据 provider 接口固定 | 噪声、漂移、延迟、失锁、采样和硬件扰动模型 |
| Process 链路 | sequencer、navigation、target_manager、onboard_state、guidance、flight_control、control_allocation | 状态机切换条件、制导律、飞控律、分配算法 |
| Output 能力 | mass、propulsion、actuator、aerodynamics provider 接口固定 | 质量构型、发动机模型、执行机构传递函数、气动插值 |
| Interaction | 读取气动、推进、质量、重力，输出机体系合力/力矩和重力项 | 坐标系约定、重力是否进入 form、其它力源叠加 |
| Perturbation | 单次运行只读取 materialized mission 中的 `vehicles[].perturbation` | case 变量、资产枚举映射、动态拉偏含义 |
| Preparation | 标准轨迹与气动表在 `prepare()` 加载；标准轨迹形成只读多列内存产品 | 项目切分、提取、判断、派生列和初始化规则 |
| 输出 | CSV 记录 observable，summary 记录基础指标 | 项目指标、debug snapshot、筛选规则 |

## `plan.md` 覆盖清单

| 条目 | 模板处理 | 主要文件 |
| --- | --- | --- |
| A. 场景类边界 | 固定为 `yyz_c6` 一类 6DoF 笛卡尔项目；研究算法、参数、资产由具体项目决定 | `README.md`, `interfaces/yyz_c6_types.hpp` |
| B. Mission 形状 | 一个主飞行器加一个简易目标；多阶段由组件局部 sequencer 承担；终止组件可替换 | `config/mission.json`, `config/assembly/*.json`, `process_sequencer.hpp`, `termination_state_metric.hpp` |
| C. Form 与坐标 | 自定义 form family；发射系平动、惯性姿态；truth 接口集中在 `Truth` | `form_rigid_body_6dof.hpp`, `interfaces/yyz_c6_types.hpp` |
| D. 输入文件格式 | 顶层 mission 短小；参数和稳定接线分层；字段带单位；未知 key warning | `config/mission.json`, `config/parameters/`, `config/assembly/`, `common/yyz_config_helpers.hpp` |
| E. 资产格式 | `FlatTable` 固定带表头的平铺文本表；气动与标准轨迹有各自必需列；资产集合可由 perturbation 切换 | `common/yyz_table.hpp`, `common/yyz_standard_trajectory_preprocessor.hpp`, `output_aerodynamics.hpp`, `data/` |
| F. Environment | CGCS2000 常数、重力、大气、风场 provider 接口固定；实现可替换 | `environment_cgcs2000.hpp`, `environment_wind_field.hpp` |
| G. Input | IMU、卫导、空速接口固定；误差、延迟和采样模型由具体项目替换 | `input_imu.hpp`, `input_satnav.hpp`, `input_air_data.hpp` |
| H. Process | 导航、轨迹规划、制导、飞控、分配、机上状态、时序和目标管理均有独立组件 | `process_*.hpp` |
| I. Output | 气动、质量、推进、执行机构 provider 接口固定；能力字段覆盖 plan 中主要物理能力 | `output_*.hpp`, `interfaces/yyz_c6_types.hpp` |
| J. Interaction | 力/力矩在机体系叠加，重力以发射系加速度传给 form | `interaction_force_moment_6dof.hpp` |
| K. Perturbation 与批量试验 | perturbation key 选择气动与标准轨迹资产；提供 single/matrix/random SimFlow；每个 case 写可独立回放的 effective mission | `config/parameters/perturbation.json`, `simflow/`, `README.md` |
| L. 输出与评估指标 | CSV 记录全链路 observable；summary 提供基础指标 | `config/mission.json`, `summary_basic_metrics.hpp` |
| M. 验证规则 | 关键物理输入和资产路径 required；未知 key warning；轻量验证覆盖注册、单次运行、物化和回放 | 各组件 `configure()`, `tools/Verify-Template.ps1` |
| N. 项目沉淀边界 | 所有项目私有接口留在 `user/yyz_cartesian_6dof_framework_9`；后续成熟后再提炼 framework 能力 | 本目录全部文件 |

## 资产契约

通用表格资产使用 `FlatTable`，构建期路径由 framework `PreparationContext` 解析：

- 支持空白或逗号分隔。
- 可带 `#` 注释行。
- 第一条非注释数据可作为表头。
- 组件可声明必需列，缺列时 build fail。
- 当前提供最近节点查询，便于形成可运行参考实现。
- 支持 `project://`、`repo://` 和 `user-data://` 资产根。
- perturbation 可通过枚举值选择完整资产目录。
- 标准轨迹处理结果保留源列并追加派生列，通过 `IStandardTrajectoryProvider` 留在内存中。
- 具体项目需要高精度时，在组件内部替换为多维插值、函数模型或积分模型。

气动三通道表的列契约：

| 通道 | 自变量列 | 输出列 |
| --- | --- | --- |
| pitch | `alpha_rad`, `mach`, `delta_pitch_rad` | `F_CA`, `F_CN`, `M_Cm` |
| yaw | `beta_rad`, `mach`, `delta_yaw_rad` | `F_CA`, `F_CY`, `M_Cn` |
| roll | `roll_rate_radps`, `mach`, `delta_roll_rad` | `F_CA`, `M_Cl` |

当前气动参考实现使用最近节点查表，并把三个通道的 `F_CA` 平均为轴向力系数。这个合成方式用于保证模板开箱可运行；具体项目应在 `computeReferenceTableCoefficients()` 中替换为项目认可的通道叠加规则。

## 扰动命名约定

扰动 key 使用以下形式：

```text
<domain>.<quantity>_scale
<domain>.<quantity>_bias
<domain>.<asset>_id
```

已使用的 key：

| key | 作用 |
| --- | --- |
| `environment.wind_scale` | 缩放风场输入 |
| `mass.scale` | 缩放初始质量 |
| `propulsion.thrust_scale` | 缩放推力 |
| `aero.F_CA_bias` | 轴向力系数偏置 |
| `aero.F_CN_bias` | 法向力系数偏置 |
| `aero.F_CY_bias` | 侧向力系数偏置 |
| `aero.asset_set` | 气动资产集合枚举；解析值是资产目录 |
| `trajectory.asset_set` | 标准轨迹资产枚举；解析值是源轨迹文件 |

具体项目新增扰动时，优先在组件配置中暴露 `*_key` 字段，让 SimFlow 只负责写入 materialized perturbation 值。

## 输出目录约定

普通 mission 的目标目录形状：

```text
user/outputs/{project}/{timestamp}/{session_name}.csv
user/outputs/{project}/{timestamp}/summary.txt
```

SimFlow 在输出目录下建立各 case 子目录，并在每个目录写出 `effective_mission.json`、CSV 和 summary。显式资产 URI 会在物化时固化，普通 `--config` 可以从 case 目录回放。Git 提交仍是实验归档的推荐入口；模板复制脚本不把某次提交号固化进 mission。

## 替换边界

保留 type id 的替换：

- 算法内部变化。
- 资产内容变化，表头列契约不变。
- 扰动 key 增减，provider 输出结构兼容。

新增 type id 的替换：

- provider 数据结构变化。
- form input 或 truth 契约变化。
- mission placement 或配置 schema 大幅变化。
- 气动、推进、执行机构的资产结构换成另一套列契约。
