# Form Family 对称性改进清单（设计迭代记录）

本文记录一次针对 form-family 对称性的审阅结果，只列出需要整理的方向和证据位置，不包含具体代码改法。

## 判断准则

- `3dof` 和 `6dof` 是平级能力轴。
- 每个 DOF 下的 `local_spherical` / geographic 与 `cartesian` / launch-frame 是平级 form family。
- 组件类型如果声明空 `form_family`，应表示它确实兼容同一层级的所有相关 form，或它和 form runtime 没有直接耦合。
- 组件类型如果绑定某个 form 的 truth view、input provider、observable 派生语义或 mission family，应在 type id、注册元数据、文档和测试中一致表达这个 family。
- `local_spherical` 不能继续作为隐含默认 family；它应和 `cartesian` 一样显式。

## 本次不纳入范围

- `coordinate_tree` 的多 form 适配暂不纳入。本项需要先决定是否为所有 form 推导坐标转换公式，并把对应 spec 固化到服务契约中。
- `local_spherical_3dof.launch_track` 相关的坐标服务现状只作为背景，不列为本清单的行动项。

## 当前实现记录

- `vehicle.input.local_spherical_*`、`vehicle.process.local_spherical_*` 已作为唯一 builtin type id 注册，早期无 family 前缀的 local-spherical 名称已经删除。
- local-spherical input、local-spherical process、cartesian/local-spherical engagement termination 和 summary 均已补齐 `form_family` 元数据。
- 顶层 project-specific termination / summary 不再回退到全局 selected family；其 family 元数据描述组件依赖的 form 接口，具体读取对象由配置和依赖预检决定。
- 示例 mission、核心测试和参考文档已切换到 canonical local-spherical 名称。
- CAVH guidance type id 已显式标注 `local_spherical`；CAVH aero assets 只保留 DOF 级 common asset 语义，`form_family` 已清空。

## 已确认的不对称项

### A. `vehicle.input` 的 local-spherical 组件缺少 form family 元数据

修复前现状：

- `vehicle.input.imu_3dof.ideal`、`satellite_nav_3dof`、`air_data_3dof`、`seeker_3dof` 的注册信息没有 `local_spherical_3dof`。
- `vehicle.input.imu_6dof.ideal`、`satellite_nav_6dof`、`air_data_6dof`、`seeker_6dof` 的注册信息没有 `local_spherical_6dof`。
- 对应实现直接包含并绑定 `gnc/forms/local_spherical_*dof/interfaces/i_truth_view.hpp`。
- Cartesian 同类 input 已经使用 `vehicle.input.cartesian_*` type id，并声明 `cartesian_3dof` / `cartesian_6dof`。

证据：

- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:173`
- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:241`
- `framework/include/gnc/vehicle/input/components/ideal_imu_3dof.hpp`
- `framework/include/gnc/vehicle/input/components/ideal_imu_6dof.hpp`
- `tests/test_component_listing.cpp:181`
- `tests/test_component_listing.cpp:332`

改进条目：

- 为 local-spherical input 建立和 cartesian input 对称的 family 表达。
- 决定是否引入显式 `vehicle.input.local_spherical_*` canonical type id，并把旧 type id 作为兼容别名或迁移入口。
- 更新组件清单测试，要求 local-spherical input 也声明对应 `form_family`。

### B. `vehicle.process` 的 local-spherical 组件元数据已有 family，type id 仍是早期默认名

修复前现状：

- `vehicle.process.phase_sequencer_3dof.ideal`、`trajectory_planner_3dof`、`navigation_3dof`、`target_tracking_3dof`、`guidance_3dof`、`flight_control_3dof`、`control_allocation_3dof` 均声明 `local_spherical_3dof`。
- `vehicle.process.phase_sequencer_6dof.ideal`、`trajectory_planner_6dof`、`navigation_6dof`、`target_tracking_6dof`、`guidance_6dof`、`attitude_control_6dof`、`control_allocation_6dof` 均声明 `local_spherical_6dof`。
- Cartesian 同类 process 使用 `vehicle.process.cartesian_*` type id。

证据：

- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:313`
- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:376`
- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:439`
- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:502`
- `tests/test_component_listing.cpp:216`
- `tests/test_component_listing.cpp:367`

改进条目：

- 建立 process type id 的 canonical 命名规则，让 local-spherical 和 cartesian 对称。
- 评估旧的无 family 前缀 type id 作为兼容别名、文档迁移名或废弃名的处理策略。
- 同步更新示例 mission，避免 geographic 示例继续强化 local-spherical 的隐含默认地位。

### C. engagement termination / summary 绑定具体 form，却没有 form family 元数据

修复前现状：

- `termination.engagement_3dof`、`termination.engagement_6dof` 绑定 local-spherical truth view，但注册时没有 `form_family`。
- `termination.engagement_cartesian_3dof`、`termination.engagement_cartesian_6dof` 绑定 cartesian truth view，但注册时也没有 `form_family`。
- `summary.engagement_3dof.ideal`、`summary.engagement_6dof.ideal`、`summary.engagement_cartesian_3dof.ideal`、`summary.engagement_cartesian_6dof.ideal` 也存在同样问题。
- `termination.component_field_below` / `termination.component_field_above` 属于按 observable 字段工作的通用组件，空 `form_family` 可以保留。

证据：

- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:764`
- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:796`
- `framework/include/gnc/termination/components/engagement_termination_3dof.hpp`
- `framework/include/gnc/termination/components/engagement_termination_cartesian_3dof.hpp`
- `framework/include/gnc/summary/components/ideal_engagement_summary_3dof.hpp`
- `framework/include/gnc/summary/components/ideal_engagement_summary_cartesian_3dof.hpp`
- `tests/test_component_listing.cpp:269`
- `tests/test_component_listing.cpp:432`

改进条目：

- 为 engagement termination / summary 建立显式 family 元数据，用来描述它们依赖的 form truth 接口。
- 将 engagement termination / summary 视为项目级 form-aware 组件；同一套 form 接口下可以复用，跨 form 复用需要显式适配。
- 命名上让 local-spherical 和 cartesian 对称，或明确这些组件的具体项目选择逻辑依赖配置项。
- 增加测试覆盖：注册清单要求 engagement termination / summary 带有 family 元数据；多 vehicle mission 中，显式配置读取目标 vehicle 或目标 component 时不被全局 family 拦截。后续如组件内部能稳定解析目标 component，可在依赖预检中给出更细的 truth family 诊断。

### D. 顶层 project-specific termination / summary 的 family 诊断边界需要收窄

修复前现状：

- `MissionAssembler` 对 `termination` 和 `summary` 使用 `scope_id = "mission"`。
- `selected_form_family_by_scope_` 当前以 vehicle id 为主；单飞行器只是 `vehicles[]` 长度为 1 的场景，不需要额外的单飞行器语义分支。
- 顶层 termination / summary 的框架契约主要是 role、stage 和 required interface；具体项目组件可以通过配置引用目标 vehicle 或目标 component。
- `ValidationPipeline` 只在 descriptor 自身 `form_family` 非空时比较 family，当前 engagement termination / summary 因为空 family 绕过该类诊断。

证据：

- `framework/include/gnc/core/mission_assembler.hpp:468`
- `framework/include/gnc/core/mission_assembler.hpp:480`
- `framework/include/gnc/core/mission_assembler.hpp:502`
- `framework/include/gnc/core/validation_pipeline.hpp:178`

改进条目：

- 明确 form-family 元数据在 project-specific termination / summary 中只描述组件依赖的 form 接口，不承担通用项目语义。
- 在 family 元数据补齐后，围绕组件配置引用的目标 component 保留后续可诊断入口；该诊断应由具体 termination / summary 的配置语义决定。
- 多 vehicle mission 中，由具体 termination / summary 的配置和依赖决定它读取哪些 vehicle 或 component，框架不推导一个全局唯一 selected family。
- 保持 `component_field_*` 这类按字段工作的通用组件不受 family 约束。

### E. form 注册函数名仍停留在早期 3DoF 语义

修复前现状：

- `registerState3DoFPackages` 同时注册 `cartesian_3dof`、`cartesian_6dof`、`local_spherical_3dof`、`local_spherical_6dof` 和 `target_point`。
- 函数名会给维护者造成错误预期，也弱化了 3DOF / 6DOF 平级关系。

证据：

- `framework/include/gnc/bootstrap/register_builtin_packages.hpp:647`

改进条目：

- 将该函数改成 family-neutral 的命名，例如 forms/state packages 语义。
- 同步更新架构 guard 中对 bootstrap 函数名的检查。

### F. `local_spherical_3dof` truth 中含 launch 派生量，`local_spherical_6dof` 没有对应边界说明

修复前现状：

- `local_spherical_3dof::Truth` 暴露 `velocity_launch_mps` 和 `launch_azimuth_rad`。
- `local_spherical_3dof::PointMass` 要求 `launch_azimuth_rad` 配置，并把 launch-frame velocity 作为 observable。
- `local_spherical_6dof::Truth` 暴露 ECEF 派生量，但没有 launch-frame 派生量。

证据：

- `framework/include/gnc/forms/local_spherical_3dof/types.hpp:29`
- `framework/include/gnc/forms/local_spherical_3dof/components/point_mass.hpp:60`
- `framework/include/gnc/forms/local_spherical_3dof/components/point_mass.hpp:146`
- `framework/include/gnc/forms/local_spherical_6dof/types.hpp:26`

改进条目：

- 先澄清 launch 派生量属于 form truth、derived view、service 查询，还是项目侧记录需求。
- 在不展开 coordinate tree 推导的前提下，记录 local-spherical 3DOF / 6DOF truth 字段的对称性原则。
- 如果保留在 form truth 中，应为 6DOF 的差异写清楚物理理由或后续扩展入口。

### G. 参考文档和示例 mission 仍强化旧的默认名

修复前现状：

- `doc/06-reference.md` 的内置 form 表只展开了 3DOF form 配置，对 6DOF form 的同级地位表达不足。
- `doc/03-mission-configuration.md` 的 local-spherical 示例使用 `vehicle.input.satellite_nav_3dof.ideal`、`vehicle.process.guidance_3dof.ideal` 等早期默认名。
- `user/example_04_ideal_6dof_baseline`、`user/example_05_ideal_3dof_geographic_baseline` 和 `user/example_08_cavh_geographic_3dof_custom` 仍使用这些默认名。
- Cartesian 示例已经使用显式 `cartesian_*` type id。

证据：

- `doc/06-reference.md:110`
- `doc/03-mission-configuration.md:179`
- `user/example_04_ideal_6dof_baseline/config/mission.json:40`
- `user/example_05_ideal_3dof_geographic_baseline/config/mission.json:41`
- `user/example_06_ideal_cartesian_3dof_baseline/config/mission.json:32`
- `user/example_07_ideal_cartesian_6dof_baseline/config/mission.json:36`
- `user/example_08_cavh_geographic_3dof_custom/config/mission.json:60`

改进条目：

- 在 reference 中以 DOF x form family 的矩阵方式列出核心 builtin type id。
- 更新示例 mission 使用 canonical type id。
- 在迁移期文档中明确旧名的兼容状态，避免用户继续新增旧式配置。

### H. 测试覆盖接受了现有不对称

修复前现状：

- `tests/test_component_listing.cpp` 对 cartesian input 要求 form family，对 local-spherical input 只检查 role/stage。
- engagement termination / summary 的测试只检查 role/stage，没有要求 family。
- 已有 form / interaction mismatch 测试主要覆盖 interaction，尚未覆盖 input、process、termination、summary 的全链路一致性。

证据：

- `tests/test_component_listing.cpp:165`
- `tests/test_component_listing.cpp:181`
- `tests/test_component_listing.cpp:269`
- `tests/test_component_listing.cpp:332`
- `tests/test_component_listing.cpp:432`
- `tests/test_mission_contract.cpp:1297`

改进条目：

- 把 component listing 测试改成对称断言。
- 增加 family mismatch 装配失败测试，覆盖 vehicle-scoped input / process / interaction 的 local-spherical/cartesian 互换；termination / summary 先覆盖注册元数据和显式目标配置语义。
- 增加架构 guard，防止后续新增 form-specific 组件时遗漏 `form_family`。

### I. CAVH user project 组件需要在 canonical 规则确定后复查

修复前现状：

- `cavh.interaction.local_spherical_3dof.aero_propulsive` 的 type id 和 form family 是对称表达。
- `cavh.process.guidance_3dof.glide_range_maximizing`、`cavh.process.guidance_3dof.programmed_aoa` 声明 `local_spherical_3dof`，type id 没有显式 local-spherical。
- `cavh.common.aero_assets_3dof.table2d`、`cavh.common.aero_assets_3dof.paper_parabolic` 声明 `local_spherical_3dof`，但它们看起来更像 DOF 级资产。需要判断这些资产是否确实 form-specific。

证据：

- `user/example_08_cavh_geographic_3dof_custom/components/cavh_aero_propulsive_interaction_3dof.hpp:163`
- `user/example_08_cavh_geographic_3dof_custom/components/cavh_glide_range_guidance.hpp:658`
- `user/example_08_cavh_geographic_3dof_custom/components/cavh_programmed_aoa_guidance.hpp:182`
- `user/example_08_cavh_geographic_3dof_custom/components/cavh_table_aero_assets_3dof.hpp:77`
- `user/example_08_cavh_geographic_3dof_custom/components/cavh_paper_aero_assets_3dof.hpp:177`

改进条目：

- canonical builtin 命名确定后，再复查 user project type id 是否跟随同一规则。
- 对 common aero assets 做语义判断：若兼容所有 3DOF form，应清空 family；若只适配 local-spherical，应在 type id 中体现。
- user project 可以保留较轻迁移节奏，但 active project mission 应尽量使用 canonical 名称。

## 迁移原则建议

- 先补元数据和测试，让现有真实绑定关系变得可诊断。
- 再确定 canonical type id，避免先改 mission 名称导致旧配置大量失效。
- 实验室框架直接切换到唯一 canonical type id，不保留兼容别名和并行入口。
- 新增或提升 builtin 时，强制检查 type id、role/stage、form family、接口声明、文档和测试是否同时对称。
