# 文档深度核对中发现的架构议题

状态：待维护者决策，复核于 2026-07-19。

本文记录本轮架构文档重构期间，从源码、测试和现有输出中偶然发现的实现风险与改进机会。它不构成当前运行契约，也不代表已经批准修改。正式契约仍以 `README.md`、`doc/`、源码和测试为准。

## 1. 摘要与建议优先级

| 编号 | 优先级建议 | 议题 | 当前影响 |
| --- | --- | --- | --- |
| F-01 | P1 | Form 完整性只按整个 mission 检查 | 多 vehicle 中某个 vehicle 可以没有任何 Form 节点而通过全局检查 |
| F-02 | P1 | runtime 异常缺少统一收尾保证 | logger、summary 和 node finalize 可能在异常路径跳过 |
| F-03 | P2 | builtin `standard` Interaction 的物理与 observable 语义易误读 | baseline 接线成功可能被理解成物理闭环；local-spherical 诊断字段会被重置 |
| F-04 | P2 | 同一 phase 的数据依赖没有显式调度契约 | 缺 priority 时，重排 mission 数组会改变链路结果 |
| F-05 | P2 | initialize 只有注册顺序和 Perturbation 特例 | 节点可能读取尚未建立运行态的依赖输出 |
| F-06 | P2 | terminal endpoint 继续执行离散 update | 状态型算法在无后续积分段时仍多更新一次 |
| F-07 | P3 | 注册接口元数据与实际动态查询并非同一权威 | 漏写 advertised interface 时，查询可能成功，清单与诊断仍不完整 |
| F-08 | P3 | active-project 组件发现使用文本包含检查 | 注释或字符串可以通过 CMake 粗粒度注册检查 |
| F-09 | P3 | direct Simulator 路径不会执行 prepare | 带资产节点直接注册后可能在未准备状态 initialize |

优先级表示建议审查顺序，不表示紧急故障等级。F-01 与 F-02 直接影响失败边界；F-03～F-06 主要影响实验解释和运行语义；其余属于维护性问题。

## 2. F-01：Form 完整性需要按 vehicle 检查

### 证据

`ValidationPipeline::validateDescriptors()` 使用单个 `bool has_form_node`，遍历全部 descriptor 后只在 `descriptors` 非空时检查整个 mission 是否至少出现一个 Form placement。

`MissionAssembler::buildForm()` 要求 `vehicles[i].form` 是 object，但 `components` 可以为空。由此，一个多 vehicle mission 只要任意 vehicle 有 Form，另一个 vehicle 的空 `form.components[]` 不会触发“该 vehicle 缺 Form”的专门错误。

### 风险

- 空 vehicle 可以悄悄进入所有权图。
- 后续节点若没有直接 required truth binding，错误可能延迟到运行结果解释阶段。
- 文档当前约定“每个 vehicle 拥有有效 Form”，实现检查力度偏弱。

### 可选方案

1. ValidationPipeline 按每个 `ScopeKind::Vehicle` 统计 Form descriptor，要求至少一个。
2. MissionAssembler 在结束单个 vehicle 装配后检查该 scope 的 Form 数量。
3. 若未来允许纯逻辑 vehicle，增加显式 vehicle kind，避免用空 Form 隐式表达。

### 建议

优先采用方案 1，让 Form 完整性继续位于 descriptor/graph 验证层，并增加：

- 两 vehicle、第二个 vehicle 空 Form 的失败测试；
- 每个 vehicle 多 Form slice、同 family 的成功测试；
- 错误消息包含 `vehicles[i].form.components` 或 vehicle id。

## 3. F-02：runtime 异常路径缺少统一收尾保证

### 证据

`Simulator::run()` 在循环正常结束后依次执行：

```text
auto_logger_.stop()
-> SimulationSummary::write()
-> phase Finalizing
-> finalize()
-> phase Completed
```

循环中的 publish、callback、discrete update、record、termination 或 integration 抛出异常时，当前函数没有 scope guard 或 catch/finally 路径，上述正常收尾步骤会被跳过。`AutoDataLogger` 的析构函数会调用 `stop()`，因此对象销毁时 sink 仍会关闭；summary、node finalize 和明确的 Failed 终态没有对应保证。

### 风险

- 异常被上层捕获且 Simulator 继续存活时，logger 会保持打开到 reset 或析构；已有行最终可由析构关闭，但没有完整性标记；
- 外部资源型节点无法保证 finalize；
- partial output 缺少统一失败标识和失败时刻；
- multiprocess SimFlow 能知道 case 失败，却难以从 case 目录判断输出完整度。

### 可选方案

1. 将 logger 已有的 RAII 收尾原则扩展到节点资源，`run()` 负责状态报告。
2. 在 `run()` 增加异常捕获，记录 failure info，执行 noexcept best-effort finalize，再重新抛出。
3. 为 Simulator 定义 Completed/Failed 两类终态和 partial-output 规则。

### 设计问题

- runtime 失败时是否写 `summary.txt`，以及怎样标识 incomplete；
- finalize 失败是否覆盖原始异常；
- 已写 CSV 是否保留、重命名或附加状态文件；
- callback 异常与模型异常是否采用相同策略。

### 建议

先写异常事务契约和测试，再实现方案 2 与 RAII 组合。测试应覆盖 update、integrator、logger 和 finalize 各自失败，保证原始异常信息保留。

## 4. F-03：builtin standard Interaction 需要明确定位并修复诊断语义

### 4.1 物理定位

`interaction.local_spherical_3dof.standard` 和 `interaction.local_spherical_6dof.standard` 收集气动、推进、质量与重力诊断，Form input 仍直接返回配置的占位加速度/角加速度。Cartesian standard closure 也以配置加速度和简化 command 叠加为主，没有把气动、推力和质量完整闭合成动力学输入。

这符合接线 baseline 的用途，`standard` 名称与完整 provider 清单容易给新人更高的物理预期。

### 4.2 observable 重置

local-spherical standard closure 实现 `IDiscreteTask`，注册在 Interaction phase：

```cpp
void update(const StepContext&) override {
    refreshDiagnostics(nullptr);
}
```

Form 在 publish 时曾用 truth 调用 `compute...Input()` 并刷新候选诊断；随后 Interaction phase 的 `update(nullptr)` 把高度和速度按零处理。现有 `example_05` CSV 可观察到：

```text
interceptor.dynamics.speed_mps = 250
interceptor.air_data.mach_number ≈ 0.743
interceptor.interaction.mach_number = 0
interceptor.interaction.dynamic_pressure_pa = 0
interceptor.interaction.gravity_mps2 = sea-level value
```

### 风险

- 使用者可能把 baseline 轨迹当作气动/推进闭环结果；
- Interaction observable 与同一行 truth 不一致；
- 诊断字段影响分析，却不影响实际 Form input，语义更难察觉。

### 可选方案

1. 把 builtin 类型和文档明确标注为 placeholder/reference closure。
2. 让 standard closure 成为纯 `SimulationNode + IInputProvider`，移除无物理作用的离散 update。
3. 若保留离散 phase，bind truth provider，并在 `update(t_k)` 使用已发布 truth 刷新记录缓存。
4. 实现真正的 reference force/acceleration closure，同时保留一个单独的 configured-input fixture。

### 建议

短期先保留行为兼容，正式文档已明确 baseline 层级。代码侧优先修复 observable 重置，并为同一行 dynamics/air-data/interaction 的 Mach 与动压增加测试。类型命名和物理实现属于更大兼容决策，可另开 ADR。

## 5. F-04：同一 phase 的生产者—消费者顺序依赖配置细节

### 证据

`Simulator::entriesFor()` 使用：

```text
priority -> registration_order
```

作为同 phase 排序。`AssemblyContext` 绑定只记录 provider 指针，不声明执行依赖。内建 baseline 的 navigation、tracking、guidance、flight control 和 allocation 多数使用相同默认 priority，当前正确顺序来自 mission 数组顺序。

YYZ 模板已经使用显式 priority 固定 Process 和 Output 链路，说明真实项目存在明确需求。

### 风险

- 为了整理 JSON 而重排数组，算法可能开始读取上一周期输出；
- summary 显示相同 priority，难以区分有意顺序和偶然顺序；
- typed dependency 给人“框架会自动排序”的误解。

### 可选方案

1. 保持当前调度器，要求同 phase 数据链显式 priority，并更新 builtin mission。
2. 增加可选 execution dependency metadata，只用于同 phase 拓扑排序。
3. 为 Process/Output 增加更多固定子阶段。

### 建议

当前项目规模优先方案 1。给 baseline 的 process/output 链增加显式 priority，测试打乱 JSON 数组后结果仍保持。若多个项目开始维护大量 priority 数字，再评估方案 2。

## 6. F-05：initialize 顺序缺少通用依赖模型

### 证据

`Simulator::initializeNodesInOrder()` 只把 execution config 为 Perturbation discrete phase 的节点稳定分区到最前，其余节点按 registry order initialize。静态 `perturbation.static` 的 phase 为 None，不进入该分区；它在单个 vehicle 的装配顺序中仍位于 Form 之前。

registry order 中，mission process 位于 environment 和 vehicle 之前；单 vehicle 内通常是 Form、common、Input、Process、Output、Interaction。多个 builtin 节点使用 `initialize() { update({0,0,0}); }`，这会读取依赖当前输出。

运行循环在 `t_0` 会重新按正式 publish/phase 顺序计算，因此默认记录通常能被纠正。initialize 中的校验、事件、副作用或一次性状态仍可能观察到依赖默认值。

### 风险

- mission Process 初始化时读取尚未 initialize 的 vehicle provider；
- Output initialize 可能读取只完成局部默认值的 Process；
- 新节点作者把注册顺序误当成生命周期依赖。

### 可选方案

1. 明确 initialize 只允许建立本地状态，依赖计算统一放到 `t_0` update。
2. 按 publish/discrete phase 初始化，静态节点另设规则。
3. 增加 initialize dependency DAG。
4. 移除 builtin 中可由第一个正式 update 替代的 `initialize()->update()`。

### 建议

先执行方案 1 和 4，减少初始化期间的跨节点读取。只有出现必须按依赖初始化的稳定案例后，再引入额外图模型。

## 7. F-06：terminal endpoint 会产生无后续积分段的离散更新

### 证据

Simulator 循环覆盖 `step = 0 ... total_steps`。在 `step == total_steps` 时仍执行 publish、全部到期离散任务、record 和 termination check，随后退出。

### 风险

- stateful controller、计数器或事件机在终点多推进一次；
- terminal 行的命令没有 `[t_N, t_{N+1}]` 保持区间；
- Summary 读取的离散内部状态包含这次终端更新；
- 与一些只在控制区间起点更新的外部仿真器对比时可能差一拍。

### 可选方案

1. 保持当前行为，把 terminal sample 明确视为“终端观测与算法评估点”。
2. 终点只 publish、record 和 terminate，跳过普通 discrete update。
3. 增加配置或独立 API，区分 terminal control update 与 terminal observation。

### 建议

当前行为已进入 CSV 和测试语义，短期采用方案 1，正式文档已经说明。若实际项目出现状态机多触发问题，再以 ADR 选择方案 2 或 3，并更新 publish/summary 回归。

## 8. F-07：advertised interface 与实际查询需要统一预期

### 证据

`NodeRegistry::addDynamic()` 把注册宏声明的 interfaces 写入 `interface_map_`。组件清单和同 scope provider 诊断依赖这张表。

`NodeRegistry::get<T>(name)` 直接对节点执行 `dynamic_cast<T*>`，没有要求 T 出现在 interface_map。节点实现接口却忘记在注册宏声明时，按名字 required binding 仍可能成功。

### 风险

- `--list-components-verbose` 漏接口；
- binding 失败诊断的 provider 候选不完整；
- 注册 metadata 与实际动态能力形成双重事实来源。

### 可选方案

1. 保持动态查询，架构测试要求所有公共 provider 都在注册宏声明。
2. name lookup 也要求 advertised interface，漏注册直接 build fail。
3. 移除 interface_map，所有诊断动态扫描 registry。

### 建议

先明确 advertised interface 是权威契约还是诊断索引。若选择权威契约，方案 2 提供最强一致性；若选择动态能力发现，方案 3 可以减少重复元数据。当前阶段可增加测试，避免 silent mismatch。

## 9. F-08：active-project 发现采用粗粒度文本检查

### 证据

`CMakeLists.txt` 扫描 `components/*.hpp` 后，用 `string(FIND ... "GNC_REGISTER_NODE_TYPE")` 判断头文件是否可注册，代码中已有 TODO 指出注释或字符串可能误通过。

### 风险

- 一个只在注释中出现宏名的文件通过配置，生成注册头后编译失败；
- CMake 错误位置与真实注册问题距离较远。

### 可选方案

1. 项目提供显式注册 manifest。
2. 生成期继续扫描，但用更严格的语法约定和正则。
3. 允许 components 中普通头，注册文件单独列出。

### 建议

项目数量较少时保持现状也可接受。若 active project 模板继续扩展，显式 manifest 会让注册顺序、type 来源和审查更加清楚。

## 10. F-09：direct Simulator 的 preparation 责任需要定型

### 证据

普通 Builder 路径执行 ValidationPipeline 和 PreparationPipeline，再返回 Simulator。直接构造 Simulator、向 registry 添加节点并调用 `initialize()` 时，只会执行 direct binding、continuous plan 和 initialize，不调用 `prepare()`。

### 风险

- 带资产节点在 direct 测试或小程序中以未准备状态 initialize；
- 维护者从普通 mission 文档推断 direct API 也包含完整生命周期。

### 可选方案

1. 明确 direct API 只适合无资产的聚焦测试，调用者自行 prepare。
2. 提供显式 `prepareDirect(PreparationContext)`。
3. 为 direct usage 提供小型 builder/harness，复用完整生命周期。

### 建议

短期采用方案 1，维护者文档已经写明。出现真实嵌入式 direct 使用者后，再提供方案 3，避免继续扩张 Simulator 自身职责。

## 11. 决策建议顺序

1. 先处理 F-01，改动小、诊断收益明确。
2. 为 F-02 写 runtime 失败事务 ADR，再实现资源收尾。
3. 对 F-03 决定 builtin baseline 的命名与物理承诺，同时可以独立修复 observable 重置。
4. 将 F-04 的显式 priority 先落实到示例和项目模板。
5. 结合真实节点审查 F-05 与 F-06，避免为了理论完整度引入新的通用 DAG。
6. F-07～F-09 结合下一次注册或 direct API 改造处理。

每个议题批准后，应新增 ADR 或更新 `doc/07-decisions.md`，同步成功/失败测试和正式文档，再从本文移入“已决策”记录。
