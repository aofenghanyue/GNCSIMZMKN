# GNCZMKN 目标架构与演进路线

原单篇路线已按架构专题和实施阶段拆分，统一入口如下：

## [进入分册总索引](gnczmkn-architecture-roadmap/README.md)

分册覆盖：

- 愿景、范围、架构原则与当前深度审阅；
- 稳定架构主轴、变化分区、依赖防火墙与扩展接缝；
- 数学与数值基础；
- 领域契约与接口层；
- 组件目录、模型包与 Mission 编译器；
- 仿真 Session、时间、调度和生命周期；
- 诊断、异常处置、可靠性与可观测性；
- 数据、Artifact、谱系和研究证据；
- DATCOM、配平、特征量、回路裕度、导航交班、GPOPS2、论文复现、图表和报告工作流；
- Python/RL、LLM、蓝图、ImGui、UE、Godot 与领域包；
- Runtime Cell Recipe、执行义务、行为组合、共享权威、CycleFrame、StepTransaction 与连续闭合的对象级设计；
- YYZ 6DoF、CAVH 制导的纵向参考设计及函数/变量/接口落位；
- 未来压力场景、R0–R8 分阶段路线、单路径直接重构、架构守卫和验收矩阵。

旧链接保留此文件作为导航入口。后续审阅和更新以分册为准。
