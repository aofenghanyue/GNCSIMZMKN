# 2026-07 框架架构重构问题与修正目标

本文记录 `fd16e35` 到 `6716db0` 这一轮统一节点重构的复核结果、功能处置决定和下一轮修正目标。它属于设计过程文件，不进入项目正式说明文档的编号体系。

## 1. 修正原则

本轮继续坚持单一路线：

- 主线只保留 `SimulationNode / NodeFactory / NodeRegistry / AssemblyContext / FrameworkCatalog`。
- 不恢复 `ComponentBase`、`ServiceContext`、service package registry 或旧 mission service schema。
- 不保留旧 type id alias，不增加兼容适配层。
- 重构前存在的正常能力必须逐项处置：保留并验证、由新机制完整替代，或者写明删除理由和新使用方式。
- 文档需要承担项目记忆、使用指南、扩展契约和参考手册职责，不能依靠源码清单代替说明。
- 状态机只作为“局部算法对象或权威 Process 节点”的一个例子。扩展判断以身份、所有权、作用域、依赖、生命周期、调度和耦合关系为主线。

## 2. 已确认保留的功能

以下结论已经通过重构前后机器差分或运行结果确认。

| 功能 | 复核证据 | 处置 |
| --- | --- | --- |
| builtin 与项目 GNC 算法 | 90 个领域组件文件均保留；代表性算法体只有生命周期 API 迁移 | 保留 |
| 组件配置契约 | 289 个逐文件配置键一致 | 保留 |
| 自动记录字段 | 381 个 observable 字段一致 | 保留 |
| 连续状态布局 | 57 个状态变量一致 | 保留 |
| 固定步长发布、离散更新、记录、停止和积分语义 | publish/record/termination 测试通过 | 保留 |
| 六组 ideal mission/component/process 示例 | 重构前后全部通过，断言数量一致 | 保留 |
| example_05 数值输出 | CSV 逐行一致 | 保留 |
| CAVH 研究项目 | 两个项目测试通过，完整 CSV SHA-256 一致 | 保留 |
| YYZ Cartesian 6DoF 项目 | 完整 CSV SHA-256 一致 | 保留 |
| SimFlow materialize/run | 重构前后测试通过 | 保留 |
| 可选坐标能力 | 坐标树测试通过；关闭坐标扩展后普通 mission 正常运行 | 由 Infrastructure 节点替代旧 service 线路 |

这些证据覆盖当前仓库中的主要运行路径。后续改动必须继续保持相同的数值与字段结果。

## 3. 功能处置决定

### 3.1 明确保留并修复

#### 3.1.1 mission 实例的调度信息

重构前 `summary.txt` 会列出实例配置的执行频率。`rate_hz` 移入 Simulator execution entry 后，摘要只能访问 NodeRegistry，导致频率信息消失。

修正目标：

- 摘要重新输出离散节点的 phase、priority、配置频率和 step interval。
- 非离散节点明确显示无离散调度，避免用 `0 Hz` 混淆“每步执行”和“不参与离散执行”。
- 增加测试覆盖 mission 级实例调度信息。

#### 3.1.2 直接 NodeRegistry/Simulator 使用

重构前允许测试或小型程序直接注册无前缀节点，并通过无前缀名称绑定同一 registry 中的其它节点。当前 Simulator fallback 把无点号名称放入 `mission.` 前缀，ValidationPipeline fallback 却使用空前缀，两条路径不一致。

修正目标：

- 名称到 scope 的推导只保留一份实现。
- 无点号直接注册节点继续使用空 registry 前缀。
- mission JSON 创建的 mission 节点继续使用 `mission.` 前缀。
- 增加直接注册、短名绑定的成功测试。

#### 3.1.3 坐标树与 frame contributor

保留以下能力：

- rotation、free vector、point 查询接口；
- 同 scope contributor 聚合；
- local-spherical 3DoF launch-track frame 定义；
- 坐标扩展未链接、未配置时核心 mission 独立运行。

当前 frame contributor 只能使用 configure/bind 后即可读取的数据。`contributeFrames()` 不能依赖另一个节点在 prepare 中才生成的产品。当前仓库没有多级准备需求，本轮将该边界写入正式契约，不增加隐式 prepare 排序。未来出现真实的多级资产依赖时，再设计显式 preparation dependency graph。

### 3.2 由新机制完整替代

#### 3.2.1 ComponentBase 对象模型

旧能力对应关系：

| 旧入口 | 新入口 |
| --- | --- |
| `ComponentBase::configure` | `SimulationNode::configure` |
| `injectDependencies(ScopedRegistry&)` | `bind(AssemblyContext&)` |
| `injectServices(ServiceContext&)` | 与普通 provider 相同的 `bind()` |
| `prepare` / `initialize` / `finalize` | `SimulationNode` 同名生命周期 |
| `update(double)` | 仅 `IDiscreteTask::update(StepContext)` |
| `publish(double)` | 仅 `IPublishTask::publish(PublishContext)` |
| `getSimTime/getSimStep` | `StepContext` 或 `PublishContext` |
| 基类 execution frequency | mission instance 的 `NodeExecutionConfig` |
| debug snapshot | `SimulationNode::snapDebug` |

新模型提供旧模型的正常运行能力，同时删除所有节点必须实现空 `update()` 的要求。

#### 3.2.2 service schema 与坐标 service package

删除内容：

- `global_services`；
- `environment.services`；
- `vehicles[].services`；
- `ServiceContext`；
- service package registry/finalization；
- 坐标 spec registry。

替代方式：

- mission/environment/vehicle 分别使用自身 `infrastructure[]`。
- 坐标树和 frame contributor 通过统一 NodeFactory 注册。
- required/optional provider 通过 AssemblyContext 绑定。
- 可选扩展通过 FrameworkCatalog 的 linked-extension 组合入口加入程序。

#### 3.2.3 含混 type id alias

删除的 alias 不恢复。它们缺少明确 form family，容易把 local-spherical 与 Cartesian 模型混用。

迁移规则：

- `vehicle.input.<sensor>_[36]dof.ideal` 改为 `vehicle.input.local_spherical_<sensor>_[36]dof.ideal` 或 `vehicle.input.cartesian_<sensor>_[36]dof.ideal`。
- `vehicle.process.<algorithm>_[36]dof.ideal` 改为带 `local_spherical_` 或 `cartesian_` 的 type id。
- `termination.engagement_[36]dof` 改为带 form family 的 engagement termination。
- `summary.engagement_[36]dof.ideal` 改为带 form family 的 engagement summary。

正式文档需要列出完整旧值到新值的映射；实现层只注册新值。

### 3.3 明确删除且不提供兼容入口

#### 3.3.1 `Simulator::step(int)`

旧实现只执行离散 stage 和连续积分，缺少 publish、before/after callback、record、termination、current time 推进和 lifecycle 状态转换。这个入口不能表达一次完整仿真步，仓库内也没有使用者。

决定：删除，不提供同名兼容函数。未来若需要交互式单步仿真，应单独定义完整 step transaction 契约。

#### 3.3.2 Simulator 内部隐式 RK4

旧 Simulator 在未配置 integrator 时自行创建 RK4。新架构把 integrator definition 放入 FrameworkCatalog，SimulationBuilder 根据 mission 显式选择。

决定：直接使用 Simulator 并注册连续系统时，调用者必须显式 `setIntegrator()`；不恢复隐藏默认值。普通 mission 仍由 `simulation.integrator` 使用默认 `rk4`。

#### 3.3.3 SimulationBuilder 无 catalog 构造

决定：SimulationBuilder 必须接收 FrameworkCatalog。这样 Builder core 不再隐式注册 builtin、扩展或项目定义。

## 4. 架构问题

### 4.1 Scope 目前没有形成单一权威拓扑

现状：

- MissionAssembler 保存 mission/environment/vehicle scope 对象。
- ValidationPipeline 根据 NodeDescriptor 再构造临时 scope。
- Simulator direct fallback 再实现一套名称推导。
- AssemblyScope 的 parent 指针没有参与解析或诊断。
- EnvironmentInstance/VehicleInstance 保存的 scope 没有成为绑定阶段的权威对象。

后果：

- 同一名称在不同入口可能解析不同。
- 新增 scope 或调整可见性时，需要同时修改 Assembler、Validator、Simulator 和 Context。
- “scope tree”停留在文档和数据字段层，无法成为后续拓扑扩展基础。

修正目标：

- 建立由装配过程拥有的 `AssemblyGraph`，集中保存稳定 scope、父子关系和 node ownership。
- NodeDescriptor 只引用 graph 中的 scope id。
- AssemblyContext 通过 AssemblyGraph 完成名称解析、同 scope 枚举和诊断。
- ValidationPipeline 使用已构建 graph，不再重建临时 scope。
- direct registry 使用同一个集中推导函数创建临时 graph。
- 当前名称可见性保持“短名只查当前 scope，跨 scope 使用完整名”；parent 关系用于所有权、诊断和未来显式策略，不增加隐式向上搜索。

### 4.2 Placement policy 写了两遍

现状：MissionAssembler 的 PlacementSpec 和 ValidationPipeline 的 `expectedRole/requiredTaskPhase/phaseIsConstrained` 分别维护 placement 规则。

修正目标：

- 引入单一 `PlacementKind + PlacementPolicy`。
- policy 统一给出 schema 名称、允许 scope、role、phase 约束和必需 capability。
- Assembler 负责读取 schema 和创建节点，Validator 只消费相同 policy 校验结果。
- 新增现有 role/phase/scope 组合中的节点类型时，不修改 Builder、Simulator 或 Assembler。
- 新增 mission schema 关系时，需要显式增加一个 placement policy 和对应 schema 入口；这一修改属于拓扑演进，不能伪装成普通组件注册。

### 4.3 Continuous group 缺少 mission 身份

现状：`IContinuousGroup` 只在直接 Simulator 测试中使用。正式 mission 没有自然 placement，文档也没有说明 group 应采用 Form、Output 或 Infrastructure role。

修正目标：

- 增加明确的 `continuous_groups[]` placement，可位于 mission 或 vehicle scope。
- 增加 `NodeRole::Coupling`，表达积分耦合组的领域身份。
- 该 placement 只允许无离散 phase 且实现 `IContinuousGroup` 的节点。
- vehicle group 的成员限定在同一 vehicle scope；跨 scope 连续耦合统一使用 mission group。
- group 通过普通 NodeFactory、NodeRegistry、AssemblyContext 和生命周期进入框架，不增加第二套 group registry。
- 增加成功装配、缺少 capability、未注册成员、重复成员和数值联合积分测试。

### 4.4 状态机示例权重失衡

正式文档中“状态机/StateMachine”出现次数由 4 次增长到 26 次，同时 PID、滤波器、插值器、优化器、事件检测器等同类算法对象缺少等量说明。

修正目标：

- 文档主线改为“是否拥有独立 mission 身份”和“状态所有权”。
- 状态机、PID、滤波器、插值器、优化器等并列作为可嵌入算法例子。
- mission process 说明覆盖协调器、试验流程、任务规划、事件驱动逻辑和权威模式等多种需求。
- 删除独立的“状态机三个位置”主章节，将其合并到通用分类判据和示例表。

## 5. 需要清理的旧代码和无效 API

### 5.1 删除旧依赖声明线路

`DependencyDeclaration`、`requireDependency()`、`optionalDependency()`、`IDependencyDeclarer` 和 `DependencyValidator::validate()` 没有任何节点实现。实际依赖预检已经由 `bind(AssemblyContext&)` 完成。

决定：删除这条空转线路。ExecutionPhaseManager 移入独立 core 文件，ValidationPipeline 只保留真实 bind preflight。

### 5.2 删除无调用接口

确认没有外部职责后删除：

- `SimulationNode::resetDependenciesBoundInternal_()`；
- `NodeRegistry::getRegisteredInterfaces()`；
- 旧的 `MissionAssembler::missionScope()/missionNodes()` getter，或由 AssemblyGraph 的明确 getter 替代。

### 5.3 清理失效命名

- `test_coordinate_tree_service` 改为 `test_coordinate_tree_node`。
- 正式架构术语使用 node；用户工作区和领域说明仍可用“组件”表示 mission 实例化对象。
- diagnostics 中涉及已删除 service package、旧 registry 或旧 API 的文字全部清除。

## 6. 文档恢复目标

文档恢复以重构前内容覆盖度为下限，同时更新为单一新架构。禁止只复制旧 API，也禁止把详细内容压缩成索引。

### 6.1 `doc/02-core-concepts.md`

恢复并完善：

- Form、Environment、Vehicle、Perturbation、Interaction 的完整边界；
- 所有权、依赖、离散执行、连续耦合、扩展组合五类拓扑；
- 连续状态、命令、物理能力、基础设施和输出记录的判断方法；
- 名称、scope、跨 scope 显式查询；
- configure/bind/prepare/initialize/publish/update/finalize 契约；
- SimFlow、记录、停止条件和常见误区。

### 6.2 `doc/03-mission-configuration.md`

恢复并完善：

- 完整 schema 和每个 placement；
- node entry、priority、rate_hz、scope 名称规则；
- continuous_groups；
- infrastructure 与坐标 contributor；
- Form family、perturbation、outputs、termination、summary；
- 旧 type id 和 service schema 的迁移表。

### 6.3 `doc/04-extension-guide.md`

恢复并完善：

- “我想修改 X”导航表；
- 完整最小离散节点示例和 mission 配置；
- 静态 provider、资产准备、可选依赖；
- 新 Form family 的逐项契约；
- Interaction、Output capability、Perturbation、Infrastructure contributor；
- mission process 的通用用例；
- continuous group 完整示例；
- project 与 framework 的进入标准；
- 成功与失败测试清单。

### 6.4 `doc/05-architecture.md`

恢复并完善维护者源码导览：

- runner/catalog/builder/assembler/graph/registry/validation/preparation/simulator 主链；
- 配置解析边界；
- placement policy；
- publish/discrete/continuous/record/termination 精确流程；
- multi-vehicle 与当前边界；
- 新架构中明确不承担的能力。

### 6.5 `doc/06-reference.md`

恢复并完善：

- 全部 80 个当前 builtin/linked type id，按 form family 和 role 分类；
- input/process/output/interaction/form/environment/termination/summary/infrastructure 矩阵；
- builtin 的关键配置字段；
- 公共接口与 include 入口；
- CLI、SimFlow、Outputs 和错误规则。

`--list-components-verbose` 用于核对当前构建，不能替代稳定 builtin 参考表。

## 7. 验收矩阵

完成修正后必须同时满足：

1. 正式架构只剩统一 Node 路线，旧 service 和 dependency declarer 不存在。
2. scope 名称解析只有一份权威实现，direct registry 与 mission builder 各有成功测试。
3. placement role/phase/capability policy只有一份。
4. mission/vehicle continuous group 可以装配并参与联合积分。
5. summary 保留实例级调度信息。
6. 当前 80 个注册 type id 全部在参考手册出现。
7. 旧 type id 和旧 schema 只用于迁移说明、明确拒绝逻辑与失败测试，不出现在注册表。
8. example_05、CAVH、YYZ 的 CSV 与修正前保持一致。
9. 核心、示例、项目、架构守卫测试全部通过。
10. 正式文档中通用分类与契约占主线，状态机保持为并列例子。

## 8. 实施与验收结果

2026-07-17 已按上述目标完成修正：

- `AssemblyGraph` 统一保存 scope、parent、node ownership 和短名解析；MissionAssembler、ValidationPipeline、AssemblyContext 与 direct Simulator fallback 均使用该模型。
- `PlacementKind + PlacementPolicy` 成为 placement 对 scope、role、phase、必需 capability 和连续组成员范围的唯一规则表。
- mission 与 vehicle 均可装配 Coupling node；测试覆盖联合积分、缺失 capability、未注册成员、重复归属和 vehicle 跨 scope 成员拒绝。
- `ExecutionPhaseManager` 与 execution metadata 独立进入 core；旧 dependency declarer 文件和无调用 API 已删除。
- summary 已恢复实例级 `phase/priority/rate_hz/step_interval`。
- 正式文档已恢复核心概念、完整 schema、扩展契约、维护者导览和稳定参考表；当前 `--list-components-verbose` 的 80 个 type id 在 `doc/06-reference.md` 中覆盖 80/80。
- 当前 active project 完整构建成功，CTest 为 25/25；CAVH project 测试为 2/2。
- 关闭 `GNC_LINK_COORDINATE_TREE_EXTENSION` 后，`gnc_sim` 构建成功，example_05 mission 正常完成；同 mission 在有无坐标扩展构建中的 CSV SHA-256 均为 `8F62C3F9F8C2F06A2D5E9BAA9F61B42FAD21FD8C683CF44005CB8CC8A655EE37`。
- CAVH 完整 CSV 与修正前逐字节一致，长度 `44256835`，SHA-256 为 `E3ADA3DFDF3EF57EAACB1DF59DCC9E75D94D67C0436E9AE9438F8D70D6DBA6B1`。
- YYZ Cartesian 6DoF 完整 CSV 与修正前逐字节一致，长度 `115477`，SHA-256 为 `FE8B60DFFD65635D9A7D330F1D7A20DDA2E0666ECC56F39711D5DB1E68EEC0E2`。
- 旧 service/dependency 运行线路和无 form-family type id 未回到注册表；源码架构守卫、搜索审计和 `git diff --check` 均通过。

## 9. 2026-07-18 复审后补充修正

在第 8 节验收基础上继续检查失败路径和扩展 seam，确认并修正以下问题：

1. 内置 JSON parser 对尾随内容、错误分隔符、非法 token、重复 key 和未闭合结构缺少确定性失败，部分输入可能停滞或越界。当前实现只补齐这些基础安全边界，并支持常用转义与合法数值语法；`\u` 等完整标准能力继续交给专用配置库。
2. `IConfigParser -> ConfigNode` 的替换边界保留。`ConfigManager` 持有 parser，`SimulationBuilder` 支持构造注入；JSON/YAML 库可以直接适配，INI 需要先约定多层 object 和 array 的映射。此次没有引入新的通用 parser 或配置格式。
3. `NodeFactory` 的重复 type id 从 warning 改为注册阶段异常，同时在模板注册处校验节点基类和声明接口。runner 会捕获 catalog assembly 异常并给出失败信息。
4. mission 顶层、environment、vehicle、form、interaction 和 node entry wrapper 采用允许字段集合校验。`outputs` 与 `debug_snapshots` 同步使用严格 key、类型和数值范围检查；项目节点自身 `config` 的未知 key 仍按既定策略给 warning。
5. continuous execution plan 在 prepare 后、logger 初始化前完成完整校验。空成员、未注册成员、嵌套和重复归属会让 `build()` 失败，已有输出文件不会被失败构建截断。重复使用同一 Builder 时会先清理旧 logger 状态。
6. Form family 选择改为每个 vehicle scope 独立同步到 descriptor，异构多飞行器 mission 不再受首个 vehicle family 影响。
7. Infrastructure placement 接受注册类型声明的显式离散 phase。静态坐标树继续使用 phase None，需要周期刷新的稳定基础设施可以进入现有离散阶段。

新增回归覆盖 parser facade 与内置子集失败、catalog type 冲突、wrapper typo、严格 outputs、离散 Infrastructure、异构 vehicle family、build 期重复连续归属和输出文件保持。正式文档已同步这些边界。

补充修正后已完成全量增量构建，CTest 通过 25/25。example_05 正常结束，CSV 长度为 `6856`，SHA-256 仍为 `8F62C3F9F8C2F06A2D5E9BAA9F61B42FAD21FD8C683CF44005CB8CC8A655EE37`。

CAVH 的 `gnc_sim` 与两个项目测试重新构建成功，项目测试通过 2/2。YYZ 的 `gnc_sim` 重新构建并完成 nominal mission，CSV 长度 `115477`，SHA-256 仍为 `FE8B60DFFD65635D9A7D330F1D7A20DDA2E0666ECC56F39711D5DB1E68EEC0E2`。
