# 参考附录｜统一术语

[返回主入口](README.md) · [进入系统主叙事](02-layered-reference-architecture.md)

**主线定位**：本附录只用于查询稳定术语。概念间的因果关系、运行顺序和架构推导统一以 02 为权威；详细对象契约以对应分册为权威。

| 术语 | 定义 |
| --- | --- |
| **研究工作台** | 覆盖问题定义、模型装配、执行、分析、论证和报告的整体产品 |
| **仿真内核** | 负责确定性时间推进、编译后组件调度、连续积分和运行状态管理的可信核心 |
| **Mission Source** | 人或工具编写的场景、模型、参数、运行和观测配置源文件集合 |
| **Source Frontend** | 把 JSON、YAML、受限 INI、蓝图或 API 输入解析为 syntax-neutral SourceTree/SourceMap 的边界；不拥有领域默认值和执行选择 |
| **SourceTree/SourceMap** | 与输入语法解耦的作者结构及其精确来源位置，是语义编译的统一入口 |
| **Canonical Model Graph** | 描述实体、状态 owner、模型 occurrence、连接、场景干预和研究意图的规范权威；Mission IR 是其 typed 表示 |
| **Authority Domain** | Design/Plan、Model、Operation、Artifact 四类提交权边界；回答某个能力切片可以改变哪一类权威事实 |
| **Capability Slice** | 一个需求分解后的最小架构分析单元，由 AuthorityDomain 与七维 ChangeVector 共同定义 |
| **ChangeSignature / ChangeVector** | 从 Vocabulary、Graph/Topology、State/Evolution、Time/Atomicity、Information/Authority/Evidence、Representation/Encoding、Execution Context/Resources 七维描述语义差异 |
| **Mission IR** | SourceTree 经迁移、归一化和领域解析后形成的 Canonical Model Graph typed 表示 |
| **Execution Plan** | Descriptor 与 process-local Image 的总称；语义权威位于 Descriptor，运行入口消费 Image |
| **Execution Plan Descriptor** | 完成绑定、排序、速率换算、连续系统分组和输出规划后的可序列化、可 hash 执行描述 |
| **Execution Plan Image** | Descriptor 与精确 package implementation link 后形成的进程内只读函数表与紧凑 handle 布局 |
| **Session Runtime Bindings** | 每个 Session 独有的 PreparedModel refs、RuntimeComponent cells、状态、workspace 和资源句柄 |
| **Simulation Session** | 一个 ExecutionPlanImage 的隔离运行容器，可承载由 reset 分隔、各有 RunId/RunOutcome 的多个 run |
| **Run Binding** | 按 Descriptor schema 校验的单次 run 输入，只包含初态、seed、time origin、允许的初始 ParameterState 与外部输入引用，并拥有独立 binding hash |
| **Committed Model State** | 某个 state epoch/tick 上已经原子提交的物理、离散、控制与实体生命周期事实 |
| **Experiment** | 一组共享研究问题与比较规则的运行集合 |
| **Model Definition** | Catalog 中所有可选择模型的稳定元数据、配置、端口、放置规则、执行形式和证据声明 |
| **Compiled Model Occurrence** | Mission 中一次模型选择经归一化后形成的不可变对象，持有 definition ref、canonical config、typed AlgorithmDefinition bundle、资产绑定和 source identity |
| **Runtime Component Descriptor** | 仅供 Session 实例化模型使用的运行描述，声明 recipe provenance、execution obligations、状态、端口、生命周期和资源边界 |
| **Runtime Component** | execution form 声明的独立运行边界；Compiler 为其分配 RuntimeInstanceId、state/port handles 和 obligations |
| **Runtime Cell** | Runtime Component 在某个 Session 中的具体物化，持有 compiled handles、workspace 与资源绑定；它只是实例称谓，不增加新的模型层次 |
| **Runtime Cell Recipe** | package/compile-time 的组件组合说明，把算法、StateFragment、嵌入机制、端口和 obligations 合成为一个运行边界 |
| **Execution Obligation** | Kernel 可执行的基础时间/副作用义务，例如 BoundaryEvaluation、DerivativeEvaluation 或 PostCommitEffect |
| **Closed Operation Language** | 每个权威域允许的有限通用操作集；Model Authority 的精确 Execution Algebra 包含 publish、compiled invocation、candidate advance、stage、validate、commit、evidence seal 与 post-commit effect |
| **Algorithm Definition** | 某个 kernel 的不可变参数、公式选择、限制和数值策略引用；属于 CompiledModelOccurrence 的 typed composition |
| **Algorithm Kernel** | 以显式 AlgorithmDefinition、State 和 Input 求值并返回 Result/Delta 的纯模型计算 |
| **Component Delta** | 组件对 owner state block 的完整 typed replacement，以及对声明输出、事件、application receipt、遥测和诊断提出的本步变更集合 |
| **CycleFrame** | 单个 StepTransaction 内由编译 handle 访问的 typed signal/interval 数据帧；view 不跨 transaction 存活 |
| **Embedded Mechanism** | 嵌入 Runtime Cell 的局部行为工具，可拥有宿主 StateFragment，但没有 Session identity、独立端口、调度或生命周期 |
| **Model Package** | 带版本、依赖、资产、ModelDefinition、测试与成熟度声明的发布单元 |
| **Artifact** | 可寻址、带 schema、哈希和谱系的研究产物 |
| **Evidence Graph** | 由 Observation、Outcome、Artifact 和 lineage 组成的研究证据权威，连接运行输入、结果、指标、图表与报告 |
| **Encoding Plan** | 将 sink-independent Observation schema 确定映射到 CSV、MAT、HDF5、数据库或流式 payload 的不可变计划 |
| **Dataset Sink** | 消费 ObservationBatch 与 EncodingPlan 并生成具体数据编码的适配器；不查询模型或改写运行状态 |
| **Entity Selector** | 经 Compiler 解析的实体选择规则，形成 cardinality、visibility、inactive policy、frame 和时间关系明确的窄只读 view |
| **Intervention Plan** | 把 ParameterId、扰动、模拟故障和 activation intent 编译到目标 builder、signal 或 owner command 的计划 |
| **Diagnostic** | 带稳定代码、位置、阶段、主体、原因和建议的结构化问题记录 |
| **Domain Contract** | 表达物理语义、时效、坐标系、单位、质量和所有权的数据或行为契约 |
| **Workflow Task** | 消费和产生 Artifact 的离线或外部工具任务 |
| **Control Plane** | 向 CLI、Python、LLM、蓝图编辑器和前端提供统一命令、查询与事件的应用层 |
