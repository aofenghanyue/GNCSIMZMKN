# 文档新读者回读与迭代记录

本文记录 2026 年 7 月对 GNCZMKN 文档的教学性审查过程。它用于保存审查依据、每轮修改和未决问题，不构成框架运行契约。正式说明仍位于 `README.md`、`doc/` 与 `user/README.md`。

## 1. 验收目标

文档需要同时支持三类任务：

1. 新读者可以完成构建、运行、查看输出，并能解释一次仿真的基本数据流。
2. 使用者可以从一个普通 mission 逐步过渡到修改 mission、运行 SimFlow、复现单个 case。
3. 项目开发者可以判断代码应放入普通库、项目节点、基础设施扩展或 framework，并能走完“实现、注册、装配、验证、运行”的闭环。

每条关键说明还应满足以下条件：

- 先交代用途和上下文，再给字段、接口或 type id。
- 教程中的命令、路径和配置都能在当前仓库中找到依据。
- 架构图表达所有权、数据流、生命周期或时序中的实际关系。
- 教程与参考手册分工清楚，参考项可以从教程直接到达。
- 时间语义、输出语义和单 case 复现入口与实现一致。

## 2. 初始回读

### 2.1 新读者任务与断点

| 新读者任务 | 初始状态 | 主要断点 |
| --- | --- | --- |
| 首次构建并运行 | 基本可完成 | 命令之后缺少“刚刚发生了什么”和输出核验步骤 |
| 读懂 mission | schema 较完整 | 缺少一份从顶层到节点的连续讲解；片段之间的依赖关系不直观 |
| 理解框架模块 | 领域边界已列出 | 术语密度高；缺少一个具体 vehicle 映射和多视角架构图 |
| 解释 CSV 一行 | 时间契约已写明 | 缺少从运行周期到具体字段的示例和检查步骤 |
| 运行 SimFlow | CLI 和简短 schema 已存在 | 缺少 base mission 前提、三种 case source、路径解析、生成物、失败处理和复现的完整教程 |
| 新增项目组件 | 有大量接口与代码 | 缺少最小可运行改动的逐步教学；注册宏和 placement 对新手跳跃较大 |
| 创建项目工作区 | 只列目录和 active project | 缺少从已有 baseline 开始、切换 active project、重新配置和确认注册的操作闭环 |

### 2.2 文档分工问题

- 根 README 同时承担项目介绍、架构摘要、完整 mission 骨架和命令入口，第一次阅读的主线容易被打断。
- `doc/01-getting-started.md` 能指导运行，但没有形成“命令—终端结果—输出文件—下一步修改”的实验闭环。
- `doc/02-core-concepts.md` 和 `doc/00-current-architecture.md` 内容准确，抽象概念先于具体实例出现，图示数量不足。
- `doc/03-mission-configuration.md` 接近 schema 参考，缺少一份可从上到下阅读的注释式 mission。
- `doc/04-extension-guide.md` 对熟悉框架的人很有用，新读者还需要一条最小组件的渐进路径。
- `doc/06-reference.md` 已有 SimFlow 摘要，篇幅不足以承担教学任务。
- `user/README.md` 解释了目录约定，没有讲清楚如何开始一个项目。

## 3. 实现核对结论

### 3.1 普通 mission

- runner 从当前目录和可执行文件目录向上搜索相对配置路径。
- mission 经 `ConfigManager`、`SimulationBuilder`、`MissionAssembler`、验证与准备阶段进入 `Simulator`。
- 节点完整名由 scope 前缀和局部名称组成；vehicle `interceptor` 中的 `dynamics` 对应 `interceptor.dynamics`。
- 每个周期在离散更新后记录 `t_k`，状态字段来自 `x_k`，离散字段来自基于 `x_k` 计算的本周期输出。

### 3.2 SimFlow

- 顶层配置由 `base_mission`、`materializer`、`outputs` 组成。
- 内建 `simflow.materializer.numeric_perturbation` 支持 `single`、`matrix`、`random`。
- `matrix.rows` 使用从 0 开始的 CSV 数据行索引；CSV 第一列必须为 `case_id`。
- `random` 要求显式 `count` 和 `seed`，输入按名称排序后采样，因此相同配置和 seed 可以复现相同 case 数值。
- 数值输入写入目标 vehicle 已存在的 `perturbation.config.inputs`；base mission 缺少该块时会在物化阶段失败。
- 显式 `repo://`、`project://`、`user-data://` 资产 URI 在写出 effective mission 前固化，方便从 case 目录直接回放。
- 每个 case 使用普通 mission 构建和运行路径。输出根生成 `simflow_summary.csv`，case 目录生成 `effective_mission.json` 和普通仿真输出。
- serial 在当前进程逐个运行，`--jobs` 通过子进程并发运行；任一 case 失败后汇总仍会写出，命令最终返回失败。

## 4. 迭代记录

### 第一轮：入口与心智模型

状态：已完成，并经第二至第四轮回读。

已修改：

- 文档导航改为四站式学习路线，每站给出完成标志，并把教程与参考手册分开。
- 根 README 增加 mission、catalog、构建、运行与输出的总图，Quick Start 增加可检查的输出结果。
- 快速上手增加 baseline 输出核验命令，以及 CSV 字段到 mission 节点的反向定位。
- 核心概念用 `interceptor.guidance` 统一解释 type、name、placement、scope、role、capability 和 phase。
- 核心概念增加构建/运行边界、三类数据含义与生命周期图。
- 当前架构增加构建期与运行期分区图、scope 所有权和跨 scope 依赖图。

首轮回读问题：

- 新读者现在可以从命令追到输出和具体节点，入口闭环已经形成。
- 文档导航已引用尚待第二轮创建的 `simflow-guide.md`，当前链接暂时不闭合。
- 快速上手中的 YYZ SimFlow 命令需要项目专用构建，已经显式提示；第二轮还需给出从切换项目到检查 summary 的连续步骤。

### 第二轮：Mission、SimFlow 与复现

状态：已完成，并经第三、第四轮回读。

已修改：

- 新增正式的 `doc/simflow-guide.md`，覆盖边界、base mission 前提、顶层 schema、三种 case source、vehicle 映射、enum map、运行时消费、串行/并行、汇总、复现、失败处理和项目 materializer。
- 教程直接使用仓库 YYZ 的 `single/matrix/random` 配置，给出独立 active-project 构建、运行、检查和回放命令。
- Mission 配置开头增加从上到下阅读现有 baseline 的顺序表，把顶层块连接到实际实例、数据流和运行规则。
- Mission 输出章节增加两行 CSV 的时间解释，并给出字段缺失时的排查顺序。
- 参考手册的 SimFlow 章节恢复为集中速查，补齐三种 mode 和目录占位符，并链接完整教程。

第二轮回读问题：

- 从“为什么需要 SimFlow”到“如何回放一个 case”已经形成连续路径，无需阅读源码即可使用内建物化器。
- 项目 materializer 只展示最小形状，复杂 ConfigNode 改写仍应查接口和测试；该内容属于进阶扩展，不阻塞普通使用。
- Mission 各块已经通过现有 geographic baseline 连起来；第三轮还需解决从理解 placement 到亲手增加项目节点的跳跃。

### 第三轮：项目扩展教学

状态：已完成，并经第四轮回读及代码示例验证。

已修改：

- 扩展指南开头增加完整的第一次扩展教程：复制可运行 baseline、实现 constant-AoA guidance、注册、替换 mission type、独立构建、检查 catalog、运行和验证 CSV。
- 教程使用 framework 现有 `IGuidance3Dof` 和 `ITargetTracking3Dof` 契约，让算法替换真实进入原有 GNC 链路。
- 用继承、configure、bind、update 和注册宏五个代码位置解释节点边界，直接标出使用者修改算法的位置。
- `user/README.md` 增加新项目起步流程、推荐目录、`simflow/` 与 `simflows/` 的区别，以及独立构建目录的原因。

第三轮回读问题：

- 新读者已有从 baseline 到首个可观察自定义算法的完整操作链，理解后可以再进入 provider、prepare、Form 和 Infrastructure 等进阶章节。
- 教程的完整 C++ 代码块已从 Markdown 原样送入 MinGW `g++ -std=c++17 -fsyntax-only`，使用当前 framework 与 Eigen include 路径编译通过。
- 扩展指南总篇幅明显增加；第四轮需要检查目录层级、重复说明和初学/进阶分界是否清楚。

### 第四轮：任务式回读

状态：已完成文面回读与运行验证。

按七个真实任务重新走查后的修正：

- 首次运行：SimFlow 的 YYZ active-project 构建前提移到命令之前，所有命令统一使用 `build-mingw-yyz`。
- 解释输出：核心概念明确区分 `vehicle.output` 物理能力与顶层 `outputs` 持久化配置。
- 阅读 mission：完整 placement 骨架标明为结构地图，避免把空 Form 和空 termination 当作可运行配置。
- 理解术语：补充 mission、type、instance、component、provider、Form、truth、placement、scope、Interaction 和 catalog 词汇表。
- 扩展组件：增加初学/普通节点/物理架构扩展/提交检查四层阅读地图。
- 定位错误：增加从 unknown type、placement、phase、binding、family、config、rate 和 asset 错误返回具体扩展步骤的表格。
- 交叉阅读：核心概念、Mission 配置和 README 末尾给出有目标的下一步链接。

文面与运行检查结果：

- 本地 Markdown 文件链接和显式 heading anchor 全部可解析。
- 所有 `json` fenced code block 都能被 JSON parser 读取。
- 第一次扩展的完整 C++ 节点和自定义 SimFlow materializer 示例均通过 MinGW C++17 语法编译。
- geographic 3DoF baseline 成功运行；CSV 的 `time = 0/0.1` 分别对应 `altitude_m = 1000/999.999697324`，同一行 guidance 指令可读取。
- YYZ single SimFlow 成功生成 `case_000001_nominal`，汇总状态为 `succeeded`，effective mission 包含预期 8 个拉偏输入。
- 生成的 YYZ effective mission 已通过普通 `--config` 成功回放。
- 当前构建的完整测试 25/25 通过，包括 SimFlow runner、架构守卫、mission、时间语义和示例集成测试。
- 禁用中文句式扫描无匹配，`git diff --check` 无空白错误。

## 5. 最终核验清单

- [x] 新读者能按一条明确路线完成首次实验。
- [x] 普通 mission 的对象归属、依赖、调度和数据流均有图示或具体例子。
- [x] SimFlow 无需阅读源码即可配置、运行、检查、复现和定位失败。
- [x] 新项目组件有最小闭环教程。
- [x] 教程示例与仓库文件、CLI 和实现一致。
- [x] 本地 Markdown 链接与显式锚点可解析。
- [x] 完整 JSON 示例可解析。
- [x] 完整 C++ 教程示例可以通过当前编译器和头文件检查。
- [x] 文档未使用项目禁止的中文句式。
- [x] 已完成四轮独立回读和修订。
