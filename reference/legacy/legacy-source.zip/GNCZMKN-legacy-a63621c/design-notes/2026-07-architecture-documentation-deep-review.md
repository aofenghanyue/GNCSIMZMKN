# 架构文档改造复核记录

状态：四轮复核完成，2026-07-19。

本文记录本次架构文档重构的事实基线、四轮复核重点和验证结果。它帮助未来维护者理解文档的组织依据，不新增运行契约。当前架构契约仍由 `README.md`、`doc/`、源码、测试与 Accepted ADR 共同表达。

## 1. 改造目标与覆盖范围

本轮文档面向三类读者：

1. 新使用者：能运行 mission、找到输出，并解释 CSV 一行的因果语义。
2. GNC 研究者：能区分软件接线、数值精度和模型有效性，逐步建立支持研究结论的证据链。
3. framework 维护者：能沿源码理解程序组合、mission 构建、六类拓扑、生命周期和固定步长运行内核。

主要交付包括：

- 重写 `doc/02-core-concepts.md`、`doc/00-current-architecture.md` 与 `doc/05-architecture.md`；
- 新增 `doc/08-research-simulation-methodology.md`；
- 重构 `doc/README.md` 的学习路线；
- 补强快速上手、Mission、扩展、SimFlow、ADR 和 user 工作区文档的教学衔接；
- 将源码核对中发现的架构议题写入独立 findings 文件。

参考手册继续承担 type id、字段和 include 索引任务，教学主线不依赖逐项 API 罗列。

## 2. 事实基线

复核使用以下源码主线：

```text
src/runner.cpp
-> src/runner_component_registration.cpp
-> framework/include/gnc/core/framework_catalog.hpp
-> framework/include/gnc/core/simulation_builder.hpp
-> framework/include/gnc/core/mission_assembler.hpp
-> framework/include/gnc/core/validation_pipeline.hpp
-> framework/include/gnc/core/preparation_pipeline.hpp
-> framework/include/gnc/core/simulator.hpp
```

同时检查：

- `AssemblyGraph`、`PlacementPolicy`、`NodeRegistry`、`NodeFactory` 与 `AssemblyContext`；
- AutoDataLogger、SimulationSummary、continuous group 和 SimFlow 实现；
- geographic/Cartesian、3DoF/6DoF baseline；
- CAVH 与 YYZ 项目 Interaction、资产准备和 priority 示例；
- mission、publish、continuous group、preparation、logger、SimFlow 与 architecture guard 测试。

## 3. 第 1 轮：源码一致性

目标：每一项生命周期、排序、记录和错误边界都能落到当前实现。

本轮校正：

- 明确 Assembler 对每个条目依次创建、配置、注册，全部实例进入 registry 后再统一绑定。
- 明确 initialize 只把具有 Perturbation 离散 phase 的 execution entry 稳定分区到前面；静态 `perturbation.static` 继续使用 registry 顺序。
- 明确 `SimulationBuilder::build()` 完成 bind、prepare、continuous plan 与 logger 初始化，节点 initialize 在 `Simulator::run()` 入口发生。
- 明确循环覆盖 `step = 0 ... N`，终点仍执行 publish、到期 update、record 与 termination check，随后停止积分。
- 为 `record_initial_state = false` 增加 `t_0` 终止行例外，避免把“命中状态保留”写成无条件规则。
- 区分正常路径 `auto_logger.stop()` 与析构收尾；runtime 异常仍会跳过 summary、node finalize 和明确 Failed 状态。
- 将 ValidationPipeline 当前仅按全 mission 检查 Form 的实现缺口写入独立 findings，不把期望行为描述成已经实现的检查。

本轮完成后，构建阶段、初始化阶段和运行阶段的文字顺序与源码主线一致。

## 4. 第 2 轮：新人学习与研究教学

目标：读者先理解物理与时间含义，再接触框架术语和扩展 API。

本轮补强：

- 建立第一次使用、开展研究和接手维护三条阅读路线，同时提供按当前任务查找文档的入口。
- 让 `example_05` 贯穿运行、mission 阅读、CSV 解释和模型边界，读者可以沿同一个实例逐步深入。
- 用 Truth、Measurement、Estimate、Reference、Command、Physical response 和 Form input 解释完整闭环。
- 显式区分 `vehicles[].input[]` 与 Form input、`vehicles[].output[]` 与顶层 `outputs`、observable 与状态所有权。
- 明确 Form 是运动状态与 truth 的权威，同时说明连续执行机构、燃料等 Output 可以拥有独立连续内部状态。
- 增加刚体平动/转动方程的逐项归责示例，说明 Environment、common、Output、Interaction 与 Form 怎样避免重复计入重力、惯性项和坐标变换。
- 增加采样—保持离散关系，解释同一 CSV 行中的 `x_k`、测量、估计、命令、物理响应及下一状态。
- 解释 RK 子步候选 truth、独立连续系统的发布态保持，以及何时需要 `IContinuousGroup`。
- 为 ideal/zero/standard baseline 标注可信度边界，并在第一个扩展教程中区分“命令可见”与“轨迹受控”。
- 统一六类拓扑：所有权、placement、依赖、离散执行、连续耦合和扩展组合。

本轮完成后，新人可以沿一个实例从 mission 追到 CSV，研究者也能把框架接线证据与物理性能证据分开。

## 5. 第 3 轮：维护交接与可执行性

目标：让文档入口、链接、代码块、源码路径、测试映射和实际命令能够互相核对。

本轮检查与校正：

- 校验全部新增或修改文档的本地链接和中文 heading anchor。
- 解析 30 个 JSON fenced block，检查 15 个 Mermaid fenced block 的边界。
- 用 MinGW C++17 对扩展指南中的第一个完整项目节点执行语法检查。
- 核对维护者文档中的 25 个现有测试和核心源码路径。
- 精化 CSV 的多速率语义：到期 task 提供本周期新输出，未到期 task 继续保持，静态与连续节点提供记录时的当前公开值。
- 运行 example_05 后确认 configured duration 为 0.2 s，termination 在 0.1 s 提前结束；快速上手与 Mission 阅读表据此补充“最大时长/实际结束时间”教学。
- 对全部目标文档执行严格 UTF-8 解码、BOM、乱码和禁用句式扫描。
- 执行 `git diff --check`，未发现空白错误。

## 6. 第 4 轮：中文表达与阅读连贯性

目标：保留技术精度，同时把备忘录式短句、重复清单和抽象连接词改成可以连续阅读的说明。

本轮使用 `shuorenhua` 技能的 `docs / standard / structural` 模式。代码块、命令、路径、接口名、数值、生命周期顺序和系统责任主体均划为保护区，改写只处理保护区外的叙述。

本轮调整：

- 重写文档总入口，直接回答“我现在要做什么、应该读到哪里”，减少重复路线表和验收式短句。
- 让当前架构与维护者导览沿一次普通 mission 的执行过程展开，先交代因果，再引入类名和实现位置。
- 合并连续短句，补足段落之间的承接；保留 Mission、reference、ADR 和问题清单中确有查询价值的表格。
- 分别回读新手教程、核心概念、研究方法、Mission、扩展、SimFlow、User 工作区和维护者文档，检查语气是否适合各自读者。
- 完成一遍技术保真回读和一遍残留表达审计。保真回读据源码修正了 CSV 字段来源：记录器读取节点公开的 `IObservable`，provider 仍用于节点间依赖。

## 7. 验证结果

| 验证 | 结果 |
| --- | --- |
| Markdown 本地链接与 anchor | 15 个目标文件全部通过 |
| fenced block 配对 | 167/167 通过 |
| JSON 示例解析 | 30/30 通过 |
| Mermaid block 边界 | 15/15 通过 |
| 第一个完整 C++ 扩展示例 | MinGW C++17 syntax check 通过 |
| UTF-8 严格解码 | 全部通过，0 个 BOM |
| 禁用句式与乱码扫描 | 无命中 |
| `ctest --test-dir build-mingw --output-on-failure` | 25/25 通过 |
| `gnc_sim --help` | 通过 |
| `gnc_sim --list-components-verbose` | 关键 Form、Interaction、Guidance type 均存在 |
| example_05 普通 mission | 通过；CSV 首两行时间为 0 与 0.1 s，summary 已生成 |
| 根 README 最小 mission | 从文档提取后独立运行通过，final time 为 10 s |

## 8. 复核结论

四轮复核后，各类正式文档可以互相支撑：

- 新人有明确入口、贯穿实例、完成标准和下一步路线。
- GNC 信号、采样保持、RK 候选状态、连续耦合、坐标单位、验证与复现均有教学说明。
- 维护者可以从组合根追到 Builder、Assembler、Validation、Preparation、Simulator、Logger 和 SimFlow，并能按修改类型找到影响面与测试。
- reference 保持索引角色，核心章节集中解释设计作用、约束和代价。
- baseline 的物理承诺已明确限制，避免把接线成功直接解释成性能结论。

当前没有遗留的文档阻塞项。源码核对中发现的九项实现议题保存在 `design-notes/2026-07-documentation-architecture-findings.md`，等待维护者选择优先级和兼容策略；它们没有在本轮文档任务中改动代码。

## 9. 后续维护触发条件

发生以下变化时，应重新走至少一轮源码一致性复核：

- mission schema、placement、scope 或 form family 规则变化；
- publish、phase、priority、rate、record、termination 或 terminal endpoint 变化；
- continuous plan、group 或积分候选状态语义变化；
- prepare/initialize 顺序和资产缓存责任变化；
- baseline 的 standard Interaction 从占位 closure 升级为真实物理闭合；
- SimFlow effective mission、路径冻结或并发失败语义变化。

复核时优先更新概念与当前架构，再更新维护者说明、Mission、扩展指南、ADR 和相关测试映射。
