# GNCZMKN 架构改进评审意见（设计迭代记录）

本文是一份规划性架构评审，目标是检查 GNCZMKN 作为实验室级 GNC 仿真框架时，基础抽象是否足以承载后续研究项目。当前可执行契约仍以 `00-current-architecture.md`、`02-core-concepts.md`、`05-architecture.md`、代码和测试为准。

评审重点包括：

- mission 如何构造一个仿真程序；
- 框架管理哪些对象，使用者直接编写哪些算法；
- scope、role、执行阶段和运行能力如何表达；
- 普通组件、状态机、资产、基础设施能力和扩展包如何定位；
- 新增一种能力时，框架主干能否保持稳定；
- 哪些抽象已经稳定，哪些抽象会迫使后续再次重构。

## 1. 总体结论

当前框架已经形成了较好的 GNC 领域边界：

- `Form` 拥有连续状态和导数方程；
- input/process/output 表达机载输入、GNC 算法和飞行器能力；
- `Interaction` 完成 form-specific 物理闭合；
- 固定阶段顺序和 priority 使离散流程可解释；
- 周期开始发布态、当前周期离散输出和同步积分的时间语义清楚；
- typed provider 接口适合实验室项目的静态检查和直接调试；
- active project 已经具备较成熟的普通组件扩展路径。

基础对象模型仍存在一次集中重构的价值。核心问题可以归纳为：

1. `ComponentBase` 同时承担装配生命周期和离散调度职责，抽取了部分稳定共性，也纳入了并非所有对象都具备的 `update()` 与执行频率。
2. 普通组件和 service package 采用两套注册、依赖、准备和生命周期机制。
3. scope、领域 role 和 execution stage 在枚举与 placement 中相互绑定，mission-scope process、可选基础设施节点等扩展缺少自然位置。
4. `SimulationBuilder` 直接注册具体 service package，并硬编码积分器等能力；应用组合根下沉到了 framework core。
5. 坐标树引擎、坐标查询接口、具体 Form 坐标定义和 service package 构建流程耦合在一起。
6. 多个独立连续系统只能读取彼此的周期边界状态，未来连续舵机、质量、推进、弹性模态等强耦合模型缺少 group 级扩展边界。

建议采用一条明确路线：

> mission 中具有独立身份的对象统一建模为仿真节点；scope 决定所有权，role 决定领域语义，capability 决定运行行为，接口决定依赖关系，extension 决定类型如何进入框架目录。

“服务”保留为一种可选基础设施用法，不再拥有独立对象体系。坐标树、星历、随机源、统一时间基准等能力都可以表现为 Infrastructure 节点；核心仿真、普通 mission 和不使用这些能力的组件不依赖它们。

## 2. 评审使用的架构判据

判断一个概念应放入 `common`、`libraries`、project node 或可选扩展包时，依次回答以下问题：

1. 它是否在 mission 中拥有独立名称和配置？
2. 它是否需要独立 scope、依赖绑定、准备或初始化？
3. 它是否由框架调度，或者只由宿主对象直接调用？
4. 它的状态由一个宿主独占，还是作为全车/全任务权威状态被多个对象读取？
5. 它表达任务策略、物理模型、基础设施能力，还是纯算法工具？
6. 删除该能力后，框架核心和无关 mission 是否仍然可以运行？

建议采用以下分类。

| 概念 | 所有者 | mission 身份 | 框架生命周期 | 调度 | 典型例子 |
| --- | --- | --- | --- | --- | --- |
| 基础类型与函数 | 调用代码 | 无 | 无 | 无 | 数学函数、向量工具、单位辅助 |
| 可嵌入算法对象 | 宿主节点 | 无 | 由宿主负责 | 由宿主调用 | PID、滤波器、状态机、插值器 |
| 只读数据产品 | producer 节点 | 通过 producer 表达 | prepare 后可用 | 通常无 | 气动表、标准轨迹、地形数据 |
| 仿真节点 | 框架 | 有 | 完整 | 由 capability 决定 | Form、导航、制导、执行机构、坐标树 |
| 扩展包 | runner/CMake | 无运行实例 | 无 | 无 | builtin definitions、项目定义、可选坐标包 |

目录语义可相应收敛为：

- `common`：基础值类型、数学和轻量无状态帮助函数；
- `libraries`：可嵌入算法对象，可拥有局部状态，不参与框架注册和 mission 装配；
- `interfaces`：跨节点的数据与能力契约；
- `nodes` 或现有领域目录：mission 可实例化的节点类型；
- `extensions`：可选编译包，通过统一 catalog 贡献节点类型或其它定义；
- `user/<project>`：研究项目的节点、接口、算法、资产和 mission。

## 3. 广义拓扑应包含五类关系

当前框架对执行顺序表达较强。为了支持后续扩展，架构心智模型还应明确区分五类关系。

### 3.1 所有权与作用域拓扑

```text
Mission
├── Environment
├── Vehicle A
└── Vehicle B
```

它决定节点生命周期、默认名称解析和依赖可见范围。

### 3.2 依赖与数据拓扑

```text
navigation -> imu + satellite_nav
guidance -> navigation + target_track
propulsion -> flight_phase
coordinates -> frame contributors
```

它表达 typed provider 关系。运行期数据依赖和准备期数据产品依赖应有明确区分，避免把所有依赖都解释为调度顺序。

### 3.3 离散执行拓扑

```text
environment -> perturbation -> input -> process
-> output -> interaction -> evaluation
```

只有具备离散执行 capability 的节点进入这张图。静态资产、纯查询节点和纯连续节点无需提供空 `update()`。

### 3.4 连续状态与耦合拓扑

```text
form state
actuator state
mass / propulsion state
flexible or slosh state
```

它决定积分器看到哪些联合候选状态。当前同步独立积分适合 sample-and-hold 耦合；强耦合模型需要显式 continuous group。

### 3.5 扩展组合拓扑

```text
framework builtins
linked optional extensions
active project definitions
             -> FrameworkCatalog
             -> Mission Builder
```

它决定哪些类型可被 mission 引用。扩展组合属于程序启动层，不属于单次仿真运行时。

这五类拓扑分开后，状态机工具只存在于宿主节点内部；权威任务状态机进入依赖图和执行图；坐标基础设施节点进入所有权图和依赖图，必要时也可以具有离散刷新 capability。

## 4. 统一仿真节点模型

### 4.1 当前 `ComponentBase` 的问题

现有 `ComponentBase` 包含：

- 配置；
- service 注入；
- component 依赖注入；
- prepare；
- initialize；
- publish；
- `update(double)`；
- finalize；
- 调度频率；
- 仿真时间和 step；
- debug snapshot。

其中，配置、依赖、准备、初始化和终结属于 mission 对象的稳定生命周期。`update()`、publish 和频率属于可选运行行为。

仓库中已有大量空 `update()`，覆盖 Form、静态环境、资产、Interaction、termination 和常质量模型。连续系统频率问题也源于执行频率挂在所有 `ComponentBase` 对象上，而 Simulator 再通过 `IContinuousSystem` 类型检查绕开离散更新。

### 4.2 目标基类

建议将共同基类收敛为：

```cpp
class SimulationNode {
public:
    virtual ~SimulationNode() = default;

    virtual void configure(const ConfigView&) {}
    virtual void bind(AssemblyContext&) {}
    virtual void prepare(const PreparationContext&) {}
    virtual void initialize() {}
    virtual void finalize() {}
};
```

运行行为通过 capability 表达：

```cpp
class IDiscreteTask {
public:
    virtual void update(const StepContext&) = 0;
};

class IPublishTask {
public:
    virtual void publish(const PublishContext&) = 0;
};
```

现有 `IContinuousSystem`、`IObservable`、`ITerminationEvaluator` 和 `ISummaryObserver` 继续作为能力接口存在。

`StepContext` 应显式提供时间语义：

```cpp
struct StepContext {
    double time_s;
    double dt_s;
    std::uint64_t step;
};
```

由此得到以下结果：

- `rate_hz` 只允许配置在 `IDiscreteTask` 上；
- Form 只实现 continuous 和 publish 能力；
- 静态资产只参与 configure/prepare；
- 纯 Interaction closure 只暴露 form input provider；
- termination 可以实现离散评估和终止接口；
- 基础设施节点按需要选择 query、publish 或 discrete capability；
- 单元测试可以直接构造 `StepContext`，无需修改节点内部仿真时间字段。

## 5. 服务的最终定位

### 5.1 服务是一种可选基础设施节点用法

服务无需形成独立 C++ 基类、注册表、生命周期或依赖容器。它具有以下语义特征：

- 提供跨多个节点共享的稳定基础设施能力；
- 通常通过查询接口使用；
- 缺省不进入离散执行阶段；
- 可以位于 mission、environment 或 vehicle scope；
- 不承载制导、控制、任务模式或物理闭合策略；
- 是否启用由 mission 和已链接扩展共同决定。

如果把“组件”定义为 mission 实例化并由框架管理的对象，服务本身就是一种组件。本评审使用 `SimulationNode` 作为统一名称，目的是解除当前 `ComponentBase` 与“必须提供离散 update”之间的绑定。它不引入位于 component 和 service 之上的第三套运行对象体系。项目也可以继续使用“组件”作为统一称呼，只要共同基类不再强制所有对象具备离散调度行为。

因此，坐标树可以是：

```text
scope      = vehicle
role       = infrastructure
capability = ICoordinateTransform
schedule   = none
```

星历服务可能是：

```text
scope      = environment
role       = infrastructure
capability = IEphemeris
schedule   = optional discrete refresh
```

### 5.2 可选性的严格含义

框架核心应满足：

1. `Simulator`、`SimulationBuilder` 和普通 NodeRegistry 不依赖任何具体基础设施节点。
2. 没有链接坐标树、星历或随机源扩展时，普通 mission 可以正常构建和运行。
3. mission 未声明某个基础设施节点时，框架不会自动创建隐藏实例。
4. 普通 builtin 节点不能无条件要求某个可选基础设施能力。
5. 节点只有在自身 type/config 明确选择该能力时，才将其声明为 required dependency。
6. 可降级功能可以使用 optional binding，并由组件显式定义无服务时的算法路径。

如果使用者选择了一个明确依赖坐标树的 IMU 或导航节点，该 mission 缺少相应 provider 时应在 build 阶段失败。这属于所选模型的依赖不完整，不代表框架核心依赖坐标服务。

### 5.3 删除独立 service 线路

目标实现中删除：

- `ServiceContext`；
- `IServicePackage`；
- `ServicePackageRegistry`；
- `IServiceFinalizationTask`；
- `injectServices()`；
- `SimulationBuilder` 内的 builtin service 注册；
- service 专用依赖解析和 finalization 顺序。

mission 可以保留 `infrastructure` 这一专业语义分区，但其中每个条目仍然通过统一 NodeFactory 创建，通过 NodeRegistry 注册，通过 AssemblyContext 绑定，通过 PreparationPipeline 准备。

建议采用 `infrastructure` 命名，以表达可选基础设施节点，并减少“service 是另一类运行对象”的暗示。

## 6. scope、role、phase 和 capability 必须正交

当前 `VehicleProcess`、`VehicleOutput` 等枚举值同时编码 scope 与领域 role，execution stage 又重复相同组合。这会限制 mission-scope process 和多种基础设施节点。

建议拆分为以下维度。

### 6.1 Scope

```cpp
enum class ScopeKind {
    Mission,
    Environment,
    Vehicle
};
```

### 6.2 Role

```cpp
enum class NodeRole {
    Infrastructure,
    Asset,
    EnvironmentModel,
    Perturbation,
    Form,
    Input,
    Process,
    Output,
    Interaction,
    Termination,
    Summary
};
```

### 6.3 Discrete phase

```cpp
enum class DiscretePhase {
    Environment,
    Perturbation,
    Input,
    Process,
    Output,
    Interaction,
    Evaluation
};
```

phase 只属于 `IDiscreteTask`。`Vehicle` 不再出现在 phase 名称中。

### 6.4 Capability

capability 由 C++ 接口表达，例如：

- `IDiscreteTask`；
- `IPublishTask`；
- `IContinuousSystem`；
- `IObservable`；
- GNC typed provider；
- 基础设施查询接口。

示例：

| 对象 | Scope | Role | Capability |
| --- | --- | --- | --- |
| 坐标树 | Vehicle | Infrastructure | `ICoordinateTransform` |
| EOP/星历 | Environment | Infrastructure | query，可选 discrete refresh |
| 飞行阶段机 | Vehicle | Process | `IDiscreteTask + IPhaseProvider` |
| 交战协调器 | Mission | Process | `IDiscreteTask + IMissionModeProvider` |
| 气动表 | Vehicle | Asset | prepared provider |
| 刚体 Form | Vehicle | Form | `IContinuousSystem + truth view` |

## 7. 状态机和控制流的定位

状态机是否进入框架拓扑，取决于其状态所有权。

### 7.1 组件局部状态机

导引头捕获状态、导航对准状态、发动机点火状态、控制器增益调度状态都由单个宿主拥有。`gnc::libraries::StateMachine` 作为成员存在，由宿主在 initialize/update 中驱动。

它无需 mission 身份、注册、独立 scope 或 service 接口。

### 7.2 Vehicle 级权威状态机

当 propulsion、guidance、control 等多个节点都读取统一飞行阶段时，应建立独立 Vehicle/Process 节点：

```text
FlightSequencer
    -> IFlightPhaseProvider
    -> guidance / propulsion / control / termination
```

该节点内部可以复用状态机库。

### 7.3 Mission 级权威状态机

多飞行器任务可能需要：

- 交战阶段；
- 目标分配；
- 发射次序；
- 协同模式；
- 试验流程。

当前顶层只有 termination 和 summary，缺少常规 Mission/Process 节点。目标架构应允许 mission scope 拥有 process 节点，并明确它们位于离散 process phase 的哪一段。

任务决策状态属于 process。多个消费者共享读取不会改变它的领域角色。

## 8. 坐标能力的重构建议

### 8.1 当前耦合

当前坐标包同时包含：

- `ICoordService`；
- CoordinateTree 实现；
- service package 构建；
- 私有 spec registry；
- `local_spherical_3dof.launch_track`；
- 对 `IEarth` 和具体 Form truth view 的绑定。

这导致新增 Form 坐标定义时必须修改坐标包内部 spec 注册，坐标基础设施也无法作为完全可选的已链接扩展存在。

### 8.2 分层目标

建议拆分为：

```text
coordinate contracts
    FrameId / rotation conventions / ICoordinateTransform

coordinate-tree extension
    graph / path search / composition / cache / infrastructure node

form or project frame definitions
    earth / launch / body / track / seeker LOS contributors
```

坐标公共接口应明确区分：

- rotation；
- free vector；
- point；
- 后续需要时增加含原点运动、角速度和导数项的 kinematic transform。

### 8.3 Frame contributor

具体坐标定义通过普通节点扩展路径提供：

```cpp
class ICoordinateFrameContributor {
public:
    virtual void contributeFrames(CoordinateTreeBuilder&) const = 0;
};
```

项目可以增加：

```text
project.frames.earth_inertial
project.frames.launch_site
project.frames.vehicle_body
project.frames.velocity_track
project.frames.seeker_los
```

它们负责配置和绑定相关 Earth、Truth、Seeker provider。CoordinateTree 节点在 prepare 阶段收集同 scope contributor，完成图校验和封存。

新增坐标定义只新增项目节点、接口实现和 mission 条目，无需修改 framework core 或 coordinate-tree extension。

## 9. 通用扩展目录与组合根

`SimulationBuilder` 当前直接注册 builtin service，并通过字符串分支构造积分器。项目组件和 SimFlow materializer 又拥有各自注册入口。建议增加显式 `FrameworkCatalog`：

```cpp
struct FrameworkCatalog {
    NodeTypeRegistry nodes;
    IntegratorRegistry integrators;
    SimFlowMaterializerRegistry simflow;
};
```

runner 只调用通用组合入口：

```cpp
FrameworkCatalog catalog;

registerFrameworkBuiltins(catalog);
registerLinkedExtensions(catalog);
registerActiveProject(catalog);

SimulationBuilder builder(catalog);
```

`registerLinkedExtensions()` 由 CMake 根据已链接扩展生成。runner 和 framework core 不出现 coordinate、ephemeris、random 等具体扩展名称。

某个扩展包内部可以提供自己的 catalog contribution 函数，但该函数只出现在生成的扩展注册链中。例如坐标树扩展、星历扩展和项目附加包都通过同一条 linked-extension 机制进入 catalog。

扩展包是编译期组合单元。当前实验室定位无需运行时 DLL 发现、插件市场、版本协商或热加载。

## 10. 依赖、准备和运行阶段

建议统一构建流程：

```text
register definitions
-> parse mission
-> instantiate all nodes
-> construct scope tree
-> bind all dependencies
-> prepare nodes and immutable products
-> initialize runtime state
-> derive execution plan from capabilities
-> run
-> finalize
```

阶段契约应明确：

- `configure()` 只读取自身配置；
- `bind()` 只解析并保存接口句柄，不调用尚未准备的 provider；
- `prepare()` 加载资产、构建只读产品和基础设施索引；
- 全部必要基础设施在 prepare 结束时可查询；
- `initialize()` 初始化节点自身运行状态；
- `update()` 只存在于 `IDiscreteTask`；
- `publish()` 只存在于 `IPublishTask` 或由 continuous state owner 明确实现；
- continuous state 只由积分器推进。

若未来出现多级资产准备，应为准备依赖增加独立声明，避免使用 runtime provider 连接隐式推导 prepare 顺序。

## 11. 连续系统扩展边界

当前同步独立积分保持所有 continuous next state 同步提交，适合以下模型：

- Form 读取本周期离散保持命令；
- 各连续组件之间采用周期边界耦合；
- 跨 vehicle 读取发布态。

以下模型会需要联合候选状态：

- 刚体与连续舵机强耦合；
- 质量、燃料和推进连续耦合；
- 弹性模态；
- 液体晃动；
- 多体约束。

建议保留明确的 `IContinuousGroup` 或 `CoupledStateAssembler` 扩展点。默认 group 可以只包含一个 continuous node，从而保持当前轻量语义；出现真实强耦合需求时，由 mission 显式声明 group。

## 12. 建议保留的设计

以下设计已经符合项目定位，重构时应继续保留：

- `vehicles[]` 作为主要物理实体布局；
- Form、Interaction、input/process/output 的 GNC 领域边界；
- 固定离散 phase 和显式 priority；
- 周期开始发布态及当前周期输出记录语义；
- typed provider 接口；
- project-first 扩展原则；
- mission 显式配置和失败早暴露；
- SimFlow 只物化 effective mission；
- 强耦合通过显式 continuous group 扩展。

固定 phase 仍然有价值。scope 与 phase 拆分后，Mission/Process 和 Vehicle/Process 可以共享 process phase，具体先后由受约束的子阶段或 priority 表达。当前阶段无需引入任意 DAG 调度器。

## 13. 单一路线重构建议

本项目适合在独立分支完成一次集中迁移，最终只保留新模型。

建议顺序：

1. 写入新的架构 ADR，冻结 `SimulationNode / Scope / Role / Capability / Phase` 术语。
2. 实现统一 NodeFactory、NodeRegistry、AssemblyScope 和 AssemblyContext。
3. 将 `update()` 从共同基类移入 `IDiscreteTask`，将 `rate_hz` 移入离散执行描述。
4. 一次性迁移 builtin、tests 和 active project 节点。
5. 将 mission placement 映射到正交 scope、role 和 phase。
6. 将坐标树迁移为可选 Infrastructure 节点，将具体 frame spec 迁移为 contributor。
7. 删除 service 专用注册、上下文、finalization 和 Builder bootstrap。
8. 引入 `FrameworkCatalog + registerLinkedExtensions()`，清除 Builder 中具体扩展名称。
9. 增加 Mission/Process 节点入口，覆盖多飞行器协调状态机用例。
10. 修复 continuous node 频率配置，并为 continuous group 留出独立契约。
11. 更新 mission、文档和架构测试，删除全部旧入口和过渡适配代码。

迁移期间可以使用连续的小提交保持编译，但合并后的主线只包含一套对象模型、一套依赖绑定和一套生命周期。

## 14. 验收标准

完成重构后，应能用以下问题检验架构是否闭合。

### 新增普通 GNC 节点

- 只增加项目类型、注册和 mission 配置；
- 无需修改 Builder、Simulator 和 Assembler 主干。

### 新增可选基础设施能力

- 通过 linked extension 或 active project 注册普通 node type；
- 未链接、未配置时，普通 mission 正常运行；
- 无独立 service registry 或生命周期；
- 使用者显式选择依赖它的节点后，缺失依赖会清楚失败。

### 新增项目坐标系

- 只增加 frame contributor；
- CoordinateTree 实现保持不变；
- framework core 保持不变。

### 新增局部状态机

- 只修改宿主算法节点；
- 无 mission 节点和注册成本。

### 新增全车或全任务状态机

- 分别放入 Vehicle/Process 或 Mission/Process；
- 通过 typed provider 发布权威模式；
- 不使用 Infrastructure 角色承载任务决策。

### 新增积分器

- 向 catalog 注册 integrator definition；
- `SimulationBuilder` 不增加字符串分支。

### 新增连续强耦合模型

- 通过 continuous group 组合状态；
- 不改变普通独立 continuous node 的运行语义。

## 15. 最终目标架构

```mermaid
flowchart TB
    Builtins["Framework builtins"] --> Catalog["FrameworkCatalog"]
    Extensions["Linked optional extensions"] --> Catalog
    Project["Active project definitions"] --> Catalog

    Mission["Mission JSON"] --> Builder["Mission Builder"]
    Catalog --> Builder
    Builder --> Scopes["AssemblyScope tree"]
    Scopes --> Nodes["SimulationNode instances"]

    Nodes --> Discrete["IDiscreteTask"]
    Nodes --> Continuous["IContinuousSystem / group"]
    Nodes --> Publish["IPublishTask"]
    Nodes --> Providers["Typed provider interfaces"]
    Nodes --> Infrastructure["Optional infrastructure capabilities"]

    Discrete --> Scheduler["Fixed-phase scheduler"]
    Continuous --> Integrator["Integrator"]
    Publish --> Scheduler
    Providers --> Bindings["Dependency graph"]
    Infrastructure --> Bindings
```

可以用一句话概括目标：

> 框架只管理统一仿真节点及其能力；服务是可选基础设施节点的使用语义；状态机等工具由宿主拥有；扩展包通过通用 catalog 进入程序；核心运行时不依赖任何具体可选能力。
