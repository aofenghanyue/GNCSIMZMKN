#pragma once

#include "gnc/core/assembly_context.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/simulation_node.hpp"
#include "gnc/extensions/coordinate_tree/coordinate_tree_builder.hpp"
#include "gnc/extensions/coordinate_tree/interfaces/i_coordinate_frame_contributor.hpp"
#include "gnc/extensions/coordinate_tree/interfaces/i_coordinate_transform.hpp"

#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace gnc::extensions::coordinate_tree {

class CoordinateTreeNode final : public gnc::core::SimulationNode,
                                 public ICoordinateTransform {
public:
    CoordinateTreeNode() : SimulationNode("CoordinateTree") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        root_frame_ = reader.optionalString("root_frame", root_frame_);
        if (root_frame_.empty()) {
            throw std::runtime_error(config_path +
                                     ".root_frame must not be empty.");
        }
        reader.validateNoUnknownKeys();
    }

    void bind(gnc::core::AssemblyContext& context) override {
        contributors_ =
            context.getAllInScope<ICoordinateFrameContributor>();
    }

    void prepare(const gnc::core::PreparationContext&) override {
        CoordinateTreeBuilder builder;
        builder.setRoot(root_frame_);
        for (const auto* contributor : contributors_) {
            contributor->contributeFrames(builder);
        }
        tree_ = builder.seal();
    }

    gnc::math::Vector3 transformVector(
        const gnc::math::Vector3& vector,
        const std::string& from_frame,
        const std::string& to_frame,
        double time) const override {
        return requireTree().transform(vector, from_frame, to_frame, time);
    }

    gnc::math::Vector3 transformPoint(
        const gnc::math::Vector3& point,
        const std::string& from_frame,
        const std::string& to_frame,
        double time) const override {
        // The current tree contains rotational frames only. The distinct API
        // preserves point semantics for a future kinematic transform model.
        return requireTree().transform(point, from_frame, to_frame, time);
    }

    gnc::math::Matrix3 getRotation(const std::string& from_frame,
                                   const std::string& to_frame,
                                   double time) const override {
        return requireTree().getRotation(from_frame, to_frame, time);
    }

    bool hasFrame(const std::string& frame_id) const override {
        return requireTree().hasFrame(frame_id);
    }

    bool hasEdge(const std::string& child_frame,
                 const std::string& parent_frame) const override {
        return requireTree().hasEdge(child_frame, parent_frame);
    }

private:
    const internal::CoordinateTree& requireTree() const {
        if (!tree_) {
            throw std::runtime_error(
                "CoordinateTree node is not prepared. Mission assembly must "
                "complete prepare() before coordinate queries.");
        }
        return *tree_;
    }

    std::string root_frame_ = "I";
    std::vector<ICoordinateFrameContributor*> contributors_;
    std::shared_ptr<const internal::CoordinateTree> tree_;
};

} // namespace gnc::extensions::coordinate_tree
