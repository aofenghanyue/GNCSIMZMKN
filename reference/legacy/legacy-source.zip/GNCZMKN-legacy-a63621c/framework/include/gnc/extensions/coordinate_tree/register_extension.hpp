#pragma once

#include "gnc/core/framework_catalog.hpp"
#include "gnc/extensions/coordinate_tree/components/coordinate_tree_node.hpp"
#include "gnc/extensions/coordinate_tree/components/local_spherical_3dof_launch_track_frames.hpp"

namespace gnc::extensions::coordinate_tree {

inline void contributeToCatalog(gnc::core::FrameworkCatalog& catalog) {
    using namespace gnc::core;
    catalog.nodes().registerType<CoordinateTreeNode, ICoordinateTransform>(
        "infrastructure.coordinate_tree",
        NodeCategory::Builtin,
        __FILE__,
        NodeRole::Infrastructure,
        DiscretePhase::None);
    catalog.nodes().registerType<LocalSpherical3DofLaunchTrackFrames,
                                 ICoordinateFrameContributor>(
        "infrastructure.coordinate_frames.local_spherical_3dof.launch_track",
        NodeCategory::Builtin,
        __FILE__,
        NodeRole::Infrastructure,
        DiscretePhase::None,
        "local_spherical_3dof");
}

} // namespace gnc::extensions::coordinate_tree
