#pragma once

#include "gnc/core/assembly_context.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/simulation_node.hpp"
#include "gnc/environment/interfaces/i_earth.hpp"
#include "gnc/extensions/coordinate_tree/coordinate_tree_builder.hpp"
#include "gnc/extensions/coordinate_tree/interfaces/i_coordinate_frame_contributor.hpp"
#include "gnc/extensions/coordinate_tree/internal/local_spherical_launch_track_math.hpp"
#include "gnc/forms/local_spherical_3dof/interfaces/i_truth_view.hpp"

#include <string>

namespace gnc::extensions::coordinate_tree {

class LocalSpherical3DofLaunchTrackFrames final
    : public gnc::core::SimulationNode,
      public ICoordinateFrameContributor {
public:
    LocalSpherical3DofLaunchTrackFrames()
        : SimulationNode("LocalSpherical3DofLaunchTrackFrames") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        earth_lookup_name_ =
            reader.optionalString("earth_lookup_name", earth_lookup_name_);
        truth_lookup_name_ =
            reader.optionalString("truth_lookup_name", truth_lookup_name_);
        latitude_rad_ = reader.requiredDouble("latitude_rad");
        longitude_rad_ = reader.requiredDouble("longitude_rad");
        azimuth_rad_ = reader.requiredDouble("azimuth_rad");
        launch_time_s_ = reader.requiredDouble("launch_time_s");
        earth_rotation_angle_rad_ =
            reader.requiredDouble("earth_rotation_angle_rad");
        reader.validateNoUnknownKeys();
    }

    void bind(gnc::core::AssemblyContext& context) override {
        earth_ = context.requireByName<gnc::environment::IEarth>(
            earth_lookup_name_);
        truth_ = context.requireByName<
            gnc::forms::local_spherical_3dof::ITruthView>(truth_lookup_name_);
    }

    void contributeFrames(CoordinateTreeBuilder& builder) const override {
        builder.addFrame("E");
        builder.addFrame("N");
        builder.addFrame("L");
        builder.addFrame("LI");
        builder.addFrame("K");

        builder.addDynamicEdge(
            "E", "I", [earth = earth_, angle = earth_rotation_angle_rad_](double time) {
                return internal::ecefToInertialRotation(
                    angle + earth->getRotationRate() * time);
            });
        builder.addStaticEdge(
            "N",
            "E",
            internal::localGeographicToEarthFixedRotation(
                latitude_rad_, longitude_rad_));
        builder.addStaticEdge(
            "L", "N", internal::launchToLocalGeographicRotation(azimuth_rad_));
        builder.addDynamicEdge(
            "LI", "L", [earth = earth_, launch = launch_time_s_](double time) {
                return internal::launchInertialToLaunchRotation(
                    launch, time, earth->getRotationRate());
            });
        builder.addDynamicEdge("K", "L", [truth = truth_](double) {
            return internal::trackToLaunchRotation(
                truth->getLocalSpherical3DoFTruth().velocity_launch_mps);
        });
    }

private:
    gnc::environment::IEarth* earth_ = nullptr;
    gnc::forms::local_spherical_3dof::ITruthView* truth_ = nullptr;
    std::string earth_lookup_name_ = "env.earth";
    std::string truth_lookup_name_ = "dynamics";
    double latitude_rad_ = 0.0;
    double longitude_rad_ = 0.0;
    double azimuth_rad_ = 0.0;
    double launch_time_s_ = 0.0;
    double earth_rotation_angle_rad_ = 0.0;
};

} // namespace gnc::extensions::coordinate_tree
