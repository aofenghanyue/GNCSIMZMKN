#pragma once

namespace gnc::extensions::coordinate_tree {

class CoordinateTreeBuilder;

class ICoordinateFrameContributor {
public:
    virtual ~ICoordinateFrameContributor() = default;
    virtual void contributeFrames(CoordinateTreeBuilder& builder) const = 0;
};

} // namespace gnc::extensions::coordinate_tree
