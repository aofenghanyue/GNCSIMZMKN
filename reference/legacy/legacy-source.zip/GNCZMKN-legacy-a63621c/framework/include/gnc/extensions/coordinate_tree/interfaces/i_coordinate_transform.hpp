#pragma once

#include "gnc/common/math/eigen_types.hpp"

#include <string>

namespace gnc::extensions::coordinate_tree {

class ICoordinateTransform {
public:
    virtual ~ICoordinateTransform() = default;

    virtual gnc::math::Vector3 transformVector(
        const gnc::math::Vector3& vector,
        const std::string& from_frame,
        const std::string& to_frame,
        double time) const = 0;
    virtual gnc::math::Vector3 transformPoint(
        const gnc::math::Vector3& point,
        const std::string& from_frame,
        const std::string& to_frame,
        double time) const = 0;
    virtual gnc::math::Matrix3 getRotation(const std::string& from_frame,
                                           const std::string& to_frame,
                                           double time) const = 0;
    virtual bool hasFrame(const std::string& frame_id) const = 0;
    virtual bool hasEdge(const std::string& child_frame,
                         const std::string& parent_frame) const = 0;
};

} // namespace gnc::extensions::coordinate_tree
