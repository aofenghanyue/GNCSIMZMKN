#pragma once

#include <string>
#include <utility>

namespace gnc::core {

enum class ScopeKind {
    Mission,
    Environment,
    Vehicle
};

inline const char* toString(ScopeKind kind) {
    switch (kind) {
    case ScopeKind::Mission:
        return "mission";
    case ScopeKind::Environment:
        return "environment";
    case ScopeKind::Vehicle:
        return "vehicle";
    default:
        return "unknown";
    }
}

struct AssemblyScope {
    ScopeKind kind = ScopeKind::Mission;
    std::string key = "mission";
    std::string id = "mission";
    std::string registry_prefix;
    std::string parent_key;

    static AssemblyScope mission() {
        return {ScopeKind::Mission, "mission", "mission", "mission.", ""};
    }

    static AssemblyScope environment() {
        return {ScopeKind::Environment,
                "environment",
                "environment",
                "env.",
                "mission"};
    }

    static AssemblyScope vehicle(std::string vehicle_id) {
        return {ScopeKind::Vehicle,
                "vehicle:" + vehicle_id,
                vehicle_id,
                vehicle_id + ".",
                "mission"};
    }

    static AssemblyScope directRoot() {
        return {ScopeKind::Mission, "direct", "direct", "", ""};
    }
};

} // namespace gnc::core
