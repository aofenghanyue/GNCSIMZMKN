#pragma once

#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>

namespace gnc::core {

/**
 * @brief Small process-local cache for immutable prepared asset products.
 *
 * Cache keys should include the source fingerprint and every processing option
 * that changes the product. Entries remain alive for the process lifetime so
 * serial case execution can reuse expensive results. The number of unique
 * source/profile combinations should therefore stay bounded by the experiment.
 */
class PreparedAssetCache {
public:
    template <typename T, typename Factory>
    static std::shared_ptr<const T> getOrCreate(const std::string& key,
                                                Factory&& factory) {
        std::lock_guard<std::mutex> lock(mutexFor<T>());
        auto& entries = entriesFor<T>();
        const auto it = entries.find(key);
        if (it != entries.end()) {
            return it->second;
        }

        std::shared_ptr<const T> created = std::forward<Factory>(factory)();
        if (!created) {
            throw std::runtime_error(
                "Prepared asset factory returned an empty shared_ptr for key '" +
                key + "'.");
        }
        entries[key] = created;
        return created;
    }

    template <typename T>
    static void clearForTests() {
        std::lock_guard<std::mutex> lock(mutexFor<T>());
        entriesFor<T>().clear();
    }

private:
    template <typename T>
    static std::unordered_map<std::string, std::shared_ptr<const T>>& entriesFor() {
        static std::unordered_map<std::string, std::shared_ptr<const T>> entries;
        return entries;
    }

    template <typename T>
    static std::mutex& mutexFor() {
        static std::mutex mutex;
        return mutex;
    }
};

} // namespace gnc::core
