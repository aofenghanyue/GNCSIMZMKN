#pragma once

#include "gnc/core/config_manager.hpp"
#include "gnc/core/preparation_context.hpp"
#include "gnc/core/runtime_capabilities.hpp"

#include <map>
#include <string>
#include <utility>

namespace gnc::core {

class AssemblyContext;

class SimulationNode {
public:
    explicit SimulationNode(std::string name) : name_(std::move(name)) {}
    virtual ~SimulationNode() = default;

    SimulationNode(const SimulationNode&) = delete;
    SimulationNode& operator=(const SimulationNode&) = delete;
    SimulationNode(SimulationNode&&) = delete;
    SimulationNode& operator=(SimulationNode&&) = delete;

    virtual void configure(const ConfigNode& config) { (void)config; }

    virtual void configure(const ConfigNode& config,
                           const std::string& config_path) {
        (void)config_path;
        configure(config);
    }

    virtual void bind(AssemblyContext& context) { (void)context; }
    virtual void prepare(const PreparationContext& context) { (void)context; }
    virtual void initialize() {}
    virtual void finalize() {}

    const std::string& getName() const { return name_; }
    const std::string& getTypeName() const { return type_name_; }
    const std::string& getNodeCategory() const { return node_category_; }
    const std::string& getRegistrationOrigin() const { return registration_origin_; }

    const std::map<std::string, double>& getDebugSnapshot() const {
        return debug_snapshot_;
    }

    void setNameInternal_(const std::string& name) { name_ = name; }
    void setTypeNameInternal_(const std::string& type_name) { type_name_ = type_name; }
    void setNodeCategoryInternal_(const std::string& category) {
        node_category_ = category;
    }
    void setRegistrationOriginInternal_(const std::string& origin) {
        registration_origin_ = origin;
    }
    void clearDebugSnapshotInternal_() { debug_snapshot_.clear(); }

    bool dependenciesBoundInternal_() const { return dependencies_bound_; }
    void markDependenciesBoundInternal_() { dependencies_bound_ = true; }

protected:
    void snapDebug(const std::string& name, double value) {
        debug_snapshot_[name] = value;
    }

private:
    std::string name_;
    std::string type_name_;
    std::string node_category_ = "project";
    std::string registration_origin_;
    std::map<std::string, double> debug_snapshot_;
    bool dependencies_bound_ = false;
};

class DiscreteNode : public SimulationNode, public IDiscreteTask {
public:
    using SimulationNode::SimulationNode;
};

} // namespace gnc::core
