#pragma once

#include "gnc/core/integrator_registry.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/simflow/simflow_materializer_registry.hpp"

namespace gnc::core {

class FrameworkCatalog {
public:
    NodeFactory& nodes() { return nodes_; }
    const NodeFactory& nodes() const { return nodes_; }

    IntegratorRegistry& integrators() { return integrators_; }
    const IntegratorRegistry& integrators() const { return integrators_; }

    simflow::SimFlowMaterializerRegistry& simflowMaterializers() {
        return simflow_materializers_;
    }
    const simflow::SimFlowMaterializerRegistry& simflowMaterializers() const {
        return simflow_materializers_;
    }

private:
    NodeFactory nodes_;
    IntegratorRegistry integrators_;
    simflow::SimFlowMaterializerRegistry simflow_materializers_;
};

} // namespace gnc::core
