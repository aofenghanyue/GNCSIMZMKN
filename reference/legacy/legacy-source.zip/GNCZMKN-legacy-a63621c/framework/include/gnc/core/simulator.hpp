#pragma once

#include "gnc/common/logger.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/core/execution_metadata.hpp"
#include "gnc/core/execution_phase_manager.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/node_registry.hpp"
#include "gnc/core/runtime_capabilities.hpp"
#include "gnc/infrastructure/auto_data_logger.hpp"
#include "gnc/infrastructure/simulation_summary.hpp"
#include "gnc/interfaces/i_continuous_group.hpp"
#include "gnc/interfaces/i_continuous_system.hpp"
#include "gnc/interfaces/i_integrator.hpp"
#include "gnc/interfaces/i_termination_evaluator.hpp"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace gnc::core {

struct SimulatorConfig {
    double dt = 0.01;
    double duration = 10.0;
};

class Simulator {
public:
    using StepCallback = std::function<void(int step, double time, double dt)>;

    Simulator() = default;
    ~Simulator() = default;

    Simulator(const Simulator&) = delete;
    Simulator& operator=(const Simulator&) = delete;

    NodeRegistry& getRegistry() { return registry_; }
    const NodeRegistry& getRegistry() const { return registry_; }

    void resetAssemblyState() {
        auto_logger_.reset();
        registry_.clear();
        execution_entries_.clear();
        entry_by_node_.clear();
        termination_reason_ = "completed";
        current_time_ = 0.0;
        is_initialized_ = false;
        integration_systems_.clear();
        phase_manager_ = ExecutionPhaseManager{};
    }

    void configure(const SimulatorConfig& config) {
        config_ = config;
        computeStepIntervals();
    }

    void setIntegrator(std::unique_ptr<interfaces::IIntegrator> integrator) {
        integrator_ = std::move(integrator);
    }

    const interfaces::IIntegrator* getIntegrator() const {
        return integrator_.get();
    }

    /** Register lifecycle metadata and, when present, a discrete task. */
    void addNodeExecution(SimulationNode* node,
                          const NodeExecutionConfig& config = {}) {
        if (!node) {
            throw std::runtime_error("Cannot schedule a null simulation node.");
        }
        if (entry_by_node_.count(node) > 0) {
            throw std::runtime_error("Execution metadata already exists for node '" +
                                     node->getName() + "'.");
        }

        auto* task = dynamic_cast<IDiscreteTask*>(node);
        if (task && config.phase == DiscretePhase::None) {
            throw std::runtime_error(
                "Discrete node '" + node->getName() +
                "' requires an explicit discrete phase.");
        }
        if (!task && config.phase != DiscretePhase::None) {
            throw std::runtime_error(
                "Node '" + node->getName() + "' is assigned to phase '" +
                std::string(toString(config.phase)) +
                "' but does not implement IDiscreteTask.");
        }
        if (!task && config.rate_hz > 0.0) {
            throw std::runtime_error(
                "Node '" + node->getName() +
                "' configures rate_hz but does not implement IDiscreteTask.");
        }
        if (config.rate_hz < 0.0 || !std::isfinite(config.rate_hz)) {
            throw std::runtime_error("Node '" + node->getName() +
                                     "' has invalid rate_hz.");
        }

        ExecutionEntry entry;
        entry.node = node;
        entry.task = task;
        entry.config = config;
        entry.registration_order = execution_entries_.size();
        execution_entries_.push_back(entry);
        entry_by_node_[node] = execution_entries_.size() - 1;
        computeStepInterval(execution_entries_.back());
    }

    const NodeExecutionConfig* executionConfigFor(
        const SimulationNode* node) const {
        const auto it = entry_by_node_.find(const_cast<SimulationNode*>(node));
        if (it == entry_by_node_.end()) {
            return nullptr;
        }
        return &execution_entries_[it->second].config;
    }

    std::unordered_map<std::string, NodeExecutionInfo> executionInfo() const {
        std::unordered_map<std::string, NodeExecutionInfo> result;
        result.reserve(execution_entries_.size());
        for (const auto& entry : execution_entries_) {
            result.emplace(entry.node->getName(),
                           NodeExecutionInfo{
                               entry.config,
                               entry.step_interval,
                               entry.task != nullptr});
        }
        return result;
    }

    bool initializeAutoDataLogger(const ConfigNode& config) {
        return auto_logger_.initialize(config, registry_);
    }

    AutoDataLogger& getAutoDataLogger() { return auto_logger_; }
    const AutoDataLogger& getAutoDataLogger() const { return auto_logger_; }

    /** Validate the bound continuous execution topology without advancing state. */
    void validateExecutionPlan() {
        buildContinuousPlan();
        if (!integrator_ && !integration_systems_.empty()) {
            throw std::runtime_error(
                "Continuous systems are present but no integrator was supplied by "
                "the FrameworkCatalog.");
        }
    }

    void onBeforeStep(StepCallback callback) {
        before_step_callbacks_.push_back(std::move(callback));
    }

    void onAfterStep(StepCallback callback) {
        after_step_callbacks_.push_back(std::move(callback));
    }

    const std::string& getTerminationReason() const {
        return termination_reason_;
    }

    void initialize() {
        phase_manager_.transitionTo(ExecutionPhaseManager::Phase::Initializing);
        LOG_INFO("Initializing simulator...");
        current_time_ = 0.0;
        computeStepIntervals();

        // MissionAssembler normally performs binding during validation. This
        // fallback keeps direct, focused Simulator tests useful without a
        // second object model or hidden service container.
        const AssemblyGraph direct_graph =
            AssemblyGraph::inferFromNodeNames(registry_.getNodeNames());
        for (auto* node : registry_.getAllNodes()) {
            if (node->dependenciesBoundInternal_()) {
                continue;
            }
            bindDirectNode(*node, direct_graph);
        }

        validateExecutionPlan();
        initializeNodesInOrder();

        is_initialized_ = true;
        LOG_INFO("Simulator initialized with {} nodes{}",
                 registry_.size(),
                 integrator_ ? std::string(" using '") + integrator_->name() + "' integrator"
                             : std::string{});
    }

    void run() {
        if (!is_initialized_) {
            initialize();
        }
        if (config_.dt <= 0.0 || config_.duration < 0.0) {
            throw std::runtime_error(
                "Simulator requires dt > 0 and duration >= 0 before run().");
        }

        LOG_INFO("Starting simulation: dt={}, duration={}", config_.dt, config_.duration);
        phase_manager_.transitionTo(ExecutionPhaseManager::Phase::Running);

        const int total_steps =
            static_cast<int>(std::llround(config_.duration / config_.dt));
        int executed_steps = 0;
        termination_reason_ = "completed";
        const auto wall_start = std::chrono::steady_clock::now();

        for (int step = 0; step <= total_steps; ++step) {
            current_time_ = step * config_.dt;
            publishCurrentState(step, current_time_);

            for (auto& callback : before_step_callbacks_) {
                callback(step, current_time_, config_.dt);
            }

            executeDiscretePhases(step);

            if (step > 0 || auto_logger_.shouldRecordInitialState()) {
                auto_logger_.recordStep(current_time_);
            }

            if (checkTerminationConditions(step, current_time_)) {
                executed_steps = step;
                break;
            }
            if (step == total_steps) {
                executed_steps = step;
                break;
            }

            integrateContinuousSystems();
            executed_steps = step + 1;
            current_time_ = executed_steps * config_.dt;

            for (auto& callback : after_step_callbacks_) {
                callback(step, current_time_, config_.dt);
            }
        }

        const auto wall_end = std::chrono::steady_clock::now();
        const double wall_seconds =
            std::chrono::duration<double>(wall_end - wall_start).count();
        auto_logger_.stop();

        if (!auto_logger_.getOutputDir().empty()) {
            SimulationSummary::SimInfo info;
            info.dt = config_.dt;
            info.duration = config_.duration;
            info.final_time = current_time_;
            info.total_steps = executed_steps;
            info.termination_reason = termination_reason_;
            info.wall_clock_seconds = wall_seconds;
            SimulationSummary::write(
                auto_logger_.getOutputDir(),
                info,
                registry_,
                auto_logger_,
                executionInfo());
        }

        phase_manager_.transitionTo(ExecutionPhaseManager::Phase::Finalizing);
        finalize();
        phase_manager_.transitionTo(ExecutionPhaseManager::Phase::Completed);
        LOG_INFO("Simulation completed. Final time: {}, reason: {}",
                 current_time_, termination_reason_);
    }

    void finalize() {
        LOG_INFO("Finalizing simulator...");
        for (auto* node : registry_.getAllNodes()) {
            node->finalize();
        }
    }

    double getCurrentTime() const { return current_time_; }

private:
    struct ExecutionEntry {
        SimulationNode* node = nullptr;
        IDiscreteTask* task = nullptr;
        NodeExecutionConfig config;
        int step_interval = 1;
        std::size_t registration_order = 0;
    };

    static constexpr std::array<DiscretePhase, 7> kOrderedPhases = {
        DiscretePhase::Environment,
        DiscretePhase::Perturbation,
        DiscretePhase::Input,
        DiscretePhase::Process,
        DiscretePhase::Output,
        DiscretePhase::Interaction,
        DiscretePhase::Evaluation};

    void bindDirectNode(SimulationNode& node, const AssemblyGraph& graph) {
        const AssemblyScope& scope = graph.scopeForNode(node.getName());
        AssemblyContext context(
            graph, scope.key, registry_, node.getName());
        node.bind(context);
        node.markDependenciesBoundInternal_();
    }

    int priorityFor(const SimulationNode* node) const {
        const auto* config = executionConfigFor(node);
        return config ? config->priority : 0;
    }

    void initializeNodesInOrder() {
        std::vector<SimulationNode*> nodes = registry_.getAllNodes();
        std::stable_partition(nodes.begin(), nodes.end(), [this](auto* node) {
            const auto* config = executionConfigFor(node);
            return config && config->phase == DiscretePhase::Perturbation;
        });

        for (auto* node : nodes) {
            LOG_INFO("Initializing node: {}", node->getName());
            node->initialize();
        }
    }

    std::vector<ExecutionEntry*> entriesFor(DiscretePhase phase) {
        std::vector<ExecutionEntry*> result;
        for (auto& entry : execution_entries_) {
            if (entry.task && entry.config.phase == phase) {
                result.push_back(&entry);
            }
        }
        std::stable_sort(result.begin(), result.end(), [](auto* lhs, auto* rhs) {
            if (lhs->config.priority != rhs->config.priority) {
                return lhs->config.priority < rhs->config.priority;
            }
            return lhs->registration_order < rhs->registration_order;
        });
        return result;
    }

    void executeDiscretePhases(int step_index) {
        const StepContext context{
            current_time_, config_.dt, static_cast<std::uint64_t>(step_index)};
        for (const auto phase : kOrderedPhases) {
            for (auto* entry : entriesFor(phase)) {
                if (step_index % entry->step_interval != 0) {
                    continue;
                }
                entry->node->clearDebugSnapshotInternal_();
                entry->task->update(context);
            }
        }
    }

    void integrateContinuousSystems() {
        if (!integrator_) {
            return;
        }

        struct PendingState {
            interfaces::IContinuousSystem* system = nullptr;
            Eigen::VectorXd state;
        };
        std::vector<PendingState> pending_states;

        for (auto* system : integration_systems_) {
            Eigen::VectorXd next_state = system->getState();
            integrator_->step(
                [system](double time,
                         const Eigen::VectorXd& state,
                         Eigen::VectorXd& derivative) {
                    system->computeDerivatives(time, state, derivative);
                },
                current_time_,
                next_state,
                config_.dt);
            pending_states.push_back({system, std::move(next_state)});
        }

        for (auto& pending : pending_states) {
            pending.system->setState(pending.state);
        }
    }

    void buildContinuousPlan() {
        integration_systems_.clear();
        const auto systems = registry_.getAll<interfaces::IContinuousSystem>();
        const auto groups = registry_.getAll<interfaces::IContinuousGroup>();
        const std::unordered_set<interfaces::IContinuousSystem*> registered(
            systems.begin(), systems.end());
        std::unordered_set<interfaces::IContinuousSystem*> grouped_members;

        for (auto* group : groups) {
            const auto* group_node = dynamic_cast<const SimulationNode*>(group);
            const std::string group_name =
                group_node ? group_node->getName() : std::string("<unnamed>");
            const auto members = group->members();
            if (members.empty()) {
                throw std::runtime_error(
                    "Continuous group '" + group_name + "' has no members.");
            }
            for (auto* member : members) {
                if (!member) {
                    throw std::runtime_error(
                        "Continuous group '" + group_name +
                        "' contains a null member.");
                }
                if (member == static_cast<interfaces::IContinuousSystem*>(group)) {
                    throw std::runtime_error(
                        "Continuous group '" + group_name +
                        "' cannot contain itself.");
                }
                if (dynamic_cast<interfaces::IContinuousGroup*>(member)) {
                    throw std::runtime_error(
                        "Continuous group '" + group_name +
                        "' cannot contain another continuous group.");
                }
                if (registered.count(member) == 0) {
                    throw std::runtime_error(
                        "Continuous group '" + group_name +
                        "' references a member that is not registered as a node.");
                }
                if (!grouped_members.insert(member).second) {
                    throw std::runtime_error(
                        "A continuous system belongs to more than one continuous group.");
                }
            }
        }

        for (auto* system : systems) {
            if (grouped_members.count(system) == 0) {
                integration_systems_.push_back(system);
            }
        }
    }

    void publishCurrentState(int step_index, double time) {
        struct Publisher {
            SimulationNode* node = nullptr;
            IPublishTask* task = nullptr;
            std::size_t order = 0;
        };
        std::vector<Publisher> publishers;
        const auto nodes = registry_.getAllNodes();
        for (std::size_t i = 0; i < nodes.size(); ++i) {
            if (auto* task = dynamic_cast<IPublishTask*>(nodes[i])) {
                publishers.push_back({nodes[i], task, i});
            }
        }
        std::stable_sort(publishers.begin(), publishers.end(), [this](auto& lhs, auto& rhs) {
            const int lhs_phase = static_cast<int>(lhs.task->publishPhase());
            const int rhs_phase = static_cast<int>(rhs.task->publishPhase());
            if (lhs_phase != rhs_phase) {
                return lhs_phase < rhs_phase;
            }
            const int lhs_priority = priorityFor(lhs.node);
            const int rhs_priority = priorityFor(rhs.node);
            if (lhs_priority != rhs_priority) {
                return lhs_priority < rhs_priority;
            }
            return lhs.order < rhs.order;
        });

        const PublishContext context{time, static_cast<std::uint64_t>(step_index)};
        for (const auto& publisher : publishers) {
            publisher.task->publish(context);
        }
    }

    bool checkTerminationConditions(int step_index, double time) {
        struct EvaluatorEntry {
            SimulationNode* node = nullptr;
            interfaces::ITerminationEvaluator* evaluator = nullptr;
            std::size_t order = 0;
        };
        std::vector<EvaluatorEntry> evaluators;
        const auto nodes = registry_.getAllNodes();
        for (std::size_t i = 0; i < nodes.size(); ++i) {
            if (auto* evaluator =
                    dynamic_cast<interfaces::ITerminationEvaluator*>(nodes[i])) {
                evaluators.push_back({nodes[i], evaluator, i});
            }
        }
        std::stable_sort(
            evaluators.begin(), evaluators.end(), [this](const auto& lhs, const auto& rhs) {
                const int lhs_priority = priorityFor(lhs.node);
                const int rhs_priority = priorityFor(rhs.node);
                if (lhs_priority != rhs_priority) {
                    return lhs_priority < rhs_priority;
                }
                return lhs.order < rhs.order;
            });

        for (const auto& entry : evaluators) {
            auto* evaluator = entry.evaluator;
            if (!evaluator || !evaluator->shouldTerminate()) {
                continue;
            }
            termination_reason_ = evaluator->reason();
            if (termination_reason_.empty()) {
                termination_reason_ = entry.node->getName();
            }
            LOG_INFO("Simulation terminated early by condition '{}' at t={} s, step={}",
                     termination_reason_, time, step_index);
            return true;
        }
        return false;
    }

    void computeStepInterval(ExecutionEntry& entry) const {
        entry.step_interval = 1;
        if (!entry.task || entry.config.rate_hz <= 0.0 || config_.dt <= 0.0) {
            return;
        }

        const double simulation_rate_hz = 1.0 / config_.dt;
        if (entry.config.rate_hz > simulation_rate_hz) {
            throw std::runtime_error(
                "Node '" + entry.node->getName() +
                "' rate_hz exceeds the simulation rate.");
        }

        const double raw_interval = simulation_rate_hz / entry.config.rate_hz;
        const double rounded_interval = std::round(raw_interval);
        const double tolerance =
            1.0e-9 * std::max(1.0, std::abs(raw_interval));
        if (rounded_interval < 1.0 ||
            std::abs(raw_interval - rounded_interval) > tolerance) {
            throw std::runtime_error(
                "Node '" + entry.node->getName() +
                "' rate_hz must form an integer simulation-step interval.");
        }
        entry.step_interval = static_cast<int>(rounded_interval);
    }

    void computeStepIntervals() {
        for (auto& entry : execution_entries_) {
            computeStepInterval(entry);
        }
    }

    NodeRegistry registry_;
    SimulatorConfig config_;
    AutoDataLogger auto_logger_;
    std::unique_ptr<interfaces::IIntegrator> integrator_;
    std::vector<interfaces::IContinuousSystem*> integration_systems_;
    ExecutionPhaseManager phase_manager_;
    std::vector<StepCallback> before_step_callbacks_;
    std::vector<StepCallback> after_step_callbacks_;
    std::vector<ExecutionEntry> execution_entries_;
    std::unordered_map<SimulationNode*, std::size_t> entry_by_node_;
    std::string termination_reason_ = "completed";
    double current_time_ = 0.0;
    bool is_initialized_ = false;
};

} // namespace gnc::core
