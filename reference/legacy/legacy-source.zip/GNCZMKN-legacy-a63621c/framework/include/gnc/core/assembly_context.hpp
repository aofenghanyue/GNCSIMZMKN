#pragma once

#include "gnc/common/string_utils.hpp"
#include "gnc/core/assembly_graph.hpp"
#include "gnc/core/node_registry.hpp"

#include <stdexcept>
#include <string>
#include <typeindex>
#include <utility>
#include <vector>

namespace gnc::core {

class AssemblyContext;

template<typename Interface>
struct DependencyBinding {
    Interface*& slot;
    std::string lookup_name;
    void apply(const AssemblyContext& context) const;
};

template<typename Interface>
struct OptionalDependencyBinding {
    Interface*& slot;
    std::string lookup_name;
    void apply(const AssemblyContext& context) const;
};

template<typename Interface>
DependencyBinding<Interface> bind(Interface*& slot, std::string lookup_name) {
    return {slot, std::move(lookup_name)};
}

template<typename Interface>
OptionalDependencyBinding<Interface> bindIfPresent(Interface*& slot,
                                                   std::string lookup_name) {
    return {slot, std::move(lookup_name)};
}

class AssemblyContext {
public:
    struct BindingDiagnostics {
        std::vector<std::string> errors;
        std::vector<std::string> warnings;
    };

    AssemblyContext(const AssemblyGraph& graph,
                    std::string scope_key,
                    NodeRegistry& registry,
                    std::string requester_name = {},
                    BindingDiagnostics* diagnostics = nullptr)
        : graph_(graph),
          scope_key_(std::move(scope_key)),
          registry_(registry),
          requester_name_(std::move(requester_name)),
          diagnostics_(diagnostics) {}

    template<typename Interface>
    Interface* tryGetByName(const std::string& name) const {
        return registry_.get<Interface>(resolveName(name));
    }

    template<typename Interface>
    Interface* requireByName(const std::string& name) const {
        auto* result = tryGetByName<Interface>(name);
        if (result) {
            return result;
        }
        const std::string message = buildLookupFailureMessage<Interface>(name);
        if (diagnostics_) {
            diagnostics_->errors.push_back(message);
            return nullptr;
        }
        throw std::runtime_error(message);
    }

    template<typename Interface>
    std::vector<Interface*> getAllInScope() const {
        std::vector<Interface*> result;
        for (const auto& name : graph_.nodesInScope(scope_key_)) {
            auto* node = registry_.get<SimulationNode>(name);
            if (!node) {
                continue;
            }
            if (auto* provider = dynamic_cast<Interface*>(node)) {
                result.push_back(provider);
            }
        }
        return result;
    }

    template<typename... Bindings>
    void bindAll(const Bindings&... bindings) const {
        (bindings.apply(*this), ...);
    }

    const AssemblyScope& scope() const { return graph_.scope(scope_key_); }
    const AssemblyGraph& graph() const { return graph_; }
    NodeRegistry& registry() { return registry_; }
    const NodeRegistry& registry() const { return registry_; }

    std::string resolveName(const std::string& name) const {
        return graph_.resolveName(scope_key_, name);
    }

private:
    static std::string joinStrings(const std::vector<std::string>& values) {
        std::string result;
        for (size_t i = 0; i < values.size(); ++i) {
            if (i > 0) {
                result += ", ";
            }
            result += values[i];
        }
        return result.empty() ? "(none)" : result;
    }

    std::vector<std::string> getScopedNodeNames() const {
        return graph_.nodesInScope(scope_key_);
    }

    template<typename Interface>
    std::vector<std::string> getScopedProviders() const {
        std::vector<std::string> result;
        for (const auto& name : registry_.getNodesForInterface(
                 std::type_index(typeid(Interface)))) {
            if (graph_.nodeBelongsTo(name, scope_key_) &&
                name != requester_name_) {
                result.push_back(name);
            }
        }
        return result;
    }

    template<typename Interface>
    std::string buildLookupFailureMessage(const std::string& name) const {
        const std::string resolved_name = resolveName(name);
        std::string message =
            "Required dependency lookup '" + name + "' resolved as '" +
            resolved_name + "' failed for interface '" +
            std::string(typeid(Interface).name()) + "'.";

        if (registry_.has(resolved_name)) {
            message += " A node with that name exists, but it does not implement "
                       "the requested interface.";
        } else {
            message += " No node with that name is registered.";
        }
        message += " Same-scope nodes: " + joinStrings(getScopedNodeNames()) + ".";
        message += " Same-scope providers for this interface: " +
                   joinStrings(getScopedProviders<Interface>()) + ".";
        message += " Scope lineage: " + graph_.describeLineage(scope_key_) + ".";
        const std::string suggestion =
            findClosestMatch(resolved_name, registry_.getNodeNames());
        if (!suggestion.empty()) {
            message += " Did you mean '" + suggestion + "'?";
        }
        return message;
    }

    const AssemblyGraph& graph_;
    std::string scope_key_;
    NodeRegistry& registry_;
    std::string requester_name_;
    BindingDiagnostics* diagnostics_ = nullptr;
};

template<typename Interface>
inline void DependencyBinding<Interface>::apply(
    const AssemblyContext& context) const {
    slot = context.requireByName<Interface>(lookup_name);
}

template<typename Interface>
inline void OptionalDependencyBinding<Interface>::apply(
    const AssemblyContext& context) const {
    slot = context.tryGetByName<Interface>(lookup_name);
}

} // namespace gnc::core
