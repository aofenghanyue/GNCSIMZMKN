#pragma once

#include "gnc/core/assembly_scope.hpp"
#include "gnc/core/node_factory.hpp"

#include <stdexcept>
#include <string>

namespace gnc::core {

enum class PlacementKind {
    MissionInfrastructure,
    MissionProcess,
    EnvironmentInfrastructure,
    EnvironmentModel,
    VehicleInfrastructure,
    Perturbation,
    Form,
    Asset,
    Input,
    VehicleProcess,
    Output,
    Interaction,
    MissionContinuousGroup,
    VehicleContinuousGroup,
    Termination,
    Summary
};

enum class RequiredCapability {
    None,
    PerturbationProvider,
    ContinuousGroup,
    TerminationEvaluator,
    SummaryObserver
};

struct PlacementPolicy {
    PlacementKind kind;
    const char* name;
    ScopeKind scope_kind;
    NodeRole role;
    DiscretePhase task_phase;
    bool constrain_task_phase;
    RequiredCapability required_capability;
    bool continuous_members_same_scope = false;
};

inline const PlacementPolicy& placementPolicy(PlacementKind kind) {
    static const PlacementPolicy mission_infrastructure{
        PlacementKind::MissionInfrastructure,
        "mission.infrastructure",
        ScopeKind::Mission,
        NodeRole::Infrastructure,
        DiscretePhase::None,
        false,
        RequiredCapability::None};
    static const PlacementPolicy mission_process{
        PlacementKind::MissionProcess,
        "mission.process",
        ScopeKind::Mission,
        NodeRole::Process,
        DiscretePhase::Process,
        true,
        RequiredCapability::None};
    static const PlacementPolicy environment_infrastructure{
        PlacementKind::EnvironmentInfrastructure,
        "environment.infrastructure",
        ScopeKind::Environment,
        NodeRole::Infrastructure,
        DiscretePhase::None,
        false,
        RequiredCapability::None};
    static const PlacementPolicy environment_model{
        PlacementKind::EnvironmentModel,
        "environment",
        ScopeKind::Environment,
        NodeRole::EnvironmentModel,
        DiscretePhase::Environment,
        true,
        RequiredCapability::None};
    static const PlacementPolicy vehicle_infrastructure{
        PlacementKind::VehicleInfrastructure,
        "vehicle.infrastructure",
        ScopeKind::Vehicle,
        NodeRole::Infrastructure,
        DiscretePhase::None,
        false,
        RequiredCapability::None};
    static const PlacementPolicy perturbation{
        PlacementKind::Perturbation,
        "perturbation",
        ScopeKind::Vehicle,
        NodeRole::Perturbation,
        DiscretePhase::Perturbation,
        true,
        RequiredCapability::PerturbationProvider};
    static const PlacementPolicy form{
        PlacementKind::Form,
        "form",
        ScopeKind::Vehicle,
        NodeRole::Form,
        DiscretePhase::None,
        true,
        RequiredCapability::None};
    static const PlacementPolicy asset{
        PlacementKind::Asset,
        "vehicle.common",
        ScopeKind::Vehicle,
        NodeRole::Asset,
        DiscretePhase::None,
        true,
        RequiredCapability::None};
    static const PlacementPolicy input{
        PlacementKind::Input,
        "vehicle.input",
        ScopeKind::Vehicle,
        NodeRole::Input,
        DiscretePhase::Input,
        true,
        RequiredCapability::None};
    static const PlacementPolicy vehicle_process{
        PlacementKind::VehicleProcess,
        "vehicle.process",
        ScopeKind::Vehicle,
        NodeRole::Process,
        DiscretePhase::Process,
        true,
        RequiredCapability::None};
    static const PlacementPolicy output{
        PlacementKind::Output,
        "vehicle.output",
        ScopeKind::Vehicle,
        NodeRole::Output,
        DiscretePhase::Output,
        true,
        RequiredCapability::None};
    static const PlacementPolicy interaction{
        PlacementKind::Interaction,
        "interaction",
        ScopeKind::Vehicle,
        NodeRole::Interaction,
        DiscretePhase::Interaction,
        true,
        RequiredCapability::None};
    static const PlacementPolicy mission_continuous_group{
        PlacementKind::MissionContinuousGroup,
        "mission.continuous_groups",
        ScopeKind::Mission,
        NodeRole::Coupling,
        DiscretePhase::None,
        true,
        RequiredCapability::ContinuousGroup};
    static const PlacementPolicy vehicle_continuous_group{
        PlacementKind::VehicleContinuousGroup,
        "vehicle.continuous_groups",
        ScopeKind::Vehicle,
        NodeRole::Coupling,
        DiscretePhase::None,
        true,
        RequiredCapability::ContinuousGroup,
        true};
    static const PlacementPolicy termination{
        PlacementKind::Termination,
        "termination",
        ScopeKind::Mission,
        NodeRole::Termination,
        DiscretePhase::Evaluation,
        true,
        RequiredCapability::TerminationEvaluator};
    static const PlacementPolicy summary{
        PlacementKind::Summary,
        "summary",
        ScopeKind::Mission,
        NodeRole::Summary,
        DiscretePhase::Evaluation,
        true,
        RequiredCapability::SummaryObserver};

    switch (kind) {
    case PlacementKind::MissionInfrastructure:
        return mission_infrastructure;
    case PlacementKind::MissionProcess:
        return mission_process;
    case PlacementKind::EnvironmentInfrastructure:
        return environment_infrastructure;
    case PlacementKind::EnvironmentModel:
        return environment_model;
    case PlacementKind::VehicleInfrastructure:
        return vehicle_infrastructure;
    case PlacementKind::Perturbation:
        return perturbation;
    case PlacementKind::Form:
        return form;
    case PlacementKind::Asset:
        return asset;
    case PlacementKind::Input:
        return input;
    case PlacementKind::VehicleProcess:
        return vehicle_process;
    case PlacementKind::Output:
        return output;
    case PlacementKind::Interaction:
        return interaction;
    case PlacementKind::MissionContinuousGroup:
        return mission_continuous_group;
    case PlacementKind::VehicleContinuousGroup:
        return vehicle_continuous_group;
    case PlacementKind::Termination:
        return termination;
    case PlacementKind::Summary:
        return summary;
    default:
        throw std::runtime_error("Unknown placement kind.");
    }
}

inline const char* toString(PlacementKind kind) {
    return placementPolicy(kind).name;
}

} // namespace gnc::core
