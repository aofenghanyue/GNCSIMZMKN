#pragma once

#include <cstdint>

namespace gnc::core {

struct StepContext {
    double time_s = 0.0;
    double dt_s = 0.0;
    std::uint64_t step = 0;
};

struct PublishContext {
    double time_s = 0.0;
    std::uint64_t step = 0;
};

enum class PublishPhase {
    StateOwner = 0,
    View = 1,
    Ordinary = 2
};

class IDiscreteTask {
public:
    virtual ~IDiscreteTask() = default;
    virtual void update(const StepContext& context) = 0;
};

class IPublishTask {
public:
    virtual ~IPublishTask() = default;
    virtual PublishPhase publishPhase() const { return PublishPhase::Ordinary; }
    virtual void publish(const PublishContext& context) = 0;
};

} // namespace gnc::core
