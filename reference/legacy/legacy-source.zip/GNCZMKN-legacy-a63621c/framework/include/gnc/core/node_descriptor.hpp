#pragma once

#include "gnc/core/node_factory.hpp"
#include "gnc/core/placement_policy.hpp"

#include <string>

namespace gnc::core {

struct NodeDescriptor {
    std::string name;
    std::string type_name;
    PlacementKind placement = PlacementKind::MissionInfrastructure;
    std::string scope_key = "mission";
    NodeRole role = NodeRole::Unknown;
    DiscretePhase discrete_phase = DiscretePhase::None;
    std::string form_family;
    std::string scope_id;
    std::string selected_form_family;
};

} // namespace gnc::core
