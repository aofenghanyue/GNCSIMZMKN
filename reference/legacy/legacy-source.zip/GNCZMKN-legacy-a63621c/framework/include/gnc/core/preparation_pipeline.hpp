#pragma once

#include "gnc/core/node_registry.hpp"
#include "gnc/core/preparation_context.hpp"

#include <exception>
#include <string>
#include <vector>

namespace gnc::core {

class PreparationPipeline {
public:
    struct Result {
        std::vector<std::string> errors;

        bool success() const { return errors.empty(); }
    };

    static Result run(NodeRegistry& registry,
                      const PreparationContext& context) {
        Result result;
        for (auto* component : registry.getAllNodes()) {
            try {
                component->prepare(context);
            } catch (const std::exception& e) {
                result.errors.push_back(
                    "Component '" + component->getName() + "' (type '" +
                    component->getTypeName() + "') failed preparation: " + e.what());
            } catch (...) {
                result.errors.push_back(
                    "Component '" + component->getName() + "' (type '" +
                    component->getTypeName() +
                    "') failed preparation with an unknown exception.");
            }
        }
        return result;
    }
};

} // namespace gnc::core
