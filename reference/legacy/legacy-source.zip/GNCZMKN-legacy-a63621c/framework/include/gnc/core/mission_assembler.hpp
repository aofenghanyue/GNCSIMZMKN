#pragma once

#include "gnc/common/string_utils.hpp"
#include "gnc/core/assembly_graph.hpp"
#include "gnc/core/config_manager.hpp"
#include "gnc/core/node_descriptor.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/simulation_node.hpp"
#include "gnc/core/simulator.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <exception>
#include <functional>
#include <initializer_list>
#include <limits>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace gnc::core {

struct EntityInstance {
    std::string id;
    std::string scope_key;
    std::vector<SimulationNode*> nodes;
};

struct VehicleInstance : EntityInstance {};
struct EnvironmentInstance : EntityInstance {};

/** Assemble mission configuration into the one unified node model. */
class MissionAssembler {
public:
    using DiagnosticReporter = std::function<void(const std::string&)>;

    MissionAssembler(Simulator& simulator,
                     NodeFactory& factory,
                     EnvironmentInstance& environment,
                     std::vector<VehicleInstance>& vehicles,
                     double simulation_dt,
                     DiagnosticReporter add_error,
                     DiagnosticReporter add_warning)
        : simulator_(simulator),
          factory_(factory),
          environment_(environment),
          vehicles_(vehicles),
          simulation_dt_(simulation_dt),
          add_error_(std::move(add_error)),
          add_warning_(std::move(add_warning)) {}

    void reset() {
        assembly_graph_.reset();
        mission_nodes_.clear();
        environment_ = EnvironmentInstance{};
        vehicles_.clear();
        selected_form_family_by_scope_.clear();
        node_descriptors_.clear();
    }

    void buildMission(const ConfigNode& root) {
        validateAllowedKeys(
            root,
            "mission",
            {"simulation", "infrastructure", "process", "continuous_groups",
             "environment", "vehicles", "outputs", "termination", "summary",
             "global_services", "stop_conditions"});
        rejectRemovedServiceSchema(root);
        buildMissionInfrastructure(root["infrastructure"]);
        buildMissionProcess(root["process"]);
        buildEnvironment(root["environment"]);
        buildVehicles(root["vehicles"]);
        synchronizeSelectedFormFamilies();
        buildMissionContinuousGroups(root["continuous_groups"]);
        buildTermination(root["termination"]);
        buildSummary(root["summary"]);
    }

    const std::vector<NodeDescriptor>& getNodeDescriptors() const {
        return node_descriptors_;
    }

    const AssemblyGraph& getAssemblyGraph() const { return assembly_graph_; }

private:
    struct PlacementSpec {
        std::string context;
        PlacementKind kind = PlacementKind::MissionInfrastructure;
        std::string scope_key = "mission";
        std::vector<SimulationNode*>* owner_nodes = nullptr;
    };

    struct SchedulingResult {
        bool valid = true;
        NodeExecutionConfig execution;
    };

    static std::string joinStrings(const std::vector<std::string>& values) {
        std::string result;
        for (std::size_t i = 0; i < values.size(); ++i) {
            if (i > 0) {
                result += ", ";
            }
            result += values[i];
        }
        return result.empty() ? "(none)" : result;
    }

    void validateAllowedKeys(
        const ConfigNode& config,
        const std::string& path,
        std::initializer_list<const char*> allowed_keys) {
        if (!config.isObject()) {
            return;
        }
        std::unordered_set<std::string> allowed;
        for (const auto* key : allowed_keys) {
            allowed.insert(key);
        }
        std::vector<std::string> unknown;
        for (const auto& [key, _] : config) {
            if (!key.empty() && key.front() == '_') {
                continue;
            }
            if (allowed.count(key) == 0) {
                unknown.push_back(key);
            }
        }
        if (unknown.empty()) {
            return;
        }
        std::sort(unknown.begin(), unknown.end());
        add_error_(path + " has unrecognized key" +
                   std::string(unknown.size() == 1 ? "" : "s") + ": " +
                   joinStrings(unknown) + ".");
    }

    static bool isValidVehicleId(const std::string& id) {
        if (id.empty() || id == "env" || id == "mission") {
            return false;
        }
        const auto valid_first = [](unsigned char ch) {
            return std::isalpha(ch) || ch == '_';
        };
        const auto valid_rest = [](unsigned char ch) {
            return std::isalnum(ch) || ch == '_' || ch == '-';
        };
        if (!valid_first(static_cast<unsigned char>(id.front()))) {
            return false;
        }
        return std::all_of(id.begin() + 1, id.end(), [&](char ch) {
            return valid_rest(static_cast<unsigned char>(ch));
        });
    }

    static void annotateNodeMetadata(SimulationNode& node,
                                     const std::string& type_name,
                                     const NodeFactory& factory) {
        node.setTypeNameInternal_(type_name);
        node.setNodeCategoryInternal_(toString(factory.getCategory(type_name)));
        node.setRegistrationOriginInternal_(factory.getRegistrationOrigin(type_name));
    }

    std::string unknownTypeMessage(const std::string& type_name,
                                   const std::string& node_name,
                                   const std::string& context) const {
        std::string message = "Unknown node type: '" + type_name +
                              "' (node name: '" + node_name + "') in " +
                              context + ". Available registered types: " +
                              factory_.describeRegisteredTypes();
        const std::string suggestion =
            common::findClosestMatch(type_name, factory_.getRegisteredTypes());
        if (!suggestion.empty()) {
            message += ". Did you mean '" + suggestion + "'?";
        }
        return message;
    }

    void rejectRemovedServiceSchema(const ConfigNode& root) {
        if (!root["global_services"].isNull()) {
            add_error_(
                "Top-level 'global_services' was removed. Declare ordinary nodes "
                "under top-level 'infrastructure'.");
        }
    }

    void buildMissionInfrastructure(const ConfigNode& config) {
        registerNodes(config,
                      {"infrastructure", PlacementKind::MissionInfrastructure,
                       assembly_graph_.missionScope().key,
                       &mission_nodes_});
    }

    void buildMissionProcess(const ConfigNode& config) {
        registerNodes(config,
                      {"process", PlacementKind::MissionProcess,
                       assembly_graph_.missionScope().key,
                       &mission_nodes_});
    }

    void buildMissionContinuousGroups(const ConfigNode& config) {
        registerNodes(config,
                      {"continuous_groups",
                       PlacementKind::MissionContinuousGroup,
                       assembly_graph_.missionScope().key,
                       &mission_nodes_});
    }

    void buildEnvironment(const ConfigNode& config) {
        if (config.isNull()) {
            return;
        }
        if (!config.isObject()) {
            add_error_("Top-level 'environment' must be an object.");
            return;
        }
        validateAllowedKeys(
            config, "environment", {"infrastructure", "components", "services"});
        if (!config["services"].isNull()) {
            add_error_(
                "'environment.services' was removed. Use "
                "'environment.infrastructure' with ordinary node entries.");
        }

        environment_.id = "environment";
        environment_.scope_key =
            assembly_graph_.ensureEnvironmentScope().key;
        registerNodes(config["infrastructure"],
                      {"environment.infrastructure",
                       PlacementKind::EnvironmentInfrastructure,
                       environment_.scope_key,
                       &environment_.nodes});
        registerNodes(config["components"],
                      {"environment.components",
                       PlacementKind::EnvironmentModel,
                       environment_.scope_key,
                       &environment_.nodes});
    }

    void buildVehicles(const ConfigNode& config) {
        if (!config.isArray()) {
            add_error_("Top-level 'vehicles' must be an array.");
            return;
        }
        if (config.size() == 0) {
            add_error_("Top-level 'vehicles' must contain at least one vehicle.");
            return;
        }

        std::unordered_set<std::string> ids;
        for (std::size_t i = 0; i < config.size(); ++i) {
            const ConfigNode& vehicle_config = config[i];
            const std::string context = "vehicles[" + std::to_string(i) + "]";
            if (!vehicle_config.isObject()) {
                add_error_(context + " must be an object.");
                continue;
            }
            validateAllowedKeys(
                vehicle_config,
                context,
                {"id", "infrastructure", "services", "perturbation", "form",
                 "common", "input", "process", "output", "interaction",
                 "continuous_groups"});
            const std::string id = vehicle_config["id"].asString();
            if (!isValidVehicleId(id)) {
                add_error_(context +
                           " must define an id matching [A-Za-z_][A-Za-z0-9_-]* "
                           "and distinct from 'env' and 'mission'.");
                continue;
            }
            if (!ids.insert(id).second) {
                add_error_("Duplicate vehicle id '" + id + "'.");
                continue;
            }

            vehicles_.push_back(VehicleInstance{});
            VehicleInstance& vehicle = vehicles_.back();
            vehicle.id = id;
            vehicle.scope_key = assembly_graph_.ensureVehicleScope(id).key;
            buildVehicle(vehicle, vehicle_config, context);
        }
    }

    void buildVehicle(VehicleInstance& vehicle,
                      const ConfigNode& config,
                      const std::string& context) {
        if (!config["services"].isNull()) {
            add_error_(context +
                       ".services was removed. Use " + context +
                       ".infrastructure with ordinary node entries.");
        }
        registerNodes(config["infrastructure"],
                      {context + ".infrastructure",
                       PlacementKind::VehicleInfrastructure,
                       vehicle.scope_key,
                       &vehicle.nodes});
        buildPerturbation(vehicle, config["perturbation"], context + ".perturbation");
        buildForm(vehicle, config["form"], context + ".form");
        registerNodes(config["common"],
                      {context + ".common", PlacementKind::Asset,
                       vehicle.scope_key, &vehicle.nodes});
        registerNodes(config["input"],
                      {context + ".input", PlacementKind::Input,
                       vehicle.scope_key, &vehicle.nodes});
        registerNodes(config["process"],
                      {context + ".process", PlacementKind::VehicleProcess,
                       vehicle.scope_key, &vehicle.nodes});
        registerNodes(config["output"],
                      {context + ".output", PlacementKind::Output,
                       vehicle.scope_key, &vehicle.nodes});
        buildInteraction(vehicle, config["interaction"], context + ".interaction");
        registerNodes(config["continuous_groups"],
                      {context + ".continuous_groups",
                       PlacementKind::VehicleContinuousGroup,
                       vehicle.scope_key,
                       &vehicle.nodes});
    }

    void buildPerturbation(VehicleInstance& vehicle,
                           const ConfigNode& config,
                           const std::string& context) {
        if (config.isNull()) {
            return;
        }
        if (!config.isObject()) {
            add_error_("Block '" + context + "' must be an object.");
            return;
        }
        registerNode(config,
                     {context, PlacementKind::Perturbation,
                      vehicle.scope_key, &vehicle.nodes},
                     context);
    }

    void buildForm(VehicleInstance& vehicle,
                   const ConfigNode& config,
                   const std::string& context) {
        if (!config.isObject()) {
            add_error_("Mission configuration must define object '" + context + "'.");
            return;
        }
        validateAllowedKeys(config, context, {"family", "components"});
        const ConfigNode& family_node = config["family"];
        if (!family_node.isNull()) {
            if (!family_node.isString() || family_node.asString().empty()) {
                add_error_(context + ".family must be a non-empty string when provided.");
            } else {
                selected_form_family_by_scope_[vehicle.id] = family_node.asString();
            }
        }
        registerNodes(config["components"],
                      {context + ".components", PlacementKind::Form,
                       vehicle.scope_key, &vehicle.nodes});
    }

    void buildInteraction(VehicleInstance& vehicle,
                          const ConfigNode& config,
                          const std::string& context) {
        if (config.isNull()) {
            return;
        }
        if (!config.isObject()) {
            add_error_("Block '" + context + "' must be an object.");
            return;
        }
        validateAllowedKeys(config, context, {"components"});
        registerNodes(config["components"],
                      {context + ".components", PlacementKind::Interaction,
                       vehicle.scope_key, &vehicle.nodes});
    }

    void buildTermination(const ConfigNode& config) {
        if (config.isNull()) {
            return;
        }
        if (!config.isObject()) {
            add_error_("Top-level 'termination' must be an object.");
            return;
        }
        registerNode(config,
                     {"termination", PlacementKind::Termination,
                      assembly_graph_.missionScope().key, &mission_nodes_},
                     "termination");
    }

    void buildSummary(const ConfigNode& config) {
        if (config.isNull()) {
            return;
        }
        if (!config.isObject()) {
            add_error_("Top-level 'summary' must be an object.");
            return;
        }
        registerNode(config,
                     {"summary", PlacementKind::Summary,
                      assembly_graph_.missionScope().key, &mission_nodes_},
                     "summary");
    }

    std::string selectedFormFamilyForScope(const std::string& scope_id) const {
        const auto it = selected_form_family_by_scope_.find(scope_id);
        return it == selected_form_family_by_scope_.end() ? "" : it->second;
    }

    void observeFormFamily(const std::string& type_name,
                           const PlacementSpec& placement) {
        if (placement.kind != PlacementKind::Form) {
            return;
        }
        const std::string family = factory_.getFormFamily(type_name);
        if (family.empty()) {
            return;
        }
        const AssemblyScope& scope = assembly_graph_.scope(placement.scope_key);
        auto& selected = selected_form_family_by_scope_[scope.id];
        if (selected.empty()) {
            selected = family;
        }
    }

    void synchronizeSelectedFormFamilies() {
        for (auto& descriptor : node_descriptors_) {
            const AssemblyScope& scope = assembly_graph_.scope(descriptor.scope_key);
            if (scope.kind != ScopeKind::Vehicle) {
                continue;
            }
            descriptor.selected_form_family = selectedFormFamilyForScope(scope.id);
        }
    }

    SchedulingResult readScheduling(const SimulationNode& node,
                                    const ConfigNode& config,
                                    const std::string& path,
                                    DiscretePhase phase) {
        SchedulingResult result;
        result.execution.phase = phase;

        const ConfigNode& priority_node = config["priority"];
        if (!priority_node.isNull()) {
            if (!priority_node.isNumber()) {
                add_error_(path + ".priority must be an integer number.");
                result.valid = false;
            } else {
                const double value = priority_node.asDouble();
                if (!std::isfinite(value) || std::floor(value) != value ||
                    value < static_cast<double>(std::numeric_limits<int>::min()) ||
                    value > static_cast<double>(std::numeric_limits<int>::max())) {
                    add_error_(path + ".priority must be an integer number.");
                    result.valid = false;
                } else {
                    result.execution.priority = static_cast<int>(value);
                }
            }
        }

        const ConfigNode& rate_node = config["rate_hz"];
        if (rate_node.isNull()) {
            return result;
        }
        if (!dynamic_cast<const IDiscreteTask*>(&node)) {
            add_error_(path +
                       ".rate_hz is only valid for nodes implementing IDiscreteTask.");
            result.valid = false;
            return result;
        }
        if (!rate_node.isNumber()) {
            add_error_(path + ".rate_hz must be a positive number.");
            result.valid = false;
            return result;
        }
        const double rate = rate_node.asDouble();
        if (!validateRateHz(path, rate)) {
            result.valid = false;
            return result;
        }
        result.execution.rate_hz = rate;
        return result;
    }

    bool validateRateHz(const std::string& path, double rate_hz) {
        if (!std::isfinite(rate_hz) || rate_hz <= 0.0) {
            add_error_(path + ".rate_hz must be > 0.");
            return false;
        }
        if (simulation_dt_ <= 0.0) {
            add_error_(path +
                       ".rate_hz cannot be validated until simulation.dt is > 0.");
            return false;
        }
        const double simulation_rate = 1.0 / simulation_dt_;
        if (rate_hz > simulation_rate) {
            add_error_(path +
                       ".rate_hz must not exceed the simulation frequency.");
            return false;
        }
        const double interval = simulation_rate / rate_hz;
        const double rounded = std::round(interval);
        const double tolerance = 1.0e-9 * std::max(1.0, std::abs(interval));
        if (rounded < 1.0 || std::abs(interval - rounded) > tolerance) {
            add_error_(path +
                       ".rate_hz must form an integer simulation-step interval.");
            return false;
        }
        return true;
    }

    void checkUnusedConfigKeys(const std::string& full_name,
                               const std::string& type_name,
                               const ConfigNode& config) {
        const auto unused = config.getUnusedKeys();
        if (unused.empty()) {
            return;
        }
        const std::string message =
            "Node '" + full_name + "' (type: " + type_name +
            ") has unrecognized config keys: " + joinStrings(unused) + ".";
        if (factory_.getCategory(type_name) == NodeCategory::Builtin) {
            add_error_(message);
        } else {
            add_warning_(message);
        }
    }

    void registerNodes(const ConfigNode& nodes, const PlacementSpec& placement) {
        if (nodes.isNull()) {
            return;
        }
        if (!nodes.isArray()) {
            add_error_("Node block '" + placement.context + "' must be an array.");
            return;
        }
        for (std::size_t i = 0; i < nodes.size(); ++i) {
            registerNode(nodes[i],
                         placement,
                         placement.context + "[" + std::to_string(i) + "]");
        }
    }

    void registerNode(const ConfigNode& node_config,
                      const PlacementSpec& placement,
                      const std::string& path) {
        if (!node_config.isObject()) {
            add_error_("Node at " + path + " must be an object.");
            return;
        }
        validateAllowedKeys(
            node_config, path, {"type", "name", "priority", "rate_hz", "config"});
        const std::string type_name = node_config["type"].asString();
        const std::string base_name = node_config["name"].asString();
        const AssemblyScope& scope = assembly_graph_.scope(placement.scope_key);
        const std::string full_name = scope.registry_prefix + base_name;
        if (type_name.empty() || base_name.empty()) {
            add_error_("Node at " + path + " is missing type or name.");
            return;
        }
        if (!factory_.hasType(type_name)) {
            add_error_(unknownTypeMessage(type_name, full_name, placement.context));
            return;
        }
        if (simulator_.getRegistry().has(full_name)) {
            add_error_("Duplicate node name '" + full_name + "'.");
            return;
        }

        auto node = factory_.create(type_name);
        SimulationNode* node_ptr = node.get();
        annotateNodeMetadata(*node_ptr, type_name, factory_);
        observeFormFamily(type_name, placement);

        const DiscretePhase phase = factory_.getDiscretePhase(type_name);
        const SchedulingResult scheduling =
            readScheduling(*node_ptr, node_config, path, phase);
        if (!scheduling.valid) {
            return;
        }

        const ConfigNode& config = node_config["config"];
        const std::string config_path = path + ".config";
        config.resetAccessTracking();
        try {
            node_ptr->configure(config, config_path);
        } catch (const std::exception& e) {
            add_error_("Node '" + full_name + "' of type '" + type_name +
                       "' failed to configure at " + config_path + ": " + e.what());
            return;
        }
        checkUnusedConfigKeys(full_name, type_name, config);

        if (placement.owner_nodes) {
            placement.owner_nodes->push_back(node_ptr);
        }
        node_descriptors_.push_back(
            {full_name,
             type_name,
             placement.kind,
             placement.scope_key,
             factory_.getRole(type_name),
             phase,
             factory_.getFormFamily(type_name),
             scope.id,
             selectedFormFamilyForScope(scope.id)});

        simulator_.getRegistry().addDynamic(
            full_name, std::move(node), factory_.getInterfaces(type_name));
        assembly_graph_.assignNode(full_name, placement.scope_key);
        try {
            simulator_.addNodeExecution(node_ptr, scheduling.execution);
        } catch (const std::exception& e) {
            add_error_(e.what());
        }
    }

    Simulator& simulator_;
    NodeFactory& factory_;
    EnvironmentInstance& environment_;
    std::vector<VehicleInstance>& vehicles_;
    double simulation_dt_ = 0.0;
    DiagnosticReporter add_error_;
    DiagnosticReporter add_warning_;
    AssemblyGraph assembly_graph_;
    std::vector<SimulationNode*> mission_nodes_;
    std::unordered_map<std::string, std::string> selected_form_family_by_scope_;
    std::vector<NodeDescriptor> node_descriptors_;
};

} // namespace gnc::core
