#pragma once

#include <filesystem>
#include <stdexcept>
#include <string>
#include <system_error>
#include <utility>

namespace gnc::core {

/**
 * @brief Resolves configuration and asset paths relative to one mission file.
 *
 * The resolver is created by SimulationBuilder and passed to every component
 * during the preparation phase. This keeps project://, repo:// and
 * user-data:// semantics out of project-specific components.
 */
class AssetPathResolver {
public:
    explicit AssetPathResolver(std::filesystem::path anchor_file = {}) {
        std::error_code ec;
        if (anchor_file.empty()) {
            anchor_file = std::filesystem::current_path(ec) / "<memory-mission>";
        }
        anchor_file_ = std::filesystem::absolute(anchor_file, ec);
        if (ec) {
            anchor_file_ = std::move(anchor_file);
        }
        anchor_file_ = anchor_file_.lexically_normal();
        repo_root_ = findRepoRoot(anchor_file_);
        project_root_ = findProjectRoot(anchor_file_, repo_root_);
    }

    AssetPathResolver(std::filesystem::path anchor_file,
                      std::filesystem::path repo_root,
                      std::filesystem::path project_root)
        : anchor_file_(std::move(anchor_file)),
          repo_root_(std::move(repo_root)),
          project_root_(std::move(project_root)) {
        anchor_file_ = anchor_file_.lexically_normal();
        repo_root_ = repo_root_.lexically_normal();
        project_root_ = project_root_.lexically_normal();
    }

    static bool startsWith(const std::string& text, const std::string& prefix) {
        return text.rfind(prefix, 0) == 0;
    }

    static std::filesystem::path findRepoRoot(const std::filesystem::path& anchor) {
        std::error_code ec;
        std::filesystem::path current = anchor;
        if (!std::filesystem::is_directory(current, ec) || ec) {
            current = anchor.has_parent_path() ? anchor.parent_path()
                                               : std::filesystem::current_path(ec);
        }
        if (ec) {
            current = ".";
        }
        current = current.lexically_normal();
        while (!current.empty()) {
            ec.clear();
            const bool has_cmake =
                std::filesystem::exists(current / "CMakeLists.txt", ec) && !ec;
            ec.clear();
            const bool has_framework =
                std::filesystem::exists(current / "framework", ec) && !ec;
            if (has_cmake && has_framework) {
                return current;
            }
            const auto parent = current.parent_path();
            if (parent == current) {
                break;
            }
            current = parent;
        }
        ec.clear();
        return std::filesystem::current_path(ec).lexically_normal();
    }

    static std::filesystem::path findProjectRoot(
        const std::filesystem::path& file,
        const std::filesystem::path& repo_root) {
        std::error_code ec;
        const auto relative = std::filesystem::relative(file, repo_root, ec);
        if (ec) {
            return {};
        }
        auto it = relative.begin();
        if (it == relative.end() || it->generic_string() != "user") {
            return {};
        }
        ++it;
        if (it == relative.end()) {
            return {};
        }
        const auto project_name = it->generic_string();
        if (project_name.empty() || project_name == "data" ||
            project_name == "outputs") {
            return {};
        }
        const auto candidate = repo_root / "user" / project_name;
        ec.clear();
        if (!std::filesystem::is_directory(candidate, ec) || ec) {
            return {};
        }
        return candidate.lexically_normal();
    }

    std::filesystem::path resolve(const std::string& value) const {
        if (value.empty()) {
            throw std::runtime_error("Asset path must not be empty.");
        }

        const auto strip = [](const std::string& input,
                              const std::string& prefix) {
            return input.substr(prefix.size());
        };

        std::filesystem::path resolved;
        if (startsWith(value, "repo://")) {
            resolved = repo_root_ / strip(value, "repo://");
        } else if (startsWith(value, "project://")) {
            if (project_root_.empty()) {
                throw std::runtime_error(
                    "project:// path requires the mission file to be under "
                    "user/<project>.");
            }
            resolved = project_root_ / strip(value, "project://");
        } else if (startsWith(value, "user-data://")) {
            resolved = repo_root_ / "user" / "data" /
                       strip(value, "user-data://");
        } else {
            const std::filesystem::path requested(value);
            if (requested.is_absolute()) {
                resolved = requested;
            } else {
                std::error_code ec;
                if (std::filesystem::exists(requested, ec) && !ec) {
                    resolved = requested;
                } else if (!repo_root_.empty()) {
                    ec.clear();
                    const auto repo_candidate = repo_root_ / requested;
                    if (std::filesystem::exists(repo_candidate, ec) && !ec) {
                        resolved = repo_candidate;
                    } else {
                        resolved = anchor_file_.parent_path() / requested;
                    }
                } else {
                    resolved = anchor_file_.parent_path() / requested;
                }
            }
        }

        std::error_code ec;
        const auto absolute = std::filesystem::absolute(resolved, ec);
        if (!ec) {
            resolved = absolute;
        }
        return resolved.lexically_normal();
    }

    std::filesystem::path resolveUnder(const std::string& root,
                                       const std::string& child) const {
        const std::filesystem::path child_path(child);
        if (child_path.is_absolute() || startsWith(child, "repo://") ||
            startsWith(child, "project://") ||
            startsWith(child, "user-data://")) {
            return resolve(child);
        }
        return (resolve(root) / child_path).lexically_normal();
    }

    std::filesystem::path requireRegularFile(
        const std::string& value,
        const std::string& description = "Asset") const {
        return requireRegularPath(resolve(value), description);
    }

    std::filesystem::path requireRegularPath(
        const std::filesystem::path& path,
        const std::string& description = "Asset") const {
        std::error_code ec;
        if (!std::filesystem::is_regular_file(path, ec) || ec) {
            throw std::runtime_error(description + " file does not exist: " +
                                     path.generic_string());
        }
        return path;
    }

    std::string fingerprint(const std::filesystem::path& path) const {
        std::error_code ec;
        auto normalized = std::filesystem::weakly_canonical(path, ec);
        if (ec) {
            normalized = path.lexically_normal();
        }
        ec.clear();
        const auto size = std::filesystem::file_size(path, ec);
        if (ec) {
            throw std::runtime_error("Cannot read asset size: " +
                                     path.generic_string());
        }
        ec.clear();
        const auto write_time = std::filesystem::last_write_time(path, ec);
        if (ec) {
            throw std::runtime_error("Cannot read asset modification time: " +
                                     path.generic_string());
        }
        return normalized.generic_string() + "|" + std::to_string(size) + "|" +
               std::to_string(write_time.time_since_epoch().count());
    }

    const std::filesystem::path& anchorFile() const { return anchor_file_; }
    const std::filesystem::path& repoRoot() const { return repo_root_; }
    const std::filesystem::path& projectRoot() const { return project_root_; }

private:
    std::filesystem::path anchor_file_;
    std::filesystem::path repo_root_;
    std::filesystem::path project_root_;
};

class PreparationContext {
public:
    explicit PreparationContext(AssetPathResolver paths)
        : paths_(std::move(paths)) {}

    const AssetPathResolver& paths() const { return paths_; }

private:
    AssetPathResolver paths_;
};

} // namespace gnc::core
