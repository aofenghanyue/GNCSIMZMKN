#pragma once

#include "gnc/common/logger.hpp"
#include "gnc/core/config_manager.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/framework_catalog.hpp"
#include "gnc/core/mission_assembler.hpp"
#include "gnc/core/preparation_pipeline.hpp"
#include "gnc/core/simulator.hpp"
#include "gnc/core/validation_pipeline.hpp"

#include <algorithm>
#include <cmath>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

namespace gnc::core {

class SimulationBuilder {
public:
    explicit SimulationBuilder(FrameworkCatalog& catalog)
        : catalog_(catalog) {}

    SimulationBuilder(FrameworkCatalog& catalog,
                      std::unique_ptr<IConfigParser> parser)
        : config_(std::move(parser)), catalog_(catalog) {}

    bool loadConfig(const std::string& filename) {
        return config_.loadFromFile(filename);
    }

    bool loadConfigString(const std::string& text) {
        return config_.loadFromString(text);
    }

    Simulator& build() {
        build_errors_.clear();
        build_warnings_.clear();
        simulator_.resetAssemblyState();

        const ConfigNode& simulation = config_.simulation();
        simulation.resetAccessTracking();
        ConfigReader reader(simulation, "simulation");
        SimulatorConfig simulator_config;
        std::string integrator_name = "rk4";
        try {
            simulator_config.dt = reader.requiredDouble("dt");
            simulator_config.duration = reader.requiredDouble("duration");
            integrator_name = reader.optionalString("integrator", "rk4");
            validateSimulationConfig(simulator_config, reader);
        } catch (const std::exception& e) {
            addBuildError(e.what());
        }
        simulator_.configure(simulator_config);
        selectIntegrator(integrator_name);

        MissionAssembler assembler(
            simulator_,
            catalog_.nodes(),
            environment_,
            vehicles_,
            simulator_config.dt,
            [this](const std::string& message) { addBuildError(message); },
            [this](const std::string& message) { addBuildWarning(message); });
        assembler.reset();
        buildMissionArchitecture(assembler);

        const auto validation = ValidationPipeline::run(
            simulator_.getRegistry(),
            assembler.getAssemblyGraph(),
            assembler.getNodeDescriptors());
        for (const auto& error : validation.errors) {
            addBuildError(error);
        }
        for (const auto& warning : validation.warnings) {
            addBuildWarning(warning);
        }

        if (build_errors_.empty()) {
            const PreparationContext context(
                AssetPathResolver(config_.sourceFile()));
            const auto preparation =
                PreparationPipeline::run(simulator_.getRegistry(), context);
            for (const auto& error : preparation.errors) {
                addBuildError(error);
            }
        }

        if (build_errors_.empty()) {
            try {
                simulator_.validateExecutionPlan();
            } catch (const std::exception& e) {
                addBuildError(std::string("Invalid continuous execution plan: ") +
                              e.what());
            }
        }

        validateOutputsConfig(config_.outputs());
        if (build_errors_.empty() &&
            !simulator_.initializeAutoDataLogger(config_.outputs())) {
            addBuildError(
                "AutoDataLogger initialization failed during simulation build.");
        }

        if (!reportBuildDiagnostics()) {
            throw std::runtime_error("Simulation build failed with " +
                                     std::to_string(build_errors_.size()) +
                                     " error(s).");
        }

        logNodeInventory();
        return simulator_;
    }

    ConfigManager& getConfigManager() { return config_; }
    Simulator& getSimulator() { return simulator_; }
    EnvironmentInstance& getEnvironment() { return environment_; }
    std::vector<VehicleInstance>& getVehicles() { return vehicles_; }
    const std::vector<std::string>& getBuildErrors() const { return build_errors_; }
    const std::vector<std::string>& getBuildWarnings() const {
        return build_warnings_;
    }

private:
    static std::string joinStrings(const std::vector<std::string>& values) {
        std::string result;
        for (std::size_t i = 0; i < values.size(); ++i) {
            if (i > 0) result += ", ";
            result += values[i];
        }
        return result.empty() ? "(none)" : result;
    }

    void logNodeInventory() {
        std::vector<std::string> builtin_types;
        std::vector<std::string> project_types;
        for (const auto& name : simulator_.getRegistry().getNodeNames()) {
            auto* node = simulator_.getRegistry().get<SimulationNode>(name);
            if (!node) continue;
            (node->getNodeCategory() == "builtin" ? builtin_types : project_types)
                .push_back(node->getTypeName());
        }
        auto unique_join = [](std::vector<std::string> values) {
            std::sort(values.begin(), values.end());
            values.erase(std::unique(values.begin(), values.end()), values.end());
            return joinStrings(values);
        };
        LOG_INFO("Mission node inventory: builtin types [{}], project types [{}]",
                 unique_join(std::move(builtin_types)),
                 unique_join(std::move(project_types)));
    }

    void buildMissionArchitecture(MissionAssembler& assembler) {
        const ConfigNode& root = config_.root();
        if (root.has("stop_conditions") ||
            root["simulation"].has("stop_conditions")) {
            addBuildError(
                "Legacy 'stop_conditions[]' are no longer supported. Use the top-level "
                "'termination' node.");
        }
        if (config_.hasEntities()) {
            addBuildError(
                "Legacy top-level 'entities[]' missions are unsupported. Use "
                "the canonical top-level 'vehicles[]' layout.");
            return;
        }
        if (root.has("components") || root.has("services") || root.has("form") ||
            root.has("vehicle") || root.has("interaction")) {
            addBuildError(
                "Legacy root-level mission blocks are unsupported. Use the "
                "canonical top-level 'vehicles[]' layout.");
            return;
        }
        if (!config_.hasModernMissionLayout()) {
            addBuildError(
                "Mission configuration must define a top-level 'vehicles' array.");
            return;
        }
        assembler.buildMission(root);
    }

    void validateSimulationConfig(const SimulatorConfig& config,
                                  const ConfigReader& reader) {
        if (config.dt <= 0.0) {
            addBuildError("simulation.dt must be > 0.");
        }
        if (config.duration < 0.0) {
            addBuildError("simulation.duration must be >= 0.");
        }
        if (config.dt > 0.0 && config.duration >= 0.0) {
            const double steps = config.duration / config.dt;
            const double rounded = std::round(steps);
            const double tolerance = 1.0e-9 * std::max(1.0, std::abs(steps));
            if (std::abs(steps - rounded) > tolerance) {
                addBuildError(
                    "simulation.duration / simulation.dt must be an integer step count.");
            }
        }
        try {
            reader.validateNoUnknownKeys();
        } catch (const std::exception& e) {
            addBuildError(e.what());
        }
    }

    void selectIntegrator(const std::string& type_id) {
        try {
            simulator_.setIntegrator(catalog_.integrators().create(type_id));
        } catch (const std::exception&) {
            addBuildError("Unknown integrator '" + type_id +
                          "'. Registered integrators: " +
                          joinStrings(catalog_.integrators().listTypes()) + ".");
            simulator_.setIntegrator(nullptr);
        }
    }

    static bool isInteger(const ConfigNode& node) {
        return node.isNumber() && std::isfinite(node.asDouble()) &&
               std::floor(node.asDouble()) == node.asDouble();
    }

    void validateStringArray(const ConfigNode& node,
                             const std::string& path) {
        if (!node.isArray()) {
            addBuildError(path + " must be an array of non-empty strings.");
            return;
        }
        for (std::size_t i = 0; i < node.size(); ++i) {
            if (!node[i].isString() || node[i].asString().empty()) {
                addBuildError(path + "[" + std::to_string(i) +
                              "] must be a non-empty string.");
            }
        }
    }

    void validateOutputsConfig(const ConfigNode& outputs) {
        if (outputs.isNull()) return;
        if (!outputs.isObject()) {
            addBuildError("outputs must be an object.");
            return;
        }
        static const std::unordered_set<std::string> known = {
            "enabled", "directory", "format", "session_name", "precision",
            "flush_every_step", "record_initial_state", "record", "exclude",
            "debug_snapshots"};
        std::vector<std::string> unknown;
        for (const auto& [key, _] : outputs) {
            if (known.count(key) == 0) unknown.push_back("outputs." + key);
        }
        if (!unknown.empty()) {
            std::sort(unknown.begin(), unknown.end());
            addBuildError("Outputs configuration has unrecognized key(s): " +
                          joinStrings(unknown) + ".");
        }

        auto require_bool = [this, &outputs](const char* key) {
            if (outputs.has(key) && !outputs[key].isBool()) {
                addBuildError(std::string("outputs.") + key + " must be a boolean.");
            }
        };
        require_bool("enabled");
        require_bool("flush_every_step");
        require_bool("record_initial_state");

        for (const char* key : {"directory", "session_name"}) {
            if (outputs.has(key) &&
                (!outputs[key].isString() || outputs[key].asString().empty())) {
                addBuildError(std::string("outputs.") + key +
                              " must be a non-empty string.");
            }
        }
        if (outputs.has("format") &&
            (!outputs["format"].isString() ||
             outputs["format"].asString() != "csv")) {
            addBuildError("outputs.format must be the string 'csv'.");
        }
        if (outputs.has("precision") &&
            (!isInteger(outputs["precision"]) ||
             outputs["precision"].asDouble() < 1.0 ||
             outputs["precision"].asDouble() > 17.0)) {
            addBuildError("outputs.precision must be an integer from 1 to 17.");
        }

        if (outputs.has("record")) {
            const ConfigNode& record = outputs["record"];
            if (record.isString()) {
                if (record.asString() != "all") {
                    addBuildError("outputs.record string value must be 'all'.");
                }
            } else if (record.isArray()) {
                validateStringArray(record, "outputs.record");
            } else if (record.isObject()) {
                for (const auto& [component, selection] : record) {
                    const std::string path = "outputs.record." + component;
                    if (component.empty()) {
                        addBuildError("outputs.record component names must be non-empty.");
                    }
                    if (selection.isString()) {
                        if (selection.asString() != "all") {
                            addBuildError(path + " string value must be 'all'.");
                        }
                    } else if (selection.isArray()) {
                        validateStringArray(selection, path);
                    } else {
                        addBuildError(path +
                                      " must be 'all' or an array of field names.");
                    }
                }
            } else {
                addBuildError(
                    "outputs.record must be 'all', a component array, or an object.");
            }
        }
        if (outputs.has("exclude")) {
            validateStringArray(outputs["exclude"], "outputs.exclude");
        }

        if (!outputs.has("debug_snapshots")) return;
        const ConfigNode& debug = outputs["debug_snapshots"];
        if (debug.isBool()) return;
        if (!debug.isObject()) {
            addBuildError("outputs.debug_snapshots must be a boolean or object.");
            return;
        }
        static const std::unordered_set<std::string> debug_known = {
            "enabled", "components", "session_name", "precision",
            "flush_every_step"};
        std::vector<std::string> debug_unknown;
        for (const auto& [key, _] : debug) {
            if (debug_known.count(key) == 0) {
                debug_unknown.push_back("outputs.debug_snapshots." + key);
            }
        }
        if (!debug_unknown.empty()) {
            std::sort(debug_unknown.begin(), debug_unknown.end());
            addBuildError(
                "Debug snapshot configuration has unrecognized key(s): " +
                joinStrings(debug_unknown) + ".");
        }
        for (const char* key : {"enabled", "flush_every_step"}) {
            if (debug.has(key) && !debug[key].isBool()) {
                addBuildError(std::string("outputs.debug_snapshots.") + key +
                              " must be a boolean.");
            }
        }
        if (debug.has("session_name") &&
            (!debug["session_name"].isString() ||
             debug["session_name"].asString().empty())) {
            addBuildError(
                "outputs.debug_snapshots.session_name must be a non-empty string.");
        }
        if (debug.has("precision") &&
            (!isInteger(debug["precision"]) ||
             debug["precision"].asDouble() < 1.0 ||
             debug["precision"].asDouble() > 17.0)) {
            addBuildError(
                "outputs.debug_snapshots.precision must be an integer from 1 to 17.");
        }
        if (debug.has("components")) {
            const ConfigNode& components = debug["components"];
            if (components.isString()) {
                if (components.asString().empty()) {
                    addBuildError(
                        "outputs.debug_snapshots.components must not be empty.");
                }
            } else if (components.isArray()) {
                validateStringArray(
                    components, "outputs.debug_snapshots.components");
            } else {
                addBuildError(
                    "outputs.debug_snapshots.components must be a string or string array.");
            }
        }
    }

    void addBuildError(const std::string& message) {
        build_errors_.push_back(message);
    }
    void addBuildWarning(const std::string& message) {
        build_warnings_.push_back(message);
    }

    bool reportBuildDiagnostics() {
        if (build_errors_.empty() && build_warnings_.empty()) return true;
        std::ostringstream report;
        report << "\n=== Simulation Build Diagnostics ===\n";
        if (!build_errors_.empty()) {
            report << "[ERRORS] (" << build_errors_.size() << ")\n";
            for (std::size_t i = 0; i < build_errors_.size(); ++i) {
                report << "  " << (i + 1) << ". " << build_errors_[i] << "\n";
            }
        }
        if (!build_warnings_.empty()) {
            report << "[WARNINGS] (" << build_warnings_.size() << ")\n";
            for (std::size_t i = 0; i < build_warnings_.size(); ++i) {
                report << "  " << (i + 1) << ". " << build_warnings_[i] << "\n";
            }
        }
        report << "====================================";
        if (!build_errors_.empty()) {
            LOG_ERROR("{}", report.str());
            return false;
        }
        LOG_WARNING("{}", report.str());
        return true;
    }

    ConfigManager config_;
    FrameworkCatalog& catalog_;
    Simulator simulator_;
    EnvironmentInstance environment_;
    std::vector<VehicleInstance> vehicles_;
    std::vector<std::string> build_errors_;
    std::vector<std::string> build_warnings_;
};

} // namespace gnc::core
