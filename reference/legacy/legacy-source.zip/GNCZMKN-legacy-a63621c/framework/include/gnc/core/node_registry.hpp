#pragma once

#include "gnc/common/logger.hpp"
#include "gnc/core/simulation_node.hpp"

#include <memory>
#include <stdexcept>
#include <string>
#include <typeindex>
#include <unordered_map>
#include <vector>

namespace gnc::core {

class NodeRegistry {
public:
    NodeRegistry() = default;
    ~NodeRegistry() = default;

    NodeRegistry(const NodeRegistry&) = delete;
    NodeRegistry& operator=(const NodeRegistry&) = delete;

    template<typename T, typename... Interfaces>
    void add(const std::string& name, std::unique_ptr<T> node) {
        if (nodes_.count(name) > 0) {
            throw std::runtime_error("Node already registered: " + name);
        }

        T* raw_ptr = node.get();
        raw_ptr->setNameInternal_(name);
        nodes_[name] = std::move(node);
        registerInterfaces<T, Interfaces...>(name, raw_ptr);
        node_order_.push_back(name);
        LOG_INFO("Registered node: {}", name);
    }

    template<typename T>
    T* get(const std::string& name) const {
        const auto it = nodes_.find(name);
        if (it == nodes_.end()) {
            return nullptr;
        }
        return dynamic_cast<T*>(it->second.get());
    }

    template<typename Interface>
    std::vector<Interface*> getAll() const {
        std::vector<Interface*> result;
        result.reserve(node_order_.size());
        for (const auto& name : node_order_) {
            if (auto* casted = dynamic_cast<Interface*>(nodes_.at(name).get())) {
                result.push_back(casted);
            }
        }
        return result;
    }

    std::vector<SimulationNode*> getAllNodes() const {
        std::vector<SimulationNode*> result;
        result.reserve(node_order_.size());
        for (const auto& name : node_order_) {
            result.push_back(nodes_.at(name).get());
        }
        return result;
    }

    bool has(const std::string& name) const { return nodes_.count(name) > 0; }
    size_t size() const { return nodes_.size(); }

    void clear() {
        nodes_.clear();
        interface_map_.clear();
        node_order_.clear();
    }

    bool hasInterface(std::type_index type) const {
        const auto it = interface_map_.find(type);
        return it != interface_map_.end() && !it->second.empty();
    }

    std::vector<std::string> getNodesForInterface(std::type_index type) const {
        std::vector<std::string> result;
        const auto it = interface_map_.find(type);
        if (it == interface_map_.end()) {
            return result;
        }
        for (const auto& entry : it->second) {
            result.push_back(entry.name);
        }
        return result;
    }

    const std::vector<std::string>& getNodeNames() const { return node_order_; }

    void addDynamic(const std::string& name,
                    std::unique_ptr<SimulationNode> node,
                    const std::vector<std::type_index>& interfaces) {
        if (nodes_.count(name) > 0) {
            throw std::runtime_error("Node already registered: " + name);
        }

        SimulationNode* raw_ptr = node.get();
        raw_ptr->setNameInternal_(name);
        nodes_[name] = std::move(node);
        for (const auto& type : interfaces) {
            interface_map_[type].push_back({name, raw_ptr});
        }
        node_order_.push_back(name);
        LOG_INFO("Registered node: {}", name);
    }

private:
    struct InterfaceEntry {
        std::string name;
        SimulationNode* ptr = nullptr;
    };

    template<typename T>
    void registerInterfaces(const std::string&, T*) {}

    template<typename T, typename First, typename... Rest>
    void registerInterfaces(const std::string& name, T* ptr) {
        interface_map_[std::type_index(typeid(First))].push_back(
            {name, static_cast<SimulationNode*>(ptr)});
        registerInterfaces<T, Rest...>(name, ptr);
    }

    std::unordered_map<std::string, std::unique_ptr<SimulationNode>> nodes_;
    std::unordered_map<std::type_index, std::vector<InterfaceEntry>> interface_map_;
    std::vector<std::string> node_order_;
};

} // namespace gnc::core
