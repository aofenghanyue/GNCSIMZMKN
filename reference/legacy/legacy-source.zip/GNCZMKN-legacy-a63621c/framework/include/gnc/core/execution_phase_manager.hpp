#pragma once

#include "gnc/common/logger.hpp"

namespace gnc::core {

/** Tracks the coarse runtime lifecycle and reports invalid transitions. */
class ExecutionPhaseManager {
public:
    enum class Phase {
        NotStarted,
        Initializing,
        Running,
        Finalizing,
        Completed
    };

    Phase getCurrentPhase() const { return current_phase_; }

    void transitionTo(Phase phase) {
        if (!isValidTransition(current_phase_, phase)) {
            LOG_ERROR("Invalid phase transition: {} -> {}",
                      phaseToString(current_phase_),
                      phaseToString(phase));
            return;
        }

        LOG_INFO("Simulation phase: {} -> {}",
                 phaseToString(current_phase_),
                 phaseToString(phase));
        current_phase_ = phase;
    }

private:
    Phase current_phase_ = Phase::NotStarted;

    static bool isValidTransition(Phase from, Phase to) {
        switch (from) {
        case Phase::NotStarted:
            return to == Phase::Initializing;
        case Phase::Initializing:
            return to == Phase::Running;
        case Phase::Running:
            return to == Phase::Finalizing;
        case Phase::Finalizing:
            return to == Phase::Completed;
        case Phase::Completed:
            return to == Phase::NotStarted;
        default:
            return false;
        }
    }

    static const char* phaseToString(Phase phase) {
        switch (phase) {
        case Phase::NotStarted:
            return "NotStarted";
        case Phase::Initializing:
            return "Initializing";
        case Phase::Running:
            return "Running";
        case Phase::Finalizing:
            return "Finalizing";
        case Phase::Completed:
            return "Completed";
        default:
            return "Unknown";
        }
    }
};

} // namespace gnc::core
