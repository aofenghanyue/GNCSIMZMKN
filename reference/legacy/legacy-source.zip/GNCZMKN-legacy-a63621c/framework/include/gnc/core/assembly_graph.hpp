#pragma once

#include "gnc/core/assembly_scope.hpp"

#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace gnc::core {

/**
 * Authoritative ownership graph for one assembled simulation.
 *
 * Name visibility remains deliberately explicit: an unqualified lookup is
 * resolved only in the requester's scope. Parent links describe ownership and
 * support diagnostics; they do not create implicit upward lookup.
 */
class AssemblyGraph {
public:
    AssemblyGraph() { reset(); }

    void reset() {
        scopes_.clear();
        scope_order_.clear();
        node_scope_.clear();
        nodes_by_scope_.clear();
        addScope(AssemblyScope::mission());
    }

    const AssemblyScope& missionScope() const { return scope("mission"); }

    const AssemblyScope& ensureEnvironmentScope() {
        return addScope(AssemblyScope::environment());
    }

    const AssemblyScope& ensureVehicleScope(const std::string& vehicle_id) {
        return addScope(AssemblyScope::vehicle(vehicle_id));
    }

    const AssemblyScope& ensureDirectRootScope() {
        return addScope(AssemblyScope::directRoot());
    }

    bool hasScope(const std::string& key) const {
        return scopes_.count(key) > 0;
    }

    const AssemblyScope& scope(const std::string& key) const {
        const auto it = scopes_.find(key);
        if (it == scopes_.end()) {
            throw std::runtime_error("Unknown assembly scope '" + key + "'.");
        }
        return it->second;
    }

    const std::vector<std::string>& scopeOrder() const { return scope_order_; }

    void assignNode(const std::string& node_name, const std::string& scope_key) {
        (void)scope(scope_key);
        if (node_scope_.count(node_name) > 0) {
            throw std::runtime_error("Node already belongs to an assembly scope: " +
                                     node_name);
        }
        node_scope_[node_name] = scope_key;
        nodes_by_scope_[scope_key].push_back(node_name);
    }

    bool hasNode(const std::string& node_name) const {
        return node_scope_.count(node_name) > 0;
    }

    const AssemblyScope& scopeForNode(const std::string& node_name) const {
        const auto it = node_scope_.find(node_name);
        if (it == node_scope_.end()) {
            throw std::runtime_error("Node has no assembly scope: " + node_name);
        }
        return scope(it->second);
    }

    bool nodeBelongsTo(const std::string& node_name,
                       const std::string& scope_key) const {
        const auto it = node_scope_.find(node_name);
        return it != node_scope_.end() && it->second == scope_key;
    }

    const std::vector<std::string>& nodesInScope(
        const std::string& scope_key) const {
        static const std::vector<std::string> empty;
        const auto it = nodes_by_scope_.find(scope_key);
        return it == nodes_by_scope_.end() ? empty : it->second;
    }

    std::string resolveName(const std::string& scope_key,
                            const std::string& name) const {
        if (name.find('.') != std::string::npos) {
            return name;
        }
        return scope(scope_key).registry_prefix + name;
    }

    std::vector<std::string> lineage(const std::string& scope_key) const {
        std::vector<std::string> result;
        std::string current = scope_key;
        while (!current.empty()) {
            const auto& item = scope(current);
            result.push_back(item.key);
            current = item.parent_key;
        }
        return result;
    }

    std::string describeLineage(const std::string& scope_key) const {
        const auto values = lineage(scope_key);
        std::string result;
        for (auto it = values.rbegin(); it != values.rend(); ++it) {
            if (!result.empty()) {
                result += " -> ";
            }
            result += *it;
        }
        return result;
    }

    /** Build the same flat ownership graph used by direct Simulator tests. */
    static AssemblyGraph inferFromNodeNames(
        const std::vector<std::string>& node_names) {
        AssemblyGraph graph;
        for (const auto& name : node_names) {
            const auto dot = name.find('.');
            std::string scope_key;
            if (dot == std::string::npos) {
                scope_key = graph.ensureDirectRootScope().key;
            } else {
                const std::string prefix = name.substr(0, dot);
                if (prefix == "mission") {
                    scope_key = graph.missionScope().key;
                } else if (prefix == "env") {
                    scope_key = graph.ensureEnvironmentScope().key;
                } else {
                    scope_key = graph.ensureVehicleScope(prefix).key;
                }
            }
            graph.assignNode(name, scope_key);
        }
        return graph;
    }

private:
    const AssemblyScope& addScope(AssemblyScope value) {
        const auto existing = scopes_.find(value.key);
        if (existing != scopes_.end()) {
            if (existing->second.kind != value.kind ||
                existing->second.id != value.id ||
                existing->second.registry_prefix != value.registry_prefix ||
                existing->second.parent_key != value.parent_key) {
                throw std::runtime_error(
                    "Conflicting assembly scope definition for '" + value.key + "'.");
            }
            return existing->second;
        }
        const std::string key = value.key;
        scopes_.emplace(key, std::move(value));
        scope_order_.push_back(key);
        return scopes_.at(key);
    }

    std::unordered_map<std::string, AssemblyScope> scopes_;
    std::vector<std::string> scope_order_;
    std::unordered_map<std::string, std::string> node_scope_;
    std::unordered_map<std::string, std::vector<std::string>> nodes_by_scope_;
};

} // namespace gnc::core
