#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/common/logger.hpp"

#include <algorithm>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>
#include <string_view>
#include <type_traits>
#include <typeindex>
#include <unordered_map>
#include <vector>

namespace gnc::core {

enum class NodeCategory {
    Builtin,
    Project
};

enum class NodeRole {
    Unknown,
    Infrastructure,
    Asset,
    EnvironmentModel,
    Perturbation,
    Form,
    Input,
    Process,
    Output,
    Interaction,
    Coupling,
    Termination,
    Summary
};

enum class DiscretePhase {
    None,
    Environment,
    Perturbation,
    Input,
    Process,
    Output,
    Interaction,
    Evaluation
};

inline const char* toString(NodeCategory category) {
    switch (category) {
    case NodeCategory::Builtin:
        return "builtin";
    case NodeCategory::Project:
        return "project";
    default:
        return "unknown";
    }
}

inline const char* toString(NodeRole role) {
    switch (role) {
    case NodeRole::Unknown:
        return "unknown";
    case NodeRole::Infrastructure:
        return "infrastructure";
    case NodeRole::Asset:
        return "asset";
    case NodeRole::EnvironmentModel:
        return "environment_model";
    case NodeRole::Perturbation:
        return "perturbation";
    case NodeRole::Form:
        return "form";
    case NodeRole::Input:
        return "input";
    case NodeRole::Process:
        return "process";
    case NodeRole::Output:
        return "output";
    case NodeRole::Interaction:
        return "interaction";
    case NodeRole::Coupling:
        return "coupling";
    case NodeRole::Termination:
        return "termination";
    case NodeRole::Summary:
        return "summary";
    default:
        return "unknown";
    }
}

inline const char* toString(DiscretePhase phase) {
    switch (phase) {
    case DiscretePhase::None:
        return "none";
    case DiscretePhase::Environment:
        return "environment";
    case DiscretePhase::Perturbation:
        return "perturbation";
    case DiscretePhase::Input:
        return "input";
    case DiscretePhase::Process:
        return "process";
    case DiscretePhase::Output:
        return "output";
    case DiscretePhase::Interaction:
        return "interaction";
    case DiscretePhase::Evaluation:
        return "evaluation";
    default:
        return "none";
    }
}

inline std::string normalizeRegistrationOrigin(std::string path) {
    std::replace(path.begin(), path.end(), '\\', '/');
    return path;
}

inline void stripTypePrefix(std::string_view& value) {
    constexpr std::string_view class_prefix = "class ";
    constexpr std::string_view struct_prefix = "struct ";
    while (value.substr(0, class_prefix.size()) == class_prefix ||
           value.substr(0, struct_prefix.size()) == struct_prefix) {
        if (value.substr(0, class_prefix.size()) == class_prefix) {
            value.remove_prefix(class_prefix.size());
            continue;
        }
        value.remove_prefix(struct_prefix.size());
    }
}

template<typename T>
std::string readableTypeName() {
#if defined(__clang__) || defined(__GNUC__)
    std::string_view function = __PRETTY_FUNCTION__;
    constexpr std::string_view marker = "T = ";
    const auto start = function.find(marker);
    if (start == std::string_view::npos) {
        return typeid(T).name();
    }
    std::string_view value = function.substr(start + marker.size());
    const auto end = value.find_first_of(";]");
    if (end != std::string_view::npos) {
        value = value.substr(0, end);
    }
#elif defined(_MSC_VER)
    std::string_view function = __FUNCSIG__;
    constexpr std::string_view prefix = "readableTypeName<";
    const auto start = function.find(prefix);
    if (start == std::string_view::npos) {
        return typeid(T).name();
    }
    std::string_view value = function.substr(start + prefix.size());
    const auto end = value.find(">(void)");
    if (end != std::string_view::npos) {
        value = value.substr(0, end);
    }
#else
    return typeid(T).name();
#endif

    stripTypePrefix(value);
    const auto namespace_pos = value.rfind("::");
    if (namespace_pos != std::string_view::npos) {
        value.remove_prefix(namespace_pos + 2);
    }
    return std::string(value);
}

class NodeCreatorBase {
public:
    virtual ~NodeCreatorBase() = default;
    virtual std::unique_ptr<SimulationNode> create() const = 0;
    virtual std::vector<std::type_index> getInterfaces() const = 0;
    virtual std::vector<std::string> getInterfaceNames() const = 0;
};

template<typename T, typename... Interfaces>
class NodeCreator final : public NodeCreatorBase {
public:
    std::unique_ptr<SimulationNode> create() const override {
        return std::make_unique<T>();
    }

    std::vector<std::type_index> getInterfaces() const override {
        return {std::type_index(typeid(Interfaces))...};
    }

    std::vector<std::string> getInterfaceNames() const override {
        return {readableTypeName<Interfaces>()...};
    }
};

class NodeFactory {
public:
    struct RegisteredTypeInfo {
        std::string type_name;
        NodeCategory category = NodeCategory::Project;
        std::string registration_origin;
        NodeRole role = NodeRole::Unknown;
        DiscretePhase discrete_phase = DiscretePhase::None;
        std::string form_family;
        std::vector<std::type_index> interfaces;
        std::vector<std::string> interface_names;
    };

    NodeFactory() = default;

    template<typename T, typename... Interfaces>
    void registerType(const std::string& type_name,
                      NodeCategory category = NodeCategory::Project,
                      const std::string& registration_origin = "",
                      NodeRole role = NodeRole::Unknown,
                      DiscretePhase discrete_phase = DiscretePhase::None,
                      const std::string& form_family = "") {
        static_assert(std::is_base_of_v<SimulationNode, T>,
                      "Registered node types must derive from SimulationNode.");
        static_assert((std::is_base_of_v<Interfaces, T> && ...),
                      "Every advertised interface must be a base of the registered node type.");
        if (type_name.empty()) {
            throw std::runtime_error("Node type registration requires a non-empty id.");
        }
        if (creators_.count(type_name) > 0) {
            throw std::runtime_error("Node type already registered: " + type_name);
        }

        RegisteredTypeEntry entry;
        entry.creator = std::make_unique<NodeCreator<T, Interfaces...>>();
        entry.category = category;
        entry.registration_origin = normalizeRegistrationOrigin(registration_origin);
        entry.role = role;
        entry.discrete_phase = discrete_phase;
        entry.form_family = form_family;
        creators_[type_name] = std::move(entry);
        LOG_INFO("Factory registered {} type: {}", toString(category), type_name);
    }

    std::unique_ptr<SimulationNode> create(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            throw std::runtime_error(
                "Unknown node type: '" + type_name +
                "'. Available registered types: " + describeRegisteredTypes());
        }
        return it->second.creator->create();
    }

    std::vector<std::type_index> getInterfaces(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return {};
        }
        return it->second.creator->getInterfaces();
    }

    std::vector<std::string> getInterfaceNames(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return {};
        }
        return it->second.creator->getInterfaceNames();
    }

    bool hasType(const std::string& type_name) const {
        return creators_.count(type_name) > 0;
    }

    std::vector<std::string> getRegisteredTypes() const {
        std::vector<std::string> types;
        const auto infos = getRegisteredTypeInfos();
        types.reserve(infos.size());
        for (const auto& info : infos) {
            types.push_back(info.type_name);
        }
        return types;
    }

    std::vector<RegisteredTypeInfo> getRegisteredTypeInfos() const {
        std::vector<RegisteredTypeInfo> infos;
        infos.reserve(creators_.size());

        for (const auto& [name, entry] : creators_) {
            RegisteredTypeInfo info;
            info.type_name = name;
            info.category = entry.category;
            info.registration_origin = entry.registration_origin;
            info.role = entry.role;
            info.discrete_phase = entry.discrete_phase;
            info.form_family = entry.form_family;
            info.interfaces = entry.creator->getInterfaces();
            info.interface_names = entry.creator->getInterfaceNames();
            std::sort(info.interface_names.begin(), info.interface_names.end());
            infos.push_back(std::move(info));
        }

        std::sort(infos.begin(),
                  infos.end(),
                  [](const RegisteredTypeInfo& lhs, const RegisteredTypeInfo& rhs) {
                      if (lhs.category != rhs.category) {
                          return lhs.category < rhs.category;
                      }
                      return lhs.type_name < rhs.type_name;
                  });
        return infos;
    }

    std::string describeRegisteredTypes() const {
        const auto infos = getRegisteredTypeInfos();
        std::vector<std::string> builtin_types;
        std::vector<std::string> project_types;

        for (const auto& info : infos) {
            if (info.category == NodeCategory::Builtin) {
                builtin_types.push_back(info.type_name);
            } else {
                project_types.push_back(info.type_name);
            }
        }

        auto join = [](const std::vector<std::string>& values) {
            std::string result;
            for (size_t i = 0; i < values.size(); ++i) {
                if (i > 0) {
                    result += ", ";
                }
                result += values[i];
            }
            return result.empty() ? "(none)" : result;
        };

        return "builtin=[" + join(builtin_types) + "], project=[" +
               join(project_types) + "]";
    }

    NodeCategory getCategory(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return NodeCategory::Project;
        }
        return it->second.category;
    }

    std::string getRegistrationOrigin(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return "";
        }
        return it->second.registration_origin;
    }

    NodeRole getRole(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return NodeRole::Unknown;
        }
        return it->second.role;
    }

    DiscretePhase getDiscretePhase(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return DiscretePhase::None;
        }
        return it->second.discrete_phase;
    }

    std::string getFormFamily(const std::string& type_name) const {
        const auto it = creators_.find(type_name);
        if (it == creators_.end()) {
            return "";
        }
        return it->second.form_family;
    }

private:
    struct RegisteredTypeEntry {
        std::unique_ptr<NodeCreatorBase> creator;
        NodeCategory category = NodeCategory::Project;
        std::string registration_origin;
        NodeRole role = NodeRole::Unknown;
        DiscretePhase discrete_phase = DiscretePhase::None;
        std::string form_family;
    };

    std::unordered_map<std::string, RegisteredTypeEntry> creators_;
};

#ifdef GNC_NODE_REGISTRATION_FN
#define GNC_REGISTER_NODE_TYPE_IMPL(TypeId, \
                                         ComponentType, \
                                         Category, \
                                         Role, \
                                         DiscretePhase, \
                                         FormFamily, \
                                         ...) \
    inline void GNC_NODE_REGISTRATION_FN(::gnc::core::NodeFactory& factory) { \
        factory.registerType<ComponentType, __VA_ARGS__>( \
            TypeId, \
            Category, \
            __FILE__, \
            Role, \
            DiscretePhase, \
            FormFamily); \
    }
#else
#define GNC_REGISTER_NODE_TYPE_IMPL(TypeId, \
                                         ComponentType, \
                                         Category, \
                                         Role, \
                                         DiscretePhase, \
                                         FormFamily, \
                                         ...) \
    static_assert(false, \
                  "GNC_REGISTER_NODE_TYPE requires GNC_NODE_REGISTRATION_FN " \
                  "to be defined by the build-generated explicit registration chain, " \
                  "and project registrations must declare role, discrete phase, " \
                  "and form family metadata.")
#endif

#define GNC_REGISTER_NODE_TYPE(TypeId, \
                                    ComponentType, \
                                    Role, \
                                    DiscretePhase, \
                                    FormFamily, \
                                    ...) \
    GNC_REGISTER_NODE_TYPE_IMPL(TypeId, \
                                     ComponentType, \
                                     ::gnc::core::NodeCategory::Project, \
                                     Role, \
                                     DiscretePhase, \
                                     FormFamily, \
                                     __VA_ARGS__)

#define GNC_REGISTER_BUILTIN_NODE(TypeId, \
                                       ComponentType, \
                                       Role, \
                                       DiscretePhase, \
                                       FormFamily, \
                                       ...) \
    GNC_REGISTER_NODE_TYPE_IMPL(TypeId, \
                                     ComponentType, \
                                     ::gnc::core::NodeCategory::Builtin, \
                                     Role, \
                                     DiscretePhase, \
                                     FormFamily, \
                                     __VA_ARGS__)

} // namespace gnc::core
