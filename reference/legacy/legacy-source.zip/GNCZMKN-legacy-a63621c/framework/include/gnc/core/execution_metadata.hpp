#pragma once

#include "gnc/core/node_factory.hpp"

namespace gnc::core {

/** User-configured scheduling metadata attached to one assembled node. */
struct NodeExecutionConfig {
    DiscretePhase phase = DiscretePhase::None;
    int priority = 0;
    double rate_hz = 0.0;
};

/** Effective scheduling information after the simulator resolves rate_hz. */
struct NodeExecutionInfo {
    NodeExecutionConfig configured;
    int step_interval = 1;
    bool is_discrete = false;
};

} // namespace gnc::core
