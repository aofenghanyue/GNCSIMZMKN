#pragma once

#include "gnc/core/assembly_context.hpp"
#include "gnc/core/assembly_graph.hpp"
#include "gnc/core/node_descriptor.hpp"
#include "gnc/core/node_registry.hpp"
#include "gnc/core/placement_policy.hpp"
#include "gnc/core/runtime_capabilities.hpp"
#include "gnc/interfaces/i_continuous_group.hpp"
#include "gnc/interfaces/i_summary_observer.hpp"
#include "gnc/interfaces/i_termination_evaluator.hpp"
#include "gnc/perturbation/interfaces/i_perturbation_provider.hpp"

#include <exception>
#include <string>
#include <vector>

namespace gnc::core {

class ValidationPipeline {
public:
    struct Result {
        std::vector<std::string> errors;
        std::vector<std::string> warnings;

        bool success() const { return errors.empty(); }
    };

    static Result run(NodeRegistry& registry,
                      const AssemblyGraph& graph,
                      const std::vector<NodeDescriptor>& descriptors) {
        Result result;
        validateDescriptors(registry, graph, descriptors, result);
        preflightBindings(registry, graph, result);
        validateContinuousGroupOwnership(registry, graph, descriptors, result);
        return result;
    }

private:
    static std::string joinDiagnosticLines(
        const std::vector<std::string>& values) {
        std::string result;
        for (std::size_t i = 0; i < values.size(); ++i) {
            result += (i == 0 ? "  - " : "\n  - ");
            result += values[i];
        }
        return result.empty() ? "  - (none)" : result;
    }

    static bool hasRequiredCapability(const SimulationNode& node,
                                      RequiredCapability capability) {
        switch (capability) {
        case RequiredCapability::None:
            return true;
        case RequiredCapability::PerturbationProvider:
            return dynamic_cast<const perturbation::IPerturbationProvider*>(
                       &node) != nullptr;
        case RequiredCapability::ContinuousGroup:
            return dynamic_cast<const interfaces::IContinuousGroup*>(&node) !=
                   nullptr;
        case RequiredCapability::TerminationEvaluator:
            return dynamic_cast<const interfaces::ITerminationEvaluator*>(&node) !=
                   nullptr;
        case RequiredCapability::SummaryObserver:
            return dynamic_cast<const interfaces::ISummaryObserver*>(&node) !=
                   nullptr;
        default:
            return false;
        }
    }

    static const char* capabilityName(RequiredCapability capability) {
        switch (capability) {
        case RequiredCapability::None:
            return "none";
        case RequiredCapability::PerturbationProvider:
            return "IPerturbationProvider";
        case RequiredCapability::ContinuousGroup:
            return "IContinuousGroup";
        case RequiredCapability::TerminationEvaluator:
            return "ITerminationEvaluator";
        case RequiredCapability::SummaryObserver:
            return "ISummaryObserver";
        default:
            return "unknown";
        }
    }

    static void validateDescriptors(
        NodeRegistry& registry,
        const AssemblyGraph& graph,
        const std::vector<NodeDescriptor>& descriptors,
        Result& result) {
        bool has_form_node = false;
        for (const auto& descriptor : descriptors) {
            SimulationNode* node = registry.get<SimulationNode>(descriptor.name);
            if (!node) {
                result.errors.push_back("Node descriptor references missing node '" +
                                        descriptor.name + "'.");
                continue;
            }
            if (!graph.hasNode(descriptor.name)) {
                result.errors.push_back("Node '" + descriptor.name +
                                        "' has no AssemblyGraph ownership entry.");
                continue;
            }

            const PlacementPolicy& policy = placementPolicy(descriptor.placement);
            const AssemblyScope& scope = graph.scope(descriptor.scope_key);
            if (!graph.nodeBelongsTo(descriptor.name, descriptor.scope_key)) {
                result.errors.push_back(
                    "Node '" + descriptor.name +
                    "' descriptor scope does not match AssemblyGraph ownership.");
            }
            if (scope.kind != policy.scope_kind) {
                result.errors.push_back(
                    "Node '" + descriptor.name + "' uses scope kind '" +
                    toString(scope.kind) + "' in placement '" + policy.name +
                    "', which requires scope kind '" +
                    toString(policy.scope_kind) + "'.");
            }

            if (descriptor.placement == PlacementKind::Form) {
                has_form_node = true;
                if (descriptor.form_family.empty()) {
                    result.errors.push_back("Form node '" + descriptor.name +
                                            "' must declare a non-empty form family.");
                }
            }
            if (descriptor.placement == PlacementKind::Interaction &&
                descriptor.form_family.empty()) {
                result.errors.push_back(
                    "Interaction node '" + descriptor.name +
                    "' must declare a non-empty form family.");
            }

            if (descriptor.role != policy.role) {
                result.errors.push_back(
                    "Node '" + descriptor.name + "' is registered as role '" +
                    toString(descriptor.role) + "' but assembled in placement '" +
                    policy.name + "', which requires role '" +
                    toString(policy.role) + "'.");
            }

            const bool task = dynamic_cast<IDiscreteTask*>(node) != nullptr;
            if (task != (descriptor.discrete_phase != DiscretePhase::None)) {
                result.errors.push_back(
                    "Node '" + descriptor.name +
                    "' has inconsistent IDiscreteTask capability and phase metadata.");
            }
            if (task && policy.constrain_task_phase &&
                descriptor.discrete_phase != policy.task_phase) {
                result.errors.push_back(
                    "Node '" + descriptor.name + "' uses phase '" +
                    toString(descriptor.discrete_phase) + "' in placement '" +
                    policy.name + "', which requires phase '" +
                    toString(policy.task_phase) + "'.");
            }

            if (!hasRequiredCapability(*node, policy.required_capability)) {
                result.errors.push_back(
                    "Node '" + descriptor.name + "' in placement '" +
                    policy.name + "' must implement " +
                    capabilityName(policy.required_capability) + ".");
            }

            const std::string& expected_family = descriptor.selected_form_family;
            if (!expected_family.empty() && !descriptor.form_family.empty() &&
                descriptor.form_family != expected_family &&
                scope.kind == ScopeKind::Vehicle) {
                result.errors.push_back(
                    "Node '" + descriptor.name + "' targets form family '" +
                    descriptor.form_family + "' while vehicle '" + scope.id +
                    "' selects '" + expected_family + "'.");
            }
        }

        if (!descriptors.empty() && !has_form_node) {
            result.errors.push_back(
                "Mission assembly did not register any nodes in the form placement.");
        }
    }

    static void preflightBindings(NodeRegistry& registry,
                                  const AssemblyGraph& graph,
                                  Result& result) {
        for (auto* node : registry.getAllNodes()) {
            AssemblyContext::BindingDiagnostics diagnostics;
            try {
                const AssemblyScope& scope = graph.scopeForNode(node->getName());
                AssemblyContext context(
                    graph, scope.key, registry, node->getName(), &diagnostics);
                node->bind(context);
            } catch (const std::exception& e) {
                result.errors.push_back("Node '" + node->getName() +
                                        "' failed dependency preflight: " + e.what());
                continue;
            }

            if (!diagnostics.errors.empty()) {
                result.errors.push_back(
                    "Node '" + node->getName() +
                    "' failed dependency preflight with " +
                    std::to_string(diagnostics.errors.size()) +
                    " required binding issue(s):\n" +
                    joinDiagnosticLines(diagnostics.errors));
                continue;
            }
            for (const auto& warning : diagnostics.warnings) {
                result.warnings.push_back("Node '" + node->getName() +
                                          "' optional dependency warning: " + warning);
            }
            node->markDependenciesBoundInternal_();
        }
    }

    static void validateContinuousGroupOwnership(
        NodeRegistry& registry,
        const AssemblyGraph& graph,
        const std::vector<NodeDescriptor>& descriptors,
        Result& result) {
        for (const auto& descriptor : descriptors) {
            const PlacementPolicy& policy = placementPolicy(descriptor.placement);
            if (!policy.continuous_members_same_scope) {
                continue;
            }

            auto* node = registry.get<SimulationNode>(descriptor.name);
            auto* group = dynamic_cast<interfaces::IContinuousGroup*>(node);
            if (!group) {
                continue;
            }
            for (auto* member : group->members()) {
                auto* member_node = dynamic_cast<SimulationNode*>(member);
                if (!member_node || !graph.hasNode(member_node->getName())) {
                    continue;
                }
                const AssemblyScope& member_scope =
                    graph.scopeForNode(member_node->getName());
                if (member_scope.key == descriptor.scope_key) {
                    continue;
                }
                result.errors.push_back(
                    "Continuous group '" + descriptor.name + "' in placement '" +
                    policy.name + "' cannot own member '" +
                    member_node->getName() + "' from scope '" + member_scope.key +
                    "'. Use a mission continuous group for cross-scope coupling.");
            }
        }
    }
};

} // namespace gnc::core
