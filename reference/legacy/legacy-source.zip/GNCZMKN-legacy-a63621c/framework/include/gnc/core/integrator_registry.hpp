#pragma once

#include "gnc/interfaces/i_integrator.hpp"

#include <algorithm>
#include <functional>
#include <memory>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace gnc::core {

class IntegratorRegistry {
public:
    using Factory = std::function<std::unique_ptr<interfaces::IIntegrator>()>;

    template<typename T>
    void registerType(const std::string& type_id) {
        registerFactory(type_id, [] { return std::make_unique<T>(); });
    }

    void registerFactory(const std::string& type_id, Factory factory) {
        if (type_id.empty() || !factory) {
            throw std::runtime_error(
                "Integrator registration requires a non-empty id and factory.");
        }
        if (factories_.count(type_id) > 0) {
            throw std::runtime_error("Integrator type already registered: " + type_id);
        }
        factories_[type_id] = std::move(factory);
    }

    bool hasType(const std::string& type_id) const {
        return factories_.count(type_id) > 0;
    }

    std::unique_ptr<interfaces::IIntegrator> create(
        const std::string& type_id) const {
        const auto it = factories_.find(type_id);
        if (it == factories_.end()) {
            throw std::runtime_error("Unknown integrator type: " + type_id);
        }
        return it->second();
    }

    std::vector<std::string> listTypes() const {
        std::vector<std::string> result;
        result.reserve(factories_.size());
        for (const auto& [type_id, _] : factories_) {
            result.push_back(type_id);
        }
        std::sort(result.begin(), result.end());
        return result;
    }

private:
    std::unordered_map<std::string, Factory> factories_;
};

} // namespace gnc::core
