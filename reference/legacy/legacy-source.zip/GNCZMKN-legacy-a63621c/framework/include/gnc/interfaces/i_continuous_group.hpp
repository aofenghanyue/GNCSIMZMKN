#pragma once

#include "gnc/interfaces/i_continuous_system.hpp"

#include <vector>

namespace gnc::interfaces {

/**
 * Explicit integration boundary for continuous states that require one joint
 * candidate vector during derivative evaluation.
 *
 * A group is itself an IContinuousSystem. Its state accessors assemble and
 * distribute the joint state, while members() identifies the independently
 * registered systems that the simulator must exclude from separate stepping.
 */
class IContinuousGroup : public IContinuousSystem {
public:
    ~IContinuousGroup() override = default;

    virtual std::vector<IContinuousSystem*> members() const = 0;
};

} // namespace gnc::interfaces
