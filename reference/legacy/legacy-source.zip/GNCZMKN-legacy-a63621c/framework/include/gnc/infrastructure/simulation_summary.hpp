/**
 * @file simulation_summary.hpp
 * @brief 仿真摘要报告生成器
 */
#pragma once

#include "gnc/common/logger.hpp"
#include "gnc/core/execution_metadata.hpp"
#include "gnc/infrastructure/auto_data_logger.hpp"
#include "gnc/core/node_registry.hpp"
#include "gnc/interfaces/i_summary_observer.hpp"

#include <chrono>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>

namespace gnc::core {

class SimulationSummary {
public:
    struct SimInfo {
        double dt = 0.0;
        double duration = 0.0;
        double final_time = 0.0;
        int total_steps = 0;
        std::string termination_reason;
        double wall_clock_seconds = 0.0;
    };

    static void write(const std::string& output_dir,
                      const SimInfo& info,
                      const NodeRegistry& registry,
                      const AutoDataLogger& logger,
                      const std::unordered_map<std::string, NodeExecutionInfo>&
                          execution_info) {
        if (output_dir.empty()) {
            return;
        }

        const std::string filepath = output_dir + "/summary.txt";
        std::ofstream file(filepath);
        if (!file.is_open()) {
            LOG_WARNING("SimulationSummary could not write summary file '{}' in output directory '{}'. Please check directory permissions.",
                        filepath, output_dir);
            return;
        }

        const auto now = std::chrono::system_clock::now();
        const auto time_value = std::chrono::system_clock::to_time_t(now);

        file << "========================================\n";
        file << "  GNC Simulation Summary Report\n";
        file << "========================================\n\n";
        file << "Generated: " << std::ctime(&time_value) << "\n";

        file << "--- Simulation Parameters ---\n";
        file << "  Time step (dt):      " << info.dt << " s\n";
        file << "  Configured duration: " << info.duration << " s\n";
        file << "  Actual final time:   " << info.final_time << " s\n";
        file << "  Total steps:         " << info.total_steps << "\n";
        file << "  Termination reason:  " << info.termination_reason << "\n";
        file << "  Wall clock time:     " << std::fixed << std::setprecision(3)
             << info.wall_clock_seconds << " s\n";
        file << "  Real-time ratio:     " << std::fixed << std::setprecision(1)
             << (info.wall_clock_seconds > 0.0 ? info.final_time / info.wall_clock_seconds : 0.0)
             << "x\n\n";

        std::vector<std::string> builtin_types;
        std::vector<std::string> project_types;
        file << std::defaultfloat << std::setprecision(12);
        file << "--- Components (" << registry.size() << ") ---\n";
        for (const auto& name : registry.getNodeNames()) {
            auto* component = registry.get<SimulationNode>(name);
            if (!component) {
                continue;
            }
            if (component->getNodeCategory() == "builtin") {
                builtin_types.push_back(component->getTypeName());
            } else {
                project_types.push_back(component->getTypeName());
            }

            file << "  [" << name << "]"
                 << " type=" << (component->getTypeName().empty() ? "(unknown)" : component->getTypeName())
                 << " category=" << component->getNodeCategory();
            if (!component->getRegistrationOrigin().empty()) {
                file << " origin=" << component->getRegistrationOrigin();
            }
            const auto execution = execution_info.find(name);
            if (execution != execution_info.end()) {
                file << " phase="
                     << toString(execution->second.configured.phase)
                     << " priority=" << execution->second.configured.priority;
                if (execution->second.is_discrete) {
                    file << " rate_hz="
                         << execution->second.configured.rate_hz
                         << " step_interval="
                         << execution->second.step_interval;
                }
            }
            file << "\n";
        }
        file << "\n";

        auto unique_join = [](std::vector<std::string> values) {
            std::sort(values.begin(), values.end());
            values.erase(std::unique(values.begin(), values.end()), values.end());

            std::string result;
            for (size_t i = 0; i < values.size(); ++i) {
                if (i > 0) result += ", ";
                result += values[i];
            }
            return result.empty() ? std::string("(none)") : result;
        };

        file << "--- Component Inventory ---\n";
        file << "  Builtin types: " << unique_join(std::move(builtin_types)) << "\n";
        file << "  Project types: " << unique_join(std::move(project_types)) << "\n\n";

        file << "--- Data Recording ---\n";
        if (logger.isEnabled()) {
            file << "  Status:  ENABLED\n";
            file << "  Fields:  " << logger.getFieldCount() << "\n";
            file << "  Output:  " << logger.getOutputDir() << "\n";
        } else {
            file << "  Status:  DISABLED\n";
        }
        file << "\n";

        bool wrote_project_summary = false;
        for (const auto& name : registry.getNodeNames()) {
            auto* component = registry.get<SimulationNode>(name);
            auto* observer =
                dynamic_cast<gnc::interfaces::ISummaryObserver*>(component);
            if (!observer) {
                continue;
            }
            if (!wrote_project_summary) {
                file << "--- Project Summary ---\n";
                wrote_project_summary = true;
            }
            file << "[" << name << "]\n";
            observer->writeSummary(file);
            file << "\n";
        }
        if (wrote_project_summary) {
            file << "\n";
        }

        file << "========================================\n";

        LOG_INFO("SimulationSummary written to '{}'", filepath);
    }
};

} // namespace gnc::core
