#pragma once

#include "gnc/bootstrap/register_builtin_packages.hpp"
#include "gnc/bootstrap/register_builtin_simflow_materializers.hpp"
#include "gnc/core/framework_catalog.hpp"
#include "gnc/core/integrators/euler_integrator.hpp"
#include "gnc/core/integrators/rk4_integrator.hpp"

namespace gnc::bootstrap {

inline void registerFrameworkBuiltins(gnc::core::FrameworkCatalog& catalog) {
    registerBuiltinPackages(catalog.nodes());
    if (!catalog.integrators().hasType("euler")) {
        catalog.integrators().registerType<gnc::core::EulerIntegrator>("euler");
    }
    if (!catalog.integrators().hasType("rk4")) {
        catalog.integrators().registerType<gnc::core::RK4Integrator>("rk4");
    }
    registerBuiltinSimFlowMaterializers(catalog.simflowMaterializers());
}

} // namespace gnc::bootstrap
