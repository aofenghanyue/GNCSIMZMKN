#pragma once

#include "gnc/core/preparation_context.hpp"
#include "gnc/core/config_manager.hpp"

#include <filesystem>
#include <string>

namespace gnc::simflow {

inline bool startsWith(const std::string& text, const std::string& prefix) {
    return gnc::core::AssetPathResolver::startsWith(text, prefix);
}

inline std::filesystem::path findRepoRoot(const std::filesystem::path& anchor) {
    return gnc::core::AssetPathResolver::findRepoRoot(anchor);
}

inline std::filesystem::path findProjectRoot(const std::filesystem::path& file,
                                             const std::filesystem::path& repo_root) {
    return gnc::core::AssetPathResolver::findProjectRoot(file, repo_root);
}

inline std::filesystem::path resolvePath(const std::string& value,
                                         const std::filesystem::path& anchor_file,
                                         const std::filesystem::path& repo_root,
                                         const std::filesystem::path& project_root) {
    const gnc::core::AssetPathResolver resolver(
        anchor_file, repo_root, project_root);
    return resolver.resolve(value);
}

/**
 * @brief Freeze explicit asset URI strings before writing an effective mission.
 *
 * project:// depends on the source project's location. A SimFlow case lives in
 * an output directory, so retaining that URI would make plain --config replay
 * ambiguous. Relative strings and ordinary non-path strings remain untouched.
 */
inline gnc::core::ConfigNode resolveExplicitPathUris(
    const gnc::core::ConfigNode& node,
    const std::filesystem::path& anchor_file,
    const std::filesystem::path& repo_root,
    const std::filesystem::path& project_root) {
    if (node.isString()) {
        const auto value = node.asString();
        if (startsWith(value, "repo://") || startsWith(value, "project://") ||
            startsWith(value, "user-data://")) {
            return gnc::core::ConfigNode::makeString(
                resolvePath(value, anchor_file, repo_root, project_root)
                    .generic_string());
        }
        return node;
    }

    if (node.isArray()) {
        auto result = gnc::core::ConfigNode::makeArray();
        for (size_t i = 0; i < node.size(); ++i) {
            result.push(resolveExplicitPathUris(
                node[i], anchor_file, repo_root, project_root));
        }
        return result;
    }

    if (node.isObject()) {
        auto result = gnc::core::ConfigNode::makeObject();
        for (const auto& [key, child] : node) {
            result.set(key,
                       resolveExplicitPathUris(
                           child, anchor_file, repo_root, project_root));
        }
        return result;
    }

    return node;
}

} // namespace gnc::simflow
