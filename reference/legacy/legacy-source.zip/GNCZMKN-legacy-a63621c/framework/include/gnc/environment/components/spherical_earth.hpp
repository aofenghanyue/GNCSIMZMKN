#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/environment/interfaces/i_earth.hpp"

#include <cmath>
#include <string>

namespace gnc::environment {

class SphericalEarth final : public gnc::core::SimulationNode,
                             public IEarth {
public:
    SphericalEarth() : SimulationNode("SphericalEarth") {}

    void configure(const gnc::core::ConfigNode& config) override {
        configure(config, "config");
    }

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        equatorial_radius_m_ =
            reader.optionalDouble("equatorial_radius_m", equatorial_radius_m_);
        rotation_rate_rad_per_s_ =
            reader.optionalDouble("rotation_rate_rad_per_s", rotation_rate_rad_per_s_);
        reader.validateNoUnknownKeys();
    }

    double getEquatorialRadius() const override { return equatorial_radius_m_; }
    double getFlattening() const override { return 0.0; }
    double getRotationRate() const override { return rotation_rate_rad_per_s_; }

    gnc::math::Vector3 geodeticToEcef(double latitude_rad,
                                      double longitude_rad,
                                      double altitude_m) const override {
        const double radius = equatorial_radius_m_ + altitude_m;
        const double sin_lat = std::sin(latitude_rad);
        const double cos_lat = std::cos(latitude_rad);
        const double sin_lon = std::sin(longitude_rad);
        const double cos_lon = std::cos(longitude_rad);

        return gnc::math::Vector3(radius * cos_lat * cos_lon,
                                  radius * cos_lat * sin_lon,
                                  radius * sin_lat);
    }

private:
    double equatorial_radius_m_ = 6371000.0;
    double rotation_rate_rad_per_s_ = 7.292115e-5;
};

} // namespace gnc::environment
