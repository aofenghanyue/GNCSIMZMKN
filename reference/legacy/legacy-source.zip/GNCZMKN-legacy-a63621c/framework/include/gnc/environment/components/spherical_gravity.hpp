#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/environment/interfaces/i_gravity.hpp"

#include <string>

namespace gnc::environment {

class SphericalGravity final : public gnc::core::SimulationNode,
                               public IGravity {
public:
    SphericalGravity() : SimulationNode("SphericalGravity") {}

    void configure(const gnc::core::ConfigNode& config) override {
        configure(config, "config");
    }

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& config_path) override {
        gnc::core::ConfigReader reader(config, config_path);
        reference_radius_m_ =
            reader.optionalDouble("reference_radius_m", reference_radius_m_);
        sea_level_gravity_mps2_ =
            reader.optionalDouble("sea_level_gravity_mps2", sea_level_gravity_mps2_);
        reader.validateNoUnknownKeys();
    }

    double getSeaLevelGravity() const override {
        return sea_level_gravity_mps2_;
    }

    double getGravityMagnitude(double altitude_m) const override {
        const double radius = reference_radius_m_ + altitude_m;
        return sea_level_gravity_mps2_ * reference_radius_m_ * reference_radius_m_ /
               (radius * radius);
    }

    gnc::math::Vector3 getGravityVector(
        const gnc::math::Vector3& position_ecef) const override {
        const double radius = position_ecef.norm();
        if (radius < 1e-9) {
            return gnc::math::Vector3(0.0, 0.0, -sea_level_gravity_mps2_);
        }
        const double magnitude = sea_level_gravity_mps2_ *
                                 reference_radius_m_ * reference_radius_m_ /
                                 (radius * radius);
        return -magnitude * position_ecef.normalized();
    }

private:
    double reference_radius_m_ = 6371000.0;
    double sea_level_gravity_mps2_ = 9.80665;
};

} // namespace gnc::environment
