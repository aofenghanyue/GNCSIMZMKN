# 文档导航：怎样读懂并接手 GNCZMKN

GNCZMKN 的文档按照实际使用过程编排。读者先运行一个现成的 mission，观察程序生成的 CSV 和摘要；接着学习这些结果在物理上、数值上分别表示什么；等到能够独立修改项目模型后，再进入装配器和运行内核。这样的顺序可以让每个架构概念都落到一项看得见的实验行为上。

参考手册主要用于查询 type id、配置字段和公共接口，不适合作为入门读物。如果文档与当前源码或测试不一致，应以源码和测试为准，并把差异作为文档缺陷修正。

```mermaid
flowchart LR
    Run["运行 baseline"] --> Read["读懂 mission 和 CSV"]
    Read --> Model["理解信号、采样与积分"]
    Model --> Change["替换项目算法或物理模型"]
    Change --> Experiment["验证、拉偏与复现"]
    Experiment --> Maintain["维护装配器与运行内核"]
```

## 1. 第一次使用框架

先从 [快速上手](01-getting-started.md) 开始。它带你构建项目、运行 `example_05`，并检查 CSV 与 `summary.txt`。第一次运行的目标很具体：知道程序从哪里取得 mission，知道输出写到哪里，也能把 `interceptor.guidance` 这样的完整实例名对应回 JSON 中的 vehicle 和节点名称。

程序跑通以后，阅读 [核心概念](02-core-concepts.md)。这一章从 GNC 信号入手，逐步解释 truth、测量、估计、命令、物理响应和 Form input 的区别。它还会说明 `time = t_k` 的一行 CSV 为什么同时含有发布态 `x_k` 和本周期离散输出。理解这两个问题以后，再读 [Mission 配置](03-mission-configuration.md)，JSON 中的 placement、scope、phase 和 `rate_hz` 就有了明确的物理与运行含义。

这一阶段可以用三个问题自测：

1. `vehicles[0].id = interceptor`、节点 `name = guidance` 时，完整实例名怎样得到？
2. CSV 中同一行的状态与命令分别在哪个阶段产生？
3. `ideal`、`zero` 和部分 `standard` baseline 能验证哪些架构行为，又留下了哪些物理简化？

## 2. 开始一项 GNC 研究

准备研究算法性能时，先读 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。文中把软件接线、数值计算和模型有效性分开讨论，也说明怎样选择步长、判断连续耦合方式、保存实验条件并限定结论。这样可以避免把“程序成功生成了曲线”直接当成模型可信的证据。

随后使用 [扩展指南](04-extension-guide.md) 替换一个项目节点。指南先演示制导算法的局部替换，再沿着下面这条路径检查命令是否真的改变了运动状态：

```text
guidance command
-> flight control
-> control allocation
-> actuator / aerodynamics / propulsion / mass
-> Interaction
-> Form input
-> computeDerivatives
-> next published state
```

当名义 case 已经通过验证，再读 [SimFlow 教程](simflow-guide.md)。SimFlow 会把每个 case 写成独立的 `effective_mission.json`，因此异常结果可以脱离批量任务单独回放。研究代码通常放在 `user/<project>`，目录组织、active project 和独立构建目录的规则见 [User Workspace](../user/README.md)。

走到这里，你应该能写清当前实验的坐标、采样、理想化和数据假设，也能用命令—物理响应—下一发布态的证据说明控制链已经接入运动方程。

## 3. 接手 framework 维护

维护工作先从 [当前运行架构](00-current-architecture.md) 开始。这篇文档站在整个程序的角度，说明 CMake 组合、catalog、mission 构建、验证、准备和固定步长循环怎样连接起来。读完后再进入 [维护者架构说明](05-architecture.md)，沿着真实源码调用路径查看对象所有权、关键不变量和常见修改的影响范围。

[设计决策](07-decisions.md) 记录已经接受的架构边界。准备修改 placement、调度、连续积分或生命周期时，应先检查相关 ADR，了解现有选择解决了什么问题，又接受了哪些限制。`design-notes/` 保存历史推演和待决议题，它们提供讨论材料，不代表当前运行契约。

维护者可以用下面这条主线检查自己是否已经建立完整的源码图景：

```text
FrameworkCatalog
-> SimulationBuilder
-> MissionAssembler
-> ValidationPipeline
-> PreparationPipeline
-> Simulator
```

如果能够说明每一层拥有哪一类事实、为什么要在仿真开始前完成校验，以及修改一行调度代码会影响哪些测试和文档，就可以开始处理 framework 内部改动。

## 4. 用同一个示例贯穿阅读

第一次学习建议一直使用 `user/example_05_ideal_3dof_geographic_baseline/config/mission.json`。它的链路短，包含两个 vehicle，也覆盖 Form、Input、Process、Output、Interaction、记录和停止条件。它使用的物理模型较轻，正适合观察框架怎样装配和调度节点；研究性能时还需要换成经过验证的项目模型。

阅读离散链时，可以跟踪 `interceptor.guidance`：

```text
mission node entry
-> NodeFactory type metadata
-> MissionAssembler::registerNode
-> NodeRegistry + AssemblyGraph
-> ValidationPipeline::preflightBindings
-> Simulator::entriesFor(Process)
-> guidance.update(t_k)
-> AutoDataLogger observable
```

阅读连续链时，再跟踪 `interceptor.dynamics`：

```text
mission form placement
-> Form configure / bind / initialize
-> publish truth at t_k
-> Interaction query with candidate truth
-> computeDerivatives
-> integrator
-> synchronized state commit
-> publish x_k+1
```

这两个实例可以把注册、装配、依赖、离散调度、连续积分和记录串在一起。遇到陌生类时，先判断它处于哪一条路径，再查看具体实现，阅读负担会小很多。

其它示例各有侧重：

| 示例 | 适合观察的内容 | 使用时的提醒 |
| --- | --- | --- |
| `example_04_ideal_6dof_baseline` | geographic 6DoF 接线与 Form family | `ideal`、`zero` 和 `standard` 组件主要服务架构验证 |
| `example_06_ideal_cartesian_3dof_baseline` | Cartesian 3DoF 与加速度输入 | 适合检查时间语义和接口 |
| `example_07_ideal_cartesian_6dof_baseline` | Cartesian 6DoF 接线 | 物理力矩闭合仍然较轻 |
| `example_08_cavh_geographic_3dof_custom` | 项目气动资产、制导和物理 Interaction | 模型适用范围仍需结合研究问题验证 |
| `yyz_cartesian_6dof_framework_9` | 项目模板、资产准备、显式 priority 和 SimFlow | reference 算法与最近节点查表是可替换的起点 |

## 5. 每篇文档负责回答什么

[快速上手](01-getting-started.md)、[核心概念](02-core-concepts.md) 和 [Mission 配置](03-mission-configuration.md) 构成使用者入口。它们依次回答“怎样运行”“结果怎样解释”和“实验怎样写进 JSON”。

[研究级 GNC 仿真方法](08-research-simulation-methodology.md)、[扩展指南](04-extension-guide.md) 与 [SimFlow 教程](simflow-guide.md) 面向项目研究。三篇文档分别讨论可信度、模型实现和批量试验复现。

[当前运行架构](00-current-architecture.md) 与 [维护者架构说明](05-architecture.md) 面向 framework 维护者。前者给出全局图，后者沿源码解释变更风险。[设计决策](07-decisions.md) 用于追溯已接受的选择，[参考手册](06-reference.md) 用于查找 CLI、type id、公共接口和配置字段。

## 6. 按当前任务查找

| 当前任务 | 先读 | 需要时再查 |
| --- | --- | --- |
| 第一次构建和运行 | [快速上手](01-getting-started.md) | [User Workspace](../user/README.md) |
| 解释一行 CSV | [核心概念，第 9 节](02-core-concepts.md#9-一个固定步长周期怎样运行) | [当前架构，第 10 节](00-current-architecture.md#10-固定步长循环的精确顺序) |
| 修改 mission | [Mission 配置](03-mission-configuration.md) | [参考手册](06-reference.md) |
| 替换算法 | [扩展指南，第 0 节](04-extension-guide.md#0-第一次扩展替换一个制导算法) | [User Workspace](../user/README.md) |
| 让命令影响轨迹 | [核心概念，第 3.6～3.7 节](02-core-concepts.md#36-vehicleoutput运行时物理能力) | [扩展指南](04-extension-guide.md) |
| 选择 `dt`、`rate_hz` 或 continuous group | [研究方法，第 4～6 节](08-research-simulation-methodology.md#4-把固定步长循环理解成采样系统) | [当前运行架构](00-current-architecture.md) |
| 使用 SimFlow | [SimFlow 教程](simflow-guide.md) | [Mission 配置，第 11 节](03-mission-configuration.md#11-perturbation-与-simflow) |
| 修改 Builder 或 Assembler | [维护者架构说明](05-architecture.md) | [设计决策](07-decisions.md) |
| 查询 type id 或字段 | [参考手册](06-reference.md) | `--list-components-verbose` |

## 7. 文档维护约定

教学文档应先解释一个设计解决了什么研究问题，再介绍 API 和字段。示例需要说明自身的物理简化与适用范围；涉及时间的描述应能对应到 `Simulator::run()` 和 CSV；新增 Form family 时，应同时写清 state、truth、input 与 closure 契约。

核心运行语义发生变化时，需要同步检查当前架构、维护者说明、ADR 和相关测试。大量 type id 与字段继续集中放在参考手册中，避免教学章节逐渐变成接口字典。
