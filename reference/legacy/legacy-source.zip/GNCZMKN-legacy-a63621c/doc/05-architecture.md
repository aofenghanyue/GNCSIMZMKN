# 维护者架构说明：沿一次运行读懂源码

本文为接手 GNCZMKN 的维护者提供一条源码阅读路径。我们从 runner 创建 catalog 开始，跟随一份 mission 完成装配、验证、准备和运行，再回头看各个对象为什么分开。函数签名可以直接在头文件中查询，这里更关心对象拥有哪类事实、调用发生在什么阶段，以及一次修改可能改变哪些实验语义。

开始前建议先读 [核心概念](02-core-concepts.md) 和 [当前运行架构](00-current-architecture.md)。前两篇文档已经解释领域术语与全局图景，本篇可以集中追踪源码。研究模型的验证方法另见 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。

## 1. 维护核心代码时要保护的九条约定

下面九条约定共同保证 mission 可以复现、错误能够在运行前暴露、一行 CSV 的时间含义保持稳定。阅读后续源码时，可以不断用它们检查每个类的职责。

1. **程序能力显式组合**：runner 创建 `FrameworkCatalog`，builtin、linked extension 和 active project 都通过 catalog 注册定义。
2. **mission 对象走同一条装配路径**：所有可实例化对象都继承 `SimulationNode`，共享一套配置、绑定和生命周期。
3. **所有权只由一张图记录**：scope、父子关系、节点归属和短名解析都交给 `AssemblyGraph`。
4. **placement 规则集中维护**：`PlacementKind + PlacementPolicy` 规定 scope kind、role、受约束 phase 和必需 capability。
5. **全部实例注册完成后再绑定依赖**：forward reference 和 contributor 聚合不受 JSON 数组顺序影响。
6. **不确定工作在构建期完成**：配置、依赖、资产和 continuous plan 都成功以后，logger 才打开结果文件。
7. **发布态划分相邻周期**：`publish(t_k)`、离散更新、记录、终止和积分提交遵循固定顺序。
8. **独立连续状态统一提交**：各系统从同一宏步边界计算 next state，全部完成以后再提交；强耦合模型由显式 group 接管。
9. **批量语义留在 Simulator 外部**：SimFlow 生成 effective mission，每个 case 仍然使用普通 Builder 和 Simulator。

评审核心改动时，先检查三件事：同一事实是否出现了第二个记录位置，一行 CSV 的时间含义是否发生变化，普通 mission 是否开始依赖某个可选项目能力。很多架构回退都能在这三项检查中提前发现。

## 2. 先用一个实例贯穿源码

完整主线：

```text
src/runner.cpp
-> src/runner_component_registration.cpp
-> framework/include/gnc/core/framework_catalog.hpp
-> framework/include/gnc/core/simulation_builder.hpp
-> framework/include/gnc/core/mission_assembler.hpp
-> framework/include/gnc/core/validation_pipeline.hpp
-> framework/include/gnc/core/preparation_pipeline.hpp
-> framework/include/gnc/core/simulator.hpp
```

直接从头遍历全部头文件很难建立主线。可以先用 `interceptor.guidance` 或 `interceptor.dynamics` 贯穿调用路径，再分四遍阅读：

| 阅读遍次 | 只追踪什么 | 读完后应能说明 |
| --- | --- | --- |
| 1. 组合 | type 定义怎样进入 catalog | 能解释 builtin、extension、project 的注册来源 |
| 2. 构建 | mission 条目怎样变成 registry 实例 | 能追踪一个 `vehicles[].process[]` 条目到 `NodeExecutionConfig` |
| 3. 运行 | `t_k` 怎样经历 publish、update、record 和 integrate | 能解释 CSV 前两行及 terminal sample |
| 4. 扩展 | provider、asset、Form、Interaction 和 group 怎样接入 | 能判断一个改动是否需要触碰 core |

第一遍暂时忽略各个 builtin 的物理细节，只关心一个实例怎样进入 catalog、registry 和执行计划。主线稳定以后，再比较不同 role 的实现会容易许多。

## 3. runner 与生成代码怎样组成应用

### 3.1 runner 只负责选择入口和组合能力

`src/runner.cpp` 处理进程级工作：

- 解析 CLI action；
- 组合 catalog；
- 解析默认或显式 mission 路径；
- 选择普通运行、SimFlow 或组件清单；
- 捕获顶层异常并转换为进程退出码。

具体 Form、Environment 和项目节点由 catalog 与 Assembler 创建，mission schema 也由构建层解释。runner 保持这条边界后，增加一个项目节点无需修改 CLI 主程序。

### 3.2 CMake 生成了什么

`gnc_framework` 是 CMake `INTERFACE` target，主要实现位于头文件中。`gnc_sim` 由 `runner.cpp` 和注册翻译单元编译，并链接这套接口库。扩展因此在编译期组合，没有运行时动态库 ABI 或插件发现协议。

这样做便于研究者直接审查模板接口、项目代码和注册元数据，也让可执行文件只包含当前项目需要的类型。相应代价是，组件集合变化后必须重新配置并编译，注册翻译单元也会包含较多头文件。

配置阶段产生三类关键头：

- `active_project_config.hpp`：active project 名与默认 mission 路径；
- `auto_registered_nodes.hpp` / `auto_registered_simflow_materializers.hpp`：当前项目显式注册调用链；
- `linked_extensions.hpp`：构建时启用的可选扩展贡献链。

`src/runner_component_registration.cpp` 把它们包装成：

```cpp
registerFrameworkBuiltins(catalog);
registerLinkedExtensions(catalog);
registerActiveProject(catalog);
```

项目头文件增删以后需要重新运行 CMake 配置。如果 `--list-components-verbose` 中没有出现新 type，应先检查 active project 和生成注册头，再检查 mission 是否引用了正确 id。

### 3.3 NodeFactory 元数据的作用

每个注册类型保存：

```text
type id
constructor
category and origin
role
discrete phase
form family
advertised provider interfaces
```

这些元数据同时用于装配校验、组件清单和依赖诊断。注册宏中的 role、phase 和 family 会改变节点能放在哪里、何时运行以及能与哪类 Form 连接，因此属于架构契约，不能只当作展示标签。

`NodeFactory::registerType` 会检查：

- 类型继承 `SimulationNode`；
- 每个声明接口确实是类型基类；
- type id 非空且不重复。

新增 provider 后，还要把接口加入注册列表。按名字取得节点后虽然最终会进行动态类型转换，遗漏 advertised interface 仍会让组件清单和 provider 诊断与真实 C++ 类型不一致。

### 3.4 FrameworkCatalog 的边界

Catalog 只保存类型定义，不保存某次 mission 创建的实例。`SimulationBuilder`、`SimFlowRunner` 和 `--list-components` 都读取同一份定义集合，因此普通运行、批量运行和组件查询不会维护三张彼此漂移的类型表。

新增积分器或 SimFlow materializer 也通过 catalog 注册。Builder 只按 id 请求工厂创建对象，不应出现 `if (integrator == "...")` 这样的具体类型分支。

## 4. SimulationBuilder 协调整个构建过程

`SimulationBuilder` 持有本次构建需要的配置、定义集合、Simulator 和诊断状态：

- `ConfigManager config_`；
- 对外部 `FrameworkCatalog` 的引用；
- `Simulator simulator_`；
- Environment/Vehicle 实例视图；
- 本次 build 的 errors 与 warnings。

`build()` 每次先清空诊断并调用 `simulator_.resetAssemblyState()`，随后执行：

```text
read and validate simulation
-> configure Simulator and select integrator
-> create MissionAssembler
-> assemble mission
-> ValidationPipeline
-> PreparationPipeline, only when no build errors
-> validate continuous execution plan
-> validate outputs
-> initialize AutoDataLogger, only when still clean
-> report aggregated diagnostics
-> return Simulator reference
```

### 4.1 Builder 为什么停在 initialize 之前

`build()` 负责得到一个可运行、已经检查的拓扑，`Simulator::run()` 负责进入运行生命周期。两者分开以后：

- 测试可以检查 build 结果而不推进运行态；
- logger 和 continuous plan 可以在 initialize 前审查；
- 资产 prepare 完成后，调用者仍有机会安装 callback 或查询 registry。

### 4.2 尽量一次报告多项构建错误

Assembler 和 ValidationPipeline 会尽量继续检查其它节点，最后由 Builder 统一报告多条结构错误。依赖预检也会收集同一节点的多个 required binding 问题，让使用者一次修正多项问题，少做几轮重复构建。

只有结构错误为空时，Builder 才开始准备资产，避免在已知无效的拓扑上执行文件 I/O。continuous plan 校验和 logger 初始化也逐层后移，前一步失败后不会继续产生更多外部状态。

### 4.3 输出文件要等所有构建检查通过后再打开

Builder 先校验 continuous plan 和 outputs schema，再调用 `initializeAutoDataLogger()`。只要保持这个顺序，构建失败就不会创建本次结果文件，也不会把同名旧 CSV 截断。

增加构建期校验时，应检查它是否能够在物理时间推进前确定。如果可以，就应把它放在 logger 初始化之前，延续失败不产生结果文件的约定。

## 5. 解析格式与 mission 语义分开处理

### 5.1 Parser facade

`IConfigParser` 只负责把输入文本解析成 `ConfigNode`。内建 JSON parser 覆盖当前 mission 使用的语法，并以确定的方式拒绝非法输入。以后若换成完整 JSON 或 YAML 库，只要输出仍是同一种 `ConfigNode`，后续装配逻辑就无需改变。

### 5.2 预处理

parser 完成以后，`ConfigManager` 继续处理：

- `$include` string 或有序数组；
- 相对 include；
- `repo://`、`project://`、`user-data://`；
- object deep merge，本地字段覆盖 include，数组整体替换。

`loadFromString()` 没有文件锚点，因此不接受 filesystem include。

### 5.3 Schema 解释

`MissionAssembler` 只解释当前顶层 `vehicles[]` 语言。解析器、include 预处理和 schema 各自独立以后，更换配置格式不会把第三方解析库细节带进 Assembler，修改 mission schema 也无需触碰 JSON tokenizer。

## 6. MissionAssembler 怎样把 placement 变成实例

### 6.1 装配顺序

当前装配顺序为：

```text
mission.infrastructure
-> mission.process
-> environment
-> vehicles, each in fixed placement order
-> synchronize selected form families
-> mission.continuous_groups
-> termination
-> summary
```

单个 vehicle 内：

```text
infrastructure
-> perturbation
-> form
-> common
-> input
-> process
-> output
-> interaction
-> continuous_groups
```

这个顺序会形成 registry order，并影响同 phase、同 priority 时的执行兜底，也会影响默认 initialize 顺序。依赖能否找到与此无关，因为 `bind()` 要等全部实例注册完成后才执行。

### 6.2 PlacementSpec

Assembler 内部的 `PlacementSpec` 只保存当前 JSON 位置所需的信息：

- 诊断路径；
- `PlacementKind`；
- `scope_key`；
- 可选 owner view。

`PlacementSpec` 不复制 role 或 phase 规则。实例创建后，`NodeDescriptor` 记录实际注册元数据和 placement；ValidationPipeline 再查询统一的 `PlacementPolicy`，检查两者能否组成合法节点。这样，placement 规则不会在 Assembler 和验证器中各维护一份。

### 6.3 registerNode 的关键顺序

维护配置与失败诊断时，需要熟悉节点注册的实际顺序：

```text
validate node wrapper
-> validate type/name and uniqueness
-> factory.create(type)
-> annotate metadata
-> observe form family
-> read priority/rate
-> node.configure(config, path)
-> check unused config keys
-> create descriptor
-> registry.addDynamic
-> graph.assignNode
-> simulator.addNodeExecution
```

节点 `configure()` 抛出的异常发生在实例进入 registry 之前。execution metadata 的错误可能出现在节点已经注册以后，但 Builder 会记录 error，后续准备和运行都不会开始。

### 6.4 form family 选择

每个 vehicle 都独立选择自己的 Form family：

- 可由 `form.family` 显式提供；
- 也可从第一个非空 Form type metadata 观察得到；
- 装配完全部 vehicle 后同步到 descriptor。

ValidationPipeline 会把 vehicle scope 中每个 descriptor 的非空 family 与该 vehicle 的选择比较。因此，同一任务中的不同 vehicle 可以使用不同 family，同时仍能在各自 scope 内检查相容性。

修改 family 选择逻辑时必须保留这种 per-scope 语义。若退回全 mission 单一 family，异构目标与拦截器等任务就无法合法装配。

## 7. 三个容易混淆的装配对象

`AssemblyGraph`、`NodeRegistry` 和 `NodeDescriptor` 都在构建阶段出现，但各自记录的事实不同：

| 对象 | 权威事实 | 生命周期中的作用 |
| --- | --- | --- |
| `AssemblyGraph` | scope、parent、node ownership、名称解析 | 构建期绑定和校验 |
| `NodeRegistry` | 节点唯一所有权、完整名到实例、typed 查询、注册顺序 | 构建期与整个运行期 |
| `NodeDescriptor` | 某实例的 placement 与注册元数据快照 | ValidationPipeline 输入 |

NodeRegistry 不能根据名称自行推断正式 scope，AssemblyGraph 不拥有节点对象，Descriptor 也不承载运行行为。维持这三条边界，可以避免所有权、命名和执行元数据互相覆盖。

### 7.1 为什么 scope graph 不保留在 Simulator 中

普通 mission 在 build 结束时已经完成绑定。运行阶段，节点持有 typed provider 引用，Simulator 只需要 registry、execution metadata 和 capability，所以无需长期保存正式 scope graph。当前 AssemblyGraph 的主要消费者都位于构建期。

direct Simulator 测试没有 Assembler。初始化时，它会根据节点完整名构造一个浅层 `AssemblyGraph::inferFromNodeNames()`，从而复用同一套短名规则；不含点号的名称进入 direct root scope。这条兼容路径服务测试，不能替代普通 mission 的正式所有权信息。

### 7.2 名称规则

`AssemblyGraph::resolveName(scope_key, name)` 只有两条规则：

- 名称含 `.`：按完整名原样返回；
- 名称不含 `.`：添加当前 scope 的 registry prefix。

节点和 provider 不应自行增加父 scope 搜索。需要跨 scope 连接时，mission 应写完整名，让依赖目标保持显式。

## 8. ValidationPipeline 怎样预检元数据和依赖

Pipeline 顺序为：

```text
validate descriptors
-> preflight all bindings
-> validate vehicle continuous-group ownership
```

### 8.1 descriptor 校验

descriptor 校验覆盖下面这些不变量：

- registry 与 graph 都包含 descriptor 节点；
- descriptor scope 与 graph ownership 一致；
- scope kind、role、phase 和必需 capability 符合 policy；
- `IDiscreteTask` 与 phase metadata 同时存在或同时缺席；
- Form/Interaction family 非空；
- vehicle family 相容；
- descriptor 非空时，当前实现至少要求整个 mission 出现一个 Form placement 节点。逐 vehicle 完整性和空 descriptor 缺口记录在 F-01。

新增 role 或 capability 时，先判断约束属于哪一层：placement 的合法组合放进 policy，运行行为由 C++ dynamic capability 表达，某个模型独有的依赖留在节点 `bind()` 中。把所有约束都塞进 `validateDescriptors()`，会让通用验证器逐渐了解过多领域细节。

### 8.2 preflightBindings

Pipeline 根据 AssemblyGraph 中记录的实际 scope，为每个 registry 节点构造带诊断收集器的 `AssemblyContext`，然后调用 `bind()`。

在诊断模式下，`requireByName<T>()` 找不到依赖时会记录错误并返回空指针。节点的 `bind()` 因此只能保存返回值，不能立即调用 required provider。若后续语句直接解引用，原本可以聚合的诊断就会退化成异常或空指针风险。

成功完成绑定的节点会通过 `markDependenciesBoundInternal_()` 标记。Simulator 的 direct fallback 只补绑尚未标记的节点，普通 Builder 路径不会重复执行。

### 8.3 bind 的编写约束

推荐的 `bind()` 形状如下：

```cpp
void bind(AssemblyContext& context) override {
    context.bindAll(
        bind(required_, required_name_),
        bindIfPresent(optional_, optional_name_));
}
```

它具有以下性质：

- 多次调用结果一致；
- 不加载文件；
- 不修改连续或离散状态；
- 不依赖另一个节点已经 initialize；
- required 与 optional 对应真实模型契约。

## 9. 资产准备和运行态初始化为何分成两步

### 9.1 PreparationPipeline

Pipeline 按 NodeRegistry 顺序调用每个节点的 `prepare()`。发生异常时，它会附加完整实例名和 type，并继续尝试其它节点，以便一次报告多项资产问题。

`PreparationContext` 当前只提供 `AssetPathResolver`。`PreparedAssetCache` 是进程级模板缓存；缓存 key 必须包含文件指纹和所有影响产品内容的处理选项，否则不同配置可能错误复用同一数据。

### 9.2 没有 preparation DAG 的后果

注册顺序不构成正式的 prepare 依赖。当前推荐的生产者—消费者写法是：

```text
producer.prepare() builds shared_ptr<const Product>
all prepare completes
consumer.initialize() reads provider.product()
```

如果 consumer 在自己的 `prepare()` 中读取另一个 producer 的结果，行为就会依赖 mission 数组顺序。等到项目中出现稳定、重复的多级资产管线后，应为 preparation 单独设计依赖声明、拓扑排序和循环诊断。

### 9.3 Simulator initialize

初始化步骤：

```text
phase -> Initializing
-> current_time = 0
-> recompute step intervals
-> bind direct nodes that remain unbound
-> validate continuous plan
-> stable-partition entries in Perturbation discrete phase first
-> node.initialize() in resulting order
-> initialized = true
```

具有离散 Perturbation phase 的节点提前，用于让其它节点初始化时读取动态拉偏状态。`perturbation.static` 注册 phase 为 None，依靠 vehicle 内 placement 注册顺序位于 Form 之前。其余 initialize 顺序仍是 registry order，没有通用依赖图。

节点最好只在 `initialize()` 中建立自身运行态。需要读取当前周期 measurement 或 command 的逻辑放进第一次 `update(t_0)`，这样不会依赖谁先初始化。某些内建节点若用 `initialize() { update({0,0,0}); }` 建立默认输出，正式的 `t_0` update 仍会按照 phase 顺序覆盖它。

## 10. Simulator 保存哪些运行时信息

`Simulator` 的主要成员可以分成节点、调度、积分和输出四组：

| 成员 | 含义 |
| --- | --- |
| `NodeRegistry registry_` | 拥有全部 node instance |
| `SimulatorConfig config_` | 固定 `dt` 与 duration |
| `unique_ptr<IIntegrator>` | 当前积分器 |
| `vector<ExecutionEntry>` | 每个节点的 task pointer、phase、priority、rate、interval、注册序 |
| `vector<IContinuousSystem*> integration_systems_` | 校验后的 continuous plan |
| `AutoDataLogger` | 记录配置和 sink |
| callbacks | before/after step hooks |
| termination/current time/phase | 运行态控制信息 |

### 10.1 addNodeExecution

每个 registry 节点都有一条 execution entry，即使它没有离散 task。这样，summary 可以为所有实例保存 phase 和 priority 元数据，publish 排序也能查询同一份 priority。

函数校验：

- task 必须有非 None phase；
- 非 task 不能有离散 phase；
- 非 task 不能配置 rate；
- rate 有限且非负。

Assembler 路径已经检查 rate 能否形成整数 interval，Simulator 仍会再计算一次，以支持绕过 Assembler 的 direct API。

### 10.2 哪些计划缓存，哪些运行时排序

当前实现：

- continuous plan 由 `buildContinuousPlan()` 形成并保存在 `integration_systems_`；
- publish 在每次 `publishCurrentState()` 中发现并排序 `IPublishTask`；
- discrete 在每次 `entriesFor(phase)` 中过滤并排序 execution entries；
- termination evaluator 在每次检查时发现并排序。

当前节点规模面向实验室任务，每次过滤和排序的成本较小，代码也更直接。若以后缓存 publish 或 discrete plan，必须在 assembly reset、execution metadata 变化和 direct registration 等所有路径上正确失效缓存，否则执行计划会与 registry 脱节。

## 11. 固定步长循环怎样落实时间契约

Builder 要求 `duration / dt` 为整数，Simulator 再用 `llround` 得到 `total_steps`。循环覆盖 `step = 0 ... total_steps`，因此起点和配置时长终点都属于发布点。

### 11.1 publishCurrentState

Publisher 排序：

```text
PublishPhase -> execution priority -> registry order
```

调用上下文只包含 `time_s` 和 `step`。publish 根据当前已提交状态刷新 view，不推进连续状态，也不提交 next state。

### 11.2 executeDiscretePhases

固定 phase 数组为：

```cpp
Environment,
Perturbation,
Input,
Process,
Output,
Interaction,
Evaluation
```

每个到期 task 在调用前会清空自己的 debug snapshot，然后执行 `update(StepContext)`。公开 observable 不会自动清空，慢速节点跳过更新时仍保持上次公开值。

`StepContext` 由 Simulator 在每次调用时创建。节点从上下文读取 step、时间和步长，无需依赖可变的全局时钟。

### 11.3 logger 与 termination

Logger 在离散 phases 后记录。`record_initial_state` 为 false 时跳过 step 0，其余步骤照常记录。

记录完成后，Simulator 找出全部 `ITerminationEvaluator`，按 priority 和 registry order 调用 `shouldTerminate()`。Evaluation phase task 可以在记录前更新内部判据，真正的终止接口检查发生在记录以后。

若某个 evaluator 命中，termination reason 取自它的 `reason()`；返回空字符串时，Simulator 使用节点名作为回退。

### 11.4 terminal endpoint

当 `step == total_steps` 时，循环仍会完成 publish、离散更新、记录和 termination check，然后退出。终点之后没有下一次 integration，也不会为这个发布点调用 after-step。

把循环条件改成 `< total_steps` 会直接删掉终端发布点，从而改变最终状态记录、终止边界和 summary 的 final time。若未来确实要区分 terminal observation 与 terminal control update，应先定义新的运行契约，并为两种终端行为增加回归测试。

### 11.5 callbacks

- before callback 收到 `(step=k, time=t_k, dt)`，位于 publish 后、离散更新前；
- after callback 收到当前宏步的 `step=k` 和 `time=t_{k+1}`，位于全部 continuous state 提交后；
- terminal publish 点没有后续积分，因此不会产生新的 after callback。

callback 常用于交互、联调和测试工具。修改它们的位置时，要与 publish、record 和 termination 的先后关系一起审查，避免外部工具观察到新的时刻语义。

## 12. 连续执行计划怎样形成

### 12.1 buildContinuousPlan

函数从 registry 动态发现：

```text
all IContinuousSystem
all IContinuousGroup
```

Simulator 校验每个 group 的成员，并把这些成员从独立 system 集合中排除。剩余 system 与 group 自身进入 `integration_systems_`。registry 顺序决定 plan entry 的计算顺序，但所有 next state 最后统一提交，所以计算顺序不会造成半新半旧状态可见。

### 12.2 integrateContinuousSystems

每个 plan entry：

```cpp
next_state = system->getState();
integrator_->step(
    [system](t, candidate, derivative) {
        system->computeDerivatives(t, candidate, derivative);
    },
    current_time_, next_state, dt);
pending.push_back(system, next_state);
```

全部 entry 算完以后，Simulator 才依次调用 `setState()` 提交 pending state。

Form derivative 可以根据自己的 candidate state 建立 candidate truth。它通过其它独立节点 provider 读取连续量时，通常仍得到对方已经提交的发布态。模型作者需要在接口说明和数值测试中明确这项跨系统保持语义。

### 12.3 IContinuousGroup 要承担什么责任

group 必须保证：

- `getState()` 按固定 layout 拼接当前成员状态；
- `computeDerivatives()` 只用联合 candidate 计算联合导数；
- `setState()` 一致分发给成员；
- `getInitialState()` 与 layout 相符；
- `members()` 在 bind 后稳定返回真实注册成员。

group 只接管联合状态的积分，不接管成员的 initialize、finalize、provider 接口和领域所有权。成员在 mission 中仍然是原来的 Form、Output 或其它节点。

## 13. 记录、摘要和正常收尾

### 13.1 AutoDataLogger

Logger 从 registry 中发现 `IObservable`，展开字段回调，应用 record 和 exclude 配置，然后写入 CSV。字段回调在 `recordStep(t_k)` 时读取节点当前公开状态。

observable 回调应轻量、确定，也不能推进物理状态。如果 closure 使用 mutable cache 保存最近一次 candidate 查询，维护者必须确认记录时该缓存代表哪个时刻、哪个候选点，并在字段契约中说明。

### 13.2 SimulationSummary

正常运行结束后，Simulator 先停止 logger，再写 summary。摘要内容来自：

- `SimInfo`；
- registry 节点元数据；
- Simulator `executionInfo()`；
- AutoDataLogger 统计；
- 每个 `ISummaryObserver::writeSummary()`。

项目 Summary 在 `finalize()` 前执行，因此可以读取终端运行态并计算末端指标。

### 13.3 finalize

正常路径会按 registry order 调用每个节点的 `finalize()`，用于释放运行期资源或完成正常收尾。当前实现尚未为运行期异常提供完整的强保证，partial output、summary 和 node finalize 的策略也没有统一。相关风险与建议记录在 `design-notes/2026-07-documentation-architecture-findings.md`。

## 14. 维护 Form、Interaction 与 Output 时要成套检查

### 14.1 新 Form family

一个新 Form family 进入 mission 前，至少要明确并测试：

1. 唯一 family id。
2. StateLayout、单位、坐标和奇异点。
3. 初值 schema 与 required 物理参数。
4. Truth view 及发布时间语义。
5. Form input provider。
6. `computeDerivatives()` 对 candidate state 的使用规则。
7. state owner publish 和 observable。
8. 对应 Interaction closure。
9. family mismatch、缺 provider、解析解和积分测试。

Form family 同时规定状态、truth、input 和方程闭合。只注册一个连续类，Input 与 Interaction 仍然不知道怎样连接，扩展也无法完整验证。

### 14.2 Output provider

新增质量、气动、推进或执行机构能力时，先定义语义明确的小型 provider，再判断它怎样随时间变化：

- 静态查询；
- 在 Output phase 采样更新；
- 独立连续系统；
- 需要 continuous group 的强耦合成员。

上述实现的 role 都可以保持 Output，具体运行方式由 capability 表达。这样，物理职责不会因为模型从理想响应升级为连续动态而改变。

### 14.3 Interaction query

Interaction 读取 candidate truth 和本周期保持的 provider，形成 Form input。RK 子步可能反复查询同一对象，因此 query 应像可重入的数值函数一样工作，避免：

- 推进离散状态；
- 消费事件；
- 依赖调用次数；
- 只用宏步缓存替代本应使用的 candidate truth；
- 把调试缓存作为下一次物理计算输入。

确实需要离散行为时，把状态变化放进明确的 `update()`，并单独测试 sample-hold 语义。query 继续根据显式输入计算 Form input。

## 15. Infrastructure 通过稳定查询接口接入

坐标树扩展展示了当前推荐结构：

```text
consumer interface
-> Infrastructure node owns engine
-> same-scope contributor provides domain definitions
-> prepare seals and validates graph
```

新增 frame contributor 只需：

- 注册普通 Infrastructure node；
- bind Earth/Truth 等显式依赖；
- 实现 `ICoordinateFrameContributor`；
- 在 mission 同 scope 声明 contributor 与 tree owner。

核心 Builder、Registry 和生命周期只处理普通节点与 provider，不应加入坐标专用分支。这样，关闭坐标扩展后，普通 mission 仍沿同一核心路径运行。

## 16. SimFlow 只负责 case 物化和批量执行

`SimFlowRunner` 与普通 runner 共享 catalog。流程为：

```text
parse simflow
-> create materializer from catalog
-> materialize case missions
-> serial: build/run in current process
   or multiprocess: invoke ordinary executable
-> aggregate simflow_summary.csv
```

materializer 可以改写 mission 配置和资产 URI，但不能把隐藏的 case 状态注入 Simulator。每个 case 都必须写出一份能够通过 `--config` 独立回放的 effective mission。

项目节点通过 `IPerturbationProvider` 读取 case 输入。如果 runtime 组件开始读取 SimFlow 文件路径、case index 或全局批量对象，单 case 回放就会依赖外部隐藏状态，应视为架构边界回退。

## 17. 常见修改会影响哪些位置

### 17.1 新增项目 Process/Input/Output 节点

这类项目节点通常只需要修改：

```text
user/<project>/interfaces or common
user/<project>/components
mission placement and config
project tests
```

Builder、Assembler、Simulator 和 framework bootstrap 一般无需变化。如果一个普通项目算法要求修改这些核心类，应先检查 provider 或 placement 是否已经能够表达需求。

### 17.2 新增 builtin 节点

修改：

- 对应领域目录与 provider interface；
- builtin bootstrap；
- `doc/06-reference.md`；
- 成功装配、严格配置和关键缺依赖测试。

如果能力仍在随论文或试验频繁变化，就继续留在 project，等待接口经过更多实际任务验证。

### 17.3 新增 placement 或 scope

新增 placement 或 scope 会改变 mission 的表达能力，至少涉及：

```text
ConfigManager/MissionAssembler schema
AssemblyScope/AssemblyGraph, if scope changes
PlacementKind/PlacementPolicy
ValidationPipeline
Simulator execution semantics, if applicable
mission tests and architecture guards
doc/00, doc/02, doc/03, doc/05, ADR
```

开始改 JSON 解析前，先写清新对象归谁所有、短名怎样解析、何时运行、怎样记录，以及缺席时普通 mission 会发生什么。没有这些语义，schema 很容易先于架构设计扩张。

### 17.4 修改离散时序

离散时序直接影响算法因果关系和 CSV 含义，修改时必须一起审查：

- publish order；
- callback 位置；
- phase order 和 priority；
- record 与 termination；
- terminal endpoint；
- multi-rate hold；
- CSV 和 summary 语义；
- `test_publish_semantics.cpp` 与相关 ADR。

### 17.5 修改连续积分

修改连续积分时检查：

- candidate state 是否真正进入 derivative；
- 独立系统提交是否仍同步；
- group 成员是否只推进一次；
- logger 在 plan validation 后初始化；
- 解析解、步长收敛和 coupled-vs-independent 测试。

### 17.6 增加多级资产准备

当前 prepare 按 registry order 执行，没有依赖图。producer 与 consumer 的准备链不能依赖数组顺序。若真实项目已经需要多级准备，应先定义 preparation dependency 契约、循环检测、失败诊断和缓存语义，再扩展 Pipeline。

## 18. 用测试保护各层契约

| 风险 | 代表测试 |
| --- | --- |
| mission schema、placement、family、binding | `test_mission_contract.cpp` |
| publish、record、termination、callback、priority/rate | `test_publish_semantics.cpp` |
| continuous group 与 direct registry | `test_continuous_group.cpp` |
| prepare、资产路径、缓存、effective path | `test_preparation_pipeline.cpp` |
| 严格节点配置 | `test_strict_config.cpp` |
| outputs 与 logger | `test_auto_data_logger.cpp` |
| SimFlow materialize/run/replay | `test_simflow_materializer.cpp`, `test_simflow_runner.cpp` |
| optional coordinate extension | `test_coordinate_tree_node.cpp`, builder tests |
| 对象模型与源码边界 | `test_architecture_guards.cpp` |
| 四种 baseline 端到端 | `test_ideal_*_mission.cpp` |

### 18.1 成功和失败都要测试

架构契约既规定成功路径，也规定错误应在什么阶段出现。新增 builtin 至少覆盖：

- 成功装配和一次可观察运行；
- unknown/required 配置；
- 错误 placement 或 role/phase；
- required dependency 缺失或接口不符；
- family mismatch；
- 非法 rate；
- 资产缺失或格式错误。

### 18.2 architecture guards 的定位

源码扫描护栏保护宏观结构，例如旧对象体系保持删除、Builder 不包含具体扩展、Graph 和 Policy 仍是统一规则来源。它可以阻止明显的结构回退，但无法证明运行行为正确，所以仍需配套行为测试。

护栏规则应尽量具体，避免注释或合法新名称造成大量误报。规则一旦经常误报，维护者就容易忽略真正的边界回退。

## 19. 诊断要把错误带回具体 mission 位置

一条有用的失败信息应尽量包含：

- mission 路径，例如 `vehicles[0].form.components[0].config.initial_state.altitude_m`；
- 完整实例名与 type id；
- 当前 scope 与解析后的依赖名；
- 期望 role/phase/family/interface；
- 可用候选和近似名称；
- 原始资产错误。

如果框架宽松猜测物理字段，拼写错误可能变成一次看似有效的运行。`integrator = rk4` 这类安全默认值可以保留；初值、质量、气动表和控制表等物理参数应保持显式 required，让缺失和拼错尽早失败。

## 20. 第一次接手时做一轮小实验

第一次接手无需立即修改核心代码。先完成下面一轮小实验，把文档中的约定与实际行为对应起来：

1. 运行 active project 和四个 baseline 中最相关的一个。
2. 阅读 `summary.txt`，从实例清单追到注册 type 和 mission placement。
3. 用 CSV 前两行验证 `x_0 -> update(t_0) -> x_1`。
4. 给一个 required dependency 故意写错名称，观察 build 诊断。
5. 给一个 Process 节点设置合法慢速 rate，核对 step interval 和保持输出。
6. 阅读一个 Form 的 publish/derivative 与一个项目 Interaction 的 candidate query。
7. 运行 continuous group 测试，理解独立积分和联合 RK 的差别。
8. 关闭坐标扩展构建一次普通 mission，确认可选边界。
9. 阅读 `doc/07-decisions.md`，确认准备修改的边界是否已有 ADR。
10. 查看 `design-notes/` 中未决问题，避免重复设计。

完成这些步骤后，再开始处理核心变更。若改动只服务当前论文或试验，优先在 `user/<project>` 建立 typed contract 和验证证据，让 framework 继续保持稳定。

## 21. 当前已知改进议题

正式文档描述当前已经生效的运行契约。本次源码核对中发现的实现风险和改进选项单独记录在：

- `design-notes/2026-07-documentation-architecture-findings.md`

其中包括 per-vehicle Form 完整性、同 phase 顺序、初始化边界、runtime 异常收尾、terminal update 和 baseline Interaction 诊断等问题。这些条目仍等待维护者决定优先级与兼容策略，不能当作当前实现已经承诺的行为。
