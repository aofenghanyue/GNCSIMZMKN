# 核心概念：从 GNC 信号到框架节点

在 GNCZMKN 中，mission 负责说明一次实验包含哪些对象、参数、连接和观测项，C++ 节点负责实现具体模型与算法。框架把两者装配起来，并统一处理生命周期、依赖绑定、离散调度、连续积分、记录和终止。

本章从一条常见的 GNC 控制链讲起。我们先区分真实状态、测量、估计、命令和物理响应，再看这些量怎样分配给 Form、Input、Process、Output 与 Interaction。后半章继续介绍节点名称、作用域、调度和连续耦合。读完以后，你应该能从 mission 中的一个节点追到对应 C++ 类型，也能根据一行 CSV 判断状态和命令的先后关系。

仓库中的 `ideal` baseline 主要用来演示节点接线和时间契约，物理模型有意保持轻量。读懂框架只能说明仿真怎样运行；模型能否支持某项研究结论，还需要数值与数据证据。相关方法见 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。

## 1. 为什么要把仿真拆成多个节点

GNC 研究很少只改一个公式。随着项目推进，下面几类内容往往会同时变化：

- 飞行器状态方程和坐标表达可能变化；
- 传感器、导航、制导、控制算法以不同频率更新；
- 气动、推进、质量和执行机构模型逐步提高保真度；
- 初值、参数、资产集合和随机扰动形成大量 case；
- 研究者需要复现实验，也需要频繁替换局部算法。

如果把这些内容都写进一个全局仿真对象，早期原型可能很快就能运行。几轮修改以后，维护困难会逐渐显现：研究者很难确认某个状态由谁推进，替换一段算法可能牵动许多无关代码，输出曲线也难以追溯到当时使用的参数与执行顺序。

GNCZMKN 将这些问题分给几套彼此关联的结构来处理：mission 保存本次实验的选择，catalog 保存当前程序可创建的类型，构建阶段负责检查连接，Simulator 负责时间推进。

```mermaid
flowchart LR
    Question["研究问题"] --> Mission["mission<br/>实例、参数、连接、记录"]
    Code["C++ 类型<br/>模型与算法"] --> Catalog["FrameworkCatalog<br/>当前程序可用定义"]
    Mission --> Build["构建期<br/>创建、校验、绑定、准备"]
    Catalog --> Build
    Build --> Runtime["运行期<br/>发布、离散更新、记录、积分"]
    Runtime --> Evidence["CSV / summary / effective mission"]
    Evidence --> Conclusion["有边界的研究结论"]
```

这样的分工有两个直接作用。第一，实验条件留在 mission 中，别人可以看见并复用；第二，节点放错位置、依赖缺失或调度无效等问题会在物理时间开始推进前暴露。运行阶段面对的是已经完成检查的节点集合，因此不需要一边积分一边猜测配置意图。

## 2. 先看懂一条真实的闭环

打开 `user/example_05_ideal_3dof_geographic_baseline/config/mission.json`，拦截器的主要链路可以概括为：

```mermaid
flowchart LR
    Form["dynamics<br/>Form truth"] --> Input["imu / satnav / air_data / seeker<br/>Input measurement"]
    Target["target.truth"] --> Input
    Env["earth / atmosphere / gravity"] --> Input
    Input --> Process["navigation / tracking / guidance<br/>flight_control / allocation"]
    Process --> Output["actuator / aero / propulsion / mass"]
    Form --> Interaction["interaction<br/>Form input provider"]
    Env --> Interaction
    Output --> Interaction
    Interaction --> Form
```

图中的箭头构成一条控制链，但每一层处理的数据含义不同。把这些含义分清，是阅读整个框架的起点。

### 2.1 Truth、Measurement、Estimate、Command 与 Response

| 信号 | 例子 | 典型所有者 | 它回答什么 |
| --- | --- | --- | --- |
| Truth | 真实位置、速度、姿态、角速度 | Form | 仿真世界当前处于什么物理状态 |
| Measurement | IMU、卫导、空速、导引头输出 | Input | 机载硬件在当前采样时刻看到了什么 |
| Estimate | 导航解、目标航迹 | Process | 算法认为当前状态是什么 |
| Reference / Mode | 参考轨迹、飞行阶段、目标分配 | Process | 当前任务希望系统做什么 |
| Command | 过载、姿态、攻角、舵偏、油门 | Process | 算法本周期发出了什么指令 |
| Physical response | 舵机状态、推力、质量、气动力矩 | Output | 飞行器能力怎样响应当前命令 |
| Form input | 加速度、力、力矩或其它导数输入 | Interaction | 当前状态方程需要哪些闭合量 |

本文中的 provider 指一个小型 C++ 查询接口。提供数据的节点实现接口，使用数据的节点在 `bind()` 中取得接口引用。这样，消费者只依赖数据语义，可以在 builtin 和项目实现之间替换具体节点。

closure 指补齐运动方程所需输入的计算。例如，Form 需要加速度或力矩，Interaction 就要把气动、推力、质量、重力和舵机状态组合成相应的 Form input。

理想传感器可以让 Measurement 直接复制 Truth，理想执行机构也可以让 Response 瞬时跟随 Command。即便采用这些简化，框架仍保留各层接口。以后加入噪声、偏置、延迟、饱和或连续动态时，只需替换相应实现，测量和物理响应的含义不会随之混淆。

### 2.2 这个 baseline 能证明到哪一步

`example_05` 使用 `ideal` Input 和 Process，可以用来检查各层接口是否已经接通。它的内建 `interaction.local_spherical_3dof.standard` 返回配置中的占位加速度，`zero` 气动和推进也明确输出零。因此，替换制导节点以后，CSV 中的制导指令会发生变化；只有当 Output 与 Interaction 继续把指令转换成真实加速度时，轨迹才会产生相应响应。

可以把证据分成三个层次。看到算法输出，说明节点已经运行并进入记录链；状态按照命令的方向和数量级变化，说明控制量已经进入运动方程；要进一步得到研究结论，还要验证数值误差、模型数据和适用范围。

## 3. 领域边界及其设计作用

### 3.1 Form：推进运动状态并发布 truth

Form 规定某一类运动状态怎样表示和推进。一个 Form family 会同时给出状态布局、初值、导数方程、truth view 和 Form input 契约。例如：

- Cartesian 3DoF：位置与速度；
- local-spherical 3DoF：经纬高、速度、弹道倾角与航向；
- Cartesian/local-spherical 6DoF：平动、姿态和角速度；
- target point：目标运动学状态。

有了这条边界，阅读者可以明确知道运动方程正在推进哪些量。导航估计和制导命令由 Process 保存，不会和真实位置、速度或姿态混进同一个隐含状态向量。连续舵机、燃料或其它 Output 可以拥有自身的连续内部状态，但不会重复保存 Form 已经负责的位置、速度或姿态 truth。

新增 Form family 时，需要同时定义状态坐标、单位、truth、input、发布时间和方程闭合方式。只加入一个微分方程类，读者仍然不知道输入从哪里来，也无法确认输出怎样解释，family 契约仍不完整。

### 3.2 Environment：只读世界查询

Environment 提供地球、大气和重力等世界模型。调用者通常用位置、高度和时间查询它。Environment 不保存某架飞行器的运动状态，也不决定任务如何推进。

多个 vehicle 因此可以共享同一套世界定义。Environment 也容易单独测试：给定相同的查询位置和时间，模型应返回确定的环境样本。

### 3.3 vehicle.common：静态资产和只读数据产品

气动表、标准轨迹、静态 profile 和预处理后的大数据产品放在 `vehicle.common`。这些内容会在构建期加载和检查，运行时再通过只读 provider 共享给其它节点。

把资产和运行时 Output 分开以后，同一套气动表可以供不同的气动计算节点使用。文件缺失、格式错误或插值区间无效等问题也能在仿真开始前报告。

### 3.4 vehicle.input：测量侧边界

Input 表示传感器和输入硬件链路。它负责把 truth 转换成机载算法能够读取的测量，并可在这个过程中加入噪声、漂移、采样保持、延迟、失锁和量化。

导航算法通常读取 Input provider。如果某个理想导航节点直接绑定 Form truth，项目说明应把它列为明确的理想化或测试 fixture，以免把真值反馈误解为传感器与导航系统的实际性能。

### 3.5 vehicle.process 与 mission.process：决策和算法

vehicle Process 处理单架飞行器的导航、跟踪、规划、制导、控制、控制分配、模式管理和事件逻辑。mission Process 管理跨飞行器协调、试验阶段、任务规划，以及整个任务共用的模式状态。

如果一个 PID、滤波器或局部状态机只服务于某个节点，把它写成普通 C++ 成员通常更简单。等到它需要独立配置、独立记录、单独调度，或者需要被多个消费者读取时，再把它做成 Process 节点。

### 3.6 vehicle.output：运行时物理能力

Output 描述飞行器在运行时具有的物理能力，包括质量、气动、推进、执行机构、构型切换和其它力源。它接收或查询算法命令，并给出运动方程能够使用的物理响应。不同 Output 可以采用静态查询、离散更新或连续积分。

例如，常质量节点只需提供查询；理想舵机可以在 Output phase 直接更新；带宽和速率受限的舵机则可以保存连续状态，并由积分器推进。它们在物理职责上都属于 Output，具体运行方式由 capability 表达。

### 3.7 Interaction：把物理能力闭合为方程输入

Interaction 与具体 Form family 配对。它读取当前候选 truth、Environment 查询、Process 保持的命令和 Output provider，然后计算该 Form 导数所需的 input。

以 RK4 为例，Form 会在一个宏步内用多个候选状态查询 Interaction。只做方程闭合的 Interaction 通常实现 input provider 即可，无需离散 `update()`。如果闭合过程还包含采样、离散模式或周期缓存，可以增加 `IDiscreteTask`；实现时要把离散保持状态和 RK 候选状态查询分开。

气动表、质量定义和推进资产仍由 common 或 Output 管理。Interaction 只负责按 Form 契约组合这些物理量并完成必要的坐标转换。这样可以让气动、推进和质量模型各自测试，也能防止 Interaction 逐渐变成难以维护的总模型。

### 3.8 Perturbation、Infrastructure 与记录

- Perturbation 保存某个 vehicle 已经物化的 case 拉偏状态。运行节点只读取它的 provider，无需解析 SimFlow 文件。
- Infrastructure 提供坐标树等稳定、可选的跨领域查询能力。任务决策和物理方程闭合仍由相应领域节点承担。
- 记录层通过 Observable、Logger 和 Summary 读取已有数据，负责写入 CSV、debug snapshot 和 summary。它只观察模型，不重新定义物理量。

### 3.9 三组容易混淆的名字

| 名字 | 真实含义 | 不要混成 |
| --- | --- | --- |
| `vehicles[].input[]` | 传感器与测量侧硬件 | Form input：导数方程所需的闭合量 |
| `vehicles[].output[]` | 质量、气动、推进、执行机构等运行时物理能力 | 顶层 `outputs`：CSV 与调试记录配置 |
| observable | 一个节点愿意公开给记录器的视图 | 模型状态所有权；公开字段不会自动成为 truth |

可以用一条信号路径记住这几个名称：测量侧 Input 进入算法，算法命令交给物理 Output，Interaction 再把物理响应转换成 Form input。顶层 `outputs` 位于这条路径之外，只配置要观察和保存哪些数据。

## 4. 从七个方面看一个节点

geographic 3DoF baseline 中的制导条目为：

```json
{
  "type": "vehicle.process.local_spherical_guidance_3dof.ideal",
  "name": "guidance",
  "config": {}
}
```

这个条目位于 `vehicles[0].process[]`，所在 vehicle 的 id 是 `interceptor`。要完整说明它在框架中的身份，需要同时回答七个问题：

| 角度 | 本例 | 回答的问题 |
| --- | --- | --- |
| Type | `vehicle.process.local_spherical_guidance_3dof.ideal` | catalog 创建哪个 C++ 实现 |
| Local name | `guidance` | 本 scope 内怎样引用它 |
| Full name | `interceptor.guidance` | 全 mission 中的唯一实例名 |
| Placement | `vehicles[].process[]` | mission 把它放在哪个语义槽位 |
| Scope | Vehicle：`interceptor` | 它归谁所有，短名在哪里解析 |
| Role | Process | 它承担哪类领域职责 |
| Capability / Phase / Family | `IDiscreteTask` / Process / `local_spherical_3dof` | 怎样运行、何时运行、适配哪类 Form |

这些信息互相配合，却各自承担不同职责。mission 的位置决定实例归属，注册元数据说明类型具有什么能力，ValidationPipeline 再检查两边能否组成合法节点。

```mermaid
flowchart LR
    Type["registered type"] --> Meta["role / phase / family / interfaces"]
    Placement["mission placement"] --> Policy["PlacementPolicy"]
    Placement --> Scope["AssemblyScope"]
    Scope --> FullName["完整实例名"]
    Meta --> Validation["ValidationPipeline"]
    Policy --> Validation
    FullName --> Validation
```

替换制导算法时，通常可以保留 `name = guidance` 和原有 provider 接口，只更换 `type`。下游飞控仍然绑定同一个实例名，因此算法实验不会迫使整条 mission 一起改名或重新接线。

### 4.1 Role 与 Capability 的差别

Role 说明节点在 GNC 模型中负责什么，Capability 说明 Simulator 怎样使用它。

| 节点 | Role | 可能的 Capability |
| --- | --- | --- |
| 球形地球 | EnvironmentModel | `IEarth` 查询 |
| 刚体 Form | Form | `IPublishTask + IContinuousSystem + ITruthView` |
| 导航 | Process | `IDiscreteTask + INavigationProvider` |
| 常质量 | Output | `IMassProvider` |
| 连续舵机 | Output | `IContinuousSystem + IActuatorProvider` |
| 坐标树 | Infrastructure | `ICoordinateTransform` |

同一种 Role 可以对应不同 Capability。常质量和连续舵机都属于 Output，但前者只提供查询，后者还要进入连续积分。框架据此只调度节点真正实现的行为，静态节点无需提供空 `update()`，连续节点也不会因为 placement 而被当成离散任务。

### 4.2 Form family 的作用

Form family 给一组状态、truth 和 input 契约命名。例如，`cartesian_3dof` 与 `local_spherical_3dof` 使用不同的状态坐标，也需要不同的 input interface。

每个 vehicle 只选择一个 family。Form 与 Interaction 必须声明非空 family；如果 Input、Process、Termination 或 Summary 依赖某个 family 的专用接口，它们的元数据也要与该 vehicle 相符。这样，Cartesian 节点误接 geographic truth 等问题会在构建时被发现。

## 5. 什么时候需要创建节点

### 5.1 普通 C++ 对象

PID、滤波器、插值器、优化器、事件检测器和局部状态机经常只被一个节点使用。满足下面这些条件时，把它们保留为普通 C++ 对象即可：

- 只有一个拥有者；
- 无需独立 mission 名称、配置、记录和调度；
- 其它节点无需按接口查找它。

普通对象的生命周期由宿主节点管理。mission 中少一个独立实例，配置和注册元数据也会相应减少，项目更容易阅读。

### 5.2 Typed interface 与数据产品

跨节点传递的数据需要一个明确的小型接口，例如 `INavigationProvider`、`IAerodynamics`、`IInputProvider`，也可以是只读气动表数据产品。

接口要写清数据的语义、单位和所有者，但不承担框架生命周期。消费者只依赖接口以后，具体实现就能在 builtin 和 project 节点之间替换。

### 5.3 SimulationNode

需要在 mission 中独立装配的对象继承 `SimulationNode`。它会拥有自己的名称和配置，参加依赖绑定、准备、初始化与终结，并按需组合运行 capability。

每增加一个节点，mission 和运行图中都会多出一个需要理解的实例。只有当独立配置、所有权、观测或调度确实有研究价值时，创建节点才有意义。

## 6. 一份 mission 会形成六张关系图

节点装配完成后，框架需要同时回答“归谁所有”“谁读取谁”“何时执行”和“连续状态怎样共同积分”等问题。代码中没有用一张万能图承载所有关系，而是分别保存六类拓扑。每张图只记录一种事实：

| 拓扑 | 记录位置 | 解决的问题 |
| --- | --- | --- |
| 所有权与命名 | `AssemblyGraph` | 节点属于 mission、environment 还是某个 vehicle |
| placement 约束 | `NodeDescriptor + PlacementPolicy` | mission 位置与 scope、role、phase、capability 是否形成合法组合 |
| 依赖与数据 | `bind(AssemblyContext&)` + typed provider | 谁读取谁，短名怎样解析 |
| 离散执行 | `DiscretePhase + priority + rate_hz` | 一个采样周期内何时更新 |
| 连续耦合 | 独立 `IContinuousSystem` 与 `IContinuousGroup` | RK 候选状态在哪个范围共享 |
| 扩展组合 | `FrameworkCatalog` | 当前可执行程序包含哪些类型、积分器和物化器 |

### 6.1 连接关系不会自动决定执行顺序

导航节点绑定卫导 provider，只能确认它有权读取相应接口。这条连接没有说明节点每秒更新多少次，也没有说明同一 Process phase 中两个算法谁先运行。

`bind()` 用于检查依赖是否完整，phase、priority 和 rate 用于表达运行时的因果顺序。如果两个项目节点在同一 phase 内构成生产者和消费者，应给它们设置不同的 priority。相同 priority 下保留注册顺序，只是为了让结果确定，不宜用来隐藏重要的数据先后关系。

### 6.2 C++ 指针也不能说明 RK 子步怎样耦合

两个连续节点即使互相持有 provider 指针，也只能在普通查询中读取对方已经发布的状态。RK 子步能否读取对方当前的候选状态，取决于它们是否加入同一个 `IContinuousGroup`。

这是一项数值离散化选择，需要由模型作者显式声明，并通过步长或联合模型对比验证。普通 C++ 指针关系无法替代这份声明。

## 7. Scope、名称与依赖

当前有三种 scope：

```text
mission.                 任务级节点、termination、summary
env.                     环境模型与环境基础设施
<vehicle-id>.            某个 vehicle 的 Form 和 GNC 链
```

一个典型 mission 的所有权树：

```text
mission
├── environment          -> env.*
├── vehicle:interceptor  -> interceptor.*
└── vehicle:target       -> target.*
```

短名会在当前 scope 中补上前缀。举例来说，`interceptor` scope 内的 `guidance` 会解析成 `interceptor.guidance`。名称中已经含有点号时，框架把它当作完整名，所以 `env.earth` 和 `target.truth` 可以用于跨 scope 绑定。

父 scope 只记录所有权并帮助生成诊断，不会触发隐式向上查找。于是，一个短名在当前 scope 中只有一种解释；后来新增 mission 节点，也不会悄悄改变已有 vehicle 的依赖目标。

绑定时常用三类 API：

- `requireByName<T>()`：模型成立所必需的依赖；缺失或接口不符时 build fail。
- `tryGetByName<T>()` / `bindIfPresent()`：物理模型允许缺席并定义了降级行为。
- `getAllInScope<T>()`：收集同 scope contributor 等扩展点。

MissionAssembler 会先注册全部节点，随后统一调用 `bind()`，因此 JSON 数组顺序不会影响依赖可见性。数组顺序仍可能成为同 phase、同 priority 时的执行兜底顺序。阅读 mission 时要把“能否找到依赖”和“运行时谁先执行”分别检查。

## 8. 生命周期：先把配置和资产准备好

普通 mission 的完整路径为：

```text
for each entry: construct -> configure -> register
-> after all entries are registered
-> validate metadata and bind all dependencies
-> prepare all nodes
-> validate continuous execution plan and initialize logger
-> initialize runtime state
-> run
-> finalize
```

| 阶段 | 应做什么 | 为什么放在这里 |
| --- | --- | --- |
| `configure` | 读取本节点字段，检查类型、单位和局部约束 | 配置错误指向具体 mission 路径 |
| register | 写入完整名、类型元数据与接口 | 建立全局可查的实例集合 |
| `bind` | 保存 required/optional provider 引用 | 在运行前验证连接，摆脱 JSON 书写顺序 |
| `prepare` | 加载、校验、预处理静态资产 | 把文件 I/O 和昂贵准备移出时间循环 |
| `initialize` | 建立运行态初值 | 此时所有 prepare 已完成 |
| `publish` | 刷新当前状态的 truth/view | 建立统一的周期边界观察点 |
| `update` | 在采样时刻生成并保持离散输出 | 表达数字 GNC 与硬件采样语义 |
| `finalize` | 正常运行结束时收尾 | 释放运行期资源 |

`bind()` 可能在诊断或 direct Simulator 路径中被再次调用，所以它应保持幂等，只保存接口引用，不推进状态。

当前 PreparationPipeline 没有依赖 DAG。producer 应在自己的 `prepare()` 中生成只读产品；等所有节点准备完成后，consumer 再在 `initialize()` 或运行阶段读取。consumer 如果在自己的 `prepare()` 中假定另一个节点已经准备好，就会暗中依赖注册顺序。

`SimulationBuilder::build()` 会完成依赖绑定、资产准备、连续计划校验和 logger 初始化，然后返回一个尚未进入运行态的 Simulator。调用 `Simulator::run()` 后，节点才执行 `initialize()`，随后开始第一个发布周期。

## 9. 一个固定步长周期怎样运行

固定步长循环可以从发布时刻 `t_k` 开始理解。Simulator 先让所有观察者看见同一时刻的状态，再执行本周期的离散任务，记录结果，最后把连续状态积分到下一时刻。

```text
publish/refresh t_k
-> before_step(t_k)
-> discrete update(t_k)
-> record t_k
-> stop check t_k
-> integrate to t_{k+1}
-> after_step(t_{k+1})
```

### 9.1 Publish phase

发布顺序为：

```text
StateOwner -> View -> Ordinary
```

Form 通常在 StateOwner phase 刷新 truth，后续 view 因而可以读取同一时刻已经发布的状态。priority 只比较同一个 publish phase 内的节点，不能改变三个 phase 的先后关系。

`publish()` 只根据当前状态刷新派生视图，不计算或提交连续 next state。如果 truth 包含加速度等依赖命令的量，此时能查询到的是边界时刻已经保持的命令或物理能力。本周期的新命令要等离散链运行以后才会产生。

### 9.2 Discrete phase

固定顺序为：

```text
environment -> perturbation -> input -> process
-> output -> interaction -> evaluation
```

这个顺序对应常见的数字控制过程。环境和 case 拉偏先更新，传感器随后采样，算法根据测量作出决策，执行机构及其它物理能力再响应命令，最后由 Interaction 和 Evaluation 完成本周期剩余工作。

只有实现 `IDiscreteTask` 的节点才进入离散 phase。静态 Environment、常质量、纯 closure 和纯连续 Form 没有离散更新，因此可以注册 `phase = none`。

### 9.3 Priority 与多速率

同一 phase 内，priority 数值较小的节点先执行。`rate_hz` 会按下面的关系转换成整数 step interval：

```text
step_interval = (1 / dt) / rate_hz
```

节点只在 `step % step_interval == 0` 时更新，两次更新之间继续保持上一次输出。框架不会把非整数间隔自动取整。例如，把 30 Hz 算法放进 100 Hz 基准步时，模型作者需要先明确真实采样策略，简单 round 会引入没有写进配置的时序误差。

### 9.4 CSV 行与停止条件

默认情况下，一行 CSV 按下面的规则解释：

- `time = t_k`；
- Form 状态字段来自 `x_k`；
- 其它字段在离散 phases 后读取；到期 task 暴露本周期新输出，跳过本步的慢速 task 暴露上次保持值，静态或连续节点暴露自身当前查询状态；
- `t_0` 行包含初始状态和由初始状态得到的首周期输出；
- 终止判断位于记录之后；默认配置下，命中状态保留为最后一行；
- 配置 `record_initial_state = false` 时会主动跳过 `t_0` 记录。

同一行适合查看“当前状态产生了什么命令”。要分析命令造成的状态变化，还要把该行命令与 `t_{k+1}` 的状态放在一起比较。

## 10. 连续积分为什么还要区分候选状态

`IContinuousSystem` 提供状态布局、当前状态、初值、导数计算和状态提交。对每个独立系统，Simulator 会完成下面四步：

1. 从相同的 `t_k` 状态复制候选向量。
2. 让积分器在该系统内部计算 RK 子步。
3. 暂存每个系统的 next state。
4. 全部计算完成后统一 `setState()`。

所有系统算完以后才统一提交，这样后计算的系统不会在同一个宏步中读到另一个系统已经提前提交的 `x_{k+1}`。独立系统之间通过普通 provider 查询时，默认看到的是宏步边界的发布态。

### 10.1 Interaction 在 RK 子步中的位置

积分器调用 `computeDerivatives(time, candidate_state, derivative)` 时，Form 可以从 `candidate_state` 建立候选 truth，再查询 Form input provider。RK4 会产生多个候选点，因此纯 Interaction 在一个宏步内可能被调用多次。

Interaction 可以读取本周期已经更新并保持的离散命令，同时根据 candidate truth 重新计算与状态有关的气动、重力或坐标量。查询函数应对相同输入给出相同结果，也不能顺手推进离散状态。

### 10.2 何时使用 IContinuousGroup

当多个连续成员必须在 RK 子步共享候选状态时，需要显式增加 group：

- group 是联合 `IContinuousSystem`；
- `members()` 声明被接管的已注册成员；
- Simulator 排除成员的独立积分；
- group 负责拼接状态、计算联合导数和分发结果。

vehicle group 只能接管同一 vehicle 中的成员，mission group 可以描述跨 scope 耦合。空成员、嵌套 group、未注册成员和重复归属都会在 logger 打开前让构建失败。

独立积分和 group 会给跨系统候选状态带来不同语义，因此这是一项数值建模决定。项目应通过步长收敛和联合模型对比说明当前选择是否足够。

## 11. Catalog 与可选扩展

`FrameworkCatalog` 汇集当前可执行程序能够使用的三类定义：

- Node type 与 role/phase/family/interface 元数据；
- Integrator type；
- SimFlow materializer type。

runner 依次注册 framework builtins、linked extensions 和 active project。重复 type id 会立即报错。`SimulationBuilder` 只读取 catalog，不包含具体坐标扩展或项目节点的头文件，因此核心构建流程不会随项目切换而变化。

坐标树可以用来理解可选扩展怎样接入：

- tree owner 是 Infrastructure node；
- frame 定义由同 scope contributor 提供；
- consumer 依赖 `ICoordinateTransform`；
- 未链接或 mission 未配置时，普通 Form/GNC/积分链仍可运行。

仍在随论文或试验频繁变化的模型通常留在 `user/<project>`。只有当它经过多个真实任务验证、接口已经稳定，而且缺少该能力时普通任务仍有清楚行为，才适合考虑移入 framework 或 linked extension。

## 12. SimFlow 与单 case 内核

SimFlow 在普通仿真开始前工作：

```text
simflow.json
-> materialize cases
-> effective_mission.json
-> ordinary SimulationBuilder
-> ordinary Simulator
```

运行节点只读取 `vehicles[].perturbation` 暴露的解析后状态，不接触 case index、SimFlow 路径或批量调度器。

每个 case 因而都有一个普通 mission 回放入口，单次仿真内核也无需理解批量任务。使用相同的 effective mission、代码和资产时，确定性模型应得到相同结果；如果模型使用随机数，还要保存显式 seed。

## 13. 为新逻辑选择位置

遇到一段新逻辑时，先判断它代表连续状态、采样输出、物理能力、方程闭合还是记录，再判断它是否需要独立名称和生命周期。

| 问题 | 推荐位置 |
| --- | --- |
| 它会被积分器推进吗？ | Form、连续 Output，或由 Coupling group 接管的连续节点 |
| 它在采样时刻生成并保持吗？ | Input、Process、离散 Output 或离散 Interaction |
| 它是气动、质量、推进或执行机构能力吗？ | `vehicle.output`，静态资产放 `vehicle.common` |
| 它把力、环境和命令组合成状态方程输入吗？ | form-specific Interaction |
| 它协调多个 vehicle 或整个试验吗？ | `mission.process` |
| 它只服务一个节点吗？ | 普通 C++ 成员 |
| 它是稳定、可选、跨领域查询能力吗？ | Infrastructure 或 linked extension |
| 它只负责记录吗？ | Observable、debug snapshot、Summary |

最后再检查它是否需要独立的 name、config、binding、prepare、record 或 schedule。如果这些能力都用不到，把逻辑留在宿主节点的普通 C++ 对象中，代码通常更容易理解。

## 14. 容易造成误判的几种情况

### “组件数组顺序已经表达依赖”

所有节点会先注册再统一 bind，因此依赖可见性与数组顺序无关。数组顺序只在同 phase、同 priority 时充当执行兜底。真正影响算法结果的因果链应使用显式 priority。

### “用了 RK4，整个模型就是四阶精度”

RK4 的阶数结论建立在导数函数满足相应光滑条件等前提上。跨独立系统的发布态保持、离散采样、事件和表格插值都会改变整个仿真的误差表现，因此还需要步长研究。

### “ideal baseline 的轨迹可以直接作为性能基准”

`ideal`、`zero` 和部分 `standard` 组件主要帮助验证接线。研究性能还需要项目侧的物理 closure、非理想传感器与执行机构、步长验证和模型数据依据。

### “Interaction phase 一定会产生 Form input”

纯 closure 可以没有离散 phase，Form 会在 publish 和 RK 子步中直接查询它。只有实现 `IDiscreteTask` 的 Interaction 才会进入 Interaction phase。

### “optional binding 可以让任务更健壮”

optional 依赖适用于模型已经定义清楚缺席行为的情况。如果质量、truth 或坐标能力本来就是方程成立的前提，把它改成 optional 会让原本可以在构建期发现的错误拖到运行时，甚至产生静默的错误结果。

## 15. 用这些问题检查理解

读完本章后，可以尝试不看正文回答下面的问题：

1. `interceptor.guidance` 的完整名怎样形成，换 type 后为什么下游还能继续连接？
2. `interceptor.navigation` 与 `interceptor.guidance` 同属 Process phase 时，怎样保证当前导航先于当前制导？
3. CSV 的 `t_k` 行中，Form 状态和 guidance 命令各来自哪个运行阶段？
4. 为什么连续舵机可以属于 Output role，同时没有 Output phase 的离散 update？
5. Form 在 RK4 子步查询 Interaction 时，哪些量是候选状态，哪些量是本周期保持输出？
6. 两个连续节点互相绑定后，为什么仍可能需要 `IContinuousGroup`？
7. 替换 ideal guidance 后轨迹没有变化，应沿哪条闭环检查？

随后可以按照当前任务继续阅读：

- 从 JSON 追踪完整实验：[Mission 配置](03-mission-configuration.md)
- 建立研究可信度：[研究级 GNC 仿真方法](08-research-simulation-methodology.md)
- 查看全局构建与运行拓扑：[当前运行架构](00-current-architecture.md)
- 写第一个项目节点：[扩展指南](04-extension-guide.md)
- 接手源码维护：[维护者架构说明](05-architecture.md)
