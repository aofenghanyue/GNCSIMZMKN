# SimFlow 教程

SimFlow 用来生成并执行一组仿真 case。开始批量运行前，需要先有一份能够单独运行的 base mission。SimFlow 把每个 case 的输入写入这份 mission，为每个 case 生成独立的 `effective_mission.json`，再调用普通仿真内核逐个运行。

`effective_mission.json` 保存当前 case 的最终配置和显式资产 URI，因此可以直接交给 `--config` 回放。完整研究复现还需要代码版本、资产版本、构建选项、随机规则和指标定义，详见 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。

本文先带你运行仓库中的 single 示例，再解释 base mission、case source、并发、汇总和失败处理。完成教程后，你可以用普通 `--config` 独立回放任意一个已经物化的 case。

## 1. 先理解边界

```mermaid
flowchart LR
    S["simflow.json<br/>case 生成规则"] --> M["materializer"]
    B["base mission<br/>完整单次仿真"] --> M
    C["single / CSV / random<br/>case 数值"] --> M
    M --> E1["case 1<br/>effective_mission.json"]
    M --> E2["case 2<br/>effective_mission.json"]
    E1 --> R1["普通 SimulationBuilder + Simulator"]
    E2 --> R2["普通 SimulationBuilder + Simulator"]
    R1 --> O1["case 1 CSV + summary"]
    R2 --> O2["case 2 CSV + summary"]
```

阅读这张图时，可以把职责分成三层：

| 层次 | 保存什么 | 不承担什么 |
| --- | --- | --- |
| Base mission | 模型、算法、初值、资产、记录和停止条件 | 批量 case 列表 |
| SimFlow | case 来源、输入映射、输出目录和并发执行 | 单次仿真的时间推进 |
| Perturbation provider | 已物化的本 case 输入 | SimFlow 文件路径、case index、批量状态 |

每份 effective mission 都符合普通 mission 的运行契约。保存批量实验时，应把对应的 `effective_mission.json` 和结果放在一起，它就是该 case 最直接的配置回放入口。

## 2. 跑通仓库中的 single 示例

仓库的 YYZ 项目包含三份现成配置：

```text
user/yyz_cartesian_6dof_framework_9/simflow/single.json
user/yyz_cartesian_6dof_framework_9/simflow/matrix.json
user/yyz_cartesian_6dof_framework_9/simflow/random.json
```

这些配置引用 YYZ 的项目节点。先用独立构建目录选择该 active project：

```powershell
cmake -S . -B build-mingw-yyz -G "MinGW Makefiles" `
    -DGNC_ACTIVE_PROJECT=yyz_cartesian_6dof_framework_9 `
    -DBUILD_TESTS=OFF
cmake --build build-mingw-yyz -j 4
```

先确认 base mission 自己能够运行：

```powershell
build-mingw-yyz\bin\gnc_sim.exe --config user/yyz_cartesian_6dof_framework_9/config/mission.json
```

再运行单 case SimFlow：

```powershell
build-mingw-yyz\bin\gnc_sim.exe --simflow user/yyz_cartesian_6dof_framework_9/simflow/single.json
```

输出位置由 `single.json` 指定。检查生成物：

```powershell
Get-ChildItem user/outputs/yyz_cartesian_6dof_framework_9/simflow_single
Import-Csv user/outputs/yyz_cartesian_6dof_framework_9/simflow_single/simflow_summary.csv
```

目录结构应包含：

```text
simflow_single/
├── simflow_summary.csv
└── case_000001_nominal/
    ├── effective_mission.json
    ├── <session_name>.csv
    └── summary.txt
```

汇总行中的 `case_id` 应为 `nominal`，`status` 应为 `succeeded`，`exit_code` 应为 `0`。

确认汇总结果后，再用普通 mission 命令复现这个 case：

```powershell
build-mingw-yyz\bin\gnc_sim.exe --config user/outputs/yyz_cartesian_6dof_framework_9/simflow_single/case_000001_nominal/effective_mission.json
```

如果这条命令能够得到相同结果，就确认该 case 不依赖批量调度器中的隐藏状态，可以独立进入普通构建和运行流程。

## 3. Base mission 必须准备什么

内建数值物化器只修改已经存在的 vehicle perturbation 节点。目标 vehicle 在 base mission 中需要包含：

```json
{
  "id": "interceptor",
  "perturbation": {
    "type": "perturbation.static",
    "name": "perturbation",
    "config": {
      "inputs": {
        "mass.scale": 1.0,
        "aero.asset_set": 0
      },
      "enum_maps": {
        "aero.asset_set": {
          "0": "project://data/aero/nominal",
          "1": "project://data/aero/demo_alternate"
        }
      }
    }
  }
}
```

`inputs` 提供普通单次运行的值，也定义项目采用的输入名称。SimFlow 会用当前 case 的数值替换整个 `inputs` object。凡是要保留的输入，都应出现在 SimFlow 的 case source 和 vehicle input 列表中。

`enum_maps` 把整数输入映射成字符串。上例会同时提供：

- `aero.asset_set`：数值 `0` 或 `1`。
- `aero.asset_set.resolved`：对应的资产路径字符串。

使用者节点通过 `IPerturbationProvider` 读取这些键：

```cpp
const double mass_scale =
    perturbation->getNumber("mass.scale", 1.0);
const std::string aero_root =
    perturbation->getString("aero.asset_set.resolved", default_root);
```

base mission 还要满足普通仿真的全部要求，包括可用的 type id、完整物理配置、依赖、Form、Interaction 和输出配置。建议始终先运行 base mission，再排查 SimFlow。

## 4. SimFlow 顶层结构

最小结构如下：

```json
{
  "base_mission": "project://config/mission.json",
  "materializer": {
    "type": "simflow.materializer.numeric_perturbation",
    "config": {
      "case_source": {},
      "vehicles": {}
    }
  },
  "outputs": {
    "directory": "repo://user/outputs/my_experiment",
    "case_directory": "case_{case_index}_{case_id}"
  }
}
```

| 字段 | 是否必需 | 含义 |
| --- | --- | --- |
| `base_mission` | 是 | 已能独立运行的普通 mission |
| `materializer.type` | 是 | case 物化器 type id |
| `materializer.config` | 否 | 传给具体物化器；内建数值物化器需要 `case_source` 和 `vehicles` |
| `outputs.directory` | 否 | SimFlow 输出根，默认 `user/outputs` |
| `outputs.case_directory` | 否 | case 子目录模板，默认 `case_{case_index}` |

`case_directory` 支持两个占位符：

- `{case_index}`：从 1 开始、六位补零，例如 `000003`。
- `{case_id}`：case source 提供的标识；缺失时使用补零索引。

推荐为项目内输入使用 `project://`，为仓库统一输出使用 `repo://user/outputs/...`。普通相对输出目录按启动进程的当前目录解释，自动化脚本中容易受到工作目录影响。

## 5. 三种内建 case source

### 5.1 Single：先验证一组输入

single 适合打通拉偏链路，也适合保存一个命名工况：

```json
{
  "case_source": {
    "mode": "single",
    "case_id": "nominal",
    "inputs": {
      "environment.wind_scale": 1.0,
      "mass.scale": 1.0,
      "aero.asset_set": 0
    }
  }
}
```

`inputs` 必须是非空数值 object。`case_id` 可省略，默认 `case_000001`。

### 5.2 Matrix：从 CSV 选择明确工况

CSV 第一列必须为 `case_id`，后续列名就是输入键：

```csv
case_id,environment.wind_scale,mass.scale,aero.asset_set
nominal,1.0,1.0,0
alternate_assets,1.2,1.0,1
light,1.0,0.98,0
```

SimFlow 配置指定文件和需要运行的数据行：

```json
{
  "case_source": {
    "mode": "matrix",
    "file": "project://simflow/cases.csv",
    "rows": [0, 1, 2]
  }
}
```

`rows` 使用从 0 开始的数据行索引，表头不计入索引。数组不能为空，越界会在物化阶段失败。内建数值物化器要求 `vehicles.<id>.inputs[]` 选中的单元格可以解析为数值；CSV 可以含有未被选择的说明列。

当前 CSV reader 处理逗号分隔和单元格首尾空白，不实现带引号逗号的完整 RFC CSV 语法。case 表建议只保存简单标识和数值。

### 5.3 Random：固定 seed 的随机样本

```json
{
  "case_source": {
    "mode": "random",
    "count": 8,
    "seed": 20260710,
    "inputs": {
      "mass.scale": {
        "distribution": "normal",
        "mean": 1.0,
        "stddev": 0.01
      },
      "aero.F_CA_bias": {
        "distribution": "uniform",
        "min": -0.02,
        "max": 0.02
      },
      "aero.asset_set": {
        "distribution": "uniform_int",
        "min": 0,
        "max": 1
      },
      "environment.wind_scale": {
        "distribution": "constant",
        "value": 1.0
      }
    }
  }
}
```

`count` 必须为正整数，`seed` 必须为非负整数。输入键在采样前排序，随机数生成器由显式 seed 初始化；相同配置与 seed 会产生相同的 case 数值序列。

支持的输入规格：

| 写法 | 字段 | 约束 |
| --- | --- | --- |
| 直接 number | 无 | 固定数值 |
| `constant` | `value` | 有限数 |
| `uniform` | `min`, `max` | `max >= min` |
| `normal` | `mean`, `stddev` | `stddev >= 0` |
| `uniform_int` | `min`, `max` | 两端为整数，`max >= min` |

random case id 自动生成为 `case_000001`、`case_000002` 等。若 case 需要长期纳入试验基线，可以把生成后的具体值固化到 matrix CSV，或直接保留 effective mission。

## 6. 把输入分配给 vehicle

`materializer.config.vehicles` 明确每个目标 vehicle 接收哪些输入：

```json
{
  "vehicles": {
    "interceptor": {
      "inputs": [
        "environment.wind_scale",
        "mass.scale",
        "aero.asset_set"
      ]
    }
  }
}
```

每个 `inputs` 数组必须非空。每个名字都要出现在当前 case 中。目标 vehicle 必须存在于 base mission，并且声明了 `perturbation` 块。

多飞行器任务可以声明多个键：

```json
{
  "vehicles": {
    "interceptor": {
      "inputs": ["interceptor.mass_scale"]
    },
    "target": {
      "inputs": ["target.speed_scale"]
    }
  }
}
```

内建物化器会分别替换两个 vehicle 的 `perturbation.config.inputs`。输入名可以带 vehicle 前缀来表达项目语义，框架只把它视为普通字符串键。

## 7. 从 case 值到运行节点

完整数据流如下：

```mermaid
sequenceDiagram
    participant F as SimFlowRunner
    participant M as Numeric materializer
    participant E as effective mission
    participant P as perturbation.static
    participant C as project components
    participant S as Simulator

    F->>M: base mission + case values + vehicle mapping
    M->>E: write perturbation.config.inputs
    F->>E: freeze explicit asset URIs and set case output directory
    F->>S: ordinary build/run of effective mission
    S->>P: configure materialized inputs and enum_maps
    C->>P: getNumber / getString / getVector
    S->>C: normal phase update and integration
```

`perturbation.static` 对原键提供 number。若 `enum_maps` 命中整数键，它还会提供 `<key>.resolved` string。项目节点可把依赖声明为可选并提供物理上合理的 nominal fallback；某项输入属于模型必要条件时，项目节点应自行检查 `has(key)` 并尽早失败。

动态拉偏源可以实现 `IDiscreteTask` 并注册 Perturbation phase。它属于普通 runtime node，仍然只消费已经物化的配置或外部明确输入。

## 8. 输出、并发与汇总

串行执行：

```powershell
build-mingw\bin\gnc_sim.exe --simflow <simflow.json>
```

并发子进程执行：

```powershell
build-mingw\bin\gnc_sim.exe --simflow <simflow.json> --jobs 4
build-mingw\bin\gnc_sim.exe --simflow <simflow.json> --jobs auto
```

`--jobs auto` 使用 `max(1, hardware_concurrency - 1)`。串行模式在当前进程逐个构建和运行 case；并发模式为每个 case 启动普通 `gnc_sim --config <effective_mission>` 子进程。两种模式生成相同的 case 目录契约。

`simflow_summary.csv` 字段：

| 字段 | 含义 |
| --- | --- |
| `case_index` | 从 1 开始的物化顺序 |
| `case_id` | single、CSV 或 random 生成的标识 |
| `case_directory` | 该 case 的输出目录 |
| `status` | `succeeded` 或 `failed` |
| `exit_code` | 0 表示成功 |
| `message` | 串行模式下的异常信息，或并发子进程退出码摘要 |

任一 case 失败时，runner 会先写完整汇总，再让 SimFlow 命令返回失败。已成功的 case 输出会保留。

每个 effective mission 还会把普通 mission 的 `outputs.directory` 改成对应 case 目录。显式 `repo://`、`project://`、`user-data://` 字符串会在写出前解析成固定路径，使 case 移到输出树后仍能找到原资产。

## 9. 复现与比较一个 case

推荐按以下顺序定位批量结果：

1. 在 `simflow_summary.csv` 中筛选失败或关注的 `case_id`。
2. 打开对应 `effective_mission.json`，确认 `vehicles[].perturbation.config.inputs`。
3. 用普通 `--config` 单独运行。
4. 查看该目录下的 `summary.txt`，核对 type、origin、phase、priority、rate 与终止原因。
5. 比较普通 CSV 中的状态、指令和项目摘要。

PowerShell 示例：

```powershell
$root = "user/outputs/yyz_cartesian_6dof_framework_9/simflow_matrix"
Import-Csv "$root/simflow_summary.csv" | Where-Object status -ne "succeeded"
Select-String -Path "$root/case_000002_alternate_assets/effective_mission.json" `
    -Pattern 'aero.asset_set|trajectory.asset_set'
build-mingw-yyz\bin\gnc_sim.exe --config `
    "$root/case_000002_alternate_assets/effective_mission.json"
```

重新运行同一个 effective mission 会按相同 `session_name` 打开 CSV，并覆盖同名普通输出和摘要。需要保留原始证据时，先复制整个 case 目录或把 effective mission 的输出目录改到新的位置。

## 10. 常见失败与排查顺序

| 失败信息或现象 | 常见原因 | 先检查 |
| --- | --- | --- |
| `simflow.base_mission is required` | 顶层缺少路径或空字符串 | `base_mission` |
| unknown materializer type | type id 未注册或项目 materializer 未进入 active project 构建 | 检查 `simflows/*.hpp`、注册宏、CMake 配置和构建输出 |
| `requires base mission perturbation block` | 目标 vehicle 没有 `perturbation` | base mission 的 vehicle 条目 |
| `references unknown vehicle` | `vehicles` 映射键与 mission id 不一致 | 两处 vehicle id |
| `case ... is missing input` | case source 和 vehicle input 列表不一致 | 输入拼写和 CSV 表头 |
| `input ... must be numeric` | matrix 选中的单元格是文本 | CSV 值；资产选择用整数加 `enum_maps` |
| CSV row index out of range | `rows` 超过数据行数 | 从 0 开始重新计数，排除表头 |
| enum map 没有对应 key | case 选择了未映射的整数 | base mission 的 `enum_maps` |
| case 全部在构建阶段失败 | base mission 本身无效，或 active project 不匹配 | 先普通运行 base mission，再查首个 case 的 effective mission |
| serial 有详细异常，parallel 只有退出码 | 子进程只回传状态 | 用同一 effective mission 串行复现 |

## 11. 何时写项目 materializer

内建数值物化器适合数值拉偏、整数资产选择和显式 case 矩阵。以下需求可能需要项目 materializer：

- case 需要改写多个 mission 结构位置。
- case 来源来自项目专用组合规则。
- 需要生成或引用项目特定的结构化数据。

项目 materializer 放在 active project 的 `simflows/*.hpp`。最小形状：

```cpp
#pragma once

#include "gnc/simflow/mission_patch.hpp"
#include "gnc/simflow/simflow_materializer.hpp"
#include "gnc/simflow/simflow_materializer_registration.hpp"

class ProjectMaterializer final
    : public gnc::simflow::ISimFlowMaterializer {
public:
    std::vector<gnc::simflow::MaterializedCase> materialize(
        const gnc::simflow::SimFlowMaterializationContext& context) override {
        gnc::simflow::MaterializedCase current;
        current.case_id = "project_case";
        current.effective_mission =
            gnc::simflow::cloneNode(context.base_mission);
        return {current};
    }
};

GNC_REGISTER_SIMFLOW_MATERIALIZER(
    ProjectMaterializer,
    "project.simflow.materializer")
```

新增或删除该头文件后重新运行 CMake 配置并构建。自定义 materializer 负责生成完整有效的 `effective_mission`；runner 仍会固化显式资产 URI、重写 case 输出目录、写文件并调用普通仿真链路。

适合 materializer 的测试至少覆盖 case 数量与 id、关键 mission patch、无效配置、生成后的普通 mission 构建，以及 `--config effective_mission.json` 回放。

## 12. 使用清单

运行前：

- [ ] Base mission 能通过普通 `--config` 运行。
- [ ] 目标 vehicle 声明 perturbation provider。
- [ ] case source 中的输入与 `vehicles.<id>.inputs[]` 一致。
- [ ] random 显式保存 seed；matrix CSV 与 SimFlow 配置一同版本管理。
- [ ] active project 包含 base mission 使用的项目节点。
- [ ] 输出目录使用稳定、可定位的路径。

运行后：

- [ ] `simflow_summary.csv` 中每个 case 都有明确状态。
- [ ] 关注的 case 目录包含 `effective_mission.json`、普通 CSV 和 `summary.txt`。
- [ ] effective mission 中的拉偏值与 case 定义一致。
- [ ] 至少抽查一个 case 能通过普通 `--config` 回放。

字段速查见 [参考手册](06-reference.md#14-simflow)，拉偏节点 placement 与运行期语义见 [Mission 配置](03-mission-configuration.md#11-perturbation-与-simflow)。
