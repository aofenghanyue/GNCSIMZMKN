# 参考手册

本页集中列出 CLI、type id、公共接口和配置字段，适合在遇到具体名称时查询。需要理解各层职责和运行时因果关系时，先读 [核心概念](02-core-concepts.md)；需要评估模型与数值可信度时，读 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)；准备维护源码时，再进入 [维护者架构说明](05-architecture.md)。

## 1. CLI

| 命令 | 说明 |
| --- | --- |
| `gnc_sim.exe` | 运行 active project 默认 mission |
| `gnc_sim.exe <config.json>` | 运行指定 mission |
| `gnc_sim.exe --config <config.json>` | 运行指定 mission |
| `gnc_sim.exe --simflow <simflow.json>` | 串行运行 SimFlow cases |
| `gnc_sim.exe --simflow <simflow.json> --jobs auto` | 使用 `max(1, hardware_concurrency - 1)` 个子进程 |
| `gnc_sim.exe --simflow <simflow.json> --jobs <N>` | 最多同时运行 N 个 case |
| `gnc_sim.exe --list-components` | 列出 catalog 中的 node type id |
| `gnc_sim.exe --list-components-verbose` | 同时列出接口、role、phase、form family 和注册来源 |
| `gnc_sim.exe --help` | 打印帮助 |

相对 mission 路径会从当前目录和可执行文件目录向上搜索。默认 mission 来自构建时 active project 的 `user/<project>/config/mission.json`。

## 2. 源码入口

| 入口 | 用途 |
| --- | --- |
| `src/runner.cpp` | CLI、catalog 组合、mission/SimFlow 启动 |
| `core/framework_catalog.hpp` | 节点、积分器、SimFlow 物化器统一 catalog |
| `core/simulation_builder.hpp` | 构建协调、simulation 校验、积分器和 logger |
| `core/mission_assembler.hpp` | placement、scope、节点创建与 execution config |
| `core/assembly_graph.hpp` | scope 树、节点 ownership 与名称解析 |
| `core/placement_policy.hpp` | placement 的 scope/role/phase/capability 规则 |
| `core/node_factory.hpp` | type id、role、phase、family、interface 元数据 |
| `core/node_registry.hpp` | 节点实例和 typed interface 查询 |
| `core/assembly_context.hpp` | scope-aware 依赖绑定 |
| `core/validation_pipeline.hpp` | 元数据、依赖和 family 预检 |
| `core/preparation_pipeline.hpp` | build-time prepare 调度 |
| `core/simulator.hpp` | publish、phase update、record、termination、integration |
| `infrastructure/auto_data_logger.hpp` | observable 与 CSV/debug snapshot |
| `simflow/simflow_runner.hpp` | case 物化与串行/多进程执行 |
| `extensions/coordinate_tree/` | 可选坐标树扩展 |

## 3. Mission 顶层字段

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `simulation` | object | 必填；固定步长、时长、积分器 |
| `infrastructure` | array | 可选；mission scope 基础设施节点 |
| `process` | array | 可选；mission scope 流程/协调节点 |
| `continuous_groups` | array | 可选；mission scope 联合连续积分节点 |
| `environment` | object | 可选；`infrastructure[]` 与 `components[]` |
| `vehicles` | array | 必填；至少一个 vehicle |
| `outputs` | object | 可选；CSV 输出配置 |
| `termination` | object | 可选；mission scope 单例 |
| `summary` | object | 可选；mission scope 单例 |

每个 vehicle 支持 `id/infrastructure/perturbation/form/common/input/process/output/interaction/continuous_groups`。`global_services` 和各 scope 的 `services` 已移除。

## 4. Scope 与名称

| ScopeKind | 前缀 | 常见 placement |
| --- | --- | --- |
| Mission | `mission.` | 顶层 infrastructure/process/termination/summary |
| Environment | `env.` | environment infrastructure/components |
| Vehicle | `<id>.` | vehicle 全部节点 |

短名在当前 scope 解析；含点号的名称视为完整名。vehicle id 匹配 `[A-Za-z_][A-Za-z0-9_-]*`，并排除 `env`、`mission`。

## 5. Node 生命周期与能力

```text
configure -> register all -> bind all -> prepare all
-> initialize all -> run -> finalize
```

| API / interface | 语义 |
| --- | --- |
| `SimulationNode::configure(config, path)` | 读取节点配置 |
| `SimulationNode::bind(context)` | 建立 typed dependency |
| `SimulationNode::prepare(context)` | 资产加载、校验、预处理 |
| `SimulationNode::initialize()` | 初始化运行态 |
| `IDiscreteTask::update(StepContext)` | 离散任务入口 |
| `IPublishTask::publish(PublishContext)` | 发布点刷新 |
| `IContinuousSystem` | 连续状态和导数 |
| `IContinuousGroup` | 联合积分边界 |

`AssemblyContext` 常用 API：

| API | 行为 |
| --- | --- |
| `requireByName<T>(name)` | 必需依赖，失败进入 build diagnostics |
| `tryGetByName<T>(name)` | 可选依赖 |
| `bind(slot, name)` | required binding helper |
| `bindIfPresent(slot, name)` | optional binding helper |
| `getAllInScope<T>()` | 收集同 scope provider |

## 6. Role 与离散 Phase

Role 值：

```text
Infrastructure, Asset, EnvironmentModel, Perturbation, Form,
Input, Process, Output, Interaction, Coupling, Termination, Summary
```

离散 Phase 值与顺序：

```text
Environment -> Perturbation -> Input -> Process
-> Output -> Interaction -> Evaluation
```

`None` 表示无离散调度。实现 `IDiscreteTask` 的类型必须注册非 None phase；其它类型必须注册 None。

PublishPhase 顺序：`StateOwner -> View -> Ordinary`。

## 7. 节点条目

| 字段 | 规则 |
| --- | --- |
| `type` | 必填 string；catalog 中已注册 type id |
| `name` | 必填 string；与 scope 前缀组成完整名 |
| `priority` | 可选整数；同组越小越先执行 |
| `rate_hz` | 仅 `IDiscreteTask` 可用；正数且形成整数 step interval |
| `config` | object；传入节点 configure |

`rate_hz <= 1 / simulation.dt`。小数 priority、非整数 interval 和 capability/phase 不匹配均为 build error。

## 8. Simulation

| 字段 | 规则 |
| --- | --- |
| `dt` | 必填 number，`> 0` |
| `duration` | 必填 number，`>= 0` |
| `integrator` | 可选 string，默认 `rk4`；内建 `rk4`、`euler` |

`duration / dt` 必须形成整数步数。积分器从 `FrameworkCatalog` 创建，未知 type 不回退。

## 9. Asset Preparation

| API | 语义 |
| --- | --- |
| `context.paths().resolve(value)` | 解析绝对、相对和显式 root 路径 |
| `requireRegularFile(value, label)` | 解析并校验普通文件 |
| `requireRegularPath(path, label)` | 校验已解析路径 |
| `fingerprint(path)` | 路径、大小和修改时间组合指纹 |
| `PreparedAssetCache::getOrCreate<T>()` | 进程生命周期 typed 只读缓存 |

显式 root：`repo://`、`project://`、`user-data://`。项目 producer 通过 typed provider 暴露只读结果。

## 10. 当前 Type ID 总表

本节列出当前标准构建的 80 个 framework/linked type id。active project 会在此基础上增加项目类型；`--list-components-verbose` 用于核对实际构建元数据。

### 10.1 Environment、Form、Interaction、Termination、Summary

| Family / 类别 | Form | Interaction | Engagement termination | Engagement summary |
| --- | --- | --- | --- | --- |
| `local_spherical_3dof` | `form.local_spherical_3dof.point_mass` | `interaction.local_spherical_3dof.standard` | `termination.engagement_local_spherical_3dof` | `summary.engagement_local_spherical_3dof.ideal` |
| `cartesian_3dof` | `form.cartesian_3dof.point_mass` | `interaction.cartesian_3dof.standard` | `termination.engagement_cartesian_3dof` | `summary.engagement_cartesian_3dof.ideal` |
| `local_spherical_6dof` | `form.local_spherical_6dof.rigid_body` | `interaction.local_spherical_6dof.standard` | `termination.engagement_local_spherical_6dof` | `summary.engagement_local_spherical_6dof.ideal` |
| `cartesian_6dof` | `form.cartesian_6dof.rigid_body` | `interaction.cartesian_6dof.standard` | `termination.engagement_cartesian_6dof` | `summary.engagement_cartesian_6dof.ideal` |

额外 Form：`form.target_point.kinematic`，family 为 `target_point`，配置 `initial_position_ecef_m` 与 `velocity_ecef_mps`。

| Environment type id | Provider | 关键配置 |
| --- | --- | --- |
| `environment.spherical_earth` | `IEarth` | 可选 `equatorial_radius_m`、`rotation_rate_rad_per_s` |
| `environment.wgs84_earth` | `IEarth` | 无 |
| `environment.standard_atmosphere` | `IAtmosphere` | 无 |
| `environment.spherical_gravity` | `IGravity` | 可选 `reference_radius_m`、`sea_level_gravity_mps2` |

通用阈值停止类型：`termination.component_field_below`、`termination.component_field_above`。两者配置完整节点名 `component`、字段 `field`、阈值 `value` 和可选 `description`。

### 10.2 Vehicle Common

| Type id | Provider / 用途 |
| --- | --- |
| `vehicle.common.aero_assets_3dof.zero` | `IAerodynamicAssets3Dof`，零气动资产 |
| `vehicle.common.aero_assets_6dof.zero` | `IAerodynamicAssets6Dof`，零气动资产 |

### 10.3 Vehicle Input

3DoF：

| Capability | `local_spherical_3dof` | `cartesian_3dof` |
| --- | --- | --- |
| IMU | `vehicle.input.local_spherical_imu_3dof.ideal` | `vehicle.input.cartesian_imu_3dof.ideal` |
| Satellite nav | `vehicle.input.local_spherical_satellite_nav_3dof.ideal` | `vehicle.input.cartesian_satellite_nav_3dof.ideal` |
| Air data | `vehicle.input.local_spherical_air_data_3dof.ideal` | `vehicle.input.cartesian_air_data_3dof.ideal` |
| Seeker | `vehicle.input.local_spherical_seeker_3dof.ideal` | `vehicle.input.cartesian_seeker_3dof.ideal` |

6DoF：

| Capability | `local_spherical_6dof` | `cartesian_6dof` |
| --- | --- | --- |
| IMU | `vehicle.input.local_spherical_imu_6dof.ideal` | `vehicle.input.cartesian_imu_6dof.ideal` |
| Satellite nav | `vehicle.input.local_spherical_satellite_nav_6dof.ideal` | `vehicle.input.cartesian_satellite_nav_6dof.ideal` |
| Air data | `vehicle.input.local_spherical_air_data_6dof.ideal` | `vehicle.input.cartesian_air_data_6dof.ideal` |
| Seeker | `vehicle.input.local_spherical_seeker_6dof.ideal` | `vehicle.input.cartesian_seeker_6dof.ideal` |

Ideal input 节点通常使用空配置，通过同 vehicle `dynamics`、`env.earth`、`env.atmosphere` 或目标 truth 的 typed interface 读取真值。需要改变 lookup 时以具体节点的严格配置为准。

### 10.4 Vehicle Process

3DoF：

| Capability | `local_spherical_3dof` | `cartesian_3dof` |
| --- | --- | --- |
| Phase sequencer | `vehicle.process.local_spherical_phase_sequencer_3dof.ideal` | `vehicle.process.cartesian_phase_sequencer_3dof.ideal` |
| Trajectory planner | `vehicle.process.local_spherical_trajectory_planner_3dof.ideal` | `vehicle.process.cartesian_trajectory_planner_3dof.ideal` |
| Navigation | `vehicle.process.local_spherical_navigation_3dof.ideal` | `vehicle.process.cartesian_navigation_3dof.ideal` |
| Target tracking | `vehicle.process.local_spherical_target_tracking_3dof.ideal` | `vehicle.process.cartesian_target_tracking_3dof.ideal` |
| Guidance | `vehicle.process.local_spherical_guidance_3dof.ideal` | `vehicle.process.cartesian_guidance_3dof.ideal` |
| Flight control | `vehicle.process.local_spherical_flight_control_3dof.ideal` | `vehicle.process.cartesian_flight_control_3dof.ideal` |
| Control allocation | `vehicle.process.local_spherical_control_allocation_3dof.ideal` | `vehicle.process.cartesian_control_allocation_3dof.ideal` |

6DoF：

| Capability | `local_spherical_6dof` | `cartesian_6dof` |
| --- | --- | --- |
| Phase sequencer | `vehicle.process.local_spherical_phase_sequencer_6dof.ideal` | `vehicle.process.cartesian_phase_sequencer_6dof.ideal` |
| Trajectory planner | `vehicle.process.local_spherical_trajectory_planner_6dof.ideal` | `vehicle.process.cartesian_trajectory_planner_6dof.ideal` |
| Navigation | `vehicle.process.local_spherical_navigation_6dof.ideal` | `vehicle.process.cartesian_navigation_6dof.ideal` |
| Target tracking | `vehicle.process.local_spherical_target_tracking_6dof.ideal` | `vehicle.process.cartesian_target_tracking_6dof.ideal` |
| Guidance | `vehicle.process.local_spherical_guidance_6dof.ideal` | `vehicle.process.cartesian_guidance_6dof.ideal` |
| Attitude control | `vehicle.process.local_spherical_attitude_control_6dof.ideal` | `vehicle.process.cartesian_attitude_control_6dof.ideal` |
| Control allocation | `vehicle.process.local_spherical_control_allocation_6dof.ideal` | `vehicle.process.cartesian_control_allocation_6dof.ideal` |

Ideal process 节点用于完整链路骨架和接口验证，通常使用空配置。论文算法和任务逻辑应在 active project 中实现同 role/provider 契约的节点。

### 10.5 Vehicle Output

| Type id | Provider | 关键配置 |
| --- | --- | --- |
| `vehicle.output.mass_3dof.constant` | `IConstantMass` | 必填 `mass_kg` |
| `vehicle.output.mass_properties_6dof.constant` | `IMassProperties6Dof` | 必填 `mass_kg`、`center_of_gravity_body_m`、`inertia_body_kgm2` |
| `vehicle.output.propulsion_3dof.zero` | `IForceProvider` | 无 |
| `vehicle.output.propulsion_6dof.zero` | `IPropulsion6Dof` | 无 |
| `vehicle.output.actuator_3dof.ideal` | `IActuator3Dof` | 无 |
| `vehicle.output.actuator_6dof.ideal` | `IActuator6Dof` | 无 |
| `vehicle.output.aerodynamics_3dof.zero` | `IAeroModel` | 无 |
| `vehicle.output.aerodynamics_6dof.zero` | `IAerodynamics6Dof` | 无 |

### 10.6 Form 关键配置

| Type id | 必填字段 | 常用可选字段 |
| --- | --- | --- |
| `form.cartesian_3dof.point_mass` | `initial_position[3]`、`initial_velocity[3]` | `input_lookup_name` |
| `form.local_spherical_3dof.point_mass` | `launch_azimuth_rad`；`initial_state` 中 longitude/latitude/altitude/speed/flight_path_angle/heading | `earth_lookup_name`、`input_lookup_name` |
| `form.cartesian_6dof.rigid_body` | `initial_state.position_m[3]`、`velocity_mps[3]`、`attitude_body_to_frame[4]`、`angular_rate_body_radps[3]` | `input_lookup_name` |
| `form.local_spherical_6dof.rigid_body` | `initial_state` 中 longitude/latitude/altitude、`velocity_nue_mps[3]`、`attitude_body_to_nue[4]`、`angular_rate_body_radps[3]` | `earth_lookup_name`、`input_lookup_name`、`reference_radius_m` |

### 10.7 其余标准类型

`perturbation.static` 在 `vehicles[].perturbation` 提供 `IPerturbationProvider` 与 `IPerturbationSnapshot`。配置见第 13 节。

两个 linked Infrastructure type id 为 `infrastructure.coordinate_tree` 与 `infrastructure.coordinate_frames.local_spherical_3dof.launch_track`，详见第 12 节。

本节合计：Environment 4、Form 5、Interaction 4、Common 2、Input 16、Process 28、Output 8、Perturbation 1、Termination 6、Summary 4、Infrastructure 2，共 80 个 type id。

### 10.8 公共接口与 Include 入口

| 能力 | Include 入口 |
| --- | --- |
| 节点生命周期与离散/发布能力 | `gnc/core/simulation_node.hpp`、`gnc/core/runtime_capabilities.hpp` |
| 依赖绑定 | `gnc/core/assembly_context.hpp` |
| 注册宏与 role/phase | `gnc/core/node_factory.hpp` |
| 连续系统与 group | `gnc/interfaces/i_continuous_system.hpp`、`gnc/interfaces/i_continuous_group.hpp` |
| Observable / termination / summary | `gnc/interfaces/i_observable.hpp`、`i_termination_evaluator.hpp`、`i_summary_observer.hpp` |
| Form truth/input | `gnc/forms/<family>/interfaces/` |
| Environment provider | `gnc/environment/interfaces/` |
| Vehicle input/process/output provider | `gnc/vehicle/<role>/interfaces/` |
| Perturbation provider | `gnc/perturbation/interfaces/i_perturbation_provider.hpp` |
| 坐标扩展查询与 contributor | `gnc/extensions/coordinate_tree/interfaces/` |

项目共享接口放在 `user/<project>/interfaces/` 或项目 include root。framework 头文件不引用具体 active project。

## 11. Continuous Groups

| Placement | 完整名称 | 注册要求 |
| --- | --- | --- |
| 顶层 `continuous_groups[]` | `mission.<name>` | Coupling role、phase None、`IContinuousGroup` |
| `vehicles[].continuous_groups[]` | `<vehicle-id>.<name>` | Coupling role、phase None、`IContinuousGroup` |

当前没有通用 builtin group；联合导数是领域模型的一部分，优先由 project 实现。group 成员必须为已注册连续系统，不能为空、不能嵌套或重复归属。vehicle group 的成员必须属于当前 vehicle scope；mission group 连接不同 scope 的成员时使用完整名。

## 12. 可选坐标扩展

构建开关：

```powershell
cmake -S . -B build-mingw -DGNC_LINK_COORDINATE_TREE_EXTENSION=ON
```

扩展贡献：

| Type id | Role | Provider / 用途 |
| --- | --- | --- |
| `infrastructure.coordinate_tree` | Infrastructure | `ICoordinateTransform` |
| `infrastructure.coordinate_frames.local_spherical_3dof.launch_track` | Infrastructure | `ICoordinateFrameContributor`；提供 `I/E/N/L/LI/K` |

坐标树配置：`root_frame`，默认 `I`。launch-track contributor 必填 `latitude_rad/longitude_rad/azimuth_rad/launch_time_s/earth_rotation_angle_rad`，可选 `earth_lookup_name`（默认 `env.earth`）和 `truth_lookup_name`（默认 `dynamics`）。两者放在相同 scope 的 `infrastructure[]`。

关闭扩展后，核心 mission 仍可构建运行；包含坐标 type id 的 mission 会报告未知 node type。

## 13. Perturbation

`perturbation.static` 配置：

| 字段 | 规则 |
| --- | --- |
| `inputs` | 可选 object；value 为 number |
| `enum_maps` | 可选 object；整数输入到 string 的映射 |

每个输入按原 key 公开 number；命中 enum map 时同时公开 `<key>.resolved` string。自定义动态拉偏节点使用 Perturbation phase。

## 14. SimFlow

本节用于字段速查。第一次配置、运行或排查 SimFlow 时请按 [SimFlow 教程](simflow-guide.md) 操作。

```json
{
  "base_mission": "user/example/config/mission.json",
  "materializer": {
    "type": "simflow.materializer.numeric_perturbation",
    "config": {
      "case_source": {
        "mode": "random",
        "seed": 12345,
        "count": 3,
        "inputs": {
          "aero.drag_bias": {
            "distribution": "uniform",
            "min": -0.05,
            "max": 0.05
          }
        }
      },
      "vehicles": {
        "vehicle": { "inputs": ["aero.drag_bias"] }
      }
    }
  },
  "outputs": {
    "directory": "user/outputs/simflow",
    "case_directory": "case_{case_index}"
  }
}
```

内建 numeric materializer 支持 `single`、`matrix`、`random`；random 分布支持 `constant/uniform/normal/uniform_int`。被引用的 vehicle 必须在 base mission 声明 perturbation 节点。

| Case source | 必需字段 | 说明 |
| --- | --- | --- |
| `single` | `inputs` | 非空数值 object；`case_id` 可选 |
| `matrix` | `file`, `rows` | CSV 第一列为 `case_id`；`rows` 是从 0 开始的数据行索引 |
| `random` | `count`, `seed`, `inputs` | `count` 为正整数，`seed` 为非负整数 |

`materializer.config.vehicles.<vehicle-id>.inputs` 是非空字符串数组，指定写入该 vehicle perturbation 的 case 键。`outputs.case_directory` 支持六位补零的 `{case_index}` 和 case 标识 `{case_id}`。

每个 case 目录包含 `effective_mission.json`，输出根包含 `simflow_summary.csv`。单 case 复现：

```powershell
gnc_sim.exe --config user/outputs/simflow/case_000001/effective_mission.json
```

项目 materializer 放在 `user/<active_project>/simflows/*.hpp`，使用 `GNC_REGISTER_SIMFLOW_MATERIALIZER`。

## 15. Outputs

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `enabled` | `true` | 是否启用自动记录 |
| `directory` | `user/outputs` | 支持 `{timestamp}` |
| `format` | `csv` | 当前只支持 CSV |
| `session_name` | `simulation_data` | 文件名前缀 |
| `precision` | `12` | 1～17 的整数数值精度 |
| `flush_every_step` | `false` | 每步 flush |
| `record_initial_state` | `true` | 记录 t0 |
| `record` | `all` | 记录规则 |
| `exclude` | `[]` | 完整字段或 `*.suffix` |
| `debug_snapshots` | disabled | 临时 debug 字段 |

CSV `time` 是发布态物理时间。每行在全部离散 phases 后写出，包含 `x_k` truth、到期 task 的本周期输出、未到期 task 的保持输出，以及静态或连续节点的当前公开值。

`record` 可以是 `"all"`、节点名数组，或 `{ "node.name": "all" | ["field_prefix"] }`。字段前缀会匹配向量子字段；`exclude` 支持完整字段和 `*.suffix`。

`debug_snapshots` 可以是 bool 或 object。object 字段包括 `enabled`、`components`、`session_name`、`precision`、`flush_every_step`。debug snapshot 只用于临时排查，不属于稳定 observable 契约。

## 16. Termination 与 Summary

内建阈值类型：

- `termination.component_field_below`
- `termination.component_field_above`

配置字段：`component` 完整名、`field`、`value`，以及可选 `description`。termination 必须实现 `ITerminationEvaluator`；summary 必须实现 `ISummaryObserver`。

`summary.txt` 包含仿真参数、终止原因、wall time、节点 type/category/origin、实例级 phase/priority/`rate_hz`/step interval、记录状态，以及各 `ISummaryObserver` 写出的项目摘要。

## 17. 构建错误规则

- unknown type、重复完整名、placement scope/role/phase/capability 不匹配均为 build error。
- catalog 中重复 type id 会在注册阶段抛出错误，runner 会终止 catalog assembly。
- mission、environment、vehicle、form、interaction 和通用 node entry 的 unknown wrapper key 均为 build error。
- builtin `config` 的 unknown key、类型错误和 required 缺失为 build error；项目节点的未读取 key 当前为 warning。
- `outputs` 与 `debug_snapshots` 的 unknown key 或错误类型为 build error；校验失败时不会打开输出文件。
- required binding 缺失或接口不匹配会报告解析后的完整名、同 scope 节点/provider、scope lineage 和近似名称。
- Form/Interaction family 为空、同 vehicle family 冲突会在运行前失败。
- `rate_hz` 非正、不整除仿真频率、配置在非离散节点上都会失败。
- continuous group 空成员、未注册成员、嵌套或重复归属会在 build 阶段失败。
- 未链接扩展的 type id 按 unknown type 处理，不启用隐藏 fallback。
