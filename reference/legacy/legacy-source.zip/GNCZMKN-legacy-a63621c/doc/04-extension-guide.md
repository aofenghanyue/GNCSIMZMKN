# 扩展指南

本指南从一次局部改动开始：复制 geographic 3DoF baseline，只替换其中的制导节点。完成注册、装配和记录以后，我们再沿控制链检查这条命令怎样进入运动方程。后续章节才逐步展开 provider、资产、Form、Interaction、Infrastructure 和连续耦合。第一次扩展先完成第 0 节即可，遇到具体需求时再查相应章节。

开始写代码前，先判断本次修改属于哪一个层次：

- **算法替换**：provider、placement、时间语义和物理接口保持不变，只修改节点内部算法。
- **契约变化**：truth、command、Form input、坐标、状态布局或所有权发生变化，需要同步修订接口、type 和测试。

许多论文算法只需要第一种改动。把两类工作分开，可以让实验差异集中在算法本身，也能避免为了一个短期模型修改 framework 的通用语言。

| 阅读层次 | 章节 | 适用任务 |
| --- | --- | --- |
| 第一次扩展 | 第 0 节 | 替换一个算法，完成注册与 mission 修改，并在 CSV 中确认输出 |
| 普通项目节点 | 第 1～6 节 | 选择节点形态、写 Process/provider、绑定依赖、准备资产 |
| 物理与架构扩展 | 第 7～11 节 | 新 Form、Interaction、Infrastructure 或连续耦合组 |
| 提交前检查 | 第 12～14 节 | 核对元数据、framework 晋升条件和测试 |

```mermaid
flowchart LR
    A["算法 C++ 类"] --> B["注册 type + 元数据"]
    B --> C["active project catalog"]
    C --> D["mission placement + config"]
    D --> E["构建期绑定与校验"]
    E --> F["运行、CSV、测试"]
```

## 0. 第一次扩展：替换一个制导算法

本节从 geographic 3DoF baseline 复制一个项目，只替换 `guidance`。原有 FlightControl 按 `IGuidance3Dof` 接口读取它，因此其它节点和 mission 拓扑保持不变。

本节先验证项目算法能够替换原节点，并被下游接口与记录器读取。baseline 的 standard Interaction 使用占位 Form input，所以此时只检查 guidance observable。怎样确认命令已经影响轨迹，将在第 0.6 节继续说明。

### 0.1 创建项目工作区

在仓库根目录执行：

```powershell
Copy-Item -Recurse `
    user/example_05_ideal_3dof_geographic_baseline `
    user/tutorial_guidance_project
New-Item -ItemType Directory -Force `
    user/tutorial_guidance_project/components
```

从 baseline 复制项目，可以保留已经通过装配测试的 Environment、Form、Input、Process、Output 和 Interaction。第一轮改动只涉及一个算法节点及其 mission 条目；若运行失败，排查范围也比较小。

### 0.2 写一个完整的项目节点

新建 `user/tutorial_guidance_project/components/constant_aoa_guidance.hpp`：

```cpp
#pragma once

#include "gnc/common/math/eigen_types.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/simulation_node.hpp"
#include "gnc/infrastructure/observable_helpers.hpp"
#include "gnc/interfaces/i_observable.hpp"
#include "gnc/vehicle/process/interfaces/i_guidance_3dof.hpp"
#include "gnc/vehicle/process/interfaces/i_target_tracking_3dof.hpp"

#include <string>
#include <vector>

namespace tutorial {

class ConstantAoAGuidance final
    : public gnc::core::DiscreteNode,
      public gnc::vehicle::process::IGuidance3Dof,
      public gnc::interfaces::IObservable {
public:
    ConstantAoAGuidance() : DiscreteNode("ConstantAoAGuidance") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& path) override {
        gnc::core::ConfigReader reader(config, path);
        tracking_name_ =
            reader.optionalString("tracking_lookup_name", tracking_name_);
        angle_of_attack_rad_ = gnc::math::deg2rad(
            reader.requiredDouble("angle_of_attack_deg"));
        bank_angle_rad_ = gnc::math::deg2rad(
            reader.requiredDouble("bank_angle_deg"));
        reader.validateNoUnknownKeys();
    }

    void bind(gnc::core::AssemblyContext& context) override {
        context.bindAll(gnc::core::bind(tracking_, tracking_name_));
    }

    void update(const gnc::core::StepContext&) override {
        // 最直接的算法逻辑：保持给定攻角与倾侧角，并转发目标视线。
        command_.line_of_sight_ecef =
            tracking_->targetTrack3Dof().line_of_sight_ecef;
        command_.acceleration_command_nue_mps2 =
            gnc::math::Vector3::Zero();
        command_.angle_of_attack_rad = angle_of_attack_rad_;
        command_.bank_angle_rad = bank_angle_rad_;
    }

    const gnc::vehicle::process::GuidanceCommand3Dof&
    guidanceCommand3Dof() const override {
        return command_;
    }

    std::vector<gnc::interfaces::ObservableField>
    getObservableFields() const override {
        gnc::core::ObservableFieldBuilder builder;
        builder.addScalar("angle_of_attack_rad", [this]() {
            return command_.angle_of_attack_rad;
        });
        builder.addScalar("bank_angle_rad", [this]() {
            return command_.bank_angle_rad;
        });
        builder.addVector3("line_of_sight_ecef", [this]()
            -> const gnc::math::Vector3& {
            return command_.line_of_sight_ecef;
        });
        return builder.build();
    }

private:
    gnc::vehicle::process::ITargetTracking3Dof* tracking_ = nullptr;
    std::string tracking_name_ = "tracking";
    double angle_of_attack_rad_ = 0.0;
    double bank_angle_rad_ = 0.0;
    gnc::vehicle::process::GuidanceCommand3Dof command_{};
};

} // namespace tutorial

GNC_REGISTER_NODE_TYPE(
    "tutorial.process.local_spherical_guidance_3dof.constant_aoa",
    tutorial::ConstantAoAGuidance,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "local_spherical_3dof",
    ::gnc::vehicle::process::IGuidance3Dof,
    ::gnc::interfaces::IObservable)
```

这个节点包含五部分，分别对应对外接口、mission 参数、依赖、运行逻辑和注册契约：

| 代码位置 | 含义 | 本例 |
| --- | --- | --- |
| 继承列表 | 运行能力和对外接口 | 离散更新、制导指令、observable |
| `configure()` | mission 提供的参数 | 攻角、倾侧角、依赖短名 |
| `bind()` | 与其它节点的 typed dependency | 同 vehicle 的 `tracking` |
| `update()` | 使用者最直接修改的算法逻辑 | 从目标视线形成本周期制导指令 |
| 注册宏 | type、role、phase、family、provider | Process / Process / `local_spherical_3dof` |

### 0.3 在 mission 中替换 type

打开 `user/tutorial_guidance_project/config/mission.json`，找到局部名为 `guidance` 的 process 节点，将它改为：

```json
{
  "type": "tutorial.process.local_spherical_guidance_3dof.constant_aoa",
  "name": "guidance",
  "config": {
    "angle_of_attack_deg": 6.0,
    "bank_angle_deg": 0.0
  }
}
```

保留 `name = guidance` 后，原 FlightControl 的依赖名称无需变化。新 type 实现相同 `IGuidance3Dof` provider，接口契约也保持一致。

同时把 `outputs.directory` 改成项目自己的目录，例如：

```json
{
  "outputs": {
    "directory": "user/outputs/tutorial_guidance_project"
  }
}
```

这里展示的是局部修改，实际文件要保留原 `outputs` 中的 `format`、`session_name` 和 `record`。

### 0.4 重新配置、确认注册并运行

项目组件清单在 CMake 配置时生成。使用独立构建目录：

```powershell
cmake -S . -B build-mingw-tutorial -G "MinGW Makefiles" `
    -DGNC_ACTIVE_PROJECT=tutorial_guidance_project `
    -DBUILD_TESTS=OFF
cmake --build build-mingw-tutorial -j 4

build-mingw-tutorial\bin\gnc_sim.exe --list-components-verbose |
    Select-String "tutorial.process.local_spherical_guidance_3dof.constant_aoa"

build-mingw-tutorial\bin\gnc_sim.exe --config `
    user/tutorial_guidance_project/config/mission.json
```

检查输出：

```powershell
Import-Csv user/outputs/tutorial_guidance_project/ideal_3dof_geographic_baseline.csv |
    Select-Object -First 2 `
        time,interceptor.guidance.angle_of_attack_rad,interceptor.guidance.bank_angle_rad
```

若字段名与 PowerShell 展示方式不一致，先查看 CSV 表头。`outputs.record` 已沿用 baseline 的 `interceptor.guidance: all`，所以新 observable 会自动进入记录。

### 0.5 完成标准与第一个实验修改

完成这个最小扩展后，逐项确认：

- 组件清单显示项目 type、Process role、Process phase 和 `local_spherical_3dof` family。
- mission 构建时成功绑定 `tracking`。
- CSV 中的攻角等于 6° 对应的弧度值。
- 把 mission 中的 `angle_of_attack_deg` 改为另一数值后，输出随之变化。
- 在 `update()` 中替换攻角规律时，mission 拓扑和下游接口无需重写。

这些结果可以确认 type 已注册、依赖已绑定、离散任务已执行，记录器也读到了新命令。它们仍无法说明攻角命令是否进入了运动方程，下一节将继续追踪物理响应。

接下来如果要增加新的数据语义，先定义小型 typed interface；需要资产准备时使用 `prepare()`；需要改变 Form 方程输入时通过 Output provider 与 Interaction 闭合。后续章节分别解释这些路径。

扩展前还要判断能力是否需要成为 mission 节点。普通算法库、typed data product 和 `SimulationNode` 各自承担不同层次的复用。

### 0.6 从“命令可见”走到“轨迹受控”

要让算法命令改变轨迹，数据至少要依次经过下面这些环节：

```text
guidance command
-> flight control
-> control allocation
-> actuator state
-> aerodynamics / propulsion / mass
-> Interaction force or acceleration closure
-> Form input
-> computeDerivatives
-> x_{k+1}
```

可以按信号传播顺序检查：

1. CSV 中 guidance、flight control、allocation 和 actuator 的量是否逐层变化。
2. 气动/推进 provider 是否读取当前 actuator 或命令，并形成有单位的力、力矩或系数。
3. Interaction 是否用 candidate truth、环境、质量和这些物理能力计算 Form input。
4. Form 的 `computeDerivatives()` 是否消费该 input，重力和惯性项有没有重复或遗漏。
5. 比较两组仅命令参数不同的短 mission，确认 `u_k` 变化后 `x_{k+1}` 以正确方向和数量级变化。

项目中的现成代码可以作为阅读样例。`user/example_08_cavh_geographic_3dof_custom/components/cavh_aero_propulsive_interaction_3dof.hpp` 使用候选 truth 计算大气、马赫数、动压、升阻力和重力，再返回 local-spherical Form acceleration。YYZ 项目的 `interaction_force_moment_6dof.hpp` 会组合机体系气动力、推力、质量和发射系重力，再交给 6DoF Form 完成平动与转动方程。

把接线 baseline 逐步改成研究模型时，可以每次只替换一层。例如先完成物理 Interaction，再换入气动资产和执行机构，最后加入传感器非理想与扰动。每一步都保留名义 case 和验证证据，出现结果变化时才能判断原因来自哪一层。

## 1. 先选扩展层次

| 需求 | 优先形态 | 位置 |
| --- | --- | --- |
| 某个组件内部的状态机、滤波器、插值器 | 普通 C++ 类 | `user/<project>/common/` 或 `include/` |
| 多个节点共享的稳定数据语义 | 项目 interface + provider | `interfaces/` + producer 节点 |
| 需要独立配置、命名、依赖或运行行为 | `SimulationNode` | `components/` |
| 项目级 case 生成逻辑 | SimFlow materializer | `simflows/` |
| 多项目稳定复用的可选基础设施 | linked extension + Infrastructure nodes | `framework/include/gnc/extensions/` |
| 当前论文或试验专用模型 | project node | `user/<project>` |

将新抽象推进 framework 前，至少确认语义稳定、role/phase/form family 清楚、配置严格、成功和失败路径可测试。

### 1.1 检查跨节点契约是否变化

| 修改 | 通常保留什么 | 通常需要新增什么 |
| --- | --- | --- |
| 制导律内部公式 | `IGuidance*`、name、placement、observable 前缀 | 算法参数与单元测试 |
| 传感器噪声或滤波 | measurement provider 和 Input placement | 状态、seed、统计测试 |
| 执行机构从理想变连续 | actuator provider 和 Output role | `IContinuousSystem`、带宽/饱和测试，必要时 group |
| 气动表替换 | aero provider 与 Interaction 连接 | 新资产契约、prepare 校验、插值测试 |
| Form 状态坐标改变 | 很少能原样保留 truth/input | 新 family、state/truth/input/Interaction 全套契约 |
| 坐标查询扩展 | `ICoordinateTransform` consumer | frame contributor 与坐标一致性测试 |

如果 provider 的数据结构、单位或时间含义发生变化，就需要按契约变化处理。此时继续沿用旧接口，会让编译与绑定顺利通过，却把语义差异隐藏到运行结果中。

## 2. Project 目录规则

```text
user/<project>/
├── config/mission.json
├── components/       # 每个头都必须包含 GNC_REGISTER_NODE_TYPE
├── interfaces/       # 项目 typed interfaces
├── common/           # 共享算法和工具
├── include/          # 项目 include root
└── simflows/         # GNC_REGISTER_SIMFLOW_MATERIALIZER
```

CMake 只自动扫描 active project 的 `components/*.hpp` 和 `simflows/*.hpp`。新增、删除或切换项目后要重新配置并构建。

## 3. 静态 provider 节点

静态资产无需离散能力：

```cpp
#pragma once

#include "gnc/core/config_reader.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/simulation_node.hpp"
#include "project/interfaces/i_engine_parameters.hpp"

namespace project {

class EngineParameters final : public gnc::core::SimulationNode,
                               public IEngineParameters {
public:
    EngineParameters() : SimulationNode("EngineParameters") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& path) override {
        gnc::core::ConfigReader reader(config, path);
        nominal_thrust_n_ = reader.requiredDouble("nominal_thrust_n");
        reader.validateNoUnknownKeys();
    }

    double nominalThrustN() const override { return nominal_thrust_n_; }

private:
    double nominal_thrust_n_ = 0.0;
};

} // namespace project

GNC_REGISTER_NODE_TYPE(
    "project.engine_parameters",
    project::EngineParameters,
    ::gnc::core::NodeRole::Asset,
    ::gnc::core::DiscretePhase::None,
    "",
    project::IEngineParameters)
```

放在 `vehicles[].common[]`。它只实现生命周期和 provider，不提供空 `update()`。

## 4. 离散 Process 节点

`DiscreteNode` 是 `SimulationNode + IDiscreteTask` 的便捷基类：

```cpp
#pragma once

#include "gnc/core/assembly_context.hpp"
#include "gnc/core/config_reader.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/simulation_node.hpp"
#include "project/interfaces/i_navigation_solution.hpp"
#include "project/interfaces/i_guidance_command.hpp"

namespace project {

class Guidance final : public gnc::core::DiscreteNode,
                       public IGuidanceCommand {
public:
    Guidance() : DiscreteNode("Guidance") {}

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& path) override {
        gnc::core::ConfigReader reader(config, path);
        navigation_name_ = reader.optionalString("navigation", "navigation");
        gain_ = reader.requiredDouble("gain");
        reader.validateNoUnknownKeys();
    }

    void bind(gnc::core::AssemblyContext& context) override {
        context.bindAll(gnc::core::bind(navigation_, navigation_name_));
    }

    void update(const gnc::core::StepContext& context) override {
        command_ = -gain_ * navigation_->crossTrackErrorM();
        sample_time_s_ = context.time_s;
    }

    double lateralCommand() const override { return command_; }

private:
    INavigationSolution* navigation_ = nullptr;
    std::string navigation_name_;
    double gain_ = 0.0;
    double command_ = 0.0;
    double sample_time_s_ = 0.0;
};

} // namespace project

GNC_REGISTER_NODE_TYPE(
    "project.guidance",
    project::Guidance,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    project::IGuidanceCommand)
```

`StepContext` 提供 `time_s`、`dt_s` 和 `step`。节点不保存由框架注入的全局仿真时间，也不在 `update()` 内推进连续状态。

对应 mission 条目放在 `vehicles[].process[]`：

```json
{
  "type": "project.guidance",
  "name": "guidance",
  "priority": 20,
  "rate_hz": 10.0,
  "config": {
    "navigation": "navigation",
    "gain": 0.08
  }
}
```

如果 Guidance 要读取同一 Process phase 中 Navigation 刚刚生成的本周期输出，应把 Navigation 的 priority 设得更小。typed binding 只能确认接口存在，无法规定同一 phase 中的执行顺序。Guidance 使用较低 `rate_hz` 时，跳过更新的 step 会继续保持上次命令，算法测试也要覆盖这项采样行为。

`initialize()` 用来建立节点自身的运行态初值。需要读取当前 measurement 或 command 的计算应放在第一次 `update(t_0)` 中，以免结果取决于 registry 中谁先执行 initialize。

## 5. 依赖绑定

`bind()` 在所有节点注册后执行：

```cpp
void bind(gnc::core::AssemblyContext& context) override {
    context.bindAll(
        gnc::core::bind(required_, "required_provider"),
        gnc::core::bindIfPresent(optional_, "coordinates"));
}
```

也可以直接调用：

```cpp
auto* earth = context.requireByName<gnc::environment::IEarth>("env.earth");
auto contributors = context.getAllInScope<IMyContributor>();
```

选择规则：

- 物理模型无法成立的依赖使用 required binding。
- 锦上添花的能力使用 optional binding，并为缺席路径定义清楚行为。
- 扩展聚合点使用 `getAllInScope<T>()`。
- `bind()` 只建立引用，不加载大资产，不推进状态。

## 6. Prepare 与数据产品

资产路径、case 选择和 profile 在 `configure()` 读取；文件加载、表格校验和预处理在 `prepare(PreparationContext)` 完成。

```cpp
void prepare(const gnc::core::PreparationContext& context) override {
    const auto path = context.paths().resolve(asset_uri_);
    table_ = std::make_shared<const AeroTable>(loadAndValidate(path));
}
```

所有节点 prepare 完成后才进入任何 initialize。consumer 应通过 typed provider 读取只读数据产品。一个 preparer 不应依赖另一个节点尚未 prepare 完成的派生产品；确有多级准备需求时，先形成明确契约，再扩展 pipeline。

## 7. 发布与连续状态

Form 或其它连续状态所有者通常组合 `IPublishTask` 和 `IContinuousSystem`：

```cpp
class MyForm final : public gnc::core::SimulationNode,
                     public gnc::core::IPublishTask,
                     public gnc::interfaces::IContinuousSystem {
public:
    gnc::core::PublishPhase publishPhase() const override {
        return gnc::core::PublishPhase::StateOwner;
    }

    void publish(const gnc::core::PublishContext& context) override {
        refreshTruth(context.time_s);
    }

    void computeDerivatives(double time,
                            const Eigen::VectorXd& candidate_state,
                            Eigen::VectorXd& derivative) const override {
        // 只计算导数；状态提交由 Simulator 负责。
    }
};
```

Form type 注册为 `NodeRole::Form`、`DiscretePhase::None`，并声明非空 form family。Interaction 也必须声明同一 family。

新增 Form family 前先写出完整契约：

1. 稳定且唯一的 family id。
2. state layout、单位、参考系、四元数约定和初值 schema。
3. truth view interface 及其发布时间语义。
4. Form input provider interface。
5. 连续状态所有者与 `computeDerivatives()` 约束。
6. `PublishPhase` 和 observable 字段。
7. Interaction 如何读取 Environment、Process、Output 并闭合为 input。
8. family mismatch、缺 input provider、状态维数和数值积分测试。

一个新 family 通常同时修改 form types、truth/input interfaces、Interaction 和至少一个 mission 示例。Output provider 可以跨 family 复用时，应使用小型稳定接口隔离坐标或维数差异。

## 8. Interaction 与 Output capability

新增物理能力时先定义小型 provider interface，例如 `IMassProperties`、`IAerodynamics`、`IActuator`。实现节点放在 `vehicle.output`，资产放在 `vehicle.common` 或外部文件。

Interaction 读取：

- Form truth。
- Environment 查询。
- Process 命令。
- Output provider。

随后生成该 Form family 的 input。Interaction 不持有气动表、质量定义或任务状态机。一个自定义 Interaction 应有缺依赖测试和 family mismatch 测试。

### 8.1 让 closure 使用 RK 候选状态

Form 的导数函数在一个 RK4 宏步内可能多次调用 Interaction input provider。可以采用下面的结构：

```cpp
FormInput computeInput(const Truth& candidate_truth,
                       double candidate_time_s) const override {
    const auto held_command = command_->command();
    const auto physical_state = output_->state();
    return closeEquations(candidate_truth,
                          candidate_time_s,
                          held_command,
                          physical_state);
}
```

这里的 `candidate_truth` 会随 RK 子步变化，离散 command 则在本周期内保持。closure 对相同输入应给出确定结果，不能推进状态、消费一次性事件，也不能依赖本宏步内的调用次数。

如果只在 `update(t_k)` 中计算一次并缓存全部状态相关气动力，这些力在整个宏步内都会按零阶保持。模型可以有意采用这种近似，同时要通过步长研究说明误差。需要随每个子步变化的气动、重力和坐标量，应根据 candidate truth 重新计算。

### 8.2 observable 缓存只用于观察

Interaction 经常用 `mutable last_input_` 保存最近一次 query，供 CSV 读取。这个缓存只服务观察，不能反向参与下一次物理计算。文档还要说明它记录的是 publish 边界输入、离散 closure 结果，还是最近一个 RK 候选点。

一种容易解释的做法，是在 publish 边界使用 `x_k` 和边界保持量刷新观察缓存，RK 子步仍保持纯计算。如果实现采用其它时间语义，应在字段名或项目文档中写明。

自定义 Perturbation 节点放在 `vehicles[].perturbation`，role 为 Perturbation。静态 provider 可以使用 `phase = none`；随时间更新的拉偏源实现 `IDiscreteTask` 并注册 Perturbation phase。其它运行节点只读取 `IPerturbationProvider`，不解析 SimFlow 文件或 case index。

## 9. 算法对象的所有权

| 需求 | 形态 | 例子 |
| --- | --- | --- |
| 单一节点私有、无需独立配置 | 普通 C++ 成员 | PID、滤波器、插值器、局部状态机、优化器 |
| 单 vehicle 独立配置或记录 | `vehicles[].process[]` 节点 | 导航器、制导器、模式管理、事件逻辑 |
| 跨 vehicle 或试验级权威 | 顶层 `process[]` 节点 | 协调器、任务规划、试验阶段推进、全局事件判定 |
| 连续状态由积分器推进 | `IContinuousSystem` 节点 | 执行机构、滤波状态、质量或机构状态 |

独立所有权、配置、依赖、记录和调度需求决定一个算法是否成为节点。算法名称本身不产生新的 role 或 Infrastructure 类型。mission process 与 vehicle process 都使用 Process role；scope 表达协调范围。

## 10. Infrastructure 扩展

可选基础设施仍是普通节点。扩展入口接收统一 catalog：

```cpp
inline void contributeToCatalog(gnc::core::FrameworkCatalog& catalog) {
    catalog.nodes().registerType<MyInfrastructure, IMyQuery>(
        "infrastructure.my_query",
        gnc::core::NodeCategory::Builtin,
        __FILE__,
        gnc::core::NodeRole::Infrastructure,
        gnc::core::DiscretePhase::None);

    catalog.integrators().registerType<MyIntegrator>("my_integrator");
}
```

扩展可以只贡献其中一类能力。应用组合层负责调用 `contributeToCatalog()`；`SimulationBuilder` 无需包含扩展头文件或识别具体 type id。

静态基础设施注册 `DiscretePhase::None`。需要按周期刷新缓存或查询产品的基础设施可以实现 `IDiscreteTask`，并在注册时明确选择 Environment、Process 等既有 phase；placement 会保留该 phase。Infrastructure 仍只承担稳定基础能力，任务流程继续使用 Process role。

坐标树采用“引擎节点 + frame contributor”模式。为新 Form family 增加坐标定义时：

1. 实现 `ICoordinateFrameContributor`。
2. 作为 Infrastructure node 注册，并填写对应 form family。
3. 在 `bind()` 获取 Earth/Truth 等显式依赖。
4. 在 `contributeFrames()` 向 builder 添加 frame 和 edge。
5. mission 在相同 scope 同时声明 contributor 与 `infrastructure.coordinate_tree`。

坐标树节点通过 `getAllInScope<ICoordinateFrameContributor>()` 聚合贡献者，避免中央 spec registry。

## 11. 连续强耦合

默认连续系统按发布态同步独立积分。需要 RK 子步共享候选状态时，实现 `IContinuousGroup`：

- group 的 state layout 拼接成员状态。
- `computeDerivatives()` 用联合候选向量计算联合导数。
- `setState()` 把联合结果分发给成员。
- `members()` 返回被接管的已注册连续系统。

group 不能嵌套，成员不能重复归属。添加测试，证明联合 RK 子步结果与 sample-hold 独立积分存在预期差异。

下面的 vehicle group 把两个标量连续节点合成联合状态。示例物理关系为质量恒速消耗、位置导数等于 RK 候选质量：

```cpp
class MassPositionGroup final
    : public gnc::core::SimulationNode,
      public gnc::interfaces::IContinuousGroup {
public:
    MassPositionGroup() : SimulationNode("MassPositionGroup") {
        mass_index_ = layout_.addVariable("mass_kg");
        position_index_ = layout_.addVariable("position_m");
        state_ = Eigen::VectorXd::Zero(2);
    }

    void configure(const gnc::core::ConfigNode& config,
                   const std::string& path) override {
        gnc::core::ConfigReader reader(config, path);
        mass_name_ = reader.requiredString("mass");
        position_name_ = reader.requiredString("position");
        reader.validateNoUnknownKeys();
    }

    void bind(gnc::core::AssemblyContext& context) override {
        mass_ = context.requireByName<gnc::interfaces::IContinuousSystem>(
            mass_name_);
        position_ = context.requireByName<gnc::interfaces::IContinuousSystem>(
            position_name_);
    }

    std::vector<gnc::interfaces::IContinuousSystem*> members() const override {
        return {mass_, position_};
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }

    const Eigen::VectorXd& getState() const override {
        state_[mass_index_] = mass_->getState()[0];
        state_[position_index_] = position_->getState()[0];
        return state_;
    }

    Eigen::VectorXd getInitialState() const override {
        Eigen::VectorXd initial(2);
        initial[mass_index_] = mass_->getInitialState()[0];
        initial[position_index_] = position_->getInitialState()[0];
        return initial;
    }

    void computeDerivatives(double,
                            const Eigen::VectorXd& candidate,
                            Eigen::VectorXd& derivative) const override {
        derivative = Eigen::VectorXd::Zero(2);
        derivative[mass_index_] = -2.0;
        derivative[position_index_] = candidate[mass_index_];
    }

    void setState(const Eigen::VectorXd& state) override {
        state_ = state;
        mass_->setState(Eigen::VectorXd::Constant(1, state[mass_index_]));
        position_->setState(
            Eigen::VectorXd::Constant(1, state[position_index_]));
    }

private:
    std::string mass_name_;
    std::string position_name_;
    gnc::interfaces::IContinuousSystem* mass_ = nullptr;
    gnc::interfaces::IContinuousSystem* position_ = nullptr;
    gnc::core::StateLayout layout_;
    mutable Eigen::VectorXd state_;
    int mass_index_ = -1;
    int position_index_ = -1;
};

GNC_REGISTER_NODE_TYPE(
    "project.coupling.mass_position",
    MassPositionGroup,
    ::gnc::core::NodeRole::Coupling,
    ::gnc::core::DiscretePhase::None,
    "",
    ::gnc::interfaces::IContinuousGroup)
```

vehicle placement：

```json
{
  "continuous_groups": [
    {
      "type": "project.coupling.mass_position",
      "name": "mass_position_group",
      "config": { "mass": "mass", "position": "position" }
    }
  ]
}
```

跨 vehicle group 放在顶层 `continuous_groups[]`，成员配置写完整名。group 只声明数值耦合边界，不吸收成员的领域角色或资产职责。

## 12. 注册元数据检查表

`GNC_REGISTER_NODE_TYPE` 参数依次是 type id、C++ 类型、role、phase、form family、provider interfaces：

```cpp
GNC_REGISTER_NODE_TYPE(
    "project.output.aerodynamics",
    project::Aerodynamics,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "local_spherical_3dof",
    project::IAerodynamics)
```

提交前检查：

- type id 稳定且唯一。
- role 与 mission placement 一致。
- `IDiscreteTask` 与 phase 元数据一致。
- Form/Interaction family 非空，相关节点 family 相容。
- factory interfaces 包含所有需要按类型查找的 provider。
- `configure()` 对 builtin 使用严格读取。
- `bind()` 只绑定依赖。
- `prepare()` 和 `initialize()` 分工清楚。
- 新失败路径给出带 mission path 的诊断。
- 切换或新增组件后重新运行 CMake。

## 13. Project 进入 Framework 的标准

项目实现优先留在 `user/<project>`。同时满足以下条件后再考虑进入 framework：

- 已有多个真实 mission 使用，语义不再随单篇论文频繁变化。
- scope、role、capability、phase 和 form family 都能清楚说明。
- provider interface 足够小，消费者无需了解具体实现。
- 物理配置严格，缺失和未知字段可诊断。
- 不依赖某个 active project 的目录、case 状态或私有全局对象。
- 有成功装配、关键缺依赖、错误 placement、错误 family 和运行结果测试。

可选 Infrastructure 还要证明其缺席路径：关闭 linked extension 后，普通 mission 仍可构建运行；显式引用该扩展时给出未知 type 或缺依赖诊断。

## 14. 测试清单

| 扩展类型 | 成功路径 | 关键失败路径 |
| --- | --- | --- |
| 普通 Process/Input/Output 节点 | mission 装配、phase 执行、observable | role/phase 不匹配、必需依赖缺失、`rate_hz` 非整数 interval |
| Form family | 状态积分、publish、Interaction 闭合 | family 为空/冲突、input provider 缺失、状态布局错误 |
| Prepared asset | 文件解析、只读产品共享、复现路径 | 文件缺失、格式/单位错误、未知配置 key |
| Perturbation | 单 case 与 SimFlow effective mission 一致 | 未声明 provider、枚举映射错误、运行节点读取 SimFlow 隐状态 |
| Infrastructure | linked + configured 正常查询，缺席时核心运行 | 未链接 type、缺 contributor、重复 frame/edge |
| Continuous group | mission/vehicle 装配与联合 RK 数值 | 空成员、未注册成员、嵌套、重复归属 |

研究模型还需要补充三类证据：

- **因果证据**：改变命令后，下游 provider、Form input 和下一发布态按照预期方向与数量级变化。
- **数值证据**：将 `dt` 减半、交叉使用积分器，或比较 independent/group 后，关键指标表现出可解释的收敛趋势。
- **物理证据**：单位、符号、守恒和解析工况检查通过，必要时还要与外部数据对比。

普通软件测试只覆盖因果证据的一部分。怎样建立完整的数值与物理证据，见 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。

框架边界变化同步更新 `test_architecture_guards.cpp`。mission schema、记录时序或连续积分语义变化还要同步更新对应文档和 ADR。

## 15. 从错误信息回到扩展步骤

| 错误类别 | 通常回到哪里检查 |
| --- | --- |
| unknown node type | active project、`components/*.hpp`、注册宏、重新 CMake 和 type 拼写 |
| role / placement mismatch | 注册宏的 role 与 mission 所在数组 |
| phase / capability mismatch | 是否继承 `IDiscreteTask`，以及注册 phase 是否为对应固定 phase |
| required binding missing | `bind()` 中的依赖名、当前 scope、provider interface 是否注册 |
| form family mismatch | Form、Interaction 和 family-specific 节点的注册 family |
| unknown config key / required field missing | `configure()` 的 ConfigReader 字段和 mission `config` |
| invalid `rate_hz` | `simulation.dt`、节点是否为离散任务、频率是否形成整数 step interval |
| asset prepare failure | 资产 URI、project root、文件格式、单位和 `prepare()` 校验 |

诊断 required binding 时先读完整解析名、当前 scope providers 和近似名称建议。临时把依赖改成 optional 会掩盖模型契约，只有物理模型确实允许缺席时才使用 `bindIfPresent()`。
