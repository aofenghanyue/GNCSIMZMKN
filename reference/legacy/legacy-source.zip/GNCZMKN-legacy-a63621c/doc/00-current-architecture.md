# 当前运行架构：一次仿真怎样从配置走到结果

本文从一次普通 mission 的运行过程出发，说明 GNCZMKN 当前使用的架构。内容覆盖程序怎样取得可用类型、mission 怎样变成节点实例、节点在运行前接受哪些检查，以及一行 CSV 怎样产生。每介绍一层结构，都会同时说明它在研究工作中解决了什么问题。

如果 Form、provider、scope 或 candidate state 还是陌生概念，建议先读 [核心概念](02-core-concepts.md)。准备沿源码处理修改时，再继续阅读 [维护者架构说明](05-architecture.md)。本页只建立全局图景，具体 type id 和字段留在参考手册中查询。

## 1. 架构目标与取舍

GNCZMKN 面向实验室研究，首先服务仓库中正在进行的仿真实验。当前架构主要保护五件事：

1. **实验条件可以审查**：mission 保存实例、参数、连接、记录和停止条件，场景逻辑尽量不藏在 runner 中。
2. **配置错误尽早出现**：未知字段、错误 placement、缺失接口和无效连续耦合都应在物理时间推进前报告。
3. **每个时刻能够解释**：发布态、离散输出、CSV、停止判断和状态提交遵循固定顺序。
4. **项目模型可以局部替换**：仍在变化的研究模型优先留在 `user/<project>`，通过小型 provider 接入其它节点。
5. **运行核心保持轻量**：框架采用固定 phase、浅层 scope 和显式 continuous group，暂时不引入任意调度 DAG、插件市场或全局 world snapshot。

这些选择都有代价。固定 phase 限制了自由调度，却让一行结果的因果关系更容易追踪；浅层 scope 无法表达任意嵌套，却让名称解析保持简单；显式 group 增加了强耦合模型的实现工作，却能防止普通模型在无意中改变连续积分语义。对于自用研究框架，可解释性和可复现性通常比无限扩展能力更有价值。

## 2. 一次运行会经历三个阶段

一次运行可以分成程序组合、mission 构建和时间推进三个阶段：

```mermaid
flowchart TB
    subgraph Compose["程序组合：CMake 与进程启动"]
        Builtins["framework builtins"] --> Catalog["FrameworkCatalog"]
        Extensions["linked extensions"] --> Catalog
        Project["active project"] --> Catalog
    end

    subgraph Build["mission 构建：仿真时间尚未推进"]
        Mission["mission JSON"] --> Config["ConfigManager"]
        Config --> Builder["SimulationBuilder"]
        Catalog --> Builder
        Builder --> Assembly["装配、校验、绑定、准备"]
        Assembly --> Validated["validated Simulator"]
    end

    subgraph Run["运行：固定步长推进"]
        Validated --> Publish["publish t_k"]
        Publish --> Discrete["discrete update t_k"]
        Discrete --> Record["record and stop check"]
        Record --> Integrate["integrate to t_k+1"]
        Integrate --> Publish
    end
```

程序组合阶段决定当前可执行文件包含哪些类型。mission 构建阶段根据 JSON 创建本次实验需要的实例，并检查连接。进入 Simulator 以后，实例才按照固定步长随时间演化。

把三个阶段分开以后，`SimulationBuilder` 无需写入某个项目算法的具体类名，Simulator 也不用读取 CMake 选项或 SimFlow 状态。研究者切换项目时，变化主要发生在 catalog 和 mission，运行内核继续遵循同一套时间规则。

## 3. 程序组合：FrameworkCatalog 记录当前可用能力

进程启动后，runner 创建一份 `FrameworkCatalog`，再按顺序注册三类内容：

```cpp
FrameworkCatalog catalog;
registerFrameworkBuiltins(catalog);
registerLinkedExtensions(catalog);
registerActiveProject(catalog);
```

Catalog 包含：

| 子注册表 | 保存内容 | 主要消费者 |
| --- | --- | --- |
| `NodeFactory` | type id、构造函数、role、phase、family、接口和来源 | MissionAssembler、组件清单 |
| `IntegratorRegistry` | 积分器 id 与构造函数 | SimulationBuilder |
| `SimFlowMaterializerRegistry` | case 物化器 id 与构造函数 | SimFlowRunner |

### 3.1 active project 怎样进入可执行程序

CMake 从 `-DGNC_ACTIVE_PROJECT=<name>` 或 `user/active_project` 取得项目名，扫描该项目的 `components/*.hpp` 和 `simflows/*.hpp`，然后生成显式注册头。可用 type 的集合在编译期形成，所以增删节点以后需要重新配置 CMake 并构建。

这种编译期组合方式适合当前实验室项目。构建结果只带入当前项目需要的类型；重复 type id 会在进程启动时立即报告；核心也无需处理动态库发现、ABI 和插件版本协商。相应的限制是，切换项目组件需要重新编译。

### 3.2 linked extension 怎样保持可选

坐标树等扩展通过构建选项进入生成的 `linked_extensions.hpp`，然后向同一 catalog 注册自己的定义。关闭扩展以后：

- catalog 不再包含对应 type；
- 未引用该能力的普通 mission 继续运行；
- 显式引用该 type 的 mission 在 unknown type 处失败。

因此，可选扩展必须同时支持“已经链接并配置”和“完全缺席”两条路径。普通 mission 在缺少扩展时仍能运行，说明核心没有暗中依赖该能力。

## 4. mission 构建要么完整成功，要么停止在运行前

`SimulationBuilder::build()` 负责把配置转换成一个可运行的 Simulator。返回时，节点已经创建，依赖和资产已经检查，连续执行计划与输出配置也已经验证；物理时间仍未推进，运行态 `initialize()` 也尚未执行。

```mermaid
sequenceDiagram
    participant R as Runner
    participant B as SimulationBuilder
    participant A as MissionAssembler
    participant G as AssemblyGraph
    participant N as NodeRegistry
    participant V as ValidationPipeline
    participant P as PreparationPipeline
    participant S as Simulator

    R->>B: catalog + loaded mission
    B->>B: validate simulation and select integrator
    B->>A: buildMission(root)
    loop each node entry
        A->>A: create and configure
        A->>N: register full name and interfaces
        A->>G: assign ownership scope
        A->>S: attach execution metadata
    end
    B->>V: descriptors + graph + registry
    V->>N: metadata validation and bind preflight
    B->>P: prepare every node
    B->>S: validate continuous plan
    B->>B: validate outputs
    B->>S: initialize logger
    B-->>R: validated Simulator
```

Logger 放在构建流程的末端。只有配置、依赖、资产和连续成员归属都检查通过以后，Builder 才打开输出文件。这样，构建失败不会提前创建空结果，也不会截断已有 CSV。

### 4.1 配置解析边界

`ConfigManager` 负责把输入文件整理成统一配置树，具体包括：

- parser facade；
- `$include` 展开和 deep merge；
- 相对路径与 `repo://`、`project://`、`user-data://` 锚点；
- 形成统一 `ConfigNode`。

`MissionAssembler` 只解释当前 mission schema。若以后改用完整 JSON 库或 YAML，可以把解析器适配成 `IConfigParser`，装配和运行内核仍然读取相同的 `ConfigNode`。SimFlow 则在 Builder 之前写出 effective mission，所以 Builder 无需理解批量配置。

### 4.2 节点创建与命名

Assembler 根据 mission 中的位置创建 scope：

```text
mission
├── environment          registry prefix = env.
├── vehicle:<id-a>       registry prefix = <id-a>.
└── vehicle:<id-b>       registry prefix = <id-b>.
```

每个节点条目依次完成：

1. 检查 wrapper key、`type`、`name`、priority 和 rate。
2. 从 NodeFactory 创建 C++ 实例。
3. 写入 type、category、origin 等实例元数据。
4. 调用 `configure(config, path)`。
5. 对 builtin 拒绝未读取的配置字段，项目节点给 warning。
6. 生成 `NodeDescriptor`。
7. 把实例所有权交给 `NodeRegistry`。
8. 把节点归属写入 `AssemblyGraph`。
9. 把 mission 实例的 phase、priority 和 rate 交给 Simulator。

NodeFactory 保存可以重复创建的类型定义，NodeRegistry 保存本次 mission 实际创建的实例。同一个 `type = X` 可以出现多次，只要每个实例的完整名称不同。

### 4.3 构建期对象所有权

主要所有权关系为：

```mermaid
flowchart TB
    Main["runner main"] --> Catalog["FrameworkCatalog"]
    Main --> Builder["SimulationBuilder"]
    Builder --> Config["ConfigManager"]
    Builder --> Simulator["Simulator"]
    Simulator --> Registry["NodeRegistry"]
    Registry --> Nodes["unique_ptr<SimulationNode>"]
    Simulator --> Integrator["IIntegrator"]
    Simulator --> Logger["AutoDataLogger"]
    Builder -. "raw pointer views" .-> EnvVehicles["EnvironmentInstance / VehicleInstance"]
```

节点对象的唯一所有权放在 NodeRegistry 中。EnvironmentInstance、VehicleInstance、执行条目和装配描述符只保存非拥有视图或元数据。这样，一个实例只会在一个地方销毁，领域容器也不会形成互相竞争的所有权。

## 5. 六类拓扑分别记录六种事实

mission 创建的节点既有所有权关系，也有数据连接、执行顺序和连续耦合关系。如果把这些事实混进同一张图，修改一类规则时很容易影响其它语义。当前实现分别保存六类拓扑，每类事实都有固定的记录位置。

### 5.1 所有权拓扑：AssemblyGraph

`AssemblyGraph` 保存 scope、父子关系、节点归属、同 scope 枚举和名称解析。父关系用来表达所有权并生成诊断，不会让短名自动向父级查找。

这张图回答下面几类问题：

- `guidance` 属于哪个 vehicle；
- `target.truth` 与 `interceptor.truth` 是否是不同实例；
- vehicle continuous group 能否接管某成员；
- required binding 失败时应列出哪些同 scope 候选。

### 5.2 placement 拓扑：PlacementPolicy

`PlacementKind + PlacementPolicy` 是 mission 位置与 scope kind、role、受约束 phase、必需 capability 之间的统一规则表。

例如：

| Placement | Scope | Role | 若实现离散任务，要求的 phase | 必需能力 |
| --- | --- | --- | --- | --- |
| `vehicles[].form.components[]` | Vehicle | Form | 不接受离散 task | family 非空由验证补充 |
| `vehicles[].process[]` | Vehicle | Process | Process | 无额外 capability |
| `vehicles[].continuous_groups[]` | Vehicle | Coupling | None | `IContinuousGroup` |
| `termination` | Mission | Termination | Evaluation | `ITerminationEvaluator` |

Assembler 记录每个实例来自哪个 placement，ValidationPipeline 再用同一份 policy 校验它。新增 placement 等于扩展 mission 语言，因此 schema、policy、Assembler、测试和文档都要一起更新。

### 5.3 依赖拓扑：AssemblyContext

全部节点注册完成后，ValidationPipeline 根据 AssemblyGraph 中的实际归属，为每个节点构造 `AssemblyContext`，再调用 `bind()`。

短名只在当前 scope 补前缀：

```text
interceptor scope: dynamics -> interceptor.dynamics
target scope:      dynamics -> target.dynamics
any scope:         env.earth -> env.earth
```

required binding 失败时，诊断会列出解析后的完整名、请求的接口、同 scope 节点与 provider、scope lineage，以及近似名称建议。使用者因此能够从 mission 路径直接回到缺失或拼错的依赖。

绑定成功只能证明 provider 存在并且接口类型相符。它不会自动增加调度边；同一 phase 中的数据先后仍要由 priority 和 rate 表达。

### 5.4 离散执行拓扑：phase、priority、rate

离散任务的排序键为：

```text
DiscretePhase -> priority -> registration order
```

`rate_hz` 进一步决定节点在某个 step 是否到期。固定 phase 给出领域之间的大顺序，priority 描述同一 phase 中的数据链，registration order 只在前两项相同时保证结果确定。

### 5.5 连续耦合拓扑：system 与 group

Simulator 从 registry 中发现 `IContinuousSystem` 和 `IContinuousGroup`，校验 group 成员后生成 continuous plan。加入 group 的成员会从独立积分列表中排除，从而保证每份连续状态在一个宏步中只推进一次。

continuous plan 只规定 RK 候选状态在哪个范围内共享。成员原有的 Form、Output 等 role 和 provider 接口保持不变。

### 5.6 扩展组合拓扑：Catalog

Catalog 记录每个 type 定义来自哪里。mission 不会在运行时下载或发现缺失 type，project 节点也不能覆盖同名 builtin。重复 id 直接报错，因此运行结果不会取决于谁最后注册。

## 6. ValidationPipeline：在运行前检查装配是否自洽

ValidationPipeline 依次检查元数据、依赖和 continuous group scope。各类错误都附带实例与 mission 位置，尽量让研究者在运行前一次看到完整问题。

### 6.1 descriptor 与 placement 一致性

- descriptor scope 与 AssemblyGraph ownership 一致；
- scope kind 符合 placement；
- 注册 role 符合 placement；
- `IDiscreteTask` 与非 None phase 一致；
- 固定 placement 中的 task phase 正确；
- Form 与 Interaction family 非空；
- vehicle 内 family 相容；
- Perturbation、Coupling、Termination、Summary 具有必需接口。

### 6.2 依赖预检

在诊断模式下，`bind()` 会收集多个 required binding 问题，使用者无需每次重启只修一个缺失依赖。绑定成功的节点会被标记，普通 Builder 路径进入 Simulator 初始化后不会再次绑定。

项目节点的 `bind()` 应保持幂等，只保存接口引用。此时资产可能还没有 prepare，运行态也尚未建立，所以函数不能加载共享数据或推进状态。

### 6.3 continuous group scope

vehicle group 的成员必须来自同一个 vehicle scope。跨 vehicle 或跨 scope 的耦合要使用 mission group。空成员、未注册成员、嵌套 group 和重复归属等更细规则由 Simulator 在建立 continuous plan 时检查。

## 7. Preparation：在仿真开始前加载和检查资产

依赖预检成功后，`PreparationPipeline` 按 registry 顺序调用每个节点的 `prepare(PreparationContext)`。上下文提供统一的资产路径解析；`PreparedAssetCache` 可以让同一进程中的串行 case 复用不可变数据产品。

关键契约为：

```text
all configure
-> all bind
-> all prepare complete
-> any initialize
```

当前没有 preparation DAG。producer 应在自己的 `prepare()` 中生成只读产品，consumer 等全部 prepare 完成以后，再在 `initialize()` 或运行阶段读取。如果 consumer 在自己的 `prepare()` 中要求另一个 producer 已经准备好，就会暗中依赖注册顺序，而当前架构没有承诺这种先后。

现有资产加载尚不需要多级准备图，所以这套顺序调用更容易理解。等到项目中出现多个稳定的“资产 A 生成产品、资产 B 再基于该产品准备”的案例后，才有足够依据为 preparation 设计显式依赖和循环检测。

## 8. Simulator 从什么时候进入运行态

`SimulationBuilder::build()` 返回以后，仿真时间仍停在零点，节点也没有执行运行态 `initialize()`。第一次调用 `Simulator::run()` 时，初始化按下面的顺序进行：

1. 为 direct Simulator 用法绑定尚未绑定的节点。
2. 再次验证 continuous plan。
3. 初始化节点；注册为 Perturbation discrete phase 的节点稳定分区到最前，其余保留 registry 顺序。静态 perturbation 没有离散 phase，仍按 registry 顺序初始化。
4. 标记 Simulator 已初始化。

当前也没有通用的 initialize 依赖 DAG。节点应在 `initialize()` 中建立自身运行态初值；静态共享产品已经在 prepare 阶段全部完成。需要读取其它节点本周期输出的计算，应等到第一次 `publish/update(t_0)`，这样结果不会依赖 registry 中的初始化顺序。

direct Simulator 路径主要服务聚焦测试和小型程序。它会补做依赖绑定并执行 initialize，但不会自动准备资产；调用者需要自行调用准备逻辑，或者使用完整 Builder 路径。

## 9. 运行时同时存在离散链和连续链

典型 vehicle 的运行数据分成两条相互连接的路径：

```mermaid
flowchart TB
    subgraph Sampled["采样与离散决策"]
        Truth["published truth x_k"] --> Input["Input y_k"]
        Input --> Process["Process command c_k"]
        Process --> Output["discrete Output response r_k"]
    end

    subgraph Continuous["候选状态与积分"]
        Candidate["candidate state x*"] --> Basis["candidate truth basis"]
        Basis --> Closure["Interaction query"]
        Output --> Closure
        Env["Environment query"] --> Closure
        Closure --> Derivative["dx/dt"]
        Derivative --> Next["x_k+1"]
    end
```

离散链在 `t_k` 产生新输出，并保持到下一次更新。随后，积分器会多次查询连续导数。Interaction 可以用 candidate truth 重新计算气动、重力和坐标量，同时读取本周期已经保持的命令与 Output 状态。

### 9.1 为什么 Interaction 既可能有 phase，也可能没有

纯函数式 closure 只提供 Form input query，注册 phase 为 None。CAVH 和 YYZ 项目的 Interaction 都采用这种方式。

如果 closure 还包含离散采样、缓存或模式切换，可以实现 `IDiscreteTask` 并进入 Interaction phase。`update(t_k)` 处理本周期离散状态，Form input query 仍可能在 RK 子步中多次调用。两种行为使用不同的时间语义，需要分别测试。

## 10. 固定步长循环的精确顺序

设 `duration / dt = N`。Simulator 会访问 `k = 0 ... N` 的每个发布点。一个周期的完整顺序如下：

```text
publish t_k
-> callbacks.before_step(t_k)
-> Environment
-> Perturbation
-> Input
-> Process
-> Output
-> Interaction
-> Evaluation
-> logger.record(t_k)
-> termination check(t_k)
-> if k == N: finish
-> integrate every continuous plan entry to t_{k+1}
-> commit every next state
-> callbacks.after_step(t_{k+1})
```

### 10.1 Publish 排序

所有 `IPublishTask` 按：

```text
PublishPhase(StateOwner, View, Ordinary)
-> priority
-> registration order
```

Form 通常在 StateOwner phase 发布 truth。publish 早于当前周期的离散更新，因此 truth 中依赖命令的派生量只能使用边界时刻已经保持的输出。

### 10.2 Discrete 排序与多速率

Simulator 为每个 phase 收集 execution entry，按 priority 和 registration order 稳定排序。`rate_hz` 会转换成整数 `step_interval`，只有满足 `k % interval == 0` 时才调用 `update()`。

慢速节点跳过某一步时，provider 会继续返回上次输出。框架不会在两个输出之间插值，也不会因此缩小连续积分步长。

### 10.3 记录、终止和 terminal sample

记录发生在全部离散更新之后。默认的 `t_0` 行保存 `x_0`，以及各个到期节点根据 `x_0` 得到的首周期输出。如果终止条件在 `t_k` 命中，记录器会先写入这一行，再结束仿真；关闭 `record_initial_state` 后，`t_0` 行仍按配置省略。

到达配置时长终点 `t_N` 时，Simulator 仍会 publish，执行到期离散任务，记录并检查终止条件，然后才结束。此后不会再积分到 `t_{N+1}`，所以终点行中的命令只能用于观察算法在终端状态下的输出，没有后续状态段可供驱动。

### 10.4 正常完成后的收尾

正常退出循环后：

1. logger 关闭 CSV；
2. `SimulationSummary` 写基础参数、节点清单、调度信息和项目 Summary；
3. 节点按 registry 顺序 `finalize()`；
4. ExecutionPhaseManager 进入 Completed。

Summary 在节点 `finalize()` 之前读取最终状态，因而可以计算末端指标。`finalize()` 只处理运行期资源和正常收尾，不再改变摘要中已经读取的结果。

## 11. 连续积分怎样保持同步

### 11.1 独立系统同步提交

对每个 continuous plan entry：

```text
copy current state
-> integrator.step(derivative, t_k, candidate, dt)
-> store pending next state
```

所有 entry 都计算完成后，Simulator 才统一提交 pending state。这样，跨独立系统查询不会在同一个宏步里看到一部分状态已经进入 `x_{k+1}`、另一部分还停在 `x_k` 的混合结果。

对单个系统来说，RK4 的 derivative 会接收该系统自己的候选状态。它通过普通 provider 查询其它独立系统时，通常仍读到发布态。同步独立积分的数值语义正来自这一区别。

### 11.2 IContinuousGroup

group 自己实现联合状态与联合导数，并声明成员。continuous plan 校验：

- 成员非空且非空指针；
- group 不包含自己；
- group 不嵌套；
- 成员是 registry 中的 continuous node；
- 一个成员只属于一个 group。

校验通过后，group 作为一个 plan entry 进入积分器，成员不再独立推进。由于 group 使用联合候选向量，所有成员都能在 RK 子步读取同一时刻的候选状态。

## 12. 记录怎样成为可复现证据

### 12.1 AutoDataLogger

Logger 从 NodeRegistry 中发现实现 `IObservable` 的节点，再按 outputs 配置选择字段。CSV 的 `time` 是发布点时间。debug snapshot 适合临时查看内部变量，长期分析依赖的字段应通过稳定 observable 提供。

公开字段需要说明：

- 物理单位和坐标系；
- 它来自 publish、update 还是候选 closure 缓存；
- 慢速节点跳过更新时是否保持；
- 是否包含一拍延迟、滤波或饱和。

### 12.2 summary.txt

摘要保存：

- `dt`、配置时长、实际终止时间和原因；
- wall clock 与步数；
- 每个实例的 type、category、origin；
- phase、priority、配置 rate 和生效 step interval；
- 记录字段统计；
- `ISummaryObserver` 提供的项目指标。

复现实验时，应先用摘要核对实际实例、type 和调度是否与设想一致，再分析 CSV 曲线。这样可以先排除构建了错误项目或使用了错误频率等基础问题。

### 12.3 失败构建与输出安全

continuous plan 和 outputs 配置都在 logger 初始化前检查。构建失败时，Builder 会抛出聚合诊断，也不会为这次失败任务创建或截断 CSV。

运行期异常尚未进入统一收尾路径；logger 最终只能依靠对象析构关闭，summary、node finalize 和失败状态文件都没有一致保证。这个限制属于当前实现事实，相关改进建议记录在 `design-notes/`，不能从成功运行路径的事务语义类推。

## 13. 坐标树展示了可选 Infrastructure 的组织方式

坐标扩展内部边界为：

```text
ICoordinateTransform          consumer 查询契约
CoordinateTreeNode            tree owner / Infrastructure node
CoordinateTreeBuilder         prepare 期构建 API
ICoordinateFrameContributor   同 scope 扩展点
LocalSpherical...Frames       一个具体 frame 定义
internal/CoordinateTree       封装后的搜索与组合实现
```

`CoordinateTreeNode::bind()` 收集同 scope contributor，`prepare()` 再统一 seal 和校验。项目新增坐标系时只需增加 contributor，tree owner 无需加入该坐标系的专用分支，也无需理解它的物理来源。

这套结构把稳定的图搜索与组合算法留在 tree owner 中，把具体坐标系的物理定义交给 Form 或项目 contributor。它适合坐标树一类可选基础设施，也说明 Infrastructure 应提供查询能力，而不接管 GNC 流程。

## 14. SimFlow 边界

SimFlow 只在仿真前物化 case 并安排执行：

```text
read simflow
-> materializer creates case values
-> patch base mission
-> freeze explicit asset URIs
-> write effective_mission.json
-> ordinary build and run
-> collect case summary
```

串行模式在当前进程中逐个构建 case，可以复用进程内的 prepared asset cache。并行模式会启动子进程，让各个 case 的运行状态彼此隔离。两种模式最终都使用普通 runner 和普通 Simulator。

runtime 节点只读取 effective mission 中的 perturbation/provider。如果节点还要读取 case index 或 SimFlow 路径，这个 case 就无法只凭 `effective_mission.json` 独立回放。

## 15. 当前明确边界

当前架构有意保持以下边界：

- mission 顶层物理实体使用 `vehicles[]`；
- scope 只有 Mission、Environment、Vehicle 三层；
- 离散调度使用固定 phase，无任意依赖 DAG；
- 默认连续模型使用同步独立积分；强耦合显式进入 group；
- 跨 vehicle 查询按发布态理解；没有全局 WorldSnapshot；
- PreparationPipeline 没有多级准备依赖图；
- Infrastructure 不承担任务流程、制导控制或方程闭合；
- Interaction 不拥有气动资产、质量定义和任务模式；
- Simulator 不解析 mission、SimFlow 或项目资产路径；
- Builder 不隐式注册 builtin、扩展或项目类型；
- direct Simulator 不隐式创建积分器，也不自动执行 asset preparation；
- 当前没有覆盖完整事务语义的交互式 `step(int)`。

这些边界可以随着真实研究需求演进。准备增加核心抽象时，先确认现有 Form、Process、Infrastructure 或 continuous group 是否已经能够表达问题；只有真实项目反复遇到同一缺口，才有理由扩展核心语言。

## 16. 从问题定位源码

| 维护问题 | 首要入口 | 继续追踪 |
| --- | --- | --- |
| type 为什么没有注册 | `src/runner_component_registration.cpp` | generated registration、CMake、NodeFactory |
| mission 条目怎样变成实例 | `simulation_builder.hpp` | `mission_assembler.hpp`、`placement_policy.hpp` |
| 短名怎样解析 | `assembly_graph.hpp` | `assembly_context.hpp`、`validation_pipeline.hpp` |
| 配置错误怎样聚合 | `simulation_builder.hpp` | `config_reader.hpp`、节点 `configure()` |
| 资产何时加载 | `preparation_pipeline.hpp` | `preparation_context.hpp`、producer `prepare()` |
| 节点为什么先后执行 | `simulator.hpp` | `execution_metadata.hpp`、注册 phase、mission priority |
| CSV 一行来自哪里 | `simulator.hpp` | `auto_data_logger.hpp`、节点 observable |
| 连续成员为何没单独推进 | `simulator.hpp::buildContinuousPlan()` | `i_continuous_group.hpp`、group `members()` |
| SimFlow 怎样保持单 case 可回放 | `simflow_runner.hpp` | materializer、mission patch、path utils |

准备进入源码时，继续阅读 [维护者架构说明](05-architecture.md)。它会沿实际调用路径展开对象职责、修改策略和测试护栏。若当前任务是审查模型可信度，可以转到 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。
