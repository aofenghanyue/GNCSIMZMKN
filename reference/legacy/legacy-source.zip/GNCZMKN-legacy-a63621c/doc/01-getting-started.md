# 快速上手

这篇教程带你完整运行一次现成实验。你会构建并测试程序，执行一个 mission，找到它生成的 CSV 和 `summary.txt`，再把输出字段对应回具体节点。做完这些步骤以后，还要学会区分三件事：程序能否正常运行，实验能否按照同一入口复现，以及当前模型能否支撑研究结论。

教程使用 geographic 3DoF baseline。它包含 `ideal`、`zero` 和占位 closure，便于观察节点装配、运行时序和记录方式。它的气动、推进及控制链物理模型都很轻，因此不能直接作为性能基准；这部分要由项目模型继续验证。

## 环境要求

- CMake 3.16 或更新版本。
- 支持 C++17 的 MinGW 工具链。
- Eigen3，且能被 `find_package(Eigen3 3.3 REQUIRED NO_MODULE)` 找到。

Windows 下推荐使用 MinGW 生成器。不要在同一个构建目录里混用 Visual Studio 生成器和 MinGW 生成器。

## 构建和测试

在仓库根目录运行：

```powershell
cmake -S . -B build-mingw -G "MinGW Makefiles" -DBUILD_TESTS=ON
cmake --build build-mingw -j 4
ctest --test-dir build-mingw --output-on-failure
```

`build-mingw` 是推荐构建目录。切换编译器或生成器时，新建另一个构建目录更稳妥。

构建完成后，依次确认下面三项：

- CMake 输出 active project 名称和 auto-registered component 数量。
- `ctest` 全部通过。
- `build-mingw/bin/gnc_sim.exe` 存在，并能打印 `--help`。

## 运行默认任务

直接运行：

```powershell
build-mingw\bin\gnc_sim.exe
```

默认任务由构建时的 active project 决定。当前 active project 写在：

```text
user/active_project
```

如果 active project 存在 `config/mission.json`，它会成为默认任务。当前仓库默认选择：

```text
example_05_ideal_3dof_geographic_baseline
```

对应 mission：

```text
user/example_05_ideal_3dof_geographic_baseline/config/mission.json
```

修改 `user/active_project` 或新增项目组件后，重新运行 CMake 配置和构建。

也可以在配置阶段显式指定 active project：

```powershell
cmake -S . -B build-mingw -G "MinGW Makefiles" -DGNC_ACTIVE_PROJECT=example_08_cavh_geographic_3dof_custom
cmake --build build-mingw -j 4
```

当 `-DGNC_ACTIVE_PROJECT` 与 `user/active_project` 不同时，CMake 使用 cache 值并给出 warning。

## 运行指定任务

可以显式传入 mission 路径：

```powershell
build-mingw\bin\gnc_sim.exe --config user/example_05_ideal_3dof_geographic_baseline/config/mission.json
```

也可以省略 `--config`：

```powershell
build-mingw\bin\gnc_sim.exe user/example_06_ideal_cartesian_3dof_baseline/config/mission.json
```

相对路径可以相对当前工作目录，也可以相对仓库根目录。runner 会从当前目录和可执行文件目录向上搜索。

### 第一次运行的检查点

建议先运行 geographic 3DoF baseline：

```powershell
build-mingw\bin\gnc_sim.exe --config user/example_05_ideal_3dof_geographic_baseline/config/mission.json
```

随后检查：

```powershell
Get-ChildItem user/outputs/example_05_ideal_3dof_geographic_baseline
Get-Content user/outputs/example_05_ideal_3dof_geographic_baseline/summary.txt
Import-Csv user/outputs/example_05_ideal_3dof_geographic_baseline/ideal_3dof_geographic_baseline.csv |
    Select-Object -First 2
```

你应看到以下对应关系：

| 看到的内容 | 回到 mission 查哪里 | 它说明什么 |
| --- | --- | --- |
| `interceptor.dynamics.*` | `vehicles[0].form.components[]` | Form 发布的周期开始状态和派生真值 |
| `interceptor.guidance.*` | `vehicles[0].process[]` 中名为 `guidance` 的节点 | 当前状态经过输入与 GNC 链路后得到的本周期指令 |
| `target.truth.*` | `vehicles[1].form.components[]` | 目标 vehicle 的发布态 |
| 节点和调度清单 | `summary.txt` | 实际实例名、type、phase、priority 与生效频率 |

CSV 第一行的 `time` 为 `0`。该行同时保存初始发布态 `x_0` 和由 `x_0` 计算出的首周期离散输出。下一行状态已经经过一次积分。

这个 baseline 在 `simulation.duration` 中配置了 0.2 s 的运行上限，termination 的 `max_time_s` 则是 0.1 s。因此，`summary.txt` 应同时显示 configured duration 0.2 s 和 actual final time 0.1 s。仿真在 0.1 s 先满足了 mission 级停止条件，记录对应的发布态后便提前结束。

### 第一次结果审查

程序返回成功以后，再从装配、时间和模型三个角度检查结果：

| 层次 | 本次检查 | 能得到的结论 |
| --- | --- | --- |
| 装配 | `summary.txt` 中的实例、type、phase、priority 和 rate 与 mission 一致 | 当前可执行文件正确创建了预期拓扑 |
| 时间 | CSV 第一行是 `x_0` 与 `update(t_0)`，第二行是一次积分后的 `x_1` | 发布、离散更新、记录和积分顺序符合契约 |
| 模型 | 查看 Interaction、气动、推进和质量的具体实现 | 当前 baseline 的物理简化范围得到确认 |

CSV 中出现 `interceptor.guidance.*`，可以确认制导节点已经运行，并通过 `IObservable` 公开了本周期命令。轨迹是否受这条命令影响，还要继续沿 `guidance -> flight_control -> control_allocation -> actuator/aero -> interaction -> Form input` 检查。以后替换算法或物理模型时，都可以沿同一条路径寻找命令与状态变化之间的证据。

### 从文件名回到实例名

`vehicles[0].id` 为 `interceptor`，节点局部 `name` 为 `guidance`，完整实例名因此是 `interceptor.guidance`。输出配置和跨 scope 依赖都使用完整名；同一 vehicle 内部绑定通常可以使用短名。

## 运行 SimFlow 批量任务

SimFlow 是仿真前置物化层。它引用一个 base mission，再通过 materializer 生成每个 case 的 `effective_mission.json`。内置 `simflow.materializer.numeric_perturbation` 提供纯数值拉偏注入：

下面的现成配置属于 YYZ 项目。先用独立构建目录选择该项目：

```powershell
cmake -S . -B build-mingw-yyz -G "MinGW Makefiles" `
    -DGNC_ACTIVE_PROJECT=yyz_cartesian_6dof_framework_9 `
    -DBUILD_TESTS=OFF
cmake --build build-mingw-yyz -j 4
```

```powershell
build-mingw-yyz\bin\gnc_sim.exe --simflow user/yyz_cartesian_6dof_framework_9/simflow/single.json
```

显式多进程运行：

```powershell
build-mingw-yyz\bin\gnc_sim.exe --simflow user/yyz_cartesian_6dof_framework_9/simflow/random.json --jobs auto
build-mingw-yyz\bin\gnc_sim.exe --simflow user/yyz_cartesian_6dof_framework_9/simflow/random.json --jobs 4
```

`--jobs auto` 使用 `max(1, CPU 核心数 - 1)`，留一个核心给系统。SimFlow 输出目录下会生成：

```text
case_000001_nominal/effective_mission.json
simflow_summary.csv
```

要复现其中一个 case，可以直接运行它的 effective mission，无需重新执行整组 SimFlow：

```powershell
build-mingw-yyz\bin\gnc_sim.exe --config user/outputs/yyz_cartesian_6dof_framework_9/simflow_single/case_000001_nominal/effective_mission.json
```

SimFlow 的配置、三种 case source 和失败处理见 [SimFlow 教程](simflow-guide.md)。

## 查看组件注册

查看 type id：

```powershell
build-mingw\bin\gnc_sim.exe --list-components
```

查看 type id、接口、role、离散 phase、form family 和注册来源：

```powershell
build-mingw\bin\gnc_sim.exe --list-components-verbose
```

新增项目组件后，先用这个命令确认 type id 是否进入当前构建。如果没有出现，通常需要检查：

- 组件头文件是否在 `user/<active_project>/components/` 下。
- `GNC_REGISTER_NODE_TYPE` 的 type id 是否与 mission 中的 `type` 完全一致。
- 是否重新运行了 CMake 配置和构建。

## 输出位置

输出由 mission 的 `outputs` 块控制。例如：

```json
{
  "outputs": {
    "directory": "user/outputs/{timestamp}",
    "format": "csv",
    "session_name": "cavh_3dof",
    "record": {
      "cavh.dynamics": "all"
    }
  }
}
```

`{timestamp}` 会在运行时替换为时间戳。自动记录器会写 CSV；仿真结束后，如果输出目录有效，还会写仿真摘要。

默认 CSV 文件名来自 `session_name`，例如：

```text
user/outputs/2026-05-01_113000/cavh_3dof.csv
user/outputs/2026-05-01_113000/summary.txt
```

CSV 的 `time` 列表示周期开始的发布时刻 `t_k`。记录器在全部离散 phase 完成后写入 `t0` 行：初始条件来自发布态 `x_0`；guidance 和离散 aero 已经给出首周期输出；常质量节点直接给出当前静态值。

这一行中的命令通常用于随后 `t_k -> t_{k+1}` 的积分，所以命令引起的状态变化要到下一行查看。truth 中若包含依赖保持命令的加速度，它在本周期 publish 阶段已经计算完成，可能使用边界时刻已有的上一周期保持量。公开这类字段时，节点契约还要说明它们对应哪个计算时刻。

调试快照可用于排查组件内部状态：

```json
{
  "outputs": {
    "directory": "user/outputs/{timestamp}",
    "record": {
      "vehicle.dynamics": "all"
    },
    "debug_snapshots": {
      "enabled": true,
      "components": ["vehicle.dynamics"]
    }
  }
}
```

## 常用命令

```powershell
build-mingw\bin\gnc_sim.exe --help
build-mingw\bin\gnc_sim.exe --list-components
build-mingw\bin\gnc_sim.exe --list-components-verbose
build-mingw\bin\gnc_sim.exe --config user/example_05_ideal_3dof_geographic_baseline/config/mission.json
build-mingw-yyz\bin\gnc_sim.exe --simflow user/yyz_cartesian_6dof_framework_9/simflow/random.json --jobs auto
```

## 常见问题

| 现象 | 处理方式 |
| --- | --- |
| CMake 找不到 Eigen3 | 确认 Eigen3 安装位置，并通过工具链文件或 `CMAKE_PREFIX_PATH` 暴露给 CMake |
| 默认任务找不到 | 使用 `--config <path>` 显式传入 mission，或检查 `user/active_project` |
| 修改 active project 后组件清单没变 | 重新运行 CMake 配置，再重新构建 |
| 提示未知组件类型 | 检查 mission 的 `type` 是否等于注册的 type id |
| 组件放错块 | 检查 type 的 role 和 phase，`--list-components-verbose` 会列出注册元数据 |
| 没有生成 CSV | 检查 `outputs.enabled`、`outputs.record`，并确认目标组件实现 `IObservable` |
| CSV 字段顺序或数量不符合预期 | 先用 `outputs.record` 精确列出组件和字段，再用 `exclude` 排除不需要的字段 |
| 停止条件找不到字段 | 确认 `component` 使用完整组件名，例如 `cavh.dynamics` |
| `rate_hz` 报错 | 让 `rate_hz` 严格整除 `1 / simulation.dt`，例如 `dt=0.1` 时可用 `10`、`5`、`2`、`1` Hz |

运行和输出都核对完成后，可以继续阅读 [核心概念](02-core-concepts.md)，再用 [Mission 配置](03-mission-configuration.md) 学习怎样修改实验。准备分析算法性能时，还应阅读 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。
