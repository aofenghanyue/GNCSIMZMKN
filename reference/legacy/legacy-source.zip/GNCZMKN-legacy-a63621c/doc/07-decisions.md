# 设计决策

本页记录已经接受的核心架构决定，帮助维护者理解当前选择解决了什么问题，又留下了哪些限制。详细运行拓扑见 [当前运行架构](00-current-architecture.md)，源码修改的影响范围见 [维护者架构说明](05-architecture.md)。`design-notes/` 中的推演和 backlog 仍是讨论材料，不代表当前运行契约。

## 阅读方式

可以先在下表中找到相关架构问题，再阅读对应 ADR 的背景、决定和结果：

| 架构问题 | 当前选择 | 主要收益 | 接受的限制 |
| --- | --- | --- | --- |
| mission 对象是否分成 component/service 两套体系 | 统一 `SimulationNode`，运行行为使用可选 capability | 一条装配、绑定和生命周期路径 | 节点元数据组合需要严格校验 |
| scope、role、phase 怎样表达 | 正交建模，PlacementPolicy 校验合法组合 | mission Process、静态 Output、连续 Form 都能清楚表达 | 概念数量增加，需要教学文档 |
| 连续系统怎样同步 | 默认独立积分后统一提交 | 顺序无关、语义简单、适合 sample-hold | 强耦合模型需要显式 group |
| 记录哪一时刻 | 周期开始发布态，离散更新后记录 | `x_k` 与当前周期命令同一行，停止状态可保留 | 分析命令响应时要查看下一发布态 |
| 资产何时加载 | bind 后统一 prepare，随后 initialize | 运行前失败、只读产品可共享 | 当前没有多级 preparation DAG |
| 批量试验放在哪里 | SimFlow 前置物化 effective mission | 单 case 可回放，Simulator 保持简单 | 批量状态不能直接进入 runtime node |
| 可选坐标能力怎样接入 | linked extension + Infrastructure node + contributor | 核心可在缺席时运行，新增 frame 无需改 tree owner | 构建期决定可用扩展集合 |
| 任务状态机怎样放置 | 局部对象、vehicle Process 或 mission Process，按所有权选择 | 状态权威与协调范围清楚 | 不提供通用 controlflow 基础设施 |

ADR 中的 “Superseded” 表示原决定已经被后续决策覆盖，旧条目仍保留，用于理解架构怎样演进。若要修改 Accepted 决策对应的运行语义，应新增 ADR 或明确修订原条目的状态，并同步更新文档与测试。

## ADR-012: 统一仿真节点与通用 Catalog

状态：Accepted，2026-07。

背景：旧架构让所有 mission 对象继承带离散 `update()` 的共同基类，同时为坐标等能力维护独立 service 注册、依赖和准备路径。新增基础设施、mission 状态机或连续强耦合模型时，需要修改核心装配器，架构维度也容易互相混合。

决定：

- mission 可实例化对象统一继承 `SimulationNode`，共享 `configure/bind/prepare/initialize/finalize` 生命周期。
- 运行行为使用可选 capability：`IDiscreteTask`、`IPublishTask`、`IContinuousSystem`、`IContinuousGroup` 等。
- Scope、Role、Capability、DiscretePhase 和 Form family 保持独立建模，由装配校验其组合。
- `AssemblyGraph` 是 scope、父子关系、节点 ownership 和短名解析的权威来源；parent 只用于所有权与诊断，不启用隐式向上查找。
- `PlacementKind + PlacementPolicy` 是 placement 对 scope、role、phase、必需 capability 的唯一规则表。
- 全部节点使用一套 `NodeFactory/NodeRegistry/AssemblyContext/NodeDescriptor` 路径。
- 基础设施是 `NodeRole::Infrastructure` 节点，按 mission/environment/vehicle scope 进入 `infrastructure[]`。缺少可选基础设施不影响核心 mission。
- 删除 service object、service package、service context 及对应 schema，不保留并行兼容路线。
- `FrameworkCatalog` 统一聚合 node types、integrators 和 SimFlow materializers。runner 组合 framework builtins、linked extensions 和 active project；core builder 只消费 catalog。
- 坐标树作为可选 linked extension，由 tree node 聚合同 scope frame contributors。坐标引擎、具体坐标系定义和 Form/project 依赖分别实现。
- 顶层 `process[]` 承载 mission scope 协调与状态机；vehicle 状态机继续放 `vehicles[].process[]`；节点局部状态机使用普通库对象。
- 强耦合连续状态通过 mission 或 vehicle `continuous_groups[]` 中的 Coupling node 声明，默认同步独立积分语义保持稳定。
- `vehicles[]` schema、固定离散 phase、周期开始发布态和 CSV 契约保持稳定。

结果：框架形成一条对象装配主线。扩展可以向 catalog 贡献能力，无需让 `SimulationBuilder` 认识具体扩展；静态节点也无需空离散方法。

明确删除且不提供兼容入口：

- `Simulator::step(int)` 缺少 publish、record、termination、callback 和 lifecycle 的完整事务语义。
- direct Simulator 不再隐式创建 RK4；直接注册连续系统的调用者必须 `setIntegrator()`。普通 mission 的 `integrator` 仍默认 `rk4`。
- `SimulationBuilder` 必须接收 `FrameworkCatalog`，不隐式注册 builtin、扩展或项目类型。
- 旧 Component/Service 对象模型、service schema、无 form-family type-id alias 和 dependency declarer 全部删除。

## ADR-011: 构建期资产准备与只读数据产品

状态：Accepted。

复杂资产使用独立 build-time preparation 生命周期。顺序固定为依赖预检完成后调用全部节点的 `prepare(PreparationContext)`，随后才允许 `Simulator::initialize()`。

决定：

- 原始资产路径、case 选择和处理 profile 保留在 mission；处理后的大表可以只保留在内存。
- 项目节点定义 typed data product 和 provider，典型 producer 放在 `vehicle.common`。
- 数据产品以只读对象共享，consumer 在 `initialize()` 或运行期读取。
- `AssetPathResolver` 统一普通 mission 的资产根语义；SimFlow 写 effective mission 时固化显式资产 URI。
- `PreparedAssetCache` 提供进程生命周期缓存，不承担跨进程共享。
- 当前不建立 preparation 依赖图。多级准备需求留待出现稳定案例后设计。

## ADR-010: 基础设施与流程边界

状态：Superseded by ADR-012。

原决策确认坐标等能力属于稳定基础设施，任务流程属于 Process。ADR-012 进一步删除独立 service object 系统，将稳定基础设施统一为可选 Infrastructure node。

保留的边界：

- controlflow 使用 project `vehicle.process` 或 mission `process` 节点，可在内部使用 `gnc::libraries::StateMachine`。
- framework 不提供 controlflow 基础设施节点。
- 制导与控制输出继续通过 form-specific Interaction 进入方程。

## ADR-009: 连续与离散边界

状态：Accepted，continuous group 部分由 ADR-012 扩展。

决定：

- `IDiscreteTask::update(StepContext)` 是离散入口。
- `IContinuousSystem::computeDerivatives()` 和已配置积分器负责连续推进。
- 连续执行机构、滤波器、质量或机构状态应实现 `IContinuousSystem`。
- 离散采样、命令、状态机和模式切换应放在 Process/Output 节点。
- 两侧通过显式项目接口通信。
- 需要联合候选状态时实现 `IContinuousGroup`。
- 当前不增加宽泛的 `IHybridSystem`。

## ADR-008: Form Extension Contract

状态：Accepted。

新 Form family 在进入 mission 前必须发布明确契约，至少包括：family id、state layout、truth view、input provider、连续状态所有权、publish 行为、observable 字段，以及 Interaction 如何把 environment/process/output 闭合成 Form input。

决定：

- `vehicles[].form.components` 中的节点声明非空 family。
- 单个 vehicle 只选择一个 family。
- Interaction 保持 form-specific closure，并声明非空 family。
- `contract_6dof` 只用作测试 fixture 和扩展示例。

## ADR-007: 多飞行器 Snapshot 后置

状态：Accepted。

当前只规定跨 vehicle 读取按发布态理解，暂不增加 world snapshot API，也不禁止现有 direct lookup。未来出现明确多体同步读取需求时单独设计。

## ADR-006B: 配置解析与预处理解耦

状态：Accepted。

`ConfigManager` 接收 `IConfigParser` 输出的 `ConfigNode`，随后执行 `$include` 展开和 deep merge。

决定：

- `loadFromFile()` 支持相对 include、`repo://`、`project://`、`user-data://`。
- 多个 include 按顺序 deep merge，本地字段覆盖 include，数组整体替换。
- `loadFromString()` 不支持 filesystem include。
- 新 JSON/YAML parser 或其它配置库适配器可以替换 parser 实现，无需改变 mission assembly。INI 需要由适配器明确多层 object 和 array 的映射约定。
- 内置 JSON parser 保持小型，只覆盖基础 mission 语法和确定性错误检查；完整标准能力交给专用配置库适配器。

## ADR-006: 配置严格化

状态：Accepted。

builtin 使用严格配置读取：

- 物理参数 required，缺失时失败。
- unknown key 是 build error。
- 类型错误是 build error。
- 错误消息包含 mission 路径。

安全默认值可以保留，例如 `integrator = rk4`。

## ADR-005: Interaction 是高级 Closure

状态：Accepted。

Interaction 是 Form 专属方程闭合点。气动、质量、推进模型属于 `vehicle.output`；Interaction 读取这些 provider 并形成 Form input。普通任务优先配置内建 Interaction。

## ADR-004: 离散 Update 契约

状态：Superseded in interface name by ADR-012，时间语义继续有效。

离散入口现为 `IDiscreteTask::update(StepContext)`。它读取 `t_k` 发布态，产生 `[t_k, t_{k+1}]` 的本周期保持输出，不负责连续积分。连续刷新使用 `IPublishTask::publish(PublishContext)`。

## ADR-003: 同步发布点的独立连续积分

状态：Accepted，强耦合扩展见 ADR-012。

默认连续系统按节点独立积分，每步统一提交 next state，避免同一步读取到部分新状态。`IContinuousGroup` 为需要联合 RK 候选状态的模型提供显式边界。

## ADR-002: 周期开始发布态

状态：Accepted。

固定步长循环以周期开始发布态为唯一记录和停止条件时间点：

```text
publish/refresh t_k -> before_step(t_k) -> update(t_k)
-> record t_k -> stop check t_k
-> synchronized integration to t_{k+1}
```

决定：

- CSV `time` 与状态字段严格对应。
- Form/truth 字段是周期开始发布态 `x_k` 及其真实派生量。
- 其它 observable 在离散 phases 后读取；到期 task 是本周期新输出，未到期 task 保持上次输出，静态或连续节点提供当前公开值。
- `t0` 行包含初始状态和由初始状态得到的首周期离散输出。
- observable 的模型延迟由节点自身定义。
- 停止条件命中的发布态保留在最后一行；关闭 `record_initial_state` 时，`t_0` 行按配置省略。

## ADR-001: Mission 使用 `vehicles[]`

状态：Accepted。

当前有效 mission schema 使用顶层 `vehicles[]`。单飞行器任务也是数组中的一个条目。

决定：

- 不支持 `entities[]`。
- 不支持根级 `components/services/form/vehicle/interaction`。
- 每个 vehicle 拥有独立 `<id>.` scope。
- mission scope 的 Infrastructure 和 Process 分别使用顶层 `infrastructure[]`、`process[]`。
