# Mission 配置

mission 是 GNCZMKN 装配一次实验的入口。它把本次运行采用的对象、参数、连接、记录项和停止条件集中写在 JSON 中，让研究者无需翻进 runner 就能看到实验怎样组成。当前 schema 统一使用顶层 `vehicles[]`，单飞行器任务也使用只含一个元素的数组。

另一位研究者阅读 mission 时，应该能够看出仿真时钟怎样推进，选用了哪些模型，实例之间怎样连接，哪些参数与资产进入当前 case，以及程序记录什么、何时结束。制导律、滤波器和动力学算法继续放在 C++ 中，大型数据保存在独立资产文件里；mission 只记录本次实验选择了哪些实现，以及传入了哪些参数。

| 内容 | 推荐载体 | 原因 |
| --- | --- | --- |
| 实例选择、连接、初值、采样率、停止与记录 | mission JSON | 构成一次可复现实验 |
| 制导律、滤波器、动力学和插值算法 | C++ 节点或普通库 | 需要类型、测试和编译期检查 |
| 气动表、标准轨迹、风场等大数据 | 外部资产 | 便于校验、版本管理和复用 |
| 批量 case 生成规则 | SimFlow | 与单 case 运行内核分离 |

保存 mission 可以恢复本次配置。要完整复现实验，还要保存代码版本、资产版本和构建选项；要判断结论是否可信，还要补充数值验证与模型适用范围。具体方法见 [研究级 GNC 仿真方法](08-research-simulation-methodology.md)。

## 如何阅读一份 mission

可以把 mission 当作一份实验装配单。阅读时从六个问题入手：仿真时钟怎样走，采用什么世界模型，任务中有哪些飞行器，每架飞行器装了哪些模型与算法，需要记录哪些数据，以及仿真在什么条件下结束。

```mermaid
flowchart TB
    Mission["mission"] --> Clock["simulation<br/>步长、时长、积分器"]
    Mission --> World["environment<br/>地球、大气、重力"]
    Mission --> Vehicles["vehicles[]"]
    Vehicles --> Form["form<br/>连续状态与真值"]
    Vehicles --> GNC["input -> process -> output"]
    Form --> Interaction["interaction<br/>方程输入闭合"]
    GNC --> Interaction
    Interaction --> Form
    Mission --> Observation["outputs / termination / summary"]
```

第一次阅读建议打开 `user/example_05_ideal_3dof_geographic_baseline/config/mission.json`，按文件顺序检查：

| 顺序 | 配置块 | 在示例中回答什么 | 形成的运行对象或规则 |
| --- | --- | --- | --- |
| 1 | `simulation` | 配置 0.1 s 步长、0.2 s 最大时长，使用 RK4 | 固定步长和积分器 |
| 2 | `environment.components[]` | 使用球形地球、标准大气和球形重力 | `env.earth`、`env.atmosphere`、`env.gravity` |
| 3 | `vehicles[0]` | 装配拦截器及其完整 GNC 链 | `interceptor.*` scope |
| 4 | `vehicles[0].form` | 初始经纬高、速度、弹道倾角和航向 | `interceptor.dynamics` 连续状态所有者 |
| 5 | `input/process/output/interaction` | 从真值到测量、估计、指令、物理能力和导数输入 | 固定离散 phase 数据流 |
| 6 | `vehicles[1]` | 装配运动学目标 | `target.truth` |
| 7 | `outputs` | 选择记录的完整实例名 | CSV 字段集合与目录 |
| 8 | `termination` / `summary` | 何时停止，结束后汇总什么 | mission scope 观察节点 |

其中一个节点条目：

```json
{
  "type": "vehicle.process.local_spherical_guidance_3dof.ideal",
  "name": "guidance",
  "config": {}
}
```

`type` 选择 catalog 中的 C++ 实现，`name` 是当前 scope 内的局部实例名，外层 `vehicles[0].process[]` 则给出 placement。这个节点属于 id 为 `interceptor` 的 vehicle，所以完整实例名是 `interceptor.guidance`。其它节点也按同样的规则命名。

每读完一个配置块，都可以检查四件事：它创建了哪个实例，实例依赖谁，在运行周期的哪个阶段产生数据，以及它采用了何种程度的物理简化。type id 中出现 `ideal`、`zero` 或 `standard` 时，还要查看具体实现与项目说明，确认该节点只用于接线、表示显式理想化，还是已经经过项目验证。

## 1. 顶层结构

下面的 JSON 用来展示全部 placement 的形状，其中空 Form、`termination: {}` 和 `summary: {}` 不能直接运行。复制可运行配置时请使用根 README 的最小 mission 或仓库 baseline。

```json
{
  "simulation": {
    "dt": 0.1,
    "duration": 600.0,
    "integrator": "rk4"
  },
  "infrastructure": [],
  "process": [],
  "continuous_groups": [],
  "environment": {
    "infrastructure": [],
    "components": []
  },
  "vehicles": [
    {
      "id": "vehicle",
      "infrastructure": [],
      "perturbation": {
        "type": "perturbation.static",
        "name": "perturbation",
        "config": { "inputs": {} }
      },
      "form": { "family": "cartesian_3dof", "components": [] },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": { "components": [] },
      "continuous_groups": []
    }
  ],
  "outputs": {},
  "termination": {},
  "summary": {}
}
```

`infrastructure`、`process`、`continuous_groups`、`environment`、`perturbation`、`outputs`、`termination` 和 `summary` 都可以按任务需要省略。每个 vehicle 仍必须包含有效的 Form。

旧式 `entities[]`、根级 `components/services/form/vehicle/interaction` 已退出 schema。`global_services`、`environment.services` 和 `vehicles[].services` 也已移除；基础设施节点分别写入对应 scope 的 `infrastructure[]`。

## 2. Scope 与 placement

| Mission 位置 | Scope | 要求的 role | 离散任务 phase |
| --- | --- | --- | --- |
| 顶层 `infrastructure[]` | Mission | Infrastructure | 由注册类型声明；静态节点为无 |
| 顶层 `process[]` | Mission | Process | Process |
| 顶层 `continuous_groups[]` | Mission | Coupling | 无；必须实现 `IContinuousGroup` |
| `environment.infrastructure[]` | Environment | Infrastructure | 由注册类型声明；静态节点为无 |
| `environment.components[]` | Environment | EnvironmentModel | Environment（若实现离散任务） |
| `vehicles[].infrastructure[]` | Vehicle | Infrastructure | 由注册类型声明；静态节点为无 |
| `vehicles[].perturbation` | Vehicle | Perturbation | Perturbation（若实现离散任务） |
| `vehicles[].form.components[]` | Vehicle | Form | 无；不接受离散任务 |
| `vehicles[].common[]` | Vehicle | Asset | 无；不接受离散任务 |
| `vehicles[].input[]` | Vehicle | Input | Input |
| `vehicles[].process[]` | Vehicle | Process | Process |
| `vehicles[].output[]` | Vehicle | Output | Output |
| `vehicles[].interaction.components[]` | Vehicle | Interaction | Interaction |
| `vehicles[].continuous_groups[]` | Vehicle | Coupling | 无；必须实现 `IContinuousGroup` |
| `termination` / `summary` | Mission | Termination / Summary | Evaluation（若实现离散任务） |

Scope、role 和 phase 分别描述节点归属、领域职责和离散执行位置。placement 只检查这三类信息能否形成合法组合，不会在装配时悄悄改写节点注册的类型或 phase。

## 3. 命名与依赖

vehicle id 必须匹配 `[A-Za-z_][A-Za-z0-9_-]*`，不可使用 `env` 或 `mission`，且任务内唯一。

| 位置 | name | 完整名 |
| --- | --- | --- |
| 顶层 `process[]` | `coordinator` | `mission.coordinator` |
| `environment.components[]` | `earth` | `env.earth` |
| vehicle `target` 的 Form | `dynamics` | `target.dynamics` |
| vehicle `target` 的 process | `guidance` | `target.guidance` |

输出记录、termination 和跨 scope 依赖应写完整名。节点内部可以使用当前 scope 的短名，例如 vehicle `target` 中的 `dynamics` 会解析为 `target.dynamics`。名称一旦含有点号，框架就把它当作完整名。Mission、environment 与 vehicle 的父子关系只表示所有权，不会触发隐式向上查询。

MissionAssembler 会先注册全部节点，再统一调用 `bind()`，所以 JSON 数组顺序不会影响依赖能否找到。只有当两个节点同属一个 phase 且 priority 相同时，数组形成的注册顺序才会作为确定性兜底。

## 4. Include 与合并

`$include` 在 mission assembly 前展开，可以是 string 或有序 string array：

```json
{
  "$include": [
    "project://config/presets/base_vehicle.json",
    "user-data://vehicles/cavh/defaults.json"
  ],
  "id": "vehicle"
}
```

| Prefix | Root |
| --- | --- |
| `repo://` | 仓库根目录 |
| `project://` | 当前 `user/<project>/` 根目录 |
| `user-data://` | `user/data/` |

普通相对路径以写出 `$include` 的 JSON 文件为锚点。多个 include 按声明顺序进行 deep merge，本地字段覆盖 include 中的同名字段，数组则整体替换。`loadFromString()` 没有文件系统锚点，因此拒绝 `$include`。

`ConfigManager` 通过 `IConfigParser` 接收解析后的 `ConfigNode`。默认的 `BuiltinJsonConfigParser` 覆盖当前 mission 使用的基础 JSON 语法，并会立即报告尾随内容、错误分隔符、重复 key 和非法 token。

如果项目需要完整 JSON、YAML 或其它格式，可以把专用配置库封装成 `IConfigParser`，再注入 `SimulationBuilder`。mission assembly、include 预处理和运行内核仍然使用同一种 `ConfigNode`。若要适配 INI，还要先规定 object 与 array 怎样映射，因为 mission schema 中包含多层对象和节点数组。

## 5. Simulation

| 字段 | 规则 |
| --- | --- |
| `dt` | 必填，固定步长，必须 `> 0` |
| `duration` | 必填，必须 `>= 0` |
| `integrator` | 可省略，默认 `rk4`；内建 `rk4`、`euler` |

`duration / dt` 必须形成整数步数。积分器 type id 必须存在于 `FrameworkCatalog::integrators()`；未知类型直接 build fail。

## 6. 节点条目与调度

通用节点条目：

```json
{
  "type": "vehicle.process.local_spherical_guidance_3dof.ideal",
  "name": "guidance",
  "priority": 10,
  "rate_hz": 10.0,
  "config": {}
}
```

- `type`、`name` 必填。
- 节点条目只接受 `type/name/priority/rate_hz/config`；拼错的 wrapper key 直接 build fail。
- `config` 传给节点，builtin 会拒绝未知 key、错误类型和缺失必需字段。
- `priority` 是可选整数，影响同一离散 phase 或 publish phase 内的顺序，默认 0。
- `rate_hz` 只适用于 `IDiscreteTask`，必须 `> 0`、不超过仿真频率，并形成整数 step interval。框架不会做隐式 round。
- 注册 phase 与 capability 必须一致：实现 `IDiscreteTask` 的类型要声明非 `none` phase；无离散能力的类型要声明 `none`。

### 6.1 依赖存在与执行先后是两件事

`bind()` 只检查 provider 能否找到，调度元数据负责规定读取发生在什么时候。如果两个节点同属 Process phase，而且消费者需要读取生产者在本周期刚算出的输出，就要用显式 priority 表明先后顺序：

```json
{
  "process": [
    {
      "type": "project.navigation",
      "name": "navigation",
      "priority": 10,
      "config": {}
    },
    {
      "type": "project.guidance",
      "name": "guidance",
      "priority": 20,
      "config": {}
    }
  ]
}
```

priority 数值较小的节点先执行。两者数值相同时，Simulator 会保留 mission 注册顺序，使相同配置得到确定结果。真正影响算法因果关系的数据链应写出不同 priority，并在 `summary.txt` 中核对实际顺序。

慢速节点只在到期 step 计算新值，provider 在更新间隔中继续返回上一次输出。因此，`rate_hz` 同时定义了采样频率与零阶保持时长。它不会为连续积分器创建更小的子步。

## 7. Environment、Form 与 GNC 链路

环境示例：

```json
{
  "environment": {
    "components": [
      { "type": "environment.spherical_earth", "name": "earth", "config": {} },
      { "type": "environment.standard_atmosphere", "name": "atmosphere", "config": {} },
      { "type": "environment.spherical_gravity", "name": "gravity", "config": {} }
    ]
  }
}
```

Cartesian 3DoF Form 示例：

```json
{
  "form": {
    "family": "cartesian_3dof",
    "components": [
      {
        "type": "form.cartesian_3dof.point_mass",
        "name": "dynamics",
        "config": {
          "initial_position": [0.0, 0.0, 1000.0],
          "initial_velocity": [250.0, 0.0, 0.0]
        }
      }
    ]
  }
}
```

典型 vehicle 链路：

```json
{
  "common": [
    { "type": "vehicle.common.aero_assets_3dof.zero", "name": "aero_assets", "config": {} }
  ],
  "input": [
    { "type": "vehicle.input.local_spherical_satellite_nav_3dof.ideal", "name": "satnav", "config": {} }
  ],
  "process": [
    { "type": "vehicle.process.local_spherical_navigation_3dof.ideal", "name": "navigation", "config": {} },
    { "type": "vehicle.process.local_spherical_guidance_3dof.ideal", "name": "guidance", "config": {} }
  ],
  "output": [
    { "type": "vehicle.output.mass_3dof.constant", "name": "mass", "config": { "mass_kg": 100.0 } },
    { "type": "vehicle.output.propulsion_3dof.zero", "name": "propulsion", "config": {} },
    { "type": "vehicle.output.actuator_3dof.ideal", "name": "actuator", "config": {} },
    { "type": "vehicle.output.aerodynamics_3dof.zero", "name": "aero", "config": {} }
  ],
  "interaction": {
    "components": [
      { "type": "interaction.local_spherical_3dof.standard", "name": "interaction", "config": {} }
    ]
  }
}
```

每个 vehicle 只能选择一个 Form family。Form 和 Interaction type 必须声明非空 family；其它带有 family 元数据的节点也要与当前 vehicle 相容。构建期会据此发现 Cartesian 节点连接 geographic truth 等错误。

### 7.1 Interaction 的两种运行形态

只负责方程闭合的 Interaction 可以注册 `DiscretePhase::None`。Form 会在 publish 或积分器 RK 子步中，用当前 truth 或候选 truth 直接查询它的 input provider。CAVH 与 YYZ 项目的 Interaction 就采用这种形式。

如果 Interaction 还需要离散采样、模式切换或周期缓存，可以实现 `IDiscreteTask` 并进入 Interaction phase。此时 `update(t_k)` 只处理离散保持状态；Form input query 仍可能在一个宏步的多个 RK 候选点被调用。query 应保持确定性，不能推进离散状态，也不能依赖调用次数。

仓库 `example_04`～`example_07` 的 builtin standard Interaction 主要用于接线基线，部分 Form input 直接采用配置中的占位加速度或角加速度。替换 guidance 后，如果要观察轨迹怎样响应命令，还要确认 Output 与 Interaction 已经把命令转换成真实的 Form input。

## 8. Mission Process 与协调逻辑

顶层 `process[]` 属于 mission scope，适合处理跨 vehicle 协调、试验阶段推进、任务规划、全局事件判定，以及整个任务共用的模式状态：

```json
{
  "process": [
    {
      "type": "project.mission.coordinator",
      "name": "coordinator",
      "priority": -100,
      "config": {}
    }
  ]
}
```

单飞行器的导航、制导、控制、事件逻辑和模式管理放在 `vehicles[].process[]`。只被一个节点使用的 PID、滤波器、插值器、状态机或优化器可以保留为普通 C++ 成员，无需为它们增加 mission placement。

## 9. 可选 Infrastructure 与坐标树

基础设施条目使用普通节点格式。坐标树扩展链接后，可以在 vehicle scope 声明 frame contributor 和查询节点：

```json
{
  "infrastructure": [
    {
      "type": "infrastructure.coordinate_frames.local_spherical_3dof.launch_track",
      "name": "launch_frames",
      "config": {
        "earth_lookup_name": "env.earth",
        "truth_lookup_name": "dynamics",
        "latitude_rad": 0.5235987755982988,
        "longitude_rad": 1.9198621771937625,
        "azimuth_rad": 1.5707963267948966,
        "launch_time_s": 0.0,
        "earth_rotation_angle_rad": 0.0
      }
    },
    {
      "type": "infrastructure.coordinate_tree",
      "name": "coordinates",
      "config": { "root_frame": "I" }
    }
  ]
}
```

`CoordinateTreeNode` 在 `bind()` 时收集同 scope 的 `ICoordinateFrameContributor`，在 `prepare()` 中构建、校验并封装整棵树。其它节点通过 `ICoordinateTransform` 查询 `coordinates`。由于 contributor 在全部节点注册以后统一收集，数组顺序不会影响结果。

普通 mission 可以省略整个 infrastructure 块。如果 mission 引用了坐标 type id，而当前构建没有链接坐标扩展，构建阶段会报告 unknown type。可以设置 `GNC_LINK_COORDINATE_TREE_EXTENSION=OFF`，确认普通 Form、GNC 和积分链在缺少该扩展时仍能运行。

## 10. 连续耦合组

`continuous_groups[]` 使用通用节点条目。vehicle group 可以用短名绑定同 vehicle 成员；mission group 使用完整名连接任意 scope：

```json
{
  "continuous_groups": [
    {
      "type": "project.coupling.aeroelastic",
      "name": "aeroelastic_group",
      "config": {
        "members": ["structure", "actuator"]
      }
    }
  ]
}
```

group type 必须注册 `NodeRole::Coupling` 和 `DiscretePhase::None`，同时实现 `IContinuousGroup`。它列出的成员都要是已经注册的 `IContinuousSystem`；成员列表不能为空，group 不能嵌套，同一成员也不能归属多个 group。vehicle group 只接管同一 vehicle scope 中的成员，跨 scope 耦合要使用 mission group。积分时，group 作为一个联合 `IContinuousSystem` 计算候选状态，并在完成后把联合结果分发给各成员。

## 11. Perturbation 与 SimFlow

`vehicles[].perturbation` 是可选的飞行器级拉偏状态源。SimFlow 内建数值物化器把每个 case 的数值输入写入：

```text
vehicles[].perturbation.config.inputs
```

示例：

```json
{
  "perturbation": {
    "type": "perturbation.static",
    "name": "perturbation",
    "config": {
      "inputs": {
        "engine.temp_level": 2,
        "aero.drag_bias": -0.03
      },
      "enum_maps": {
        "engine.temp_level": {
          "0": "cold.txt",
          "2": "hot.txt"
        }
      }
    }
  }
}
```

case 输入经过三步进入运行节点：

1. SimFlow 或单次 mission 提供 case 数值输入。
2. perturbation 节点解析为 number/string/vector 状态。
3. 气动、发动机、质量或制导节点通过 `IPerturbationProvider` 读取。

运行时节点只读取 `IPerturbationProvider`，不会接触 SimFlow 路径或 case index。每个 `effective_mission.json` 都是完整的单 case 回放入口，其中的资产 URI 已经物化成明确路径。

动态拉偏可由自定义 `IDiscreteTask` 在 Perturbation phase 更新。同一周期的 Input、Process、Output 和 Interaction 可以读取更新后的状态。

本节只说明普通 mission 怎样接收拉偏 provider。base mission 的前提、`single/matrix/random` case source、路径规则、批量输出、失败处理和单 case 回放见 [SimFlow 教程](simflow-guide.md)。

## 12. Outputs

```json
{
  "outputs": {
    "directory": "user/outputs/{timestamp}",
    "format": "csv",
    "session_name": "ideal_3dof",
    "record_initial_state": true,
    "record": {
      "vehicle.dynamics": "all",
      "vehicle.guidance": ["command"]
    },
    "exclude": ["*.debug_counter"]
  }
}
```

`record` 支持 `"all"`、节点名数组、节点到字段选择的 object。字段数组按 observable 前缀匹配。`debug_snapshots` 可记录临时排查量，这些字段不承担长期契约。

`outputs` 及 `debug_snapshots` object 使用严格字段和类型检查。未知 key、错误类型、非 `csv` format 或超出 1～17 的 precision 都会在打开文件前导致 build fail。

CSV 的每一行对应发布时刻 `t_k`。Form 和 truth 字段来自发布态 `x_k`，其它字段在离散 phase 全部完成后读取。本步到期的 task 给出本周期新输出，未到期的 task 保持上次输出，静态或连续节点给出当前可查询的值。停止条件命中的行会先写入 CSV；如果关闭 `record_initial_state`，而任务在 `t_0` 已经命中，`t_0` 行会按配置省略。

Form truth 如果包含加速度、比力等依赖保持输入的派生量，这些字段会在本周期离散更新前的 publish 阶段形成。当前周期的新命令随后产生，并用于 `t_k -> t_{k+1}` 的积分。项目应为这类 observable 单独说明计算时刻和所用保持量。

### 12.1 用两行 CSV 检查时间语义

假设 `dt = 0.1`，CSV 的前两行应按下面理解：

| `time` | Form / truth 字段 | Input / Process / Output 字段 |
| --- | --- | --- |
| `0.0` | 初始发布态 `x_0` | 离散 phases 后的首周期值；到期 task 基于 `x_0` 更新，静态节点暴露当前能力 |
| `0.1` | 第一次积分提交后的 `x_1` | 离散 phases 后的当前值；到期 task 基于 `x_1` 更新，慢速 task 可能继续保持 |

同一行可以用来分析当前状态产生了什么指令。若算法自身包含一拍延迟，延迟由节点内部状态和 observable 语义表达；记录器不会自行补偿或重新对齐。

到达配置时长终点 `t_N` 后，Simulator 仍会执行 publish、到期离散任务、记录和停止判断，然后结束运行。终点行可以观察算法在终端状态下给出的输出，但这条命令没有后续 `t_N -> t_{N+1}` 状态段可供驱动。

修改 `record` 后，先用短任务运行并检查 CSV 表头。字段不存在时依次检查完整实例名、节点是否实现 `IObservable`、字段前缀和 `exclude`。

## 13. Termination 与 Summary

```json
{
  "termination": {
    "type": "termination.component_field_below",
    "name": "termination",
    "config": {
      "component": "vehicle.dynamics",
      "field": "altitude_m",
      "value": 10000.0,
      "description": "Terminate below 10 km altitude"
    }
  }
}
```

`termination` 是 mission scope 单例，必须实现 `ITerminationEvaluator`。`summary` 同样是 mission scope 单例，必须实现 `ISummaryObserver`。旧 `stop_conditions[]` 已移除。

## 14. 已删除 schema 与 type id 迁移

本节服务于旧 mission 迁移。第一次写新 mission 可以跳过。

实现层只保留当前路径。旧字段或旧 type id 会直接构建失败。

| 已删除入口 | 当前入口 |
| --- | --- |
| `entities[]` | `vehicles[]` |
| 根级 `components/form/vehicle/interaction` | 对应的 mission、environment 或 vehicle placement |
| `global_services` | 顶层 `infrastructure[]` |
| `environment.services` | `environment.infrastructure[]` |
| `vehicles[].services` | `vehicles[].infrastructure[]` |
| `stop_conditions[]` | 顶层单例 `termination` |

旧的无 form-family type id 全部删除，完整映射如下：

| 旧 type id | 当前 local-spherical type id | Cartesian 选择 |
| --- | --- | --- |
| `vehicle.input.imu_3dof.ideal` | `vehicle.input.local_spherical_imu_3dof.ideal` | `vehicle.input.cartesian_imu_3dof.ideal` |
| `vehicle.input.satellite_nav_3dof.ideal` | `vehicle.input.local_spherical_satellite_nav_3dof.ideal` | `vehicle.input.cartesian_satellite_nav_3dof.ideal` |
| `vehicle.input.air_data_3dof.ideal` | `vehicle.input.local_spherical_air_data_3dof.ideal` | `vehicle.input.cartesian_air_data_3dof.ideal` |
| `vehicle.input.seeker_3dof.ideal` | `vehicle.input.local_spherical_seeker_3dof.ideal` | `vehicle.input.cartesian_seeker_3dof.ideal` |
| `vehicle.input.imu_6dof.ideal` | `vehicle.input.local_spherical_imu_6dof.ideal` | `vehicle.input.cartesian_imu_6dof.ideal` |
| `vehicle.input.satellite_nav_6dof.ideal` | `vehicle.input.local_spherical_satellite_nav_6dof.ideal` | `vehicle.input.cartesian_satellite_nav_6dof.ideal` |
| `vehicle.input.air_data_6dof.ideal` | `vehicle.input.local_spherical_air_data_6dof.ideal` | `vehicle.input.cartesian_air_data_6dof.ideal` |
| `vehicle.input.seeker_6dof.ideal` | `vehicle.input.local_spherical_seeker_6dof.ideal` | `vehicle.input.cartesian_seeker_6dof.ideal` |
| `vehicle.process.phase_sequencer_3dof.ideal` | `vehicle.process.local_spherical_phase_sequencer_3dof.ideal` | `vehicle.process.cartesian_phase_sequencer_3dof.ideal` |
| `vehicle.process.trajectory_planner_3dof.ideal` | `vehicle.process.local_spherical_trajectory_planner_3dof.ideal` | `vehicle.process.cartesian_trajectory_planner_3dof.ideal` |
| `vehicle.process.navigation_3dof.ideal` | `vehicle.process.local_spherical_navigation_3dof.ideal` | `vehicle.process.cartesian_navigation_3dof.ideal` |
| `vehicle.process.target_tracking_3dof.ideal` | `vehicle.process.local_spherical_target_tracking_3dof.ideal` | `vehicle.process.cartesian_target_tracking_3dof.ideal` |
| `vehicle.process.guidance_3dof.ideal` | `vehicle.process.local_spherical_guidance_3dof.ideal` | `vehicle.process.cartesian_guidance_3dof.ideal` |
| `vehicle.process.flight_control_3dof.ideal` | `vehicle.process.local_spherical_flight_control_3dof.ideal` | `vehicle.process.cartesian_flight_control_3dof.ideal` |
| `vehicle.process.control_allocation_3dof.ideal` | `vehicle.process.local_spherical_control_allocation_3dof.ideal` | `vehicle.process.cartesian_control_allocation_3dof.ideal` |
| `vehicle.process.phase_sequencer_6dof.ideal` | `vehicle.process.local_spherical_phase_sequencer_6dof.ideal` | `vehicle.process.cartesian_phase_sequencer_6dof.ideal` |
| `vehicle.process.trajectory_planner_6dof.ideal` | `vehicle.process.local_spherical_trajectory_planner_6dof.ideal` | `vehicle.process.cartesian_trajectory_planner_6dof.ideal` |
| `vehicle.process.navigation_6dof.ideal` | `vehicle.process.local_spherical_navigation_6dof.ideal` | `vehicle.process.cartesian_navigation_6dof.ideal` |
| `vehicle.process.target_tracking_6dof.ideal` | `vehicle.process.local_spherical_target_tracking_6dof.ideal` | `vehicle.process.cartesian_target_tracking_6dof.ideal` |
| `vehicle.process.guidance_6dof.ideal` | `vehicle.process.local_spherical_guidance_6dof.ideal` | `vehicle.process.cartesian_guidance_6dof.ideal` |
| `vehicle.process.attitude_control_6dof.ideal` | `vehicle.process.local_spherical_attitude_control_6dof.ideal` | `vehicle.process.cartesian_attitude_control_6dof.ideal` |
| `vehicle.process.control_allocation_6dof.ideal` | `vehicle.process.local_spherical_control_allocation_6dof.ideal` | `vehicle.process.cartesian_control_allocation_6dof.ideal` |
| `termination.engagement_3dof` | `termination.engagement_local_spherical_3dof` | `termination.engagement_cartesian_3dof` |
| `termination.engagement_6dof` | `termination.engagement_local_spherical_6dof` | `termination.engagement_cartesian_6dof` |
| `summary.engagement_3dof.ideal` | `summary.engagement_local_spherical_3dof.ideal` | `summary.engagement_cartesian_3dof.ideal` |
| `summary.engagement_6dof.ideal` | `summary.engagement_local_spherical_6dof.ideal` | `summary.engagement_cartesian_6dof.ideal` |

写完新 mission 后，先把 `duration` 设短，运行一次并检查 `summary.txt` 中的实例与调度清单，再查看 CSV 前两行的状态和命令是否符合时间契约。type id 和字段默认值可以在 [参考手册](06-reference.md) 中查询；准备批量试验时继续阅读 [SimFlow 教程](simflow-guide.md)。
