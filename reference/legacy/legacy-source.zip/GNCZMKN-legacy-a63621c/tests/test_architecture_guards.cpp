#include "test_support.hpp"

#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace {

namespace fs = std::filesystem;

fs::path repoRoot() {
    return fs::path(__FILE__).lexically_normal().parent_path().parent_path();
}

std::string normalizePath(const fs::path& path) {
    return path.lexically_normal().generic_string();
}

std::string readFile(const fs::path& path) {
    std::ifstream stream(path, std::ios::binary);
    test_support::require(stream.is_open(),
                          "Failed to read file: " + normalizePath(path));
    std::ostringstream buffer;
    buffer << stream.rdbuf();
    return buffer.str();
}

std::vector<fs::path> collectFiles(const fs::path& root) {
    std::vector<fs::path> files;
    if (!fs::exists(root)) return files;
    for (const auto& entry : fs::recursive_directory_iterator(root)) {
        if (entry.is_regular_file()) files.push_back(entry.path());
    }
    return files;
}

void requireNoFormInternalLeakage(const fs::path& root) {
    const std::string forbidden =
        "forms/local_spherical_3dof/internal/";
    const std::string allowed =
        "framework/include/gnc/forms/local_spherical_3dof/";
    const auto self = normalizePath(fs::path(__FILE__));
    for (const auto& scan_root : {root / "framework/include/gnc",
                                  root / "src",
                                  root / "tests"}) {
        for (const auto& file : collectFiles(scan_root)) {
            const auto normalized = normalizePath(file);
            if (normalized == self) continue;
            if (normalized.find(allowed) != std::string::npos) continue;
            test_support::require(
                readFile(file).find(forbidden) == std::string::npos,
                "Form-internal header leaked outside its form family: " +
                    normalized);
        }
    }
}

void requireSingleNodeObjectModel(const fs::path& root) {
    const std::vector<fs::path> removed = {
        root / "framework/include/gnc/core/component_base.hpp",
        root / "framework/include/gnc/core/component_factory.hpp",
        root / "framework/include/gnc/core/component_registry.hpp",
        root / "framework/include/gnc/core/scoped_registry.hpp",
        root / "framework/include/gnc/core/assembly_descriptor.hpp",
        root / "framework/include/gnc/core/service_context.hpp",
        root / "framework/include/gnc/core/service_package_registry.hpp",
        root / "framework/include/gnc/bootstrap/register_builtin_service_packages.hpp",
        root / "framework/include/gnc/infrastructure/dependency_validator.hpp",
    };
    for (const auto& path : removed) {
        test_support::require(!fs::exists(path),
                              "Removed object-model path still exists: " +
                                  normalizePath(path));
    }

    const auto node_text =
        readFile(root / "framework/include/gnc/core/simulation_node.hpp");
    const auto capability_text =
        readFile(root / "framework/include/gnc/core/runtime_capabilities.hpp");
    test_support::require(
        node_text.find("class SimulationNode") != std::string::npos &&
            node_text.find("virtual void prepare") != std::string::npos,
        "SimulationNode must own the common mission-object lifecycle.");
    test_support::require(
        capability_text.find("class IDiscreteTask") != std::string::npos &&
            capability_text.find("class IPublishTask") != std::string::npos &&
            capability_text.find("struct StepContext") != std::string::npos,
        "Discrete and publish behavior must remain optional capabilities.");
    test_support::require(
        node_text.find("getSimTime") == std::string::npos &&
            node_text.find("getExecutionFrequency") == std::string::npos,
        "Simulation time and scheduling metadata must stay outside SimulationNode.");
}

void requireNoLegacyRuntimeLine(const fs::path& root) {
    const std::vector<std::string> forbidden = {
        "ComponentBase",
        "ComponentFactory",
        "ComponentRegistry",
        "ScopedRegistry",
        "ServiceContext",
        "ServicePackageRegistry",
        "IServicePackage",
        "IServiceFinalizationTask",
        "IDependencyDeclarer",
        "injectServices",
        "NodeFactory::instance",
        "SimFlowMaterializerRegistry::instance",
        "services/coordinate_tree",
    };
    const auto self = normalizePath(fs::path(__FILE__));
    for (const auto& scan_root : {root / "framework/include/gnc",
                                  root / "src",
                                  root / "user"}) {
        for (const auto& file : collectFiles(scan_root)) {
            if (normalizePath(file) == self) continue;
            const auto text = readFile(file);
            for (const auto& token : forbidden) {
                test_support::require(
                    text.find(token) == std::string::npos,
                    "Legacy runtime token '" + token + "' remains in " +
                        normalizePath(file));
            }
        }
    }
}

void requireOrthogonalTopology(const fs::path& root) {
    const auto scope_text =
        readFile(root / "framework/include/gnc/core/assembly_scope.hpp");
    const auto graph_text =
        readFile(root / "framework/include/gnc/core/assembly_graph.hpp");
    const auto factory_text =
        readFile(root / "framework/include/gnc/core/node_factory.hpp");
    const auto policy_text =
        readFile(root / "framework/include/gnc/core/placement_policy.hpp");
    const auto assembler_text =
        readFile(root / "framework/include/gnc/core/mission_assembler.hpp");
    const auto validation_text =
        readFile(root / "framework/include/gnc/core/validation_pipeline.hpp");
    const auto simulator_text =
        readFile(root / "framework/include/gnc/core/simulator.hpp");

    test_support::require(
        scope_text.find("enum class ScopeKind") != std::string::npos &&
            scope_text.find("Mission") != std::string::npos &&
            scope_text.find("Environment") != std::string::npos &&
            scope_text.find("Vehicle") != std::string::npos,
        "Mission, environment, and vehicle ownership scopes are incomplete.");
    test_support::require(
        graph_text.find("class AssemblyGraph") != std::string::npos &&
            graph_text.find("assignNode") != std::string::npos &&
            graph_text.find("scopeForNode") != std::string::npos &&
            graph_text.find("resolveName") != std::string::npos,
        "AssemblyGraph must remain the authoritative scope and name graph.");
    test_support::require(
        factory_text.find("enum class NodeRole") != std::string::npos &&
            factory_text.find("Infrastructure") != std::string::npos &&
            factory_text.find("enum class DiscretePhase") != std::string::npos,
        "Role and discrete phase must remain independent metadata dimensions.");
    test_support::require(
        policy_text.find("enum class PlacementKind") != std::string::npos &&
            policy_text.find("MissionInfrastructure") != std::string::npos &&
            policy_text.find("VehicleInfrastructure") != std::string::npos &&
            assembler_text.find("buildMissionInfrastructure") != std::string::npos &&
            validation_text.find("placementPolicy") != std::string::npos,
        "PlacementPolicy must be the single role/phase/scope validation table.");
    test_support::require(
        simulator_text.find("rate_hz but does not implement IDiscreteTask") !=
            std::string::npos,
        "rate_hz must be rejected for nodes without discrete capability.");
}

void requireCatalogCompositionRoot(const fs::path& root) {
    const auto catalog_text =
        readFile(root / "framework/include/gnc/core/framework_catalog.hpp");
    const auto builder_text =
        readFile(root / "framework/include/gnc/core/simulation_builder.hpp");
    const auto runner_text = readFile(root / "src/runner.cpp");
    const auto registration_text =
        readFile(root / "src/runner_component_registration.cpp");

    test_support::require(
        catalog_text.find("NodeFactory nodes_") != std::string::npos &&
            catalog_text.find("IntegratorRegistry integrators_") !=
                std::string::npos &&
            catalog_text.find("SimFlowMaterializerRegistry") !=
                std::string::npos,
        "FrameworkCatalog must own node, integrator, and SimFlow definitions.");
    test_support::require(
        builder_text.find("FrameworkCatalog&") != std::string::npos &&
            builder_text.find("RK4Integrator") == std::string::npos &&
            builder_text.find("coordinate_tree") == std::string::npos,
        "SimulationBuilder must consume the catalog without concrete extensions.");
    test_support::require(
        runner_text.find("registerFrameworkBuiltins(catalog)") !=
                std::string::npos &&
            runner_text.find("registerLinkedExtensions(catalog)") !=
                std::string::npos &&
            runner_text.find("registerActiveProject(catalog)") !=
                std::string::npos,
        "Runner must use the generic composition-root sequence.");
    test_support::require(
        registration_text.find("registerAutoLinkedExtensions(catalog)") !=
            std::string::npos,
        "Linked extensions must enter through the generated catalog chain.");
}

void requireOptionalCoordinateExtension(const fs::path& root) {
    const auto core_root = root / "framework/include/gnc/core";
    for (const auto& file : collectFiles(core_root)) {
        test_support::require(
            readFile(file).find("coordinate_tree") == std::string::npos,
            "Framework core depends on the optional coordinate extension: " +
                normalizePath(file));
    }

    const auto extension = root / "framework/include/gnc/extensions/coordinate_tree";
    test_support::require(
        fs::exists(extension / "components/coordinate_tree_node.hpp") &&
            fs::exists(extension /
                       "interfaces/i_coordinate_frame_contributor.hpp") &&
            fs::exists(extension / "register_extension.hpp"),
        "Coordinate-tree extension boundaries are incomplete.");
    const auto node_text =
        readFile(extension / "components/coordinate_tree_node.hpp");
    test_support::require(
        node_text.find("getAllInScope<ICoordinateFrameContributor>") !=
            std::string::npos,
        "CoordinateTree node must collect same-scope frame contributors.");
}

void requireContinuousGroupSeam(const fs::path& root) {
    const auto group_path =
        root / "framework/include/gnc/interfaces/i_continuous_group.hpp";
    test_support::require(fs::exists(group_path),
                          "IContinuousGroup contract is missing.");
    const auto simulator_text =
        readFile(root / "framework/include/gnc/core/simulator.hpp");
    const auto assembler_text =
        readFile(root / "framework/include/gnc/core/mission_assembler.hpp");
    const auto policy_text =
        readFile(root / "framework/include/gnc/core/placement_policy.hpp");
    test_support::require(
        simulator_text.find("buildContinuousPlan") != std::string::npos &&
            simulator_text.find("belongs to more than one continuous group") !=
                std::string::npos,
        "Simulator must construct and validate the continuous coupling plan.");
    test_support::require(
        assembler_text.find("buildMissionContinuousGroups") !=
                std::string::npos &&
            assembler_text.find("config[\"continuous_groups\"]") !=
                std::string::npos &&
            policy_text.find("MissionContinuousGroup") != std::string::npos &&
            policy_text.find("VehicleContinuousGroup") != std::string::npos,
        "Mission and vehicle continuous-group placements are incomplete.");
}

void requireRuntimeInventory(const fs::path& root) {
    const auto simulator_text =
        readFile(root / "framework/include/gnc/core/simulator.hpp");
    const auto summary_text =
        readFile(root / "framework/include/gnc/infrastructure/simulation_summary.hpp");
    test_support::require(
        simulator_text.find("executionInfo() const") != std::string::npos &&
            summary_text.find("step_interval") != std::string::npos &&
            summary_text.find("rate_hz") != std::string::npos,
        "Simulation summary must expose configured and effective scheduling metadata.");
}

void requireProjectAndPreparationBoundaries(const fs::path& root) {
    const auto cmake_text = readFile(root / "CMakeLists.txt");
    const auto builder_text =
        readFile(root / "framework/include/gnc/core/simulation_builder.hpp");
    const auto simulator_text =
        readFile(root / "framework/include/gnc/core/simulator.hpp");
    test_support::require(
        cmake_text.find("GNC_REGISTER_NODE_TYPE") != std::string::npos &&
            cmake_text.find("${USER_PROJECT_DIR}/interfaces") !=
                std::string::npos &&
            cmake_text.find("${USER_PROJECT_DIR}/common") != std::string::npos,
        "Active-project registration and private include roots are incomplete.");
    const auto validation = builder_text.find("ValidationPipeline::run");
    const auto preparation = builder_text.find("PreparationPipeline::run");
    test_support::require(
        validation != std::string::npos && preparation != std::string::npos &&
            validation < preparation,
        "Dependency validation must precede preparation.");
    test_support::require(
        simulator_text.find("PreparationPipeline") == std::string::npos,
        "Preparation must stay outside the runtime loop.");
}

void requireDeferredBroadApisStayClosed(const fs::path& root) {
    const std::vector<std::string> forbidden = {
        "class IHybridSystem",
        "struct IHybridSystem",
        "WorldSnapshot",
        "GenericGuidanceCommandProvider",
        "IProjectServicePackage",
        "registerProjectServicePackage",
    };
    for (const auto& scan_root : {root / "framework/include/gnc",
                                  root / "src",
                                  root / "tests"}) {
        for (const auto& file : collectFiles(scan_root)) {
            if (normalizePath(file) == normalizePath(fs::path(__FILE__))) continue;
            const auto text = readFile(file);
            for (const auto& token : forbidden) {
                test_support::require(
                    text.find(token) == std::string::npos,
                    "Deferred broad API '" + token + "' appeared in " +
                        normalizePath(file));
            }
        }
    }
}

void requireDocumentMemoryBoundary(const fs::path& root) {
    test_support::require(
        !fs::exists(root / "doc/08-form-family-symmetry-backlog.md"),
        "Design backlog must stay outside the formal project documentation.");
    test_support::require(
        fs::exists(root /
                   "design-notes/2026-07-form-family-symmetry-backlog.md"),
        "The retained design backlog is missing from design-notes/.");
    const auto decisions = readFile(root / "doc/07-decisions.md");
    test_support::require(
        decisions.find("ADR-012: 统一仿真节点与通用 Catalog") !=
            std::string::npos,
        "The unified node architecture requires an ADR.");
}

} // namespace

int main() {
    try {
        const fs::path root = repoRoot();
        test_support::require(fs::exists(root / "CMakeLists.txt"),
                              "Could not locate repository root from __FILE__.");

        requireNoFormInternalLeakage(root);
        requireSingleNodeObjectModel(root);
        requireNoLegacyRuntimeLine(root);
        requireOrthogonalTopology(root);
        requireCatalogCompositionRoot(root);
        requireOptionalCoordinateExtension(root);
        requireContinuousGroupSeam(root);
        requireRuntimeInventory(root);
        requireProjectAndPreparationBoundaries(root);
        requireDeferredBroadApisStayClosed(root);
        requireDocumentMemoryBoundary(root);

        std::cout << "architecture guard checks passed\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
