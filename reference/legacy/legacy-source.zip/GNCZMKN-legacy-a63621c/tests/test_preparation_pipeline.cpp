#include "test_support.hpp"

#include "gnc/core/node_factory.hpp"
#include "gnc/core/prepared_asset_cache.hpp"
#include "gnc/core/preparation_context.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/core/simulation_builder.hpp"
#include "gnc/simflow/path_utils.hpp"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

namespace {

namespace fs = std::filesystem;

std::vector<std::string> g_trace;

class IPreparedNumber {
public:
    virtual ~IPreparedNumber() = default;
    virtual double value() const = 0;
    virtual bool ready() const = 0;
};

class PreparedNumberProvider final : public gnc::core::SimulationNode,
                                     public IPreparedNumber {
public:
    PreparedNumberProvider() : SimulationNode("PreparedNumberProvider") {}

    void prepare(const gnc::core::PreparationContext&) override {
        g_trace.push_back("provider.prepare");
        value_ = 42.0;
        ready_ = true;
    }

    void initialize() override { g_trace.push_back("provider.initialize"); }
    double value() const override { return value_; }
    bool ready() const override { return ready_; }

private:
    double value_ = 0.0;
    bool ready_ = false;
};

class FailingPreparedNumberProvider final : public gnc::core::SimulationNode,
                                            public IPreparedNumber {
public:
    FailingPreparedNumberProvider()
        : SimulationNode("FailingPreparedNumberProvider") {}

    void prepare(const gnc::core::PreparationContext&) override {
        throw std::runtime_error("synthetic asset parse failure");
    }
    double value() const override { return 0.0; }
    bool ready() const override { return false; }
};

class PreparedConsumerForm final : public gnc::core::SimulationNode {
public:
    PreparedConsumerForm() : SimulationNode("PreparedConsumerForm") {}

    void bind(gnc::core::AssemblyContext& registry) override {
        provider_ = registry.requireByName<IPreparedNumber>("prepared_asset");
        g_trace.push_back("consumer.inject");
    }

    void prepare(const gnc::core::PreparationContext&) override {
        g_trace.push_back("consumer.prepare");
    }

    void initialize() override {
        g_trace.push_back("consumer.initialize");
        if (!provider_ || !provider_->ready() || provider_->value() != 42.0) {
            throw std::runtime_error(
                "consumer could not read the prepared provider product");
        }
    }

private:
    IPreparedNumber* provider_ = nullptr;
};

void registerTypes() {
    using namespace gnc::core;
    auto& factory = test_support::nodeFactory();
    factory.registerType<PreparedNumberProvider, IPreparedNumber>(
        "test.prepared_number",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Asset,
        DiscretePhase::None,
        "preparation_test");
    factory.registerType<FailingPreparedNumberProvider, IPreparedNumber>(
        "test.failing_prepared_number",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Asset,
        DiscretePhase::None,
        "preparation_test");
    factory.registerType<PreparedConsumerForm>(
        "test.prepared_consumer_form",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Form,
        DiscretePhase::None,
        "preparation_test");
}

std::string mission(const std::string& provider_type) {
    return R"json({
  "simulation": {"dt": 0.1, "duration": 0.0},
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {"components": [
        {"type": "test.prepared_consumer_form", "name": "form", "config": {}}
      ]},
      "common": [
        {"type": ")json" + provider_type + R"json(", "name": "prepared_asset", "config": {}}
      ],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {"components": []}
    }
  ],
  "outputs": {"enabled": false}
})json";
}

size_t traceIndex(const std::string& value) {
    const auto it = std::find(g_trace.begin(), g_trace.end(), value);
    test_support::require(it != g_trace.end(), "Missing lifecycle trace: " + value);
    return static_cast<size_t>(std::distance(g_trace.begin(), it));
}

bool contains(const std::vector<std::string>& lines, const std::string& value) {
    return std::any_of(lines.begin(), lines.end(), [&](const std::string& line) {
        return line.find(value) != std::string::npos;
    });
}

void testBuilderLifecycle() {
    g_trace.clear();
    gnc::core::SimulationBuilder builder(test_support::catalog());
    test_support::require(builder.loadConfigString(mission("test.prepared_number")),
                          "Preparation lifecycle mission failed to parse.");
    auto& simulator = builder.build();

    test_support::require(traceIndex("consumer.inject") <
                              traceIndex("provider.prepare"),
                          "Dependency preflight must finish before preparation.");
    test_support::require(traceIndex("consumer.prepare") <
                              traceIndex("provider.prepare"),
                          "Preparation should follow component registration order.");
    test_support::require(
        std::find(g_trace.begin(), g_trace.end(), "consumer.initialize") ==
            g_trace.end(),
        "SimulationBuilder::build must not initialize runtime components.");

    simulator.initialize();
    test_support::require(traceIndex("provider.prepare") <
                              traceIndex("consumer.initialize"),
                          "Every prepare call must finish before any initialize call.");
    test_support::require(traceIndex("consumer.initialize") <
                              traceIndex("provider.initialize"),
                          "The test must retain form-before-common initialize order.");
    test_support::require(
        std::count(g_trace.begin(), g_trace.end(), "provider.prepare") == 1,
        "Provider preparation must run exactly once during one build.");
}

void testPreparationFailure() {
    g_trace.clear();
    gnc::core::SimulationBuilder builder(test_support::catalog());
    test_support::require(
        builder.loadConfigString(mission("test.failing_prepared_number")),
        "Failing preparation mission failed to parse.");
    bool failed = false;
    try {
        builder.build();
    } catch (const std::exception&) {
        failed = true;
    }
    test_support::require(failed, "Preparation exception must fail mission build.");
    test_support::require(
        contains(builder.getBuildErrors(), "vehicle.prepared_asset"),
        "Preparation failure must identify the full component name.");
    test_support::require(
        contains(builder.getBuildErrors(), "test.failing_prepared_number"),
        "Preparation failure must identify the component type.");
    test_support::require(
        contains(builder.getBuildErrors(), "synthetic asset parse failure"),
        "Preparation failure must preserve the original diagnostic.");
}

void testPathResolution() {
    const fs::path repo = fs::path(__FILE__).lexically_normal().parent_path().parent_path();
    const fs::path project = repo / "user" /
                             "yyz_cartesian_6dof_framework_9";
    const fs::path mission_file = project / "config" / "mission.json";
    const gnc::core::AssetPathResolver paths(mission_file, repo, project);

    test_support::require(
        paths.resolve("repo://README.md") == (repo / "README.md").lexically_normal(),
        "repo:// path did not resolve from repository root.");
    test_support::require(
        paths.resolve("project://plan.md") == (project / "plan.md").lexically_normal(),
        "project:// path did not resolve from project root.");
    test_support::require(
        paths.resolve("user-data://README.md") ==
            (repo / "user" / "data" / "README.md").lexically_normal(),
        "user-data:// path did not resolve from shared data root.");
    test_support::require(
        paths.resolve("mission.json") == mission_file.lexically_normal(),
        "Mission-relative path did not resolve from the mission directory.");
    test_support::require(
        paths.requireRegularFile("project://plan.md", "Plan") ==
            (project / "plan.md").lexically_normal(),
        "requireRegularFile did not return the resolved file.");
    test_support::require(!paths.fingerprint(project / "plan.md").empty(),
                          "Asset fingerprint must be non-empty.");
}

void testPreparedAssetCache() {
    struct Product {
        int value = 0;
    };
    gnc::core::PreparedAssetCache::clearForTests<Product>();
    int factory_calls = 0;
    auto first = gnc::core::PreparedAssetCache::getOrCreate<Product>(
        "same-key", [&] {
            ++factory_calls;
            return std::make_shared<Product>(Product{7});
        });
    auto second = gnc::core::PreparedAssetCache::getOrCreate<Product>(
        "same-key", [&] {
            ++factory_calls;
            return std::make_shared<Product>(Product{9});
        });
    test_support::require(first == second,
                          "Cache must share one immutable product for one key.");
    test_support::require(first->value == 7 && factory_calls == 1,
                          "Cache factory must run once while the product is live.");
    first.reset();
    second.reset();
    const auto third = gnc::core::PreparedAssetCache::getOrCreate<Product>(
        "same-key", [&] {
            ++factory_calls;
            return std::make_shared<Product>(Product{11});
        });
    test_support::require(third->value == 7 && factory_calls == 1,
                          "Cache must retain products for serial case reuse.");
}

void testEffectiveMissionPathFreezing() {
    const fs::path repo = fs::path(__FILE__).lexically_normal().parent_path().parent_path();
    const fs::path project = repo / "user" / "yyz_cartesian_6dof_framework_9";
    auto node = gnc::core::ConfigNode::makeObject();
    node.set("asset", gnc::core::ConfigNode::makeString(
                          "project://data/trajectory/nominal.csv"));
    node.set("label", gnc::core::ConfigNode::makeString("scheme project:// is documented"));
    node.set("relative", gnc::core::ConfigNode::makeString("data/file.csv"));
    const auto frozen = gnc::simflow::resolveExplicitPathUris(
        node, project / "config/mission.json", repo, project);
    test_support::require(
        frozen["asset"].asString() ==
            (project / "data/trajectory/nominal.csv").generic_string(),
        "Effective mission must freeze project:// asset paths.");
    test_support::require(
        frozen["label"].asString() == "scheme project:// is documented",
        "Only strings beginning with an asset URI scheme may be rewritten.");
    test_support::require(frozen["relative"].asString() == "data/file.csv",
                          "Relative strings must remain unchanged.");
}

} // namespace

int main() {
    try {
        test_support::registerBuiltinComponentTypes();
        registerTypes();
        testBuilderLifecycle();
        testPreparationFailure();
        testPathResolution();
        testPreparedAssetCache();
        testEffectiveMissionPathFreezing();
        std::cout << "Preparation pipeline tests passed." << std::endl;
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Preparation pipeline tests failed: " << e.what() << std::endl;
        return 1;
    }
}
