#include "test_support.hpp"

#include "gnc/core/integrators/rk4_integrator.hpp"
#include "gnc/core/simulator.hpp"
#include "gnc/interfaces/i_continuous_group.hpp"

#include <exception>
#include <iostream>
#include <memory>
#include <vector>

namespace {

class IDirectProbe {
public:
    virtual ~IDirectProbe() = default;
    virtual int value() const = 0;
};

class DirectProvider final : public gnc::core::SimulationNode,
                             public IDirectProbe {
public:
    DirectProvider() : SimulationNode("DirectProvider") {}
    int value() const override { return 42; }
};

class DirectConsumer final : public gnc::core::SimulationNode {
public:
    DirectConsumer() : SimulationNode("DirectConsumer") {}

    void bind(gnc::core::AssemblyContext& context) override {
        provider_ = context.requireByName<IDirectProbe>("provider");
    }

    int boundValue() const { return provider_ ? provider_->value() : -1; }

private:
    IDirectProbe* provider_ = nullptr;
};

class ScalarState final : public gnc::core::SimulationNode,
                          public gnc::interfaces::IContinuousSystem {
public:
    ScalarState(const char* name, const char* state_name, double initial)
        : SimulationNode(name) {
        index_ = layout_.addVariable(state_name);
        state_ = Eigen::VectorXd::Constant(1, initial);
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }
    void computeDerivatives(double,
                            const Eigen::VectorXd&,
                            Eigen::VectorXd& derivative) const override {
        derivative = Eigen::VectorXd::Zero(1);
    }
    const Eigen::VectorXd& getState() const override { return state_; }
    void setState(const Eigen::VectorXd& state) override { state_ = state; }
    Eigen::VectorXd getInitialState() const override { return state_; }
    double value() const { return state_[index_]; }

private:
    gnc::core::StateLayout layout_;
    Eigen::VectorXd state_;
    int index_ = -1;
};

class CoupledMassPositionGroup final
    : public gnc::core::SimulationNode,
      public gnc::interfaces::IContinuousGroup {
public:
    CoupledMassPositionGroup(ScalarState* mass, ScalarState* position)
        : SimulationNode("CoupledMassPositionGroup"),
          mass_(mass),
          position_(position) {
        mass_index_ = layout_.addVariable("mass_kg");
        position_index_ = layout_.addVariable("position_m");
        state_ = Eigen::VectorXd::Zero(2);
        state_[mass_index_] = mass_->value();
        state_[position_index_] = position_->value();
        initial_state_ = state_;
    }

    std::vector<gnc::interfaces::IContinuousSystem*> members() const override {
        return {mass_, position_};
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }

    void computeDerivatives(double,
                            const Eigen::VectorXd& state,
                            Eigen::VectorXd& derivative) const override {
        derivative = Eigen::VectorXd::Zero(2);
        derivative[mass_index_] = -2.0;
        derivative[position_index_] = state[mass_index_];
    }

    const Eigen::VectorXd& getState() const override { return state_; }

    void setState(const Eigen::VectorXd& state) override {
        state_ = state;
        mass_->setState(Eigen::VectorXd::Constant(1, state_[mass_index_]));
        position_->setState(
            Eigen::VectorXd::Constant(1, state_[position_index_]));
    }

    Eigen::VectorXd getInitialState() const override { return initial_state_; }

private:
    ScalarState* mass_ = nullptr;
    ScalarState* position_ = nullptr;
    gnc::core::StateLayout layout_;
    Eigen::VectorXd state_;
    Eigen::VectorXd initial_state_;
    int mass_index_ = -1;
    int position_index_ = -1;
};

class MemberListGroup final : public gnc::core::SimulationNode,
                              public gnc::interfaces::IContinuousGroup {
public:
    explicit MemberListGroup(
        std::vector<gnc::interfaces::IContinuousSystem*> members)
        : SimulationNode("MemberListGroup"), members_(std::move(members)) {
        layout_.addVariable("group_state");
        state_ = Eigen::VectorXd::Zero(1);
    }

    std::vector<gnc::interfaces::IContinuousSystem*> members() const override {
        return members_;
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }

    void computeDerivatives(double,
                            const Eigen::VectorXd&,
                            Eigen::VectorXd& derivative) const override {
        derivative = Eigen::VectorXd::Zero(1);
    }

    const Eigen::VectorXd& getState() const override { return state_; }
    void setState(const Eigen::VectorXd& state) override { state_ = state; }
    Eigen::VectorXd getInitialState() const override { return state_; }

private:
    std::vector<gnc::interfaces::IContinuousSystem*> members_;
    gnc::core::StateLayout layout_;
    Eigen::VectorXd state_;
};

} // namespace

int main() {
    try {
        gnc::core::Simulator simulator;
        simulator.configure({1.0, 1.0});
        simulator.setIntegrator(std::make_unique<gnc::core::RK4Integrator>());

        auto mass = std::make_unique<ScalarState>("Mass", "mass_kg", 10.0);
        auto* mass_ptr = mass.get();
        simulator.getRegistry().add<ScalarState,
                                    gnc::interfaces::IContinuousSystem>(
            "vehicle.mass", std::move(mass));
        simulator.addNodeExecution(mass_ptr);

        auto position =
            std::make_unique<ScalarState>("Position", "position_m", 0.0);
        auto* position_ptr = position.get();
        simulator.getRegistry().add<ScalarState,
                                    gnc::interfaces::IContinuousSystem>(
            "vehicle.position", std::move(position));
        simulator.addNodeExecution(position_ptr);

        auto group =
            std::make_unique<CoupledMassPositionGroup>(mass_ptr, position_ptr);
        auto* group_ptr = group.get();
        simulator.getRegistry().add<CoupledMassPositionGroup,
                                    gnc::interfaces::IContinuousGroup>(
            "vehicle.coupled_group", std::move(group));
        simulator.addNodeExecution(group_ptr);

        simulator.run();

        test_support::requireNear(
            mass_ptr->value(), 8.0, 1.0e-12,
            "Continuous group did not distribute the integrated mass state.");
        test_support::requireNear(
            position_ptr->value(), 9.0, 1.0e-12,
            "Continuous group did not evaluate position against RK4 candidate mass.");

        {
            gnc::core::Simulator invalid_member_simulator;
            invalid_member_simulator.configure({1.0, 1.0});
            invalid_member_simulator.setIntegrator(
                std::make_unique<gnc::core::RK4Integrator>());

            auto unregistered =
                std::make_unique<ScalarState>("Orphan", "orphan", 1.0);
            auto invalid_group = std::make_unique<MemberListGroup>(
                std::vector<gnc::interfaces::IContinuousSystem*>{
                    unregistered.get()});
            auto* invalid_group_ptr = invalid_group.get();
            invalid_member_simulator.getRegistry()
                .add<MemberListGroup, gnc::interfaces::IContinuousGroup>(
                    "vehicle.invalid_group", std::move(invalid_group));
            invalid_member_simulator.addNodeExecution(invalid_group_ptr);

            bool rejected = false;
            try {
                invalid_member_simulator.initialize();
            } catch (const std::exception& ex) {
                rejected = std::string(ex.what()).find(
                               "not registered as a node") != std::string::npos;
            }
            test_support::require(
                rejected,
                "Continuous group must reject an unregistered member.");
        }

        {
            gnc::core::Simulator duplicate_member_simulator;
            duplicate_member_simulator.configure({1.0, 1.0});
            duplicate_member_simulator.setIntegrator(
                std::make_unique<gnc::core::RK4Integrator>());

            auto shared =
                std::make_unique<ScalarState>("Shared", "shared", 1.0);
            auto* shared_ptr = shared.get();
            duplicate_member_simulator.getRegistry()
                .add<ScalarState, gnc::interfaces::IContinuousSystem>(
                    "vehicle.shared", std::move(shared));
            duplicate_member_simulator.addNodeExecution(shared_ptr);

            auto first_group = std::make_unique<MemberListGroup>(
                std::vector<gnc::interfaces::IContinuousSystem*>{shared_ptr});
            auto* first_group_ptr = first_group.get();
            duplicate_member_simulator.getRegistry()
                .add<MemberListGroup, gnc::interfaces::IContinuousGroup>(
                    "vehicle.first_group", std::move(first_group));
            duplicate_member_simulator.addNodeExecution(first_group_ptr);

            auto second_group = std::make_unique<MemberListGroup>(
                std::vector<gnc::interfaces::IContinuousSystem*>{shared_ptr});
            auto* second_group_ptr = second_group.get();
            duplicate_member_simulator.getRegistry()
                .add<MemberListGroup, gnc::interfaces::IContinuousGroup>(
                    "vehicle.second_group", std::move(second_group));
            duplicate_member_simulator.addNodeExecution(second_group_ptr);

            bool rejected = false;
            try {
                duplicate_member_simulator.initialize();
            } catch (const std::exception& ex) {
                rejected = std::string(ex.what()).find(
                               "more than one continuous group") !=
                           std::string::npos;
            }
            test_support::require(
                rejected,
                "Continuous system must reject duplicate group ownership.");
        }

        gnc::core::Simulator direct_simulator;
        direct_simulator.configure({0.1, 0.0});

        auto provider = std::make_unique<DirectProvider>();
        auto* provider_ptr = provider.get();
        direct_simulator.getRegistry().add<DirectProvider, IDirectProbe>(
            "provider", std::move(provider));
        direct_simulator.addNodeExecution(provider_ptr);

        auto consumer = std::make_unique<DirectConsumer>();
        auto* consumer_ptr = consumer.get();
        direct_simulator.getRegistry().add<DirectConsumer>(
            "consumer", std::move(consumer));
        direct_simulator.addNodeExecution(consumer_ptr);

        direct_simulator.initialize();
        test_support::require(
            consumer_ptr->boundValue() == 42,
            "Direct Simulator assembly must resolve unqualified names in its root scope.");

        std::cout << "continuous group checks passed\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
