#include "test_support.hpp"

#include "gnc/core/assembly_context.hpp"
#include "gnc/core/framework_catalog.hpp"
#include "gnc/core/integrators/rk4_integrator.hpp"
#include "gnc/core/node_registry.hpp"
#include "gnc/core/preparation_context.hpp"
#include "gnc/core/simulation_builder.hpp"
#include "gnc/environment/interfaces/i_earth.hpp"
#include "gnc/extensions/coordinate_tree/components/coordinate_tree_node.hpp"
#include "gnc/extensions/coordinate_tree/components/local_spherical_3dof_launch_track_frames.hpp"
#include "gnc/extensions/coordinate_tree/interfaces/i_coordinate_frame_contributor.hpp"
#include "gnc/extensions/coordinate_tree/interfaces/i_coordinate_transform.hpp"
#include "gnc/extensions/coordinate_tree/register_extension.hpp"
#include "gnc/forms/local_spherical_3dof/interfaces/i_truth_view.hpp"

#include <algorithm>
#include <exception>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

namespace {

bool containsSubstring(const std::vector<std::string>& lines,
                       const std::string& needle) {
    return std::any_of(lines.begin(), lines.end(), [&](const std::string& line) {
        return line.find(needle) != std::string::npos;
    });
}

class FixedEarth final : public gnc::core::SimulationNode,
                         public gnc::environment::IEarth {
public:
    FixedEarth() : SimulationNode("FixedEarth") {}

    double getEquatorialRadius() const override { return 6378137.0; }
    double getFlattening() const override { return 1.0 / 298.257223563; }
    double getRotationRate() const override { return 7.292115e-5; }

    gnc::math::Vector3 geodeticToEcef(double latitude_rad,
                                      double longitude_rad,
                                      double altitude_m) const override {
        const double radius = getEquatorialRadius() + altitude_m;
        return {radius * std::cos(latitude_rad) * std::cos(longitude_rad),
                radius * std::cos(latitude_rad) * std::sin(longitude_rad),
                radius * std::sin(latitude_rad)};
    }
};

class PassiveForm final : public gnc::core::SimulationNode {
public:
    PassiveForm() : SimulationNode("PassiveForm") {}
};

class CoordinateConsumer final : public gnc::core::DiscreteNode {
public:
    CoordinateConsumer() : DiscreteNode("CoordinateConsumer") {}

    void bind(gnc::core::AssemblyContext& context) override {
        coordinates_ = context.requireByName<
            gnc::extensions::coordinate_tree::ICoordinateTransform>(
            "coordinates");
    }

    void update(const gnc::core::StepContext&) override {
        (void)coordinates_->hasFrame("I");
    }

private:
    gnc::extensions::coordinate_tree::ICoordinateTransform* coordinates_ =
        nullptr;
};

void registerMinimalCore(gnc::core::FrameworkCatalog& catalog) {
    catalog.integrators().registerType<gnc::core::RK4Integrator>("rk4");
    catalog.nodes().registerType<PassiveForm>(
        "test.passive_form",
        gnc::core::NodeCategory::Project,
        __FILE__,
        gnc::core::NodeRole::Form,
        gnc::core::DiscretePhase::None,
        "test_form");
    catalog.nodes().registerType<CoordinateConsumer>(
        "test.coordinate_consumer",
        gnc::core::NodeCategory::Project,
        __FILE__,
        gnc::core::NodeRole::Process,
        gnc::core::DiscretePhase::Process);
}

class FixedTruthView final
    : public gnc::core::SimulationNode,
      public gnc::forms::local_spherical_3dof::ITruthView {
public:
    FixedTruthView() : SimulationNode("FixedTruthView") {
        truth_.velocity_launch_mps = gnc::math::Vector3::UnitX();
    }

    const gnc::forms::local_spherical_3dof::Truth&
    getLocalSpherical3DoFTruth() const override {
        return truth_;
    }

private:
    gnc::forms::local_spherical_3dof::Truth truth_{};
};

gnc::core::ConfigNode launchTrackConfig() {
    using namespace test_support;
    return object({
        field("earth_lookup_name", string("env.earth")),
        field("truth_lookup_name", string("truth")),
        field("latitude_rad", number(0.5235987755982988)),
        field("longitude_rad", number(1.9198621771937625)),
        field("azimuth_rad", number(1.5707963267948966)),
        field("launch_time_s", number(0.0)),
        field("earth_rotation_angle_rad", number(0.0)),
    });
}

std::string optionalInfrastructureMission(bool include_coordinates,
                                          bool include_consumer = false) {
    return std::string(R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.0, "integrator": "rk4" },
  "environment": {},
  "vehicles": [
    {
      "id": "target",
)json") +
           (include_coordinates
                ? R"json(      "infrastructure": [
        {
          "type": "infrastructure.coordinate_tree",
          "name": "coordinates",
          "config": {}
        }
      ],
)json"
                : "") +
           R"json(      "form": {
        "components": [
          {
            "type": "test.passive_form",
            "name": "truth",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [
)json" +
           (include_consumer
                ? R"json(        {
          "type": "test.coordinate_consumer",
          "name": "coordinate_consumer",
          "config": {}
        }
)json"
                : "") +
           R"json(      ],
      "output": [],
      "interaction": { "components": [] }
    }
  ],
  "outputs": { "enabled": false }
}
)json";
}

} // namespace

int main() {
    try {
        using namespace gnc::extensions::coordinate_tree;

        CoordinateTreeNode unprepared;
        bool unprepared_failed = false;
        try {
            (void)unprepared.hasFrame("I");
        } catch (const std::exception& ex) {
            unprepared_failed =
                std::string(ex.what()).find("not prepared") != std::string::npos;
        }
        test_support::require(
            unprepared_failed,
            "CoordinateTree node should reject queries before prepare().");

        gnc::core::NodeRegistry empty_registry;
        auto empty_tree = std::make_unique<CoordinateTreeNode>();
        auto* empty_tree_ptr = empty_tree.get();
        empty_registry.add<CoordinateTreeNode, ICoordinateTransform>(
            "vehicle.coordinates", std::move(empty_tree));
        const auto empty_graph =
            gnc::core::AssemblyGraph::inferFromNodeNames(
                empty_registry.getNodeNames());
        gnc::core::AssemblyContext empty_context(
            empty_graph,
            empty_graph.scopeForNode("vehicle.coordinates").key,
            empty_registry,
            "vehicle.coordinates");
        empty_tree_ptr->bind(empty_context);
        empty_tree_ptr->prepare(gnc::core::PreparationContext(
            gnc::core::AssetPathResolver{}));
        test_support::require(empty_tree_ptr->hasFrame("I"),
                              "CoordinateTree node should build its root frame.");
        test_support::requireVectorNear(
            empty_tree_ptr->transformVector(
                gnc::math::Vector3::UnitX(), "I", "I", 0.0),
            gnc::math::Vector3::UnitX(),
            1e-9,
            "Root-frame vector transform should preserve identity.");

        gnc::core::NodeRegistry registry;
        registry.add<FixedEarth, gnc::environment::IEarth>(
            "env.earth", std::make_unique<FixedEarth>());
        registry.add<FixedTruthView,
                     gnc::forms::local_spherical_3dof::ITruthView>(
            "vehicle.truth", std::make_unique<FixedTruthView>());

        auto frames = std::make_unique<LocalSpherical3DofLaunchTrackFrames>();
        auto* frames_ptr = frames.get();
        frames_ptr->configure(launchTrackConfig(), "frames.config");
        registry.add<LocalSpherical3DofLaunchTrackFrames,
                     ICoordinateFrameContributor>(
            "vehicle.launch_track_frames", std::move(frames));

        auto tree = std::make_unique<CoordinateTreeNode>();
        auto* tree_ptr = tree.get();
        registry.add<CoordinateTreeNode, ICoordinateTransform>(
            "vehicle.coordinates", std::move(tree));

        const auto graph =
            gnc::core::AssemblyGraph::inferFromNodeNames(registry.getNodeNames());
        gnc::core::AssemblyContext frame_context(
            graph,
            graph.scopeForNode("vehicle.launch_track_frames").key,
            registry,
            "vehicle.launch_track_frames");
        frames_ptr->bind(frame_context);
        gnc::core::AssemblyContext tree_context(
            graph,
            graph.scopeForNode("vehicle.coordinates").key,
            registry,
            "vehicle.coordinates");
        tree_ptr->bind(tree_context);
        tree_ptr->prepare(gnc::core::PreparationContext(
            gnc::core::AssetPathResolver{}));

        for (const char* frame_id : {"I", "E", "N", "L", "LI", "K"}) {
            test_support::require(
                tree_ptr->hasFrame(frame_id),
                std::string("Launch-track contributor is missing frame: ") +
                    frame_id);
        }
        test_support::require(tree_ptr->hasEdge("K", "L"),
                              "Launch-track contributor is missing K -> L.");
        test_support::requireVectorNear(
            tree_ptr->transformVector(
                gnc::math::Vector3::UnitX(), "K", "L", 0.0),
            gnc::math::Vector3::UnitX(),
            1e-9,
            "K -> L should align with UnitX launch-frame velocity.");

        gnc::core::FrameworkCatalog core_catalog;
        registerMinimalCore(core_catalog);
        gnc::core::SimulationBuilder core_builder(core_catalog);
        test_support::require(
            core_builder.loadConfigString(optionalInfrastructureMission(false)),
            "Core-only mission JSON did not parse.");
        core_builder.build().run();

        gnc::core::SimulationBuilder missing_provider_builder(core_catalog);
        test_support::require(
            missing_provider_builder.loadConfigString(
                optionalInfrastructureMission(false, true)),
            "Required-coordinate mission JSON did not parse.");
        bool missing_provider_failed = false;
        try {
            missing_provider_builder.build();
        } catch (const std::exception&) {
            missing_provider_failed = true;
        }
        test_support::require(
            missing_provider_failed,
            "A node that selects coordinate infrastructure must fail when its provider is absent.");
        test_support::require(
            containsSubstring(missing_provider_builder.getBuildErrors(),
                              "Required dependency lookup 'coordinates'"),
            "Missing coordinate provider did not produce a required-dependency diagnostic.");
        test_support::require(
            containsSubstring(missing_provider_builder.getBuildErrors(),
                              "target.coordinates"),
            "Missing coordinate provider diagnostic did not include the resolved scoped name.");

        gnc::core::SimulationBuilder unavailable_builder(core_catalog);
        test_support::require(
            unavailable_builder.loadConfigString(optionalInfrastructureMission(true)),
            "Coordinate mission JSON did not parse.");
        bool unavailable_failed = false;
        try {
            unavailable_builder.build();
        } catch (const std::exception&) {
            unavailable_failed = true;
        }
        test_support::require(
            unavailable_failed,
            "A coordinate node type must remain unavailable until its extension contributes to the catalog.");

        gnc::core::FrameworkCatalog extension_catalog;
        registerMinimalCore(extension_catalog);
        contributeToCatalog(extension_catalog);
        gnc::core::SimulationBuilder extension_builder(extension_catalog);
        test_support::require(
            extension_builder.loadConfigString(
                optionalInfrastructureMission(true, true)),
            "Linked coordinate mission JSON did not parse.");
        auto& extension_simulator = extension_builder.build();
        test_support::require(
            extension_simulator.getRegistry().get<ICoordinateTransform>(
                "target.coordinates") != nullptr,
            "Coordinate extension did not assemble its infrastructure node.");
        extension_simulator.run();

        std::cout << "coordinate tree node checks passed\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
