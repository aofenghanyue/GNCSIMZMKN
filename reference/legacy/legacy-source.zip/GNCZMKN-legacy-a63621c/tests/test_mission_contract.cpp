#include "test_support.hpp"

#include "gnc/core/assembly_context.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/core/simulation_builder.hpp"
#include "gnc/forms/cartesian_3dof/interfaces/i_truth_view.hpp"
#include "gnc/forms/local_spherical_3dof/interfaces/i_truth_view.hpp"
#include "gnc/interfaces/i_continuous_group.hpp"
#include "gnc/interfaces/i_summary_observer.hpp"
#include "gnc/vehicle/input/interfaces/i_air_data_3dof.hpp"

#include <algorithm>
#include <exception>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace {

std::vector<std::string> g_stage_trace;

class RecordingComponent : public gnc::core::DiscreteNode {
public:
    RecordingComponent(std::string class_name, std::string trace_label)
        : DiscreteNode(std::move(class_name)), trace_label_(std::move(trace_label)) {}

    void update(const gnc::core::StepContext&) override {
        g_stage_trace.push_back(trace_label_);
    }

private:
    std::string trace_label_;
};

class EnvironmentProbe final : public RecordingComponent {
public:
    EnvironmentProbe() : RecordingComponent("EnvironmentProbe", "environment") {}
};

class InputProbe final : public RecordingComponent {
public:
    InputProbe() : RecordingComponent("InputProbe", "input") {}
};

class CommonProbe final : public gnc::core::SimulationNode {
public:
    CommonProbe() : SimulationNode("CommonProbe") {}
};

class InfrastructureRefreshProbe final : public RecordingComponent {
public:
    InfrastructureRefreshProbe()
        : RecordingComponent("InfrastructureRefreshProbe", "infrastructure") {}
};

class SphericalInfrastructureProbe final : public gnc::core::SimulationNode {
public:
    SphericalInfrastructureProbe()
        : SimulationNode("SphericalInfrastructureProbe") {}
};

class ProcessProbe final : public RecordingComponent {
public:
    ProcessProbe() : RecordingComponent("ProcessProbe", "process") {}
};

class MissionProcessProbe final : public RecordingComponent {
public:
    MissionProcessProbe()
        : RecordingComponent("MissionProcessProbe", "mission_process") {}
};

class OutputProbe final : public RecordingComponent {
public:
    OutputProbe() : RecordingComponent("OutputProbe", "output") {}
};

class InteractionProbe final : public RecordingComponent {
public:
    InteractionProbe() : RecordingComponent("InteractionProbe", "interaction") {}
};

class InteractionProbeOtherFamily final : public RecordingComponent {
public:
    InteractionProbeOtherFamily()
        : RecordingComponent("InteractionProbeOtherFamily", "interaction_other") {}
};

class FormProbe final : public gnc::core::SimulationNode {
public:
    FormProbe() : SimulationNode("FormProbe") {}
};

class ContinuousFormProbe final
    : public gnc::core::SimulationNode,
      public gnc::interfaces::IContinuousSystem {
public:
    ContinuousFormProbe() : SimulationNode("ContinuousFormProbe") {
        state_index_ = layout_.addVariable("value");
        state_ = Eigen::VectorXd::Constant(1, 2.0);
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }

    void computeDerivatives(double,
                            const Eigen::VectorXd&,
                            Eigen::VectorXd& derivative) const override {
        derivative = Eigen::VectorXd::Constant(1, 1.0);
    }

    const Eigen::VectorXd& getState() const override { return state_; }
    void setState(const Eigen::VectorXd& state) override { state_ = state; }
    Eigen::VectorXd getInitialState() const override { return state_; }
    double value() const { return state_[state_index_]; }

private:
    gnc::core::StateLayout layout_;
    Eigen::VectorXd state_;
    int state_index_ = -1;
};

class ContinuousGroupProbe final
    : public gnc::core::SimulationNode,
      public gnc::interfaces::IContinuousGroup {
public:
    ContinuousGroupProbe() : SimulationNode("ContinuousGroupProbe") {
        state_index_ = layout_.addVariable("member_value");
        state_ = Eigen::VectorXd::Zero(1);
    }

    void configure(const gnc::core::ConfigNode& config) override {
        member_name_ = config["member"].asString();
    }

    void bind(gnc::core::AssemblyContext& context) override {
        member_ = context.requireByName<gnc::interfaces::IContinuousSystem>(
            member_name_);
        if (member_) {
            state_[state_index_] = member_->getState()[0];
            initial_state_ = state_;
        }
    }

    std::vector<gnc::interfaces::IContinuousSystem*> members() const override {
        return {member_};
    }

    const gnc::core::StateLayout& getStateLayout() const override {
        return layout_;
    }

    void computeDerivatives(double,
                            const Eigen::VectorXd&,
                            Eigen::VectorXd& derivative) const override {
        derivative = Eigen::VectorXd::Constant(1, 3.0);
    }

    const Eigen::VectorXd& getState() const override { return state_; }

    void setState(const Eigen::VectorXd& state) override {
        state_ = state;
        if (member_) {
            member_->setState(state);
        }
    }

    Eigen::VectorXd getInitialState() const override { return initial_state_; }

private:
    std::string member_name_;
    gnc::interfaces::IContinuousSystem* member_ = nullptr;
    gnc::core::StateLayout layout_;
    Eigen::VectorXd state_;
    Eigen::VectorXd initial_state_ = Eigen::VectorXd::Zero(1);
    int state_index_ = -1;
};

class NonContinuousGroupProbe final : public gnc::core::SimulationNode {
public:
    NonContinuousGroupProbe() : SimulationNode("NonContinuousGroupProbe") {}
};

class CommonStageLeakProbe final : public RecordingComponent {
public:
    CommonStageLeakProbe()
        : RecordingComponent("CommonStageLeakProbe", "common_stage_leak") {}
};

class NonTerminationProbe final : public RecordingComponent {
public:
    NonTerminationProbe()
        : RecordingComponent("NonTerminationProbe", "non_termination") {}
};

class NonSummaryProbe final : public RecordingComponent {
public:
    NonSummaryProbe() : RecordingComponent("NonSummaryProbe", "non_summary") {}
};

bool containsSubstring(const std::vector<std::string>& lines, const std::string& needle) {
    return std::any_of(lines.begin(), lines.end(), [&](const std::string& line) {
        return line.find(needle) != std::string::npos;
    });
}

void registerMissionContractTestTypes() {
    using namespace gnc::core;

    auto& factory = test_support::nodeFactory();
    factory.registerType<EnvironmentProbe>("test.environment_probe",
                                           NodeCategory::Project,
                                           __FILE__,
                                           NodeRole::EnvironmentModel,
                                           DiscretePhase::Environment);
    factory.registerType<CommonProbe>("test.common_probe",
                                      NodeCategory::Project,
                                      __FILE__,
                                      NodeRole::Asset,
                                      DiscretePhase::None);
    factory.registerType<InfrastructureRefreshProbe>(
        "test.infrastructure_refresh_probe",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Infrastructure,
        DiscretePhase::Process);
    factory.registerType<SphericalInfrastructureProbe>(
        "test.spherical_infrastructure_probe",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Infrastructure,
        DiscretePhase::None,
        "local_spherical_3dof");
    factory.registerType<InputProbe>("test.input_probe",
                                     NodeCategory::Project,
                                     __FILE__,
                                     NodeRole::Input,
                                     DiscretePhase::Input);
    factory.registerType<ProcessProbe>("test.process_probe",
                                       NodeCategory::Project,
                                       __FILE__,
                                       NodeRole::Process,
                                       DiscretePhase::Process);
    factory.registerType<MissionProcessProbe>("test.mission_process_probe",
                                              NodeCategory::Project,
                                              __FILE__,
                                              NodeRole::Process,
                                              DiscretePhase::Process);
    factory.registerType<OutputProbe>("test.output_probe",
                                      NodeCategory::Project,
                                      __FILE__,
                                      NodeRole::Output,
                                      DiscretePhase::Output);
    factory.registerType<InteractionProbe>("test.interaction_probe",
                                           NodeCategory::Project,
                                           __FILE__,
                                           NodeRole::Interaction,
                                           DiscretePhase::Interaction,
                                           "test_form");
    factory.registerType<InteractionProbeOtherFamily>("test.interaction_probe_other_family",
                                                      NodeCategory::Project,
                                                      __FILE__,
                                                      NodeRole::Interaction,
                                                      DiscretePhase::Interaction,
                                                      "other_form");
    factory.registerType<FormProbe>("test.form_probe",
                                    NodeCategory::Project,
                                    __FILE__,
                                    NodeRole::Form,
                                    DiscretePhase::None,
                                    "test_form");
    factory.registerType<ContinuousFormProbe,
                         gnc::interfaces::IContinuousSystem>(
        "test.continuous_form_probe",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Form,
        DiscretePhase::None,
        "test_continuous");
    factory.registerType<ContinuousGroupProbe,
                         gnc::interfaces::IContinuousGroup>(
        "test.continuous_group_probe",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Coupling,
        DiscretePhase::None,
        "test_continuous");
    factory.registerType<NonContinuousGroupProbe>(
        "test.non_continuous_group_probe",
        NodeCategory::Project,
        __FILE__,
        NodeRole::Coupling,
        DiscretePhase::None,
        "test_continuous");
    factory.registerType<CommonStageLeakProbe>("test.common_stage_leak_probe",
                                               NodeCategory::Project,
                                               __FILE__,
                                               NodeRole::Asset,
                                               DiscretePhase::Output);
    factory.registerType<NonTerminationProbe>("test.non_termination_probe",
                                              NodeCategory::Project,
                                              __FILE__,
                                              NodeRole::Termination,
                                              DiscretePhase::Evaluation);
    factory.registerType<NonSummaryProbe>("test.non_summary_probe",
                                          NodeCategory::Project,
                                          __FILE__,
                                          NodeRole::Summary,
                                          DiscretePhase::Evaluation);
}

} // namespace

int main() {
    try {
        test_support::registerBuiltinComponentTypes();
        registerMissionContractTestTypes();

        const char* infrastructure_refresh_mission = R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.0 },
  "infrastructure": [
    {
      "type": "test.infrastructure_refresh_probe",
      "name": "refresh",
      "config": {}
    }
  ],
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "family": "test_form",
        "components": [
          { "type": "test.form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [], "input": [], "process": [], "output": []
    }
  ],
  "outputs": { "enabled": false }
}
)json";
        gnc::core::SimulationBuilder infrastructure_refresh_builder(
            test_support::catalog());
        test_support::require(
            infrastructure_refresh_builder.loadConfigString(
                infrastructure_refresh_mission),
            "Infrastructure refresh mission JSON could not be parsed.");
        g_stage_trace.clear();
        infrastructure_refresh_builder.build().run();
        test_support::require(
            std::find(g_stage_trace.begin(), g_stage_trace.end(), "infrastructure") !=
                g_stage_trace.end(),
            "A discrete Infrastructure node was not scheduled in its declared phase.");

        const char* strict_schema_mission = R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.0 },
  "vehicles": [
    {
      "id": "vehicle",
      "proces": [],
      "form": {
        "family": "test_form",
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "priorty": 1,
            "config": {}
          }
        ]
      },
      "common": [], "input": [], "process": [], "output": []
    }
  ],
  "outputs": { "enabld": false }
}
)json";
        gnc::core::SimulationBuilder strict_schema_builder(test_support::catalog());
        test_support::require(
            strict_schema_builder.loadConfigString(strict_schema_mission),
            "Strict-schema mission JSON could not be parsed.");
        bool strict_schema_failed = false;
        try {
            (void)strict_schema_builder.build();
        } catch (const std::runtime_error&) {
            strict_schema_failed = true;
        }
        test_support::require(strict_schema_failed,
                              "Unknown mission wrapper keys must fail the build.");
        test_support::require(
            containsSubstring(strict_schema_builder.getBuildErrors(),
                              "vehicles[0] has unrecognized key: proces"),
            "Vehicle wrapper typo did not include its mission path.");
        test_support::require(
            containsSubstring(strict_schema_builder.getBuildErrors(), "priorty"),
            "Node wrapper typo was not diagnosed.");
        test_support::require(
            containsSubstring(strict_schema_builder.getBuildErrors(), "outputs.enabld"),
            "Outputs wrapper typo was not diagnosed as an error.");

        auto& factory = test_support::nodeFactory();
        test_support::require(factory.hasType("test_fixture.process_probe"),
                              "Stable test fixture process probe was not auto-registered.");
        test_support::require(
            factory.getRole("test_fixture.process_probe") ==
                gnc::core::NodeRole::Process,
            "Test fixture process probe did not retain vehicle.process package metadata.");
        test_support::require(
            factory.getDiscretePhase("test_fixture.process_probe") ==
                gnc::core::DiscretePhase::Process,
            "Test fixture process probe did not retain vehicle.process stage metadata.");
        test_support::require(
            factory.getRole("test_fixture.output_probe") ==
                gnc::core::NodeRole::Output,
            "Test fixture output probe did not retain vehicle.output package metadata.");
        test_support::require(
            factory.getDiscretePhase("test_fixture.output_probe") ==
                gnc::core::DiscretePhase::Output,
            "Test fixture output probe did not retain vehicle.output stage metadata.");
        test_support::require(
            factory.getFormFamily("test_fixture.local_spherical_output_probe") ==
                "local_spherical_3dof",
            "Test fixture local_spherical output probe did not retain form-family metadata.");

        const char* legacy_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.2
  },
  "outputs": {
    "enabled": false
  },
  "entities": [
    {
      "id": "vehicle",
      "role": "vehicle",
      "components": [
        {
          "type": "form.cartesian_3dof.point_mass",
          "name": "dynamics",
          "config": {
            "initial_position": [0.0, 0.0, 1000.0],
            "initial_velocity": [250.0, 0.0, 40.0]
          }
        }
      ]
    }
  ]
}
)json";

        gnc::core::SimulationBuilder legacy_builder(test_support::catalog());
        test_support::require(legacy_builder.loadConfigString(legacy_mission),
                              "Legacy mission JSON could not be parsed.");

        bool legacy_failed = false;
        try {
            legacy_builder.build();
        } catch (const std::exception&) {
            legacy_failed = true;
        }

        test_support::require(legacy_failed,
                              "Legacy entities[] mission format should now fail fast.");
        test_support::require(
            containsSubstring(legacy_builder.getBuildErrors(),
            "Legacy top-level 'entities[]' missions"),
            "Legacy mission failure did not explain that entities[] is unsupported.");
        test_support::require(
            containsSubstring(legacy_builder.getBuildErrors(),
                              "canonical top-level 'vehicles[]' layout"),
            "Legacy mission failure did not direct the user to the canonical vehicles[] layout.");

        const char* global_service_scope_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "global_services": {
    "coordinate_tree": {
      "spec": "empty"
    }
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [
                0.0,
                0.0,
                1000.0
              ],
              "initial_velocity": [
                250.0,
                0.0,
                0.0
              ]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [
                0.0,
                0.0,
                -9.81
              ]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder global_service_scope_builder(test_support::catalog());
        test_support::require(
            global_service_scope_builder.loadConfigString(global_service_scope_mission),
            "Global-service-scope mission JSON could not be parsed.");

        bool global_service_scope_failed = false;
        try {
            global_service_scope_builder.build();
        } catch (const std::exception&) {
            global_service_scope_failed = true;
        }

        test_support::require(
            global_service_scope_failed,
            "The removed global_services schema must fail assembly.");
        test_support::require(
            containsSubstring(global_service_scope_builder.getBuildErrors(),
                              "Top-level 'global_services' was removed"),
            "Global service migration failure did not direct users to infrastructure nodes.");

        const char* environment_service_scope_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {
    "services": {
      "coordinate_tree": {
        "spec": "empty"
      }
    }
  },
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [
                0.0,
                0.0,
                1000.0
              ],
              "initial_velocity": [
                250.0,
                0.0,
                0.0
              ]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [
                0.0,
                0.0,
                -9.81
              ]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder environment_service_scope_builder(test_support::catalog());
        test_support::require(
            environment_service_scope_builder.loadConfigString(
                environment_service_scope_mission),
            "Environment-service-scope mission JSON could not be parsed.");

        bool environment_service_scope_failed = false;
        try {
            environment_service_scope_builder.build();
        } catch (const std::exception&) {
            environment_service_scope_failed = true;
        }

        test_support::require(
            environment_service_scope_failed,
            "The removed environment.services schema must fail assembly.");
        test_support::require(
            containsSubstring(environment_service_scope_builder.getBuildErrors(),
                              "'environment.services' was removed"),
            "Environment service migration failure did not direct users to infrastructure nodes.");

        const char* architecture_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.2,
    "integrator": "rk4"
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [
                0.0,
                0.0,
                1000.0
              ],
              "initial_velocity": [
                250.0,
                0.0,
                0.0
              ]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [
                0.0,
                0.0,
                -9.81
              ]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder architecture_builder(test_support::catalog());
        test_support::require(architecture_builder.loadConfigString(architecture_mission),
                              "Top-level mission JSON could not be parsed.");

        auto& architecture_simulator = architecture_builder.build();
        const auto& component_names = architecture_simulator.getRegistry().getNodeNames();
        test_support::require(
            std::find(component_names.begin(), component_names.end(), "vehicle.dynamics") !=
                component_names.end(),
            "Form components must be registered under the unified vehicle scope.");
        test_support::require(
            std::find(component_names.begin(), component_names.end(), "dynamics") ==
                component_names.end(),
            "Missions should not register bare component names under the new schema.");

        const char* multi_vehicle_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.5,
    "integrator": "rk4"
  },
  "environment": {},
  "vehicles": [
    {
      "id": "chaser",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [0.0, 0.0, 1000.0],
              "initial_velocity": [250.0, 0.0, 0.0]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [0.0, 0.0, -9.81]
            }
          }
        ]
      }
    },
    {
      "id": "target",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [1000.0, 0.0, 2000.0],
              "initial_velocity": [100.0, 0.0, 10.0]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [0.0, 0.0, 0.0]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder multi_vehicle_builder(test_support::catalog());
        test_support::require(
            multi_vehicle_builder.loadConfigString(multi_vehicle_mission),
            "Multi-vehicle mission JSON could not be parsed.");

        auto& multi_vehicle_simulator = multi_vehicle_builder.build();
        test_support::require(multi_vehicle_builder.getVehicles().size() == 2,
                              "Multi-vehicle mission did not create two vehicle scopes.");

        auto* chaser_dynamics =
            multi_vehicle_simulator.getRegistry().get<gnc::forms::cartesian_3dof::ITruthView>(
                "chaser.dynamics");
        auto* target_dynamics =
            multi_vehicle_simulator.getRegistry().get<gnc::forms::cartesian_3dof::ITruthView>(
                "target.dynamics");
        test_support::require(chaser_dynamics != nullptr,
                              "Multi-vehicle mission did not register chaser.dynamics.");
        test_support::require(target_dynamics != nullptr,
                              "Multi-vehicle mission did not register target.dynamics.");

        multi_vehicle_simulator.initialize();
        const double initial_chaser_altitude =
            chaser_dynamics->getCartesian3DoFTruth().state.position_m.z();
        const double initial_target_altitude =
            target_dynamics->getCartesian3DoFTruth().state.position_m.z();

        multi_vehicle_simulator.run();

        test_support::require(
            chaser_dynamics->getCartesian3DoFTruth().state.position_m.z() <
                initial_chaser_altitude,
            "Chaser dynamics did not integrate with its own acceleration input.");
        test_support::require(
            target_dynamics->getCartesian3DoFTruth().state.position_m.z() >
                initial_target_altitude,
            "Target dynamics did not integrate independently in its own vehicle scope.");

        const char* heterogeneous_vehicle_forms_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1,
    "integrator": "rk4"
  },
  "environment": {
    "components": [
      { "type": "environment.spherical_earth", "name": "earth", "config": {} }
    ]
  },
  "vehicles": [
    {
      "id": "cart",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [0.0, 0.0, 1000.0],
              "initial_velocity": [100.0, 0.0, 0.0]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [0.0, 0.0, -9.81]
            }
          }
        ]
      }
    },
    {
      "id": "spherical",
      "infrastructure": [
        {
          "type": "test.spherical_infrastructure_probe",
          "name": "coordinate_context",
          "config": {}
        }
      ],
      "form": {
        "components": [
          {
            "type": "form.local_spherical_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "launch_azimuth_rad": 0.0,
              "initial_state": {
                "longitude_rad": 0.0,
                "latitude_rad": 0.0,
                "altitude_m": 10000.0,
                "speed_mps": 500.0,
                "flight_path_angle_rad": -0.05,
                "heading_angle_rad": 0.0
              }
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.local_spherical_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "local_acceleration_nue_mps2": [0.0, -9.80665, 0.0]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder heterogeneous_vehicle_forms_builder(test_support::catalog());
        test_support::require(
            heterogeneous_vehicle_forms_builder.loadConfigString(
                heterogeneous_vehicle_forms_mission),
            "Heterogeneous multi-vehicle mission JSON could not be parsed.");

        auto& heterogeneous_vehicle_forms_simulator =
            heterogeneous_vehicle_forms_builder.build();
        test_support::require(
            heterogeneous_vehicle_forms_simulator.getRegistry()
                .get<gnc::forms::cartesian_3dof::ITruthView>("cart.dynamics") != nullptr,
            "Multi-vehicle mission rejected a cartesian form in one vehicle scope.");
        test_support::require(
            heterogeneous_vehicle_forms_simulator.getRegistry()
                .get<gnc::forms::local_spherical_3dof::ITruthView>(
                    "spherical.dynamics") != nullptr,
            "Multi-vehicle mission rejected a local-spherical form in another vehicle scope.");
        test_support::require(
            heterogeneous_vehicle_forms_simulator.getRegistry().has(
                "spherical.coordinate_context"),
            "Family-specific infrastructure used another vehicle's form family.");

        const char* project_wrong_block_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [
        {
          "type": "test_fixture.output_probe",
          "name": "misplaced_output",
          "config": {}
        }
      ],
      "output": [],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder project_wrong_block_builder(test_support::catalog());
        test_support::require(
            project_wrong_block_builder.loadConfigString(project_wrong_block_mission),
            "Project wrong-block mission JSON could not be parsed.");

        bool project_wrong_block_failed = false;
        try {
            project_wrong_block_builder.build();
        } catch (const std::exception&) {
            project_wrong_block_failed = true;
        }

        test_support::require(
            project_wrong_block_failed,
            "Project components placed in the wrong vehicle block must fail assembly.");
        test_support::require(
            containsSubstring(project_wrong_block_builder.getBuildErrors(),
                              "registered as role 'output' but assembled in "
                              "placement 'vehicle.process'"),
            "Project wrong-block failure did not report the registered vehicle role.");

        const char* project_stage_mismatch_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [
        {
          "type": "test_fixture.process_wrong_stage_probe",
          "name": "bad_stage",
          "config": {}
        }
      ],
      "output": [],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder project_stage_mismatch_builder(test_support::catalog());
        test_support::require(
            project_stage_mismatch_builder.loadConfigString(project_stage_mismatch_mission),
            "Project stage-mismatch mission JSON could not be parsed.");

        bool project_stage_mismatch_failed = false;
        try {
            project_stage_mismatch_builder.build();
        } catch (const std::exception&) {
            project_stage_mismatch_failed = true;
        }

        test_support::require(
            project_stage_mismatch_failed,
            "Project components with mismatched execution stage metadata must fail assembly.");
        test_support::require(
            containsSubstring(project_stage_mismatch_builder.getBuildErrors(),
                              "uses phase 'output'"),
            "Project stage mismatch did not report the registered execution stage.");
        test_support::require(
            containsSubstring(project_stage_mismatch_builder.getBuildErrors(),
                              "placement 'vehicle.process', which requires phase 'process'"),
            "Project stage mismatch did not report the expected vehicle.process stage.");

        const char* project_form_family_mismatch_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [
        {
          "type": "test_fixture.local_spherical_output_probe",
          "name": "family_specific_output",
          "config": {}
        }
      ],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder project_form_family_mismatch_builder(test_support::catalog());
        test_support::require(
            project_form_family_mismatch_builder.loadConfigString(
                project_form_family_mismatch_mission),
            "Project form-family mismatch mission JSON could not be parsed.");

        bool project_form_family_mismatch_failed = false;
        try {
            project_form_family_mismatch_builder.build();
        } catch (const std::exception&) {
            project_form_family_mismatch_failed = true;
        }

        test_support::require(
            project_form_family_mismatch_failed,
            "Project components with incompatible form-family metadata must fail assembly.");
        test_support::require(
            containsSubstring(project_form_family_mismatch_builder.getBuildErrors(),
                              "targets form family 'local_spherical_3dof'"),
            "Project form-family mismatch did not report the component family.");
        test_support::require(
            containsSubstring(project_form_family_mismatch_builder.getBuildErrors(),
                              "while vehicle 'vehicle' selects 'test_form'"),
            "Project form-family mismatch did not report the selected mission family.");

        const char* stage_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "process": [
    {
      "type": "test.mission_process_probe",
      "name": "coordinator",
      "config": {}
    }
  ],
  "environment": {
    "components": [
      {
        "type": "test.environment_probe",
        "name": "world",
        "config": {}
      }
    ]
  },
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [
        {
          "type": "test.common_probe",
          "name": "common_data",
          "config": {}
        }
      ],
      "input": [
        {
          "type": "test.input_probe",
          "name": "sensor",
          "config": {}
        }
      ],
      "process": [
        {
          "type": "test.process_probe",
          "name": "guidance",
          "config": {}
        }
      ],
      "output": [
        {
          "type": "test.output_probe",
          "name": "actuator",
          "config": {}
        }
      ],
      "interaction": {
        "components": [
          {
            "type": "test.interaction_probe",
            "name": "bridge",
            "config": {}
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder stage_builder(test_support::catalog());
        test_support::require(stage_builder.loadConfigString(stage_mission),
                              "Stage-order mission JSON could not be parsed.");

        g_stage_trace.clear();
        auto& stage_simulator = stage_builder.build();
        test_support::require(
            stage_simulator.getRegistry().get<MissionProcessProbe>(
                "mission.coordinator") != nullptr,
            "Mission/Process node was not assembled in mission scope.");
        stage_simulator.run();

        const std::vector<std::string> expected_trace = {
            "environment", "input", "mission_process", "process", "output",
            "interaction"};
        test_support::require(
            !g_stage_trace.empty() &&
                (g_stage_trace.size() % expected_trace.size()) == 0,
            "Execution stage trace length is not a whole number of cycles.");
        for (size_t offset = 0; offset < g_stage_trace.size();
             offset += expected_trace.size()) {
            const std::vector<std::string> cycle_trace(
                g_stage_trace.begin() + static_cast<std::ptrdiff_t>(offset),
                g_stage_trace.begin() +
                    static_cast<std::ptrdiff_t>(offset + expected_trace.size()));
            test_support::require(
                cycle_trace == expected_trace,
                "Execution stages no longer run in the expected environment -> input -> "
                "mission/vehicle process -> output -> interaction order.");
        }
        test_support::require(
            std::find(g_stage_trace.begin(), g_stage_trace.end(), "perturbation") ==
                g_stage_trace.end(),
            "Mission without vehicles[].perturbation should not execute a perturbation component.");

        const char* invalid_common_stage_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [
        {
          "type": "test.common_stage_leak_probe",
          "name": "common_data",
          "config": {}
        }
      ],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder invalid_common_stage_builder(test_support::catalog());
        test_support::require(
            invalid_common_stage_builder.loadConfigString(invalid_common_stage_mission),
            "Invalid common-stage mission JSON could not be parsed.");

        bool invalid_common_stage_failed = false;
        try {
            invalid_common_stage_builder.build();
        } catch (const std::exception&) {
            invalid_common_stage_failed = true;
        }

        test_support::require(
            invalid_common_stage_failed,
            "vehicle.common should reject components that still advertise a runtime stage.");
        test_support::require(
            containsSubstring(invalid_common_stage_builder.getBuildErrors(),
                              "placement 'vehicle.common', which requires phase 'none'"),
            "vehicle.common stage validation did not explain that common is non-scheduled.");

        const char* invalid_termination_interface_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  },
  "termination": {
    "type": "test.non_termination_probe",
    "name": "termination",
    "config": {}
  }
}
)json";

        gnc::core::SimulationBuilder invalid_termination_interface_builder(test_support::catalog());
        test_support::require(
            invalid_termination_interface_builder.loadConfigString(
                invalid_termination_interface_mission),
            "Invalid termination-interface mission JSON could not be parsed.");

        bool invalid_termination_interface_failed = false;
        try {
            invalid_termination_interface_builder.build();
        } catch (const std::exception&) {
            invalid_termination_interface_failed = true;
        }

        test_support::require(
            invalid_termination_interface_failed,
            "Top-level termination must require ITerminationEvaluator.");
        test_support::require(
            containsSubstring(invalid_termination_interface_builder.getBuildErrors(),
                              "must implement ITerminationEvaluator"),
            "Termination interface validation did not report ITerminationEvaluator.");

        const char* invalid_summary_interface_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  },
  "summary": {
    "type": "test.non_summary_probe",
    "name": "summary",
    "config": {}
  }
}
)json";

        gnc::core::SimulationBuilder invalid_summary_interface_builder(test_support::catalog());
        test_support::require(
            invalid_summary_interface_builder.loadConfigString(
                invalid_summary_interface_mission),
            "Invalid summary-interface mission JSON could not be parsed.");

        bool invalid_summary_interface_failed = false;
        try {
            invalid_summary_interface_builder.build();
        } catch (const std::exception&) {
            invalid_summary_interface_failed = true;
        }

        test_support::require(invalid_summary_interface_failed,
                              "Top-level summary must require ISummaryObserver.");
        test_support::require(
            containsSubstring(invalid_summary_interface_builder.getBuildErrors(),
                              "must implement ISummaryObserver"),
            "Summary interface validation did not report ISummaryObserver.");

        const char* incompatible_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "test.form_probe",
            "name": "dynamics",
            "config": {}
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test.interaction_probe_other_family",
            "name": "bridge",
            "config": {}
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder incompatible_builder(test_support::catalog());
        test_support::require(incompatible_builder.loadConfigString(incompatible_mission),
                              "Incompatible mission JSON could not be parsed.");

        bool incompatible_failed = false;
        try {
            incompatible_builder.build();
        } catch (const std::exception&) {
            incompatible_failed = true;
        }

        test_support::require(incompatible_failed,
                              "Missions with incompatible form and interaction families must fail.");
        test_support::require(
            containsSubstring(incompatible_builder.getBuildErrors(), "targets form family"),
            "Incompatible family failure did not explain the form-family mismatch.");

        const char* input_family_mismatch_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [0.0, 0.0, 1000.0],
              "initial_velocity": [250.0, 0.0, 0.0]
            }
          }
        ]
      },
      "common": [],
      "input": [
        {
          "type": "vehicle.input.local_spherical_air_data_3dof.ideal",
          "name": "air_data",
          "config": {}
        }
      ],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [0.0, 0.0, -9.81]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder input_family_mismatch_builder(test_support::catalog());
        test_support::require(
            input_family_mismatch_builder.loadConfigString(
                input_family_mismatch_mission),
            "Input family mismatch mission JSON could not be parsed.");

        bool input_family_mismatch_failed = false;
        try {
            input_family_mismatch_builder.build();
        } catch (const std::exception&) {
            input_family_mismatch_failed = true;
        }

        test_support::require(
            input_family_mismatch_failed,
            "Cartesian form should reject a local_spherical_3dof vehicle.input component.");
        test_support::require(
            containsSubstring(input_family_mismatch_builder.getBuildErrors(),
                              "targets form family 'local_spherical_3dof'"),
            "Input family mismatch did not report the component family.");
        test_support::require(
            containsSubstring(input_family_mismatch_builder.getBuildErrors(),
                              "while vehicle 'vehicle' selects 'cartesian_3dof'"),
            "Input family mismatch did not report the selected vehicle family.");

        const char* project_summary_configured_vehicle_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {
    "components": [
      { "type": "environment.spherical_earth", "name": "earth", "config": {} }
    ]
  },
  "vehicles": [
    {
      "id": "cart",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [0.0, 0.0, 1000.0],
              "initial_velocity": [250.0, 0.0, 0.0]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [0.0, 0.0, -9.81]
            }
          }
        ]
      }
    },
    {
      "id": "spherical",
      "infrastructure": [
        {
          "type": "test.spherical_infrastructure_probe",
          "name": "coordinate_context",
          "config": {}
        }
      ],
      "form": {
        "components": [
          {
            "type": "form.local_spherical_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "launch_azimuth_rad": 0.0,
              "initial_state": {
                "longitude_rad": 0.0,
                "latitude_rad": 0.0,
                "altitude_m": 10000.0,
                "speed_mps": 500.0,
                "flight_path_angle_rad": -0.05,
                "heading_angle_rad": 0.0
              }
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.local_spherical_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "local_acceleration_nue_mps2": [0.0, -9.80665, 0.0]
            }
          }
        ]
      }
    },
    {
      "id": "target",
      "form": {
        "components": [
          {
            "type": "form.target_point.kinematic",
            "name": "truth",
            "config": {
              "initial_position_ecef_m": [1000.0, 0.0, 0.0],
              "velocity_ecef_mps": [0.0, 0.0, 0.0]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": []
      }
    }
  ],
  "outputs": {
    "enabled": false
  },
  "summary": {
    "type": "summary.engagement_local_spherical_3dof.ideal",
    "name": "summary",
    "config": {
      "interceptor_truth_lookup_name": "spherical.dynamics",
      "target_truth_lookup_name": "target.truth"
    }
  }
}
)json";

        gnc::core::SimulationBuilder project_summary_configured_vehicle_builder(test_support::catalog());
        test_support::require(
            project_summary_configured_vehicle_builder.loadConfigString(
                project_summary_configured_vehicle_mission),
            "Project summary configured-vehicle mission JSON could not be parsed.");

        bool project_summary_configured_vehicle_failed = false;
        try {
            project_summary_configured_vehicle_builder.build();
        } catch (const std::exception&) {
            project_summary_configured_vehicle_failed = true;
        }

        test_support::require(
            !project_summary_configured_vehicle_failed,
            "Top-level project summary should use its configured component names without a global vehicle-family shortcut.");

        const char* real_family_mismatch_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.1
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [
                0.0,
                0.0,
                1000.0
              ],
              "initial_velocity": [
                250.0,
                0.0,
                0.0
              ]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.local_spherical_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "local_acceleration_nue_mps2": [
                0.0,
                -9.80665,
                0.0
              ]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder real_family_mismatch_builder(test_support::catalog());
        test_support::require(
            real_family_mismatch_builder.loadConfigString(real_family_mismatch_mission),
            "Real form-family mismatch mission JSON could not be parsed.");

        bool real_family_mismatch_failed = false;
        try {
            real_family_mismatch_builder.build();
        } catch (const std::exception&) {
            real_family_mismatch_failed = true;
        }

        test_support::require(
            real_family_mismatch_failed,
            "Cartesian form should reject a local_spherical_3dof interaction.");
        test_support::require(
            containsSubstring(real_family_mismatch_builder.getBuildErrors(), "cartesian_3dof"),
            "Real form-family mismatch did not mention the selected cartesian_3dof family.");

        const char* local_acceleration_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.5,
    "integrator": "rk4"
  },
  "environment": {
    "components": [
      {
        "type": "environment.spherical_earth",
        "name": "earth",
        "config": {}
      },
      {
        "type": "environment.standard_atmosphere",
        "name": "atmosphere",
        "config": {}
      }
    ]
  },
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.local_spherical_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "launch_azimuth_rad": 1.5707963267948966,
              "initial_state": {
                "longitude_rad": 1.9198621771937625,
                "latitude_rad": 0.5235987755982988,
                "altitude_m": 10000.0,
                "speed_mps": 500.0,
                "flight_path_angle_rad": -0.05,
                "heading_angle_rad": -1.5707963267948966
              }
            }
          }
        ]
      },
      "common": [],
      "input": [
        { "type": "vehicle.input.local_spherical_air_data_3dof.ideal", "name": "air_data", "config": {} }
      ],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.local_spherical_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "local_acceleration_nue_mps2": [
                0.0,
                -9.80665,
                0.0
              ]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  }
}
)json";

        gnc::core::SimulationBuilder direct_builder(test_support::catalog());
        test_support::require(direct_builder.loadConfigString(local_acceleration_mission),
                              "Local-spherical acceleration mission could not be parsed.");

        auto& direct_simulator = direct_builder.build();
        auto* direct_dynamics =
            direct_simulator.getRegistry().get<gnc::forms::local_spherical_3dof::ITruthView>(
                "vehicle.dynamics");
        auto* direct_air_data =
            direct_simulator.getRegistry().get<gnc::vehicle::input::IAirData3Dof>(
                "vehicle.air_data");
        test_support::require(direct_dynamics != nullptr,
                              "Local-spherical acceleration mission did not expose truth view.");
        test_support::require(direct_air_data != nullptr,
                              "Local-spherical acceleration mission did not expose air-data.");

        direct_simulator.initialize();
        const double initial_direct_altitude =
            direct_dynamics->getLocalSpherical3DoFTruth().state.altitude_m;
        direct_simulator.run();

        test_support::require(
            direct_dynamics->getLocalSpherical3DoFTruth().state.altitude_m <
                initial_direct_altitude,
                              "Local-spherical acceleration mission did not descend.");
        test_support::require(
            direct_air_data->airDataMeasurement3Dof().dynamic_pressure_pa > 0.0,
            "Local-spherical acceleration mission returned non-physical air-data.");

        const char* vehicle_continuous_group_mission = R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.1, "integrator": "rk4" },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "family": "test_continuous",
        "components": [
          { "type": "test.continuous_form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "continuous_groups": [
        {
          "type": "test.continuous_group_probe",
          "name": "coupled_dynamics",
          "config": { "member": "dynamics" }
        }
      ]
    }
  ],
  "outputs": { "enabled": false }
}
)json";

        gnc::core::SimulationBuilder vehicle_group_builder(test_support::catalog());
        test_support::require(
            vehicle_group_builder.loadConfigString(vehicle_continuous_group_mission),
            "Vehicle continuous-group mission JSON could not be parsed.");
        auto& vehicle_group_simulator = vehicle_group_builder.build();
        auto* vehicle_group_member =
            vehicle_group_simulator.getRegistry().get<ContinuousFormProbe>(
                "vehicle.dynamics");
        test_support::require(vehicle_group_member != nullptr,
                              "Vehicle continuous group member was not assembled.");
        test_support::require(
            vehicle_group_simulator.getRegistry()
                    .get<gnc::interfaces::IContinuousGroup>(
                        "vehicle.coupled_dynamics") != nullptr,
            "Vehicle continuous group was not assembled in the vehicle scope.");
        vehicle_group_simulator.run();
        test_support::requireNear(
            vehicle_group_member->value(),
            2.3,
            1.0e-12,
            "Vehicle continuous group did not replace independent member integration.");

        const char* mission_continuous_group_mission = R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.1, "integrator": "rk4" },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "family": "test_continuous",
        "components": [
          { "type": "test.continuous_form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": []
    }
  ],
  "continuous_groups": [
    {
      "type": "test.continuous_group_probe",
      "name": "coupled_dynamics",
      "config": { "member": "vehicle.dynamics" }
    }
  ],
  "outputs": { "enabled": false }
}
)json";

        gnc::core::SimulationBuilder mission_group_builder(test_support::catalog());
        test_support::require(
            mission_group_builder.loadConfigString(mission_continuous_group_mission),
            "Mission continuous-group JSON could not be parsed.");
        auto& mission_group_simulator = mission_group_builder.build();
        auto* mission_group_member =
            mission_group_simulator.getRegistry().get<ContinuousFormProbe>(
                "vehicle.dynamics");
        test_support::require(mission_group_member != nullptr,
                              "Mission continuous group member was not assembled.");
        test_support::require(
            mission_group_simulator.getRegistry()
                    .get<gnc::interfaces::IContinuousGroup>(
                        "mission.coupled_dynamics") != nullptr,
            "Mission continuous group was not assembled in the mission scope.");
        mission_group_simulator.run();
        test_support::requireNear(
            mission_group_member->value(),
            2.3,
            1.0e-12,
            "Mission continuous group did not replace independent member integration.");

        const char* cross_vehicle_group_mission = R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.1, "integrator": "rk4" },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle_a",
      "form": {
        "family": "test_continuous",
        "components": [
          { "type": "test.continuous_form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [], "input": [], "process": [], "output": [],
      "continuous_groups": [
        {
          "type": "test.continuous_group_probe",
          "name": "invalid_cross_scope_group",
          "config": { "member": "vehicle_b.dynamics" }
        }
      ]
    },
    {
      "id": "vehicle_b",
      "form": {
        "family": "test_continuous",
        "components": [
          { "type": "test.continuous_form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [], "input": [], "process": [], "output": []
    }
  ],
  "outputs": { "enabled": false }
}
)json";

        gnc::core::SimulationBuilder cross_vehicle_group_builder(
            test_support::catalog());
        test_support::require(
            cross_vehicle_group_builder.loadConfigString(
                cross_vehicle_group_mission),
            "Cross-vehicle continuous-group mission JSON could not be parsed.");
        bool cross_vehicle_group_failed = false;
        try {
            (void)cross_vehicle_group_builder.build();
        } catch (const std::runtime_error&) {
            cross_vehicle_group_failed = true;
        }
        test_support::require(
            cross_vehicle_group_failed,
            "A vehicle continuous group must reject cross-scope members.");
        test_support::require(
            containsSubstring(
                cross_vehicle_group_builder.getBuildErrors(),
                "Use a mission continuous group for cross-scope coupling"),
            "Cross-scope continuous-group failure did not identify the mission placement.");

        const char* invalid_continuous_group_mission = R"json(
{
  "simulation": { "dt": 0.1, "duration": 0.1, "integrator": "rk4" },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "family": "test_continuous",
        "components": [
          { "type": "test.continuous_form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "continuous_groups": [
        {
          "type": "test.non_continuous_group_probe",
          "name": "invalid_group",
          "config": {}
        }
      ]
    }
  ],
  "outputs": { "enabled": false }
}
)json";

        gnc::core::SimulationBuilder invalid_group_builder(test_support::catalog());
        test_support::require(
            invalid_group_builder.loadConfigString(invalid_continuous_group_mission),
            "Invalid continuous-group mission JSON could not be parsed.");
        bool invalid_group_failed = false;
        try {
            invalid_group_builder.build();
        } catch (const std::exception&) {
            invalid_group_failed = true;
        }
        test_support::require(
            invalid_group_failed,
            "continuous_groups placement must reject nodes without IContinuousGroup.");
        test_support::require(
            containsSubstring(invalid_group_builder.getBuildErrors(),
                              "must implement IContinuousGroup"),
            "Invalid continuous group did not report its missing capability.");

        namespace fs = std::filesystem;
        const fs::path atomic_output_dir =
            fs::absolute(fs::path("test_outputs") / "mission_build_atomic");
        fs::create_directories(atomic_output_dir);
        const fs::path sentinel_path =
            atomic_output_dir / "sentinel_debug_snapshots.csv";
        {
            std::ofstream sentinel(sentinel_path, std::ios::trunc);
            sentinel << "preserve-this-file\n";
        }
        std::ostringstream duplicate_group_mission;
        duplicate_group_mission
            << R"json({
  "simulation": { "dt": 0.1, "duration": 0.1, "integrator": "rk4" },
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "family": "test_continuous",
        "components": [
          { "type": "test.continuous_form_probe", "name": "dynamics", "config": {} }
        ]
      },
      "common": [], "input": [], "process": [], "output": []
    }
  ],
  "continuous_groups": [
    {
      "type": "test.continuous_group_probe",
      "name": "group_a",
      "config": { "member": "vehicle.dynamics" }
    },
    {
      "type": "test.continuous_group_probe",
      "name": "group_b",
      "config": { "member": "vehicle.dynamics" }
    }
  ],
  "outputs": {
    "directory": ")json"
            << atomic_output_dir.generic_string()
            << R"json(",
    "session_name": "sentinel",
    "record": [],
    "debug_snapshots": true
  }
})json";

        gnc::core::SimulationBuilder duplicate_group_builder(
            test_support::catalog());
        test_support::require(
            duplicate_group_builder.loadConfigString(duplicate_group_mission.str()),
            "Duplicate continuous-group mission JSON could not be parsed.");
        bool duplicate_group_failed = false;
        try {
            (void)duplicate_group_builder.build();
        } catch (const std::runtime_error&) {
            duplicate_group_failed = true;
        }
        test_support::require(
            duplicate_group_failed,
            "Duplicate continuous-group ownership must fail during build().");
        test_support::require(
            containsSubstring(duplicate_group_builder.getBuildErrors(),
                              "more than one continuous group"),
            "Duplicate continuous-group ownership did not report its cause.");
        std::ifstream preserved_file(sentinel_path);
        std::string preserved_text;
        std::getline(preserved_file, preserved_text);
        test_support::require(
            preserved_text == "preserve-this-file",
            "A failed build truncated an existing output file.");
        preserved_file.close();
        fs::remove_all(atomic_output_dir);

        const char* cartesian_acceleration_mission = R"json(
{
  "simulation": {
    "dt": 0.1,
    "duration": 0.5,
    "integrator": "rk4"
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [
                0.0,
                0.0,
                1000.0
              ],
              "initial_velocity": [
                250.0,
                0.0,
                0.0
              ]
            }
          }
        ]
      },
      "common": [],
      "input": [],
      "process": [],
      "output": [],
      "interaction": {
        "components": [
          {
            "type": "test_fixture.cartesian_3dof.acceleration_input",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [
                0.0,
                0.0,
                -9.81
              ]
            }
          }
        ]
      }
    }
  ],
  "outputs": {
    "enabled": false
  },
  "termination": {
      "type": "termination.component_field_below",
      "name": "termination",
      "config": {
      "component": "vehicle.dynamics",
      "field": "altitude",
      "value": 999.0,
      "description": "Cartesian direct-accel descent threshold"
    }
  }
}
)json";

        gnc::core::SimulationBuilder cartesian_builder(test_support::catalog());
        test_support::require(cartesian_builder.loadConfigString(cartesian_acceleration_mission),
                              "Cartesian acceleration mission could not be parsed.");

        auto& cartesian_simulator = cartesian_builder.build();
        auto* cartesian_dynamics =
            cartesian_simulator.getRegistry().get<gnc::forms::cartesian_3dof::ITruthView>(
                "vehicle.dynamics");
        test_support::require(cartesian_dynamics != nullptr,
                              "Cartesian direct-accel mission did not expose cartesian truth view.");

        cartesian_simulator.run();

        test_support::require(
            cartesian_simulator.getTerminationReason() ==
                "Cartesian direct-accel descent threshold",
            "Cartesian direct-accel mission did not trigger the expected descent stop condition.");

        std::cout << "mission contract checks passed\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
