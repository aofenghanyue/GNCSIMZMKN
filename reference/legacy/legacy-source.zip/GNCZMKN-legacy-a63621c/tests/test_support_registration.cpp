#include "test_support.hpp"

#include "auto_registered_test_components.hpp"
#include "gnc/bootstrap/register_framework_builtins.hpp"

namespace test_support {

gnc::core::FrameworkCatalog& catalog() {
    static gnc::core::FrameworkCatalog value;
    return value;
}

gnc::core::NodeFactory& nodeFactory() {
    return catalog().nodes();
}

void registerBuiltinComponentTypes() {
    gnc::bootstrap::registerFrameworkBuiltins(catalog());
    gnc::build::registerAutoRegisteredTestNodes(catalog().nodes());
}

void registerStableTestProjectComponentTypes() {
    gnc::build::registerAutoRegisteredTestNodes(catalog().nodes());
}

void registerAvailableComponentTypes() {
    registerBuiltinComponentTypes();
}

} // namespace test_support
