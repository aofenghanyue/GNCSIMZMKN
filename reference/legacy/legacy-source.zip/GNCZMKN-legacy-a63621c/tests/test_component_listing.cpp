#include "test_support.hpp"

#include "gnc/core/node_factory.hpp"

#include <algorithm>
#include <exception>
#include <iostream>
#include <string>
#include <vector>

namespace {

using gnc::core::NodeFactory;
using gnc::core::NodeRole;
using gnc::core::DiscretePhase;

class CatalogProbe final : public gnc::core::SimulationNode {
public:
    CatalogProbe() : SimulationNode("CatalogProbe") {}
};

bool containsValue(const std::vector<std::string>& values,
                   const std::string& expected) {
    return std::find(values.begin(), values.end(), expected) != values.end();
}

const NodeFactory::RegisteredTypeInfo& requireType(
    const std::vector<NodeFactory::RegisteredTypeInfo>& infos,
    const std::string& type_name) {
    const auto it = std::find_if(
        infos.begin(),
        infos.end(),
        [&](const NodeFactory::RegisteredTypeInfo& info) {
            return info.type_name == type_name;
        });
    test_support::require(it != infos.end(),
                          "Missing registered builtin component type: " + type_name);
    return *it;
}

void requireMetadata(const std::vector<NodeFactory::RegisteredTypeInfo>& infos,
                     const std::string& type_name,
                     NodeRole role,
                     DiscretePhase phase,
                     const std::string& form_family) {
    const auto& info = requireType(infos, type_name);
    test_support::require(info.role == role,
                          type_name + " has the wrong package role.");
    test_support::require(info.discrete_phase == phase,
                          type_name + " has the wrong discrete phase.");
    test_support::require(info.form_family == form_family,
                          type_name + " has the wrong form family.");
}

void requireInterface(const std::vector<NodeFactory::RegisteredTypeInfo>& infos,
                      const std::string& type_name,
                      const std::string& interface_name) {
    const auto& info = requireType(infos, type_name);
    test_support::require(containsValue(info.interface_names, interface_name),
                          type_name + " should advertise " + interface_name + ".");
}

void requireAbsent(NodeFactory& factory, const std::string& type_name) {
    test_support::require(!factory.hasType(type_name),
                          "Legacy builtin should not be registered: " + type_name);
}

} // namespace

int main() {
    try {
        NodeFactory collision_factory;
        collision_factory.registerType<CatalogProbe>("test.catalog_probe");
        bool duplicate_rejected = false;
        try {
            collision_factory.registerType<CatalogProbe>("test.catalog_probe");
        } catch (const std::runtime_error&) {
            duplicate_rejected = true;
        }
        test_support::require(
            duplicate_rejected,
            "NodeFactory must reject duplicate type ids during catalog assembly.");

        test_support::registerBuiltinComponentTypes();

        auto& factory = test_support::nodeFactory();
        const auto infos = factory.getRegisteredTypeInfos();

        requireMetadata(infos,
                        "environment.spherical_earth",
                        NodeRole::EnvironmentModel,
                        DiscretePhase::None,
                        "");
        requireMetadata(infos,
                        "environment.standard_atmosphere",
                        NodeRole::EnvironmentModel,
                        DiscretePhase::None,
                        "");
        requireMetadata(infos,
                        "environment.spherical_gravity",
                        NodeRole::EnvironmentModel,
                        DiscretePhase::None,
                        "");

        requireMetadata(infos,
                        "form.cartesian_3dof.point_mass",
                        NodeRole::Form,
                        DiscretePhase::None,
                        "cartesian_3dof");
        requireInterface(infos, "form.cartesian_3dof.point_mass", "IContinuousSystem");
        requireInterface(infos, "form.cartesian_3dof.point_mass", "ITruthView");
        requireInterface(infos, "form.cartesian_3dof.point_mass", "IObservable");

        requireMetadata(infos,
                        "form.local_spherical_3dof.point_mass",
                        NodeRole::Form,
                        DiscretePhase::None,
                        "local_spherical_3dof");
        requireInterface(infos,
                         "form.local_spherical_3dof.point_mass",
                         "IContinuousSystem");
        requireInterface(infos, "form.local_spherical_3dof.point_mass", "ITruthView");
        requireInterface(infos, "form.local_spherical_3dof.point_mass", "IObservable");

        requireMetadata(infos,
                        "form.cartesian_6dof.rigid_body",
                        NodeRole::Form,
                        DiscretePhase::None,
                        "cartesian_6dof");
        requireMetadata(infos,
                        "form.local_spherical_6dof.rigid_body",
                        NodeRole::Form,
                        DiscretePhase::None,
                        "local_spherical_6dof");
        requireMetadata(infos,
                        "form.target_point.kinematic",
                        NodeRole::Form,
                        DiscretePhase::None,
                        "target_point");

        requireMetadata(infos,
                        "interaction.cartesian_3dof.standard",
                        NodeRole::Interaction,
                        DiscretePhase::Interaction,
                        "cartesian_3dof");
        requireMetadata(infos,
                        "interaction.local_spherical_3dof.standard",
                        NodeRole::Interaction,
                        DiscretePhase::Interaction,
                        "local_spherical_3dof");
        requireMetadata(infos,
                        "interaction.cartesian_6dof.standard",
                        NodeRole::Interaction,
                        DiscretePhase::Interaction,
                        "cartesian_6dof");
        requireMetadata(infos,
                        "interaction.local_spherical_6dof.standard",
                        NodeRole::Interaction,
                        DiscretePhase::Interaction,
                        "local_spherical_6dof");

        requireMetadata(infos,
                        "perturbation.static",
                        NodeRole::Perturbation,
                        DiscretePhase::None,
                        "");
        requireInterface(infos, "perturbation.static", "IPerturbationProvider");

        requireMetadata(infos,
                        "vehicle.common.aero_assets_3dof.zero",
                        NodeRole::Asset,
                        DiscretePhase::None,
                        "");
        requireInterface(infos,
                         "vehicle.common.aero_assets_3dof.zero",
                         "IAerodynamicAssets3Dof");
        requireMetadata(infos,
                        "vehicle.common.aero_assets_6dof.zero",
                        NodeRole::Asset,
                        DiscretePhase::None,
                        "");
        requireInterface(infos,
                         "vehicle.common.aero_assets_6dof.zero",
                         "IAerodynamicAssets6Dof");

        requireMetadata(infos,
                        "vehicle.input.cartesian_satellite_nav_3dof.ideal",
                        NodeRole::Input,
                        DiscretePhase::Input,
                        "cartesian_3dof");
        requireMetadata(infos,
                        "vehicle.input.local_spherical_satellite_nav_3dof.ideal",
                        NodeRole::Input,
                        DiscretePhase::Input,
                        "local_spherical_3dof");
        requireMetadata(infos,
                        "vehicle.process.cartesian_navigation_6dof.ideal",
                        NodeRole::Process,
                        DiscretePhase::Process,
                        "cartesian_6dof");
        requireMetadata(infos,
                        "vehicle.process.local_spherical_navigation_6dof.ideal",
                        NodeRole::Process,
                        DiscretePhase::Process,
                        "local_spherical_6dof");

        requireMetadata(infos,
                        "vehicle.output.mass_3dof.constant",
                        NodeRole::Output,
                        DiscretePhase::None,
                        "");
        requireMetadata(infos,
                        "vehicle.output.mass_properties_6dof.constant",
                        NodeRole::Output,
                        DiscretePhase::None,
                        "");

        requireMetadata(infos,
                        "termination.component_field_below",
                        NodeRole::Termination,
                        DiscretePhase::None,
                        "");
        requireMetadata(infos,
                        "summary.engagement_cartesian_3dof.ideal",
                        NodeRole::Summary,
                        DiscretePhase::Evaluation,
                        "cartesian_3dof");

        requireAbsent(factory, "cavh.constant_mass");
        requireAbsent(factory, "cavh.aero_table");
        requireAbsent(factory, "vehicle.process.coordinate_probe");
        requireAbsent(factory, "vehicle.process.programmed_aoa");
        requireAbsent(factory, "interaction.cartesian_3dof.direct_accel");
        requireAbsent(factory, "interaction.local_spherical_3dof.aero_propulsive");
        requireAbsent(factory, "form.local_spherical_3dof.flight_state_view");

        std::cout << "component metadata checks passed\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
