#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/interfaces/i_observable.hpp"

namespace tests::project_components {

class OutputProbe final : public gnc::core::DiscreteNode,
                          public gnc::interfaces::IObservable {
public:
    OutputProbe() : DiscreteNode("StableTestOutputProbe") {}

    void update(const gnc::core::StepContext& context) override {}

    std::vector<gnc::interfaces::ObservableField> getObservableFields() const override {
        return {};
    }
};

} // namespace tests::project_components

GNC_REGISTER_NODE_TYPE(
    "test_fixture.output_probe",
    tests::project_components::OutputProbe,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "",
    ::gnc::interfaces::IObservable)
