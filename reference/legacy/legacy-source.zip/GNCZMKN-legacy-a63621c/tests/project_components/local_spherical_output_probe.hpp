#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/interfaces/i_observable.hpp"

namespace tests::project_components {

class LocalSphericalOutputProbe final : public gnc::core::DiscreteNode,
                                        public gnc::interfaces::IObservable {
public:
    LocalSphericalOutputProbe() : DiscreteNode("StableTestLocalSphericalOutputProbe") {}

    void update(const gnc::core::StepContext& context) override {}

    std::vector<gnc::interfaces::ObservableField> getObservableFields() const override {
        return {};
    }
};

} // namespace tests::project_components

GNC_REGISTER_NODE_TYPE(
    "test_fixture.local_spherical_output_probe",
    tests::project_components::LocalSphericalOutputProbe,
    ::gnc::core::NodeRole::Output,
    ::gnc::core::DiscretePhase::Output,
    "local_spherical_3dof",
    ::gnc::interfaces::IObservable)
