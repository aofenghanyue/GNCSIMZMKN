#pragma once

#include "gnc/core/simulation_node.hpp"
#include "gnc/core/node_factory.hpp"
#include "gnc/interfaces/i_observable.hpp"

namespace tests::project_components {

class ProcessProbe final : public gnc::core::DiscreteNode,
                           public gnc::interfaces::IObservable {
public:
    ProcessProbe() : DiscreteNode("StableTestProcessProbe") {}

    void update(const gnc::core::StepContext& context) override {}

    std::vector<gnc::interfaces::ObservableField> getObservableFields() const override {
        return {};
    }
};

} // namespace tests::project_components

GNC_REGISTER_NODE_TYPE(
    "test_fixture.process_probe",
    tests::project_components::ProcessProbe,
    ::gnc::core::NodeRole::Process,
    ::gnc::core::DiscretePhase::Process,
    "",
    ::gnc::interfaces::IObservable)
