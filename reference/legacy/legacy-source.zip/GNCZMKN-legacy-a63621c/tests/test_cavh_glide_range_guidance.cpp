#include "test_support.hpp"

#define GNC_NODE_REGISTRATION_FN gnc_register_cavh_glide_range_guidance_test
#include "user/example_08_cavh_geographic_3dof_custom/components/cavh_glide_range_guidance.hpp"
#undef GNC_NODE_REGISTRATION_FN

#define GNC_NODE_REGISTRATION_FN gnc_register_cavh_paper_aero_assets_test
#include "user/example_08_cavh_geographic_3dof_custom/components/cavh_paper_aero_assets_3dof.hpp"
#undef GNC_NODE_REGISTRATION_FN

#include "gnc/core/node_registry.hpp"
#include "gnc/core/assembly_context.hpp"
#include "gnc/environment/interfaces/i_atmosphere.hpp"
#include "gnc/environment/interfaces/i_gravity.hpp"
#include "gnc/vehicle/output/interfaces/i_aero_model.hpp"
#include "gnc/vehicle/output/interfaces/i_constant_mass.hpp"
#include "gnc/vehicle/process/interfaces/i_navigation_3dof.hpp"

#include <cmath>
#include <exception>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>

namespace {

class StubNavigation final
    : public gnc::core::DiscreteNode,
      public gnc::vehicle::process::INavigation3Dof {
public:
    StubNavigation() : DiscreteNode("StubNavigation") {}

    void setState(double altitude_m,
                  double speed_mps,
                  double flight_path_angle_rad,
                  double mach_number) {
        state_.altitude_m = altitude_m;
        state_.speed_mps = speed_mps;
        state_.flight_path_angle_rad = flight_path_angle_rad;
        state_.mach_number = mach_number;
    }

    void update(const gnc::core::StepContext& context) override {}

    const gnc::vehicle::process::NavigationState3Dof& navigationState3Dof()
        const override {
        return state_;
    }

private:
    gnc::vehicle::process::NavigationState3Dof state_{};
};

class ExponentialAtmosphere final
    : public gnc::core::DiscreteNode,
      public gnc::environment::IAtmosphere {
public:
    ExponentialAtmosphere(double sea_level_density_kg_per_m3,
                          double scale_height_m,
                          double speed_of_sound_mps)
        : DiscreteNode("ExponentialAtmosphere"),
          sea_level_density_kg_per_m3_(sea_level_density_kg_per_m3),
          scale_height_m_(scale_height_m),
          speed_of_sound_mps_(speed_of_sound_mps) {}

    void update(const gnc::core::StepContext& context) override {}

    gnc::environment::AtmosphereSample sample(double altitude_m) const override {
        gnc::environment::AtmosphereSample sample;
        sample.density_kg_per_m3 =
            sea_level_density_kg_per_m3_ *
            std::exp(-altitude_m / scale_height_m_);
        sample.speed_of_sound_mps = speed_of_sound_mps_;
        return sample;
    }

    double getSeaLevelDensity() const override {
        return sea_level_density_kg_per_m3_;
    }

    double getSeaLevelPressure() const override { return 101325.0; }

    double getSeaLevelTemperature() const override { return 288.15; }

    double getSeaLevelSpeedOfSound() const override {
        return speed_of_sound_mps_;
    }

private:
    double sea_level_density_kg_per_m3_ = 1.225;
    double scale_height_m_ = 7200.0;
    double speed_of_sound_mps_ = 300.0;
};

class ConstantGravity final : public gnc::core::DiscreteNode,
                              public gnc::environment::IGravity {
public:
    explicit ConstantGravity(double gravity_mps2)
        : DiscreteNode("ConstantGravity"), gravity_mps2_(gravity_mps2) {}

    void update(const gnc::core::StepContext& context) override {}

    double getSeaLevelGravity() const override { return gravity_mps2_; }

    double getGravityMagnitude(double) const override { return gravity_mps2_; }

    gnc::math::Vector3 getGravityVector(
        const gnc::math::Vector3&) const override {
        return gnc::math::Vector3(0.0, -gravity_mps2_, 0.0);
    }

private:
    double gravity_mps2_ = 9.81;
};

class ConstantMass final : public gnc::core::DiscreteNode,
                           public gnc::vehicle::output::IConstantMass {
public:
    explicit ConstantMass(double mass_kg)
        : DiscreteNode("ConstantMass"), mass_kg_(mass_kg) {}

    void update(const gnc::core::StepContext& context) override {}

    double getMassKg() const override { return mass_kg_; }

private:
    double mass_kg_ = 1.0;
};

class ParabolicAero final : public gnc::core::DiscreteNode,
                            public gnc::vehicle::output::IAeroModel {
public:
    ParabolicAero(double lift_intercept,
                  double lift_slope_per_rad,
                  double zero_lift_drag,
                  double induced_drag_factor,
                  double reference_area_m2,
                  double zero_lift_drag_slope_per_mach = 0.0)
        : DiscreteNode("ParabolicAero"),
          lift_intercept_(lift_intercept),
          lift_slope_per_rad_(lift_slope_per_rad),
          zero_lift_drag_(zero_lift_drag),
          induced_drag_factor_(induced_drag_factor),
          reference_area_m2_(reference_area_m2),
          zero_lift_drag_slope_per_mach_(zero_lift_drag_slope_per_mach) {}

    void update(const gnc::core::StepContext& context) override {}

    gnc::vehicle::output::AeroCoefficients computeCoefficients(
        double angle_of_attack_rad,
        double,
        double mach_number) const override {
        gnc::vehicle::output::AeroCoefficients coefficients;
        coefficients.lift_coefficient =
            lift_intercept_ + lift_slope_per_rad_ * angle_of_attack_rad;
        coefficients.drag_coefficient =
            zero_lift_drag_ + zero_lift_drag_slope_per_mach_ * mach_number +
            induced_drag_factor_ * coefficients.lift_coefficient *
                coefficients.lift_coefficient;
        return coefficients;
    }

    double getReferenceArea() const override { return reference_area_m2_; }

    double getReferenceLength() const override { return 1.0; }

private:
    double lift_intercept_ = 0.0;
    double lift_slope_per_rad_ = 1.0;
    double zero_lift_drag_ = 0.02;
    double induced_drag_factor_ = 0.08;
    double reference_area_m2_ = 1.0;
    double zero_lift_drag_slope_per_mach_ = 0.0;
};

gnc::core::ConfigNode validGuidanceConfig() {
    using namespace test_support;
    return object({
        field("navigation_lookup_name", string("navigation")),
        field("aero_lookup_name", string("aero")),
        field("atmosphere_lookup_name", string("env.atmosphere")),
        field("gravity_lookup_name", string("env.gravity")),
        field("mass_lookup_name", string("mass")),
        field("tdct_gain", number(0.15)),
        field("gamma_command_model", string("eq18_simplified")),
        field("bank_angle_deg", number(0.0)),
        field("alpha_min_deg", number(0.0)),
        field("alpha_max_deg", number(30.0)),
        field("alpha_samples", number(1201.0)),
        field("density_gradient_step_m", number(1.0)),
        field("mach_derivative_step", number(0.01)),
    });
}

double observableValue(const gnc::interfaces::IObservable& observable,
                       const std::string& field_name) {
    for (const auto& field : observable.getObservableFields()) {
        if (field.name == field_name) {
            return field.getter();
        }
    }
    throw std::runtime_error("Observable field not found: " + field_name);
}

double paperEq18GammaCommand(double lift_coefficient,
                             double drag_coefficient,
                             double density_kg_per_m3,
                             double density_gradient_per_m,
                             double speed_mps,
                             double gravity_mps2,
                             double mass_kg,
                             double reference_area_m2,
                             double earth_radius_m,
                             double altitude_m) {
    const double radius_m = earth_radius_m + altitude_m;
    const double dynamic_pressure_pa =
        0.5 * density_kg_per_m3 * speed_mps * speed_mps;
    const double drag_force_n =
        drag_coefficient * dynamic_pressure_pa * reference_area_m2;

    const double a21 = density_gradient_per_m * speed_mps * speed_mps /
                       (2.0 * density_kg_per_m3 * gravity_mps2);
    const double a24 =
        2.0 * mass_kg /
        (lift_coefficient * density_kg_per_m3 * reference_area_m2 * radius_m);
    const double a25 = mass_kg * speed_mps * speed_mps /
                       (lift_coefficient * density_kg_per_m3 * gravity_mps2 *
                        reference_area_m2 * radius_m * radius_m);
    const double a31 =
        density_gradient_per_m * lift_coefficient * speed_mps * speed_mps *
        reference_area_m2 * radius_m / (4.0 * mass_kg * gravity_mps2);
    const double a34 = 1.0 / a24;
    const double a35 =
        speed_mps * speed_mps / (2.0 * gravity_mps2 * radius_m);

    return -drag_force_n / (mass_kg * gravity_mps2) *
           (1.0 / (1.0 - a21 + a24 + a25) +
            1.0 / (1.0 - a31 + a34 + a35));
}

double paperEq17GammaCommand(double lift_coefficient,
                             double drag_coefficient,
                             double d_lift_coefficient_d_mach,
                             double partial_mach_partial_speed,
                             double partial_mach_partial_altitude,
                             double density_kg_per_m3,
                             double density_gradient_per_m,
                             double speed_mps,
                             double gravity_mps2,
                             double mass_kg,
                             double reference_area_m2,
                             double earth_radius_m,
                             double altitude_m) {
    const double radius_m = earth_radius_m + altitude_m;
    const double dynamic_pressure_pa =
        0.5 * density_kg_per_m3 * speed_mps * speed_mps;
    const double drag_force_n =
        drag_coefficient * dynamic_pressure_pa * reference_area_m2;
    const double dcl_dma_dv =
        d_lift_coefficient_d_mach * partial_mach_partial_speed;

    const double a11 = density_gradient_per_m * lift_coefficient * speed_mps /
                       (dcl_dma_dv * density_kg_per_m3 * gravity_mps2);
    const double a12 = partial_mach_partial_altitude * speed_mps /
                       (partial_mach_partial_speed * gravity_mps2);
    const double a13 =
        2.0 * lift_coefficient / (dcl_dma_dv * speed_mps);
    const double a14 = 4.0 * mass_kg /
                       (dcl_dma_dv * density_kg_per_m3 * speed_mps *
                        reference_area_m2 * radius_m);
    const double a15 =
        2.0 * speed_mps * mass_kg /
        (dcl_dma_dv * density_kg_per_m3 * reference_area_m2 * gravity_mps2 *
         radius_m * radius_m);

    const double a21 = density_gradient_per_m * speed_mps * speed_mps /
                       (2.0 * density_kg_per_m3 * gravity_mps2);
    const double a22 = d_lift_coefficient_d_mach *
                       partial_mach_partial_altitude * speed_mps * speed_mps /
                       (2.0 * lift_coefficient * gravity_mps2);
    const double a23 = 1.0 / a13;
    const double a24 =
        2.0 * mass_kg /
        (lift_coefficient * density_kg_per_m3 * reference_area_m2 * radius_m);
    const double a25 = mass_kg * speed_mps * speed_mps /
                       (lift_coefficient * density_kg_per_m3 * gravity_mps2 *
                        reference_area_m2 * radius_m * radius_m);

    const double a31 =
        density_gradient_per_m * lift_coefficient * speed_mps * speed_mps *
        reference_area_m2 * radius_m / (4.0 * mass_kg * gravity_mps2);
    const double a32 =
        d_lift_coefficient_d_mach * partial_mach_partial_altitude *
        density_kg_per_m3 * speed_mps * speed_mps * reference_area_m2 *
        radius_m / (4.0 * mass_kg * gravity_mps2);
    const double a33 = 1.0 / a14;
    const double a34 = 1.0 / a24;
    const double a35 =
        speed_mps * speed_mps / (2.0 * gravity_mps2 * radius_m);

    return -drag_force_n / (mass_kg * gravity_mps2) *
           (1.0 / (1.0 - a11 - a12 + a13 + a14 + a15) +
            1.0 / (1.0 - a21 - a22 + a23 + a24 + a25) +
            1.0 / (1.0 - a31 - a32 + a33 + a34 + a35));
}

void requirePaperLawCommand() {
    constexpr double sea_level_density = 1.225;
    constexpr double scale_height_m = 7200.0;
    constexpr double speed_of_sound_mps = 300.0;
    constexpr double altitude_m = 30000.0;
    constexpr double speed_mps = 3000.0;
    constexpr double mach_number = speed_mps / speed_of_sound_mps;
    constexpr double gravity_mps2 = 9.81;
    constexpr double mass_kg = 50000.0;
    constexpr double reference_area_m2 = 100.0;
    constexpr double earth_radius_m = 6371000.0;
    constexpr double alpha_star_rad = 0.25;
    constexpr double lift_coefficient_star = 0.5;
    constexpr double drag_coefficient_star = 0.04;
    constexpr double tdct_gain = 0.15;
    constexpr double gamma_error_rad = -0.02;

    gnc::core::NodeRegistry registry;
    auto navigation = std::make_unique<StubNavigation>();
    auto* navigation_ptr = navigation.get();
    registry.add<StubNavigation, gnc::vehicle::process::INavigation3Dof>(
        "vehicle.navigation",
        std::move(navigation));
    registry.add<ExponentialAtmosphere, gnc::environment::IAtmosphere>(
        "env.atmosphere",
        std::make_unique<ExponentialAtmosphere>(
            sea_level_density, scale_height_m, speed_of_sound_mps));
    registry.add<ConstantGravity, gnc::environment::IGravity>(
        "env.gravity",
        std::make_unique<ConstantGravity>(gravity_mps2));
    registry.add<ConstantMass, gnc::vehicle::output::IConstantMass>(
        "vehicle.mass",
        std::make_unique<ConstantMass>(mass_kg));
    registry.add<ParabolicAero, gnc::vehicle::output::IAeroModel>(
        "vehicle.aero",
        std::make_unique<ParabolicAero>(
            0.0, 2.0, 0.02, 0.08, reference_area_m2));

    const double density =
        sea_level_density * std::exp(-altitude_m / scale_height_m);
    const double density_gradient = -density / scale_height_m;
    const double gamma_star =
        paperEq18GammaCommand(lift_coefficient_star,
                              drag_coefficient_star,
                              density,
                              density_gradient,
                              speed_mps,
                              gravity_mps2,
                              mass_kg,
                              reference_area_m2,
                              earth_radius_m,
                              altitude_m);
    navigation_ptr->setState(
        altitude_m, speed_mps, gamma_star + gamma_error_rad, mach_number);

    cavh::components::GlideRangeGuidance guidance;
    guidance.configure(validGuidanceConfig(), "vehicles[0].process[4].config");
    const auto graph =
        gnc::core::AssemblyGraph::inferFromNodeNames(registry.getNodeNames());
    gnc::core::AssemblyContext scoped(
        graph, graph.scopeForNode("vehicle.navigation").key, registry,
        "vehicle.guidance");
    guidance.bind(scoped);
    guidance.update({0.0, 0.1, 0});

    const auto& command = guidance.guidanceCommand3Dof();
    test_support::requireNear(observableValue(guidance, "alpha_star_rad"),
                              alpha_star_rad,
                              1.0e-10,
                              "Guidance should maximize L/D to compute alpha star.");
    test_support::requireNear(observableValue(guidance, "gamma_command_rad"),
                              gamma_star,
                              2.0e-8,
                              "Guidance should compute the Eq. (18) path-angle command.");
    test_support::requireNear(observableValue(guidance, "tdct_gain"),
                              tdct_gain,
                              1.0e-12,
                              "Guidance should expose the TDCT damping gain.");
    test_support::requireNear(observableValue(guidance, "tdct_error_rad"),
                              -gamma_error_rad,
                              2.0e-8,
                              "TDCT error should be gamma star minus measured gamma.");
    test_support::requireNear(
        observableValue(guidance, "tdct_angle_of_attack_correction_rad"),
        -tdct_gain * gamma_error_rad,
        2.0e-8,
        "TDCT should expose its angle-of-attack damping correction.");
    test_support::requireNear(command.angle_of_attack_rad,
                              alpha_star_rad - tdct_gain * gamma_error_rad,
                              2.0e-8,
                              "Guidance should add TDCT path-angle damping to alpha star.");
    test_support::requireNear(command.bank_angle_rad,
                              0.0,
                              1.0e-12,
                              "Guidance should preserve configured bank angle.");
}

void requireMachDerivativePaperLawCommand() {
    constexpr double sea_level_density = 1.225;
    constexpr double scale_height_m = 7200.0;
    constexpr double speed_of_sound_mps = 300.0;
    constexpr double altitude_m = 30000.0;
    constexpr double speed_mps = 3000.0;
    constexpr double mach_number = speed_mps / speed_of_sound_mps;
    constexpr double gravity_mps2 = 9.81;
    constexpr double mass_kg = 50000.0;
    constexpr double reference_area_m2 = 100.0;
    constexpr double earth_radius_m = 6371000.0;
    constexpr double lift_slope_per_rad = 2.0;
    constexpr double zero_lift_drag = 0.02;
    constexpr double zero_lift_drag_slope_per_mach = 0.001;
    constexpr double induced_drag_factor = 0.08;
    constexpr double mach_step = 0.01;

    auto liftCoefficientStar = [](double mach) {
        return std::sqrt((zero_lift_drag +
                          zero_lift_drag_slope_per_mach * mach) /
                         induced_drag_factor);
    };
    const double lift_coefficient_star = liftCoefficientStar(mach_number);
    const double drag_coefficient_star =
        zero_lift_drag + zero_lift_drag_slope_per_mach * mach_number +
        induced_drag_factor * lift_coefficient_star * lift_coefficient_star;
    const double alpha_star_rad =
        lift_coefficient_star / lift_slope_per_rad;
    const double d_lift_coefficient_d_mach =
        (liftCoefficientStar(mach_number + mach_step) -
         liftCoefficientStar(mach_number - mach_step)) /
        (2.0 * mach_step);

    const double density =
        sea_level_density * std::exp(-altitude_m / scale_height_m);
    const double density_gradient = -density / scale_height_m;
    const double gamma_star =
        paperEq17GammaCommand(lift_coefficient_star,
                              drag_coefficient_star,
                              d_lift_coefficient_d_mach,
                              1.0 / speed_of_sound_mps,
                              0.0,
                              density,
                              density_gradient,
                              speed_mps,
                              gravity_mps2,
                              mass_kg,
                              reference_area_m2,
                              earth_radius_m,
                              altitude_m);

    gnc::core::NodeRegistry registry;
    auto navigation = std::make_unique<StubNavigation>();
    auto* navigation_ptr = navigation.get();
    registry.add<StubNavigation, gnc::vehicle::process::INavigation3Dof>(
        "vehicle.navigation",
        std::move(navigation));
    registry.add<ExponentialAtmosphere, gnc::environment::IAtmosphere>(
        "env.atmosphere",
        std::make_unique<ExponentialAtmosphere>(
            sea_level_density, scale_height_m, speed_of_sound_mps));
    registry.add<ConstantGravity, gnc::environment::IGravity>(
        "env.gravity",
        std::make_unique<ConstantGravity>(gravity_mps2));
    registry.add<ConstantMass, gnc::vehicle::output::IConstantMass>(
        "vehicle.mass",
        std::make_unique<ConstantMass>(mass_kg));
    registry.add<ParabolicAero, gnc::vehicle::output::IAeroModel>(
        "vehicle.aero",
        std::make_unique<ParabolicAero>(0.0,
                                        lift_slope_per_rad,
                                        zero_lift_drag,
                                        induced_drag_factor,
                                        reference_area_m2,
                                        zero_lift_drag_slope_per_mach));

    auto config = validGuidanceConfig();
    using namespace test_support;
    config.set("gamma_command_model", string("eq17_mach_derivative"));
    navigation_ptr->setState(
        altitude_m, speed_mps, gamma_star, mach_number);

    cavh::components::GlideRangeGuidance guidance;
    guidance.configure(config, "vehicles[0].process[4].config");
    const auto graph =
        gnc::core::AssemblyGraph::inferFromNodeNames(registry.getNodeNames());
    gnc::core::AssemblyContext scoped(
        graph, graph.scopeForNode("vehicle.navigation").key, registry,
        "vehicle.guidance");
    guidance.bind(scoped);
    guidance.update({0.0, 0.1, 0});

    test_support::requireNear(observableValue(guidance, "alpha_star_rad"),
                              alpha_star_rad,
                              1.0e-8,
                              "Eq. (17) guidance should maximize Mach-dependent L/D.");
    test_support::requireNear(observableValue(guidance, "gamma_command_rad"),
                              gamma_star,
                              1.0e-6,
                              "Guidance should compute the Eq. (17) path-angle command.");
    test_support::requireNear(guidance.guidanceCommand3Dof().angle_of_attack_rad,
                              alpha_star_rad,
                              1.0e-6,
                              "No feedback correction should be added when gamma equals gamma star.");
}

void requireBankedGuidanceUsesVerticalLiftProjection() {
    constexpr double sea_level_density = 1.225;
    constexpr double scale_height_m = 7200.0;
    constexpr double speed_of_sound_mps = 300.0;
    constexpr double altitude_m = 30000.0;
    constexpr double speed_mps = 3000.0;
    constexpr double mach_number = speed_mps / speed_of_sound_mps;
    constexpr double gravity_mps2 = 9.81;
    constexpr double mass_kg = 50000.0;
    constexpr double reference_area_m2 = 100.0;
    constexpr double earth_radius_m = 6371000.0;
    constexpr double lift_coefficient_star = 0.5;
    constexpr double drag_coefficient_star = 0.04;
    constexpr double bank_angle_deg = 60.0;
    constexpr double vertical_lift_scale = 0.5;

    const double density =
        sea_level_density * std::exp(-altitude_m / scale_height_m);
    const double density_gradient = -density / scale_height_m;
    const double gamma_star =
        paperEq18GammaCommand(lift_coefficient_star * vertical_lift_scale,
                              drag_coefficient_star,
                              density,
                              density_gradient,
                              speed_mps,
                              gravity_mps2,
                              mass_kg,
                              reference_area_m2,
                              earth_radius_m,
                              altitude_m);

    gnc::core::NodeRegistry registry;
    auto navigation = std::make_unique<StubNavigation>();
    auto* navigation_ptr = navigation.get();
    registry.add<StubNavigation, gnc::vehicle::process::INavigation3Dof>(
        "vehicle.navigation",
        std::move(navigation));
    registry.add<ExponentialAtmosphere, gnc::environment::IAtmosphere>(
        "env.atmosphere",
        std::make_unique<ExponentialAtmosphere>(
            sea_level_density, scale_height_m, speed_of_sound_mps));
    registry.add<ConstantGravity, gnc::environment::IGravity>(
        "env.gravity",
        std::make_unique<ConstantGravity>(gravity_mps2));
    registry.add<ConstantMass, gnc::vehicle::output::IConstantMass>(
        "vehicle.mass",
        std::make_unique<ConstantMass>(mass_kg));
    registry.add<ParabolicAero, gnc::vehicle::output::IAeroModel>(
        "vehicle.aero",
        std::make_unique<ParabolicAero>(
            0.0, 2.0, 0.02, 0.08, reference_area_m2));

    auto config = validGuidanceConfig();
    using namespace test_support;
    config.set("bank_angle_deg", number(bank_angle_deg));
    config.set("tdct_gain", number(0.0));
    navigation_ptr->setState(altitude_m, speed_mps, gamma_star, mach_number);

    cavh::components::GlideRangeGuidance guidance;
    guidance.configure(config, "vehicles[0].process[4].config");
    const auto graph =
        gnc::core::AssemblyGraph::inferFromNodeNames(registry.getNodeNames());
    gnc::core::AssemblyContext scoped(
        graph, graph.scopeForNode("vehicle.navigation").key, registry,
        "vehicle.guidance");
    guidance.bind(scoped);
    guidance.update({0.0, 0.1, 0});

    test_support::requireNear(observableValue(guidance, "vertical_lift_scale"),
                              vertical_lift_scale,
                              1.0e-12,
                              "Guidance should expose the bank projection applied to vertical lift.");
    test_support::requireNear(observableValue(guidance, "gamma_command_rad"),
                              gamma_star,
                              2.0e-8,
                              "Banked guidance should compute gamma star from the vertical lift projection.");
}

void requirePaperAeroModelUsesDigitizedCurves() {
    cavh::components::PaperAeroAssets3Dof assets;
    assets.configure(test_support::object({}), "vehicles[0].common[0].config");
    assets.initialize();

    gnc::vehicle::common::AeroQuery3Dof query;
    query.mach_number = 10.0;
    query.angle_of_attack_rad = gnc::math::deg2rad(4.0);
    const auto coefficients = assets.sampleAeroCoefficients3Dof(query);

    constexpr double cl0 = -0.0100;
    constexpr double cl_alpha_per_deg = 0.0142;
    constexpr double cd0 = 0.0080;
    constexpr double induced_drag_factor = 3.35;
    constexpr double expected_cl = cl0 + cl_alpha_per_deg * 4.0;
    constexpr double expected_cd =
        cd0 + induced_drag_factor * expected_cl * expected_cl;

    test_support::requireNear(coefficients.lift_coefficient,
                              expected_cl,
                              1.0e-12,
                              "Paper aero model should use the digitized CL0 and CL_alpha curves.");
    test_support::requireNear(coefficients.drag_coefficient,
                              expected_cd,
                              1.0e-12,
                              "Paper aero model should use CD0 + K * CL^2.");
    test_support::requireNear(observableValue(assets, "angle_of_attack_deg"),
                              4.0,
                              1.0e-12,
                              "Paper aero diagnostics should report attack angle in degrees.");
}

void requireAlphaSampleValidation() {
    using namespace test_support;
    auto config = validGuidanceConfig();
    config.set("alpha_samples", number(1.0));

    cavh::components::GlideRangeGuidance guidance;
    bool failed = false;
    std::string message;
    try {
        guidance.configure(config, "vehicles[0].process[4].config");
    } catch (const std::exception& ex) {
        failed = true;
        message = ex.what();
    }

    test_support::require(failed, "alpha_samples below 2 should fail.");
    test_support::require(message.find("alpha_samples") != std::string::npos,
                          "alpha_samples diagnostic should name the field.");
}

} // namespace

int main() {
    try {
        requireAlphaSampleValidation();
        requirePaperLawCommand();
        requireMachDerivativePaperLawCommand();
        requireBankedGuidanceUsesVerticalLiftProjection();
        requirePaperAeroModelUsesDigitizedCurves();

        std::cout << "CAVH glide range guidance checks passed\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << ex.what() << '\n';
        return 1;
    }
}
