#include "auto_registered_nodes.hpp"
#include "auto_registered_simflow_materializers.hpp"
#include "gnc/bootstrap/register_framework_builtins.hpp"
#include "gnc/core/framework_catalog.hpp"
#include "linked_extensions.hpp"

void registerFrameworkBuiltins(gnc::core::FrameworkCatalog& catalog) {
    gnc::bootstrap::registerFrameworkBuiltins(catalog);
}

void registerLinkedExtensions(gnc::core::FrameworkCatalog& catalog) {
    gnc::build::registerAutoLinkedExtensions(catalog);
}

void registerActiveProject(gnc::core::FrameworkCatalog& catalog) {
    gnc::build::registerAutoRegisteredProjectNodes(catalog.nodes());
    gnc::build::registerAutoRegisteredSimFlowMaterializers(
        catalog.simflowMaterializers());
}
