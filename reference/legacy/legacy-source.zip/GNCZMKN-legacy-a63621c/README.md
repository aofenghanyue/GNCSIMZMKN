# GNCZMKN

GNCZMKN 是一个面向制导、导航与控制研究的轻量 C++ 仿真框架。它适合在实验室中反复搭建原型：研究人员用 mission JSON 写明一次实验采用哪些对象、模型和参数，再用 C++ 节点实现具体算法。框架负责装配这些节点，并给生命周期、执行顺序和结果记录提供统一规则。

适合使用它的场景：

- 验证固定步长 GNC 算法、飞行动力学，以及传感器、制导和控制链路的原型。
- 把论文或项目专用模型接入现有仿真，同时保留便于测试和替换的接口。
- 用 mission JSON 保存场景装配，减少 runner 中难以追溯的硬编码。

当前 mission 的物理实体统一写在顶层 `vehicles[]` 中，单飞行器任务也使用只含一个元素的数组。旧式 `entities[]`、根级 `components/services` 和根级 `form/vehicle/interaction` 已退出当前运行时契约。

框架可以检查装配关系，并固定生命周期、时序和记录语义。模型是否具有足够的数值精度和物理可信度，仍要由项目侧给出证据。仓库中的 `ideal` baseline 主要用于学习架构接线；`zero` 和部分 `standard` 组件保留了简化或占位物理。准备研究性能时，请先阅读 [研究级 GNC 仿真方法](doc/08-research-simulation-methodology.md)。

## 一次实验如何穿过框架

一次仿真有两个主要输入。mission 说明本次实验要创建哪些实例、怎样配置和连接它们；C++ 代码提供这些实例所使用的模型与算法。框架在运行前核对两者，随后按照固定时序推进仿真并写出结果。

```mermaid
flowchart LR
    Mission["mission JSON<br/>对象、配置、连接"] --> Build["构建与校验<br/>创建、绑定、准备"]
    Code["framework + active project<br/>节点类型与算法"] --> Catalog["FrameworkCatalog"]
    Catalog --> Build
    Build --> Loop["固定步长循环<br/>发布、离散更新、积分"]
    Loop --> Result["CSV + summary.txt"]
```

mission 中的 `type` 选择一种已注册的 C++ 类型，`name` 给本次实验中的实例命名，节点所在的 placement 则说明它属于环境、某个飞行器或整个任务。构建阶段会检查节点能否放在该位置、所需接口是否存在，以及调度配置是否有效。检查通过以后，Simulator 才开始推进物理时间。

## 核心心智模型

| 概念 | 放什么 | 不放什么 |
| --- | --- | --- |
| `Form` | 飞行器或目标的运动连续状态、导数方程、truth view、form input | 导航估计、制导控制策略 |
| `Environment` | 地球、大气、重力等只读世界查询 | 飞行器状态、任务模式 |
| `Vehicle` | `common/input/process/output` 飞行器侧能力 | form-specific 闭合方程 |
| `Interaction` | 把 truth、环境、process 命令和 output 能力闭合成 form input | 气动表、质量定义、推进资产 |
| `Coupling` | 显式 `IContinuousGroup`，声明联合积分边界 | GNC 流程、成员资产所有权 |
| `Infrastructure` | 坐标树等可选的稳定辅助能力 | 任务流程、方程闭合 |

表中的几个名字需要结合上下文理解。`vehicles[].output[]` 保存质量、气动、推进和执行机构等飞行器能力，顶层 `outputs` 配置 CSV 与调试记录。`vehicles[].input[]` 表示传感器和测量链路，Form input 则是 Interaction 交给运动方程的加速度、力或力矩等输入。

mission 能够创建的对象都继承 `SimulationNode`，并经历 `configure -> bind -> prepare -> initialize -> finalize` 生命周期。节点再按自己的运行方式实现发布、离散更新、连续状态或停止判定等能力接口。静态资产和可选基础设施没有离散行为，因此无需为了进入框架而提供空的 `update()`。

`FrameworkCatalog` 汇集当前可执行程序可用的节点类型、积分器和 SimFlow 物化器。runner 依次注册框架内建能力、构建时链接的扩展和当前 active project。核心构建器只读取 catalog，因此无需包含某个项目节点的具体类名。坐标树等可选扩展即使没有链接或配置，也不会妨碍普通 mission 运行。

`AssemblyGraph` 记录 mission、environment 和 vehicle scope，以及每个节点的归属。`PlacementPolicy` 规定各个 mission 位置允许使用什么 scope、role、phase 和必需 capability。依赖名称没有点号时，只在当前 scope 中补全前缀；跨 scope 连接要写完整名。

固定步长循环采用周期开始发布态：

```text
publish/refresh t_k -> before_step(t_k) -> discrete update(t_k)
-> record t_k -> stop check t_k
-> synchronized independent integration to t_{k+1}
-> next cycle
```

CSV 的 `time` 列表示该行发布态的物理时间。Form、dynamics 和 truth view 字段来自周期开始时的 `x_k` 及其派生量。记录器会在全部离散 phase 完成后读取其它字段：本步到期的节点给出基于 `x_k` 计算的新输出，未到期的慢速节点继续保持上次结果，静态或连续 Output 给出当前可查询的值。

在默认配置下，第一行包含初始状态 `x_0`、首周期离散输出和静态能力。停止条件命中的发布态会先写入 CSV，再结束仿真。关闭 `record_initial_state` 后，如果任务在 `t_0` 就满足停止条件，`t_0` 行会按配置省略。

同一行的命令 `u_k` 随后用于 `t_k -> t_{k+1}` 的积分，因此命令造成的状态响应要到下一行查看。truth 中的加速度等派生量在 publish 阶段形成；如果它依赖保持命令，时间归属还要结合该节点的契约判断。完整说明见 [核心概念](doc/02-core-concepts.md)。

## 快速开始

第一次使用可以依次完成四件事：构建并测试，运行仓库示例，查看 CSV 和摘要，最后回到 mission 找到产生这些字段的节点。完整操作与结果解释见 [快速上手](doc/01-getting-started.md)。

```powershell
cmake -S . -B build-mingw -G "MinGW Makefiles" -DBUILD_TESTS=ON
cmake --build build-mingw -j 4
ctest --test-dir build-mingw --output-on-failure
```

默认 `BUILD_TESTS=ON` 只注册 core 测试，覆盖 mission 装配、配置校验、调度时间语义、日志、SimFlow 复现和关键 builtin 元数据。其它测试按需打开：

```powershell
# 示例和 baseline mission 集成测试
cmake -S . -B build-mingw -G "MinGW Makefiles" -DBUILD_TESTS=ON -DGNC_BUILD_EXAMPLE_TESTS=ON

# user/example_08 CAVH 项目组件测试
cmake -S . -B build-mingw -G "MinGW Makefiles" -DBUILD_TESTS=ON -DGNC_BUILD_PROJECT_TESTS=ON

# 源码扫描类迁移护栏
cmake -S . -B build-mingw -G "MinGW Makefiles" -DBUILD_TESTS=ON -DGNC_BUILD_ARCHITECTURE_GUARDS=ON
```

也可以按标签运行：

```powershell
ctest --test-dir build-mingw -L core --output-on-failure
ctest --test-dir build-mingw -L example --output-on-failure
ctest --test-dir build-mingw -L project --output-on-failure
```

运行当前 active project：

```powershell
build-mingw\bin\gnc_sim.exe
```

显式运行示例：

```powershell
build-mingw\bin\gnc_sim.exe --config user/example_05_ideal_3dof_geographic_baseline/config/mission.json
```

该示例把输出写入 `user/outputs/example_05_ideal_3dof_geographic_baseline/`。运行后至少应看到 `ideal_3dof_geographic_baseline.csv` 和 `summary.txt`。CSV 的 `interceptor.dynamics.*` 来自 Form 发布态，其余字段在本周期离散 phases 完成后读取；该 baseline 的离散节点每步到期，静态质量等节点直接暴露当前能力值。

查看已注册组件：

```powershell
build-mingw\bin\gnc_sim.exe --list-components-verbose
```

## 最小 mission 示例

下面是可运行的最小 Cartesian 3DoF mission 形状；完整示例见 `user/example_06_ideal_cartesian_3dof_baseline/config/mission.json`。

```json
{
  "simulation": {
    "dt": 0.1,
    "duration": 10.0,
    "integrator": "rk4"
  },
  "environment": {},
  "vehicles": [
    {
      "id": "vehicle",
      "form": {
        "components": [
          {
            "type": "form.cartesian_3dof.point_mass",
            "name": "dynamics",
            "config": {
              "initial_position": [0.0, 0.0, 1000.0],
              "initial_velocity": [250.0, 0.0, 40.0]
            }
          }
        ]
      },
      "common": [
        { "type": "vehicle.common.aero_assets_3dof.zero", "name": "aero_assets", "config": {} }
      ],
      "input": [],
      "process": [],
      "output": [
        { "type": "vehicle.output.mass_3dof.constant", "name": "mass", "config": { "mass_kg": 100.0 } },
        { "type": "vehicle.output.propulsion_3dof.zero", "name": "propulsion", "config": {} },
        { "type": "vehicle.output.actuator_3dof.ideal", "name": "actuator", "config": {} },
        { "type": "vehicle.output.aerodynamics_3dof.zero", "name": "aero", "config": {} }
      ],
      "interaction": {
        "components": [
          {
            "type": "interaction.cartesian_3dof.standard",
            "name": "interaction",
            "config": {
              "acceleration_mps2": [0.0, 0.0, -9.81]
            }
          }
        ]
      },
      "continuous_groups": []
    }
  ],
  "outputs": {
    "directory": "user/outputs/{timestamp}",
    "format": "csv",
    "session_name": "minimal_cartesian_3dof",
    "record": {
      "vehicle.dynamics": "all"
    }
  },
  "termination": {
    "type": "termination.component_field_below",
    "name": "termination",
    "config": {
      "component": "vehicle.dynamics",
      "field": "altitude",
      "value": 0.0
    }
  }
}
```

`simulation.dt` 和 `simulation.duration` 必须显式配置；`integrator` 可省略，默认 `rk4`。物理参数如初始状态、质量、气动表和控制表不会静默使用默认值。

这份 mission 主要用于检查接线。`zero` 气动和推进不会产生物理作用，`standard` Interaction 直接采用配置中的加速度。它可以演示 Form 推进、结果记录和停止条件。加入制导以后，如果还要研究轨迹怎样响应命令，就需要让 Output 与 Interaction 把命令转换成真实的 Form input。

实现 `IDiscreteTask` 的节点条目可以增加可选 `priority` 和 `rate_hz`；框架先应用固定离散 phase / publish phase，再在同一组内按 priority 排序。`rate_hz` 必须严格整除仿真频率。静态节点和纯连续节点不能配置 `rate_hz`。

需要 RK 子步共享候选状态的模型，将 project `IContinuousGroup` 节点放入顶层或 vehicle 的 `continuous_groups[]`。普通 mission 可以省略该 placement，继续使用同步独立积分。

## 仓库目录

| 路径 | 用途 |
| --- | --- |
| `framework/include/gnc/core/` | 运行时外壳、装配、配置、验证、调度 |
| `framework/include/gnc/forms/` | 内置 form 和 form 专属接口 |
| `framework/include/gnc/environment/` | 环境组件和查询接口 |
| `framework/include/gnc/vehicle/` | vehicle common/input/process/output 包 |
| `framework/include/gnc/interactions/` | form-aware interaction 包 |
| `framework/include/gnc/extensions/` | 可选基础设施和其它链接扩展 |
| `framework/data/` | 仿真资产 |
| `user/` | active project、示例 mission、项目组件和输出 |
| `tests/` | 架构契约、组件、mission、日志和时间语义测试 |
| `doc/` | 用户和维护文档 |

## 文档入口

- 选择学习路线：先读 [文档导航](doc/README.md)。
- 第一次运行：读 [快速上手](doc/01-getting-started.md) 和 [核心概念](doc/02-core-concepts.md)。
- 开展研究：读 [研究级 GNC 仿真方法](doc/08-research-simulation-methodology.md)、[扩展指南](doc/04-extension-guide.md) 和 [SimFlow 教程](doc/simflow-guide.md)。
- 理解架构全貌：按 [核心概念](doc/02-core-concepts.md)、[当前架构总览](doc/00-current-architecture.md)、[维护者架构说明](doc/05-architecture.md) 的顺序读。
- 写 mission：读 [核心概念](doc/02-core-concepts.md)、[Mission 配置](doc/03-mission-configuration.md) 和 [参考手册](doc/06-reference.md)。
- 写项目组件：读 [扩展指南](doc/04-extension-guide.md) 和 [User Workspace](user/README.md)。
- 维护框架：读 [当前架构总览](doc/00-current-architecture.md)、[维护者架构说明](doc/05-architecture.md) 和 [设计决策](doc/07-decisions.md)。
