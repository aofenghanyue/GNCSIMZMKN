timestr = 'time_2026-06-21_131828';
path=['C:\Users\17721\Documents\workwork\GNCZMKN\user\outputs\example_08_cavh_geographic_3dof_custom\',timestr,'\cavh_geographic_3dof_custom.csv'];
gnc_import_csv_to_sdi(path)